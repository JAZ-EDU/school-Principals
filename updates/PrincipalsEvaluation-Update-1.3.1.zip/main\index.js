"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
const electron = require("electron");
const node_path = require("node:path");
const node_fs = require("node:fs");
const Database = require("better-sqlite3");
const node_crypto = require("node:crypto");
const node_os = require("node:os");
const archiver = require("archiver");
const AdmZip = require("adm-zip");
const ExcelJS = require("exceljs");
const decimal_js = require("decimal.js");
let logDir = null;
function setupLogger() {
  logDir = node_path.join(electron.app.getPath("userData"), "logs");
  try {
    node_fs.mkdirSync(logDir, { recursive: true });
  } catch {
  }
}
function write(level, message, meta) {
  const entry = {
    ts: (/* @__PURE__ */ new Date()).toISOString(),
    level,
    message: message instanceof Error ? message.message : String(message),
    stack: message instanceof Error ? message.stack : void 0,
    meta
  };
  try {
    const file = node_path.join(logDir, `app-${entry.ts.slice(0, 10)}.log`);
    node_fs.appendFileSync(file, JSON.stringify(entry) + "\n", "utf8");
  } catch {
  }
  const out = level === "error" ? console.error : console.log;
  out(`[${level}]`, message, meta || "");
}
const logger = {
  info: (m, meta) => write("info", m, meta),
  warn: (m, meta) => write("warn", m, meta),
  error: (m, meta) => write("error", m, meta)
};
let db = null;
function getDb() {
  if (db) return db;
  const dataDir = node_path.join(electron.app.getPath("userData"), "data");
  node_fs.mkdirSync(dataDir, { recursive: true });
  db = new Database(node_path.join(dataDir, "app.db"));
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  return db;
}
function closeDb() {
  if (db) {
    try {
      db.close();
    } catch {
    }
    db = null;
  }
}
const name$d = "initial";
const version$d = 1;
const up$d = `
CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS education_administrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  is_archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS school_stages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS schools (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  administration_id INTEGER REFERENCES education_administrations(id),
  stage_id INTEGER REFERENCES school_stages(id),
  is_archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS managers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  school_id INTEGER REFERENCES schools(id),
  employee_number TEXT,
  national_id TEXT,
  notes TEXT,
  is_sample INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_managers_employee_unique
  ON managers(employee_number)
  WHERE employee_number IS NOT NULL AND employee_number <> '';

CREATE TABLE IF NOT EXISTS academic_years (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  label TEXT NOT NULL UNIQUE,
  is_active INTEGER NOT NULL DEFAULT 0,
  is_archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS evaluation_periods (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  academic_year_id INTEGER NOT NULL REFERENCES academic_years(id),
  name TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (academic_year_id, name)
);

CREATE TABLE IF NOT EXISTS evaluation_forms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  is_official INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS form_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  form_id INTEGER NOT NULL REFERENCES evaluation_forms(id),
  version_number TEXT NOT NULL,
  source_reference TEXT,
  rounding_places INTEGER NOT NULL DEFAULT 2,
  rounding_mode TEXT NOT NULL DEFAULT 'HALF_UP',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived')),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (form_id, version_number)
);

CREATE TABLE IF NOT EXISTS performance_levels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  form_version_id INTEGER NOT NULL REFERENCES form_versions(id),
  score_value INTEGER NOT NULL CHECK (score_value BETWEEN 1 AND 5),
  label TEXT NOT NULL,
  description TEXT,
  UNIQUE (form_version_id, score_value)
);

CREATE TABLE IF NOT EXISTS form_version_elements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  form_version_id INTEGER NOT NULL REFERENCES form_versions(id),
  element_number INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  weight_bp INTEGER NOT NULL CHECK (weight_bp >= 0),
  sort_order INTEGER NOT NULL DEFAULT 0,
  UNIQUE (form_version_id, element_number)
);

CREATE TABLE IF NOT EXISTS evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  manager_id INTEGER NOT NULL REFERENCES managers(id),
  academic_year_id INTEGER NOT NULL REFERENCES academic_years(id),
  period_id INTEGER NOT NULL REFERENCES evaluation_periods(id),
  form_version_id INTEGER NOT NULL REFERENCES form_versions(id),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','completed','approved','superseded')),
  final_score TEXT,
  previous_evaluation_id INTEGER REFERENCES evaluations(id),
  correction_reason TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  approved_at TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_evaluations_active_unique
  ON evaluations(manager_id, academic_year_id, period_id, form_version_id)
  WHERE status IN ('draft','completed','approved');

CREATE TABLE IF NOT EXISTS evaluation_item_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  evaluation_id INTEGER NOT NULL REFERENCES evaluations(id),
  source_element_id INTEGER,
  element_number INTEGER NOT NULL,
  name TEXT NOT NULL,
  weight_bp INTEGER NOT NULL,
  score_value INTEGER CHECK (score_value BETWEEN 1 AND 5),
  level_label TEXT,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS evidences (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  manager_id INTEGER NOT NULL REFERENCES managers(id),
  evaluation_id INTEGER REFERENCES evaluations(id),
  element_number INTEGER,
  title TEXT NOT NULL,
  description TEXT,
  file_path TEXT,
  file_name TEXT,
  file_size INTEGER,
  mime_type TEXT,
  sha256 TEXT,
  is_archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS improvement_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  manager_id INTEGER NOT NULL REFERENCES managers(id),
  evaluation_id INTEGER REFERENCES evaluations(id),
  element_number INTEGER,
  goal TEXT NOT NULL,
  actions TEXT,
  starts_on TEXT,
  ends_on TEXT,
  status TEXT NOT NULL DEFAULT 'not_started'
    CHECK (status IN ('not_started','in_progress','completed','overdue')),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id INTEGER,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_managers_status ON managers(status);
CREATE INDEX IF NOT EXISTS idx_managers_school ON managers(school_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_manager ON evaluations(manager_id);
CREATE INDEX IF NOT EXISTS idx_evaluations_period ON evaluations(academic_year_id, period_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
`;
const m001 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$d,
  up: up$d,
  version: version$d
}, Symbol.toStringTag, { value: "Module" }));
const name$c = "batch2";
const version$c = 2;
const up$c = `
ALTER TABLE school_stages ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;
ALTER TABLE form_versions ADD COLUMN activated_at TEXT;
CREATE INDEX IF NOT EXISTS idx_form_elements_version ON form_version_elements(form_version_id);
CREATE INDEX IF NOT EXISTS idx_levels_version ON performance_levels(form_version_id);
CREATE INDEX IF NOT EXISTS idx_periods_year ON evaluation_periods(academic_year_id);
`;
const m002 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$c,
  up: up$c,
  version: version$c
}, Symbol.toStringTag, { value: "Module" }));
const name$b = "batch4";
const version$b = 3;
const up$b = `
ALTER TABLE evidences ADD COLUMN updated_at TEXT;
UPDATE evidences SET updated_at = created_at WHERE updated_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_evidences_manager ON evidences(manager_id);
CREATE INDEX IF NOT EXISTS idx_evidences_evaluation ON evidences(evaluation_id);
CREATE INDEX IF NOT EXISTS idx_evidences_element ON evidences(manager_id, element_number);
`;
const m003 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$b,
  up: up$b,
  version: version$b
}, Symbol.toStringTag, { value: "Module" }));
const name$a = "batch5";
const version$a = 4;
const up$a = `
ALTER TABLE improvement_plans ADD COLUMN is_archived INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_plans_manager ON improvement_plans(manager_id);
CREATE INDEX IF NOT EXISTS idx_plans_evaluation ON improvement_plans(evaluation_id);
CREATE INDEX IF NOT EXISTS idx_plans_status ON improvement_plans(status);
CREATE INDEX IF NOT EXISTS idx_plans_archived ON improvement_plans(is_archived);

CREATE TABLE IF NOT EXISTS plan_follow_ups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plan_id INTEGER NOT NULL REFERENCES improvement_plans(id) ON DELETE CASCADE,
  note TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_follow_ups_plan ON plan_follow_ups(plan_id);
`;
const m004 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$a,
  up: up$a,
  version: version$a
}, Symbol.toStringTag, { value: "Module" }));
const name$9 = "batch6";
const version$9 = 5;
const up$9 = `
INSERT OR IGNORE INTO app_settings (key, value) VALUES ('org_name', '');
INSERT OR IGNORE INTO app_settings (key, value) VALUES ('org_subtitle', '');
`;
const m005 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$9,
  up: up$9,
  version: version$9
}, Symbol.toStringTag, { value: "Module" }));
const name$8 = "batch7";
const version$8 = 6;
const up$8 = `
INSERT OR IGNORE INTO app_settings (key, value) VALUES ('last_manual_backup_at', '');
INSERT OR IGNORE INTO app_settings (key, value) VALUES ('last_manual_backup_path', '');
INSERT OR IGNORE INTO app_settings (key, value) VALUES ('backup_dir_override', '');
`;
const m006 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$8,
  up: up$8,
  version: version$8
}, Symbol.toStringTag, { value: "Module" }));
const name$7 = "official_form_elements";
const version$7 = 7;
const up$7 = `
ALTER TABLE evaluations ADD COLUMN general_rating TEXT;
`;
const m007 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$7,
  up: up$7,
  version: version$7
}, Symbol.toStringTag, { value: "Module" }));
const name$6 = "period_type_and_rename";
const version$6 = 8;
const up$6 = `
  ALTER TABLE evaluation_periods ADD COLUMN period_type TEXT NOT NULL DEFAULT 'OTHER';

  -- تحديث المسميات القديمة والأنواع
  UPDATE evaluation_periods
  SET name = 'التقييم النصف سنوي',
      period_type = 'MIDYEAR'
  WHERE name LIKE '%أول%' OR name LIKE '%الأول%' OR name LIKE '%نصف%';

  UPDATE evaluation_periods
  SET name = 'التقييم النهائي',
      period_type = 'FINAL'
  WHERE name LIKE '%ثاني%' OR name LIKE '%الثاني%' OR name LIKE '%نهائي%';
`;
const m008 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$6,
  up: up$6,
  version: version$6
}, Symbol.toStringTag, { value: "Module" }));
const name$5 = "auth_and_settings";
const version$5 = 9;
const up$5 = `
  CREATE TABLE IF NOT EXISTS app_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'custom',
    permissions_json TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sync_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id INTEGER,
    payload TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    last_attempt TEXT
  );
`;
const m009 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$5,
  up: up$5,
  version: version$5
}, Symbol.toStringTag, { value: "Module" }));
const name$4 = "notifications";
const version$4 = 10;
const up$4 = `
  CREATE TABLE IF NOT EXISTS app_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'info',
    reference_id TEXT,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
  );
`;
const m010 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$4,
  up: up$4,
  version: version$4
}, Symbol.toStringTag, { value: "Module" }));
const name$3 = "manager_experience_and_multiple_schools";
const version$3 = 11;
const up$3 = `
  ALTER TABLE managers ADD COLUMN education_experience_years INTEGER DEFAULT 0;
  ALTER TABLE managers ADD COLUMN administration_experience_years INTEGER DEFAULT 0;
  ALTER TABLE managers ADD COLUMN has_multiple_schools INTEGER DEFAULT 0;
`;
const m011 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$3,
  up: up$3,
  version: version$3
}, Symbol.toStringTag, { value: "Module" }));
const name$2 = "notifications_portal_id_and_manager";
const version$2 = 12;
const up$2 = `
  ALTER TABLE app_notifications ADD COLUMN manager_id INTEGER;
  ALTER TABLE app_notifications ADD COLUMN portal_id TEXT;
  CREATE UNIQUE INDEX IF NOT EXISTS idx_notifications_portal_unique ON app_notifications(portal_id, type) WHERE portal_id IS NOT NULL;
`;
const m012 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$2,
  up: up$2,
  version: version$2
}, Symbol.toStringTag, { value: "Module" }));
const name$1 = "multi_attachments_evidences_and_plans";
const version$1 = 13;
const up$1 = `
  ALTER TABLE evidences ADD COLUMN attachments_json TEXT;
  ALTER TABLE improvement_plans ADD COLUMN attachments_json TEXT;
`;
function upFn$1(db2) {
  try {
    db2.exec("ALTER TABLE evidences ADD COLUMN attachments_json TEXT;");
  } catch {
  }
  try {
    db2.exec("ALTER TABLE improvement_plans ADD COLUMN attachments_json TEXT;");
  } catch {
  }
}
const m013 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name: name$1,
  up: up$1,
  upFn: upFn$1,
  version: version$1
}, Symbol.toStringTag, { value: "Module" }));
const version = 14;
const name = "014_context_comments_alerts";
function addColumnSafe(db2, sql) {
  try {
    db2.exec(sql);
  } catch (e) {
    if (!String(e.message || "").includes("duplicate column name")) {
      throw e;
    }
  }
}
function upFn(db2) {
  addColumnSafe(db2, "ALTER TABLE evidences ADD COLUMN academic_year_id INTEGER REFERENCES academic_years(id);");
  addColumnSafe(db2, "ALTER TABLE evidences ADD COLUMN period_id INTEGER REFERENCES evaluation_periods(id);");
  addColumnSafe(db2, "ALTER TABLE evidences ADD COLUMN portal_id INTEGER;");
  db2.exec(`
    CREATE TABLE IF NOT EXISTS evidence_comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      evidence_id INTEGER NOT NULL REFERENCES evidences(id) ON DELETE CASCADE,
      comment TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_evidence_comments_ev ON evidence_comments(evidence_id);
  `);
  addColumnSafe(db2, "ALTER TABLE improvement_plans ADD COLUMN academic_year_id INTEGER REFERENCES academic_years(id);");
  addColumnSafe(db2, "ALTER TABLE improvement_plans ADD COLUMN period_id INTEGER REFERENCES evaluation_periods(id);");
  addColumnSafe(db2, "ALTER TABLE improvement_plans ADD COLUMN portal_id INTEGER;");
  db2.exec(`
    CREATE TABLE IF NOT EXISTS supervisor_alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      manager_id INTEGER NOT NULL REFERENCES managers(id) ON DELETE CASCADE,
      academic_year_id INTEGER REFERENCES academic_years(id),
      period_id INTEGER REFERENCES evaluation_periods(id),
      title TEXT,
      message TEXT NOT NULL,
      portal_id INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
    CREATE INDEX IF NOT EXISTS idx_supervisor_alerts_mgr ON supervisor_alerts(manager_id);
  `);
  const years = db2.prepare("SELECT id, label FROM academic_years ORDER BY id ASC").all();
  for (const yr of years) {
    const m = String(yr.label || "").trim().match(/^(\d{4})\s*\/\s*(\d{4})$/);
    if (m) {
      const candidateA = m[1];
      const candidateB = m[2];
      const existsA = db2.prepare("SELECT id FROM academic_years WHERE label = ? AND id <> ?").get(candidateA, yr.id);
      const existsB = db2.prepare("SELECT id FROM academic_years WHERE label = ? AND id <> ?").get(candidateB, yr.id);
      const targetLabel = !existsB ? candidateB : !existsA ? candidateA : null;
      if (targetLabel) {
        db2.prepare("UPDATE academic_years SET label = ? WHERE id = ?").run(targetLabel, yr.id);
      }
    }
  }
  const allYears = db2.prepare("SELECT id FROM academic_years").all();
  const insPeriod = db2.prepare(
    "INSERT INTO evaluation_periods (academic_year_id, name, period_type, is_active) VALUES (?, ?, ?, 1)"
  );
  for (const yr of allYears) {
    const cnt = db2.prepare("SELECT COUNT(*) AS c FROM evaluation_periods WHERE academic_year_id = ?").get(yr.id).c;
    if (cnt === 0) {
      insPeriod.run(yr.id, "التقييم النصف سنوي", "MIDYEAR");
      insPeriod.run(yr.id, "التقييم النهائي", "FINAL");
    }
  }
  let activeYear = db2.prepare("SELECT id FROM academic_years WHERE is_active = 1 ORDER BY id DESC LIMIT 1").get();
  if (!activeYear) {
    activeYear = db2.prepare("SELECT id FROM academic_years ORDER BY id DESC LIMIT 1").get();
  }
  let defaultPeriod = null;
  if (activeYear) {
    defaultPeriod = db2.prepare(`
      SELECT id FROM evaluation_periods
      WHERE academic_year_id = ? AND is_active = 1
      ORDER BY CASE WHEN period_type = 'MIDYEAR' THEN 0 ELSE 1 END, id ASC
      LIMIT 1
    `).get(activeYear.id) || db2.prepare(`
      SELECT id FROM evaluation_periods WHERE academic_year_id = ? ORDER BY id ASC LIMIT 1
    `).get(activeYear.id);
  }
  db2.exec(`
    UPDATE evidences
    SET academic_year_id = (SELECT academic_year_id FROM evaluations WHERE evaluations.id = evidences.evaluation_id),
        period_id = (SELECT period_id FROM evaluations WHERE evaluations.id = evidences.evaluation_id)
    WHERE evaluation_id IS NOT NULL AND (academic_year_id IS NULL OR period_id IS NULL);
  `);
  db2.exec(`
    UPDATE improvement_plans
    SET academic_year_id = (SELECT academic_year_id FROM evaluations WHERE evaluations.id = improvement_plans.evaluation_id),
        period_id = (SELECT period_id FROM evaluations WHERE evaluations.id = improvement_plans.evaluation_id)
    WHERE evaluation_id IS NOT NULL AND (academic_year_id IS NULL OR period_id IS NULL);
  `);
  if (activeYear) {
    db2.prepare("UPDATE evidences SET academic_year_id = ? WHERE academic_year_id IS NULL").run(activeYear.id);
    db2.prepare("UPDATE improvement_plans SET academic_year_id = ? WHERE academic_year_id IS NULL").run(activeYear.id);
    if (defaultPeriod) {
      db2.prepare("UPDATE evidences SET period_id = ? WHERE period_id IS NULL").run(defaultPeriod.id);
      db2.prepare("UPDATE improvement_plans SET period_id = ? WHERE period_id IS NULL").run(defaultPeriod.id);
    }
    const upsertSetting2 = db2.prepare(`
      INSERT INTO app_settings (key, value, updated_at)
      VALUES (?, ?, datetime('now', 'localtime'))
      ON CONFLICT(key) DO NOTHING
    `);
    upsertSetting2.run("active_year_id", String(activeYear.id));
    if (defaultPeriod) {
      upsertSetting2.run("active_period_id", String(defaultPeriod.id));
    }
  }
}
const up = "";
const m014 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  name,
  up,
  upFn,
  version
}, Symbol.toStringTag, { value: "Module" }));
const OFFICIAL_FORM_ELEMENTS = [
  {
    elementNumber: 1,
    name: "أداء الواجبات الوظيفية",
    weightBp: 500,
    weightPercent: 5,
    description: "الالتزام بأداء المهام والواجبات الوظيفية والأنظمة واللوائح التعليمية"
  },
  {
    elementNumber: 2,
    name: "التفاعل مع المجتمع المهني",
    weightBp: 500,
    weightPercent: 5,
    description: "المشاركة الفاعلة مع مجتمعات التعلم المهنية وتبادل الخبرات التربوية"
  },
  {
    elementNumber: 3,
    name: "التفاعل مع أولياء الأمور",
    weightBp: 500,
    weightPercent: 5,
    description: "التواصل الإيجابي والمستمر مع أولياء الأمور وتفعيل مجالس الآباء والمعلمين"
  },
  {
    elementNumber: 4,
    name: "مرن وقادر على تنفيذ أعماله في ظل ظروف العمل المختلفة",
    weightBp: 500,
    weightPercent: 5,
    description: "المرونة والقدرة على التعامل مع المتغيرات وإدارة الأزمات والمستجدات"
  },
  {
    elementNumber: 5,
    name: "يدعم ويشارك في المبادرات النوعية",
    weightBp: 500,
    weightPercent: 5,
    description: "تشجيع ورعاية المبادرات الإبداعية والمشاريع التربوية المتميزة"
  },
  {
    elementNumber: 6,
    name: "يتخذ إجراءات تربوية تحقق الانضباط المدرسي",
    weightBp: 500,
    weightPercent: 5,
    description: "تطبيق قواعد السلوك والمواظبة والإجراءات التربوية لضمان بيئة منضبطة"
  },
  {
    elementNumber: 7,
    name: "يدير الموارد في المدرسة بكفاءة",
    weightBp: 500,
    weightPercent: 5,
    description: "الاستثمار الأمثل للموارد المادية والمالية والبشرية المتاحة بالمدرسة"
  },
  {
    elementNumber: 8,
    name: "يعد خطة للتطوير المهني",
    weightBp: 500,
    weightPercent: 5,
    description: "تحديد الاحتياجات التدريبية وإعداد خطة تطوير مهني لمنسوبي المدرسة"
  },
  {
    elementNumber: 9,
    name: "يقدم التغذية الراجعة ويتابع تحقق مؤشرات الأداء الوظيفي",
    weightBp: 500,
    weightPercent: 5,
    description: "تقديم الدعم والتغذية الراجعة البناءة ومتابعة مؤشرات الأداء الوظيفي"
  },
  {
    elementNumber: 10,
    name: "يدعم تنفيذ برامج التطوير المهني",
    weightBp: 500,
    weightPercent: 5,
    description: "تيسير وتفعيل برامج وورش التدريب والتطوير المهني داخل المدرسة"
  },
  {
    elementNumber: 11,
    name: "يقيّم أداء منسوبي المدرسة",
    weightBp: 500,
    weightPercent: 5,
    description: "التقييم الدوري والموضوعي لأداء الهيئتين التعليمية والإدارية بالمدرسة"
  },
  {
    elementNumber: 12,
    name: "ينفذ إجراءات علمية لتحسين نتائج التعلم",
    weightBp: 500,
    weightPercent: 5,
    description: "تحليل نتائج التحصيل الدراسي وتطبيق استراتيجيات علاجية وإثرائية علمية"
  },
  {
    elementNumber: 13,
    name: "يسهم في تحسين مستوى أداء المدرسة",
    weightBp: 1e3,
    weightPercent: 10,
    description: "تحقيق التحسين المستمر في مؤشرات الأداء العام ونواتج التعلم والبيئة المدرسية"
  },
  {
    elementNumber: 14,
    name: "يعد الخطط المدرسية اللازمة",
    weightBp: 500,
    weightPercent: 5,
    description: "إعداد الخطة التشغيلية السنوية وخطط العمل المتنوعة وفق الأهداف المعتمدة"
  },
  {
    elementNumber: 15,
    name: "يتابع تنفيذ الخطط المدرسية بمختلف أنواعها",
    weightBp: 500,
    weightPercent: 5,
    description: "المتابعة الميدانية الدورية لنسب تنفيذ الخطط التشغيلية ومعالجة الانحرافات"
  },
  {
    elementNumber: 16,
    name: "يهيئ الفرص والإمكانات الداعمة لمشاركة الطلاب في الأنشطة الصفية وغير الصفية",
    weightBp: 500,
    weightPercent: 5,
    description: "تحفيز مشاركة الطلاب في الأنشطة الطلابية والمسابقات والفعاليات المتنوعة"
  },
  {
    elementNumber: 17,
    name: "يوظف المنصات الرقمية وتطبيقاتها المعتمدة في دعم عمليات التعليم والتعلم",
    weightBp: 500,
    weightPercent: 5,
    description: "استخدام وتفعيل المنصات التعليمية المعتمدة (مثل منصة مدرستي) في العمليات المدرسية"
  },
  {
    elementNumber: 18,
    name: "يتابع تعزيز السلوك الإيجابي للطلاب",
    weightBp: 500,
    weightPercent: 5,
    description: "تنفيذ برامج تعزيز القيم والسلوك الإيجابي وتكريم المتميزين سلوكيًا"
  },
  {
    elementNumber: 19,
    name: "يهيئ بيئة مدرسية آمنة ومحفزة على التعلم",
    weightBp: 500,
    weightPercent: 5,
    description: "تطبيق معايير الأمن والسلامة المدرسية وتوفير بيئة جاذبة ومحفزة للطلاب والمعلمين"
  }
];
const ALL_PERMISSIONS = [
  "view_only",
  "evaluate",
  "manage_managers",
  "upload_evidences",
  "upload_plans",
  "view_results",
  "view_comparisons",
  "delete_evaluation",
  "repair_evaluation",
  "manage_settings",
  "manage_users"
];
const PRESET_ROLES = {
  admin: {
    label: "مسؤول النظام (كامل الصلاحيات)",
    permissions: [...ALL_PERMISSIONS]
  },
  evaluator: {
    label: "مقيّم مدراء المدارس",
    permissions: [
      "evaluate",
      "upload_evidences",
      "upload_plans",
      "view_results",
      "view_comparisons"
    ]
  },
  monitor: {
    label: "متابع / تدقيق (عرض فقط)",
    permissions: [
      "view_only",
      "view_results",
      "view_comparisons"
    ]
  },
  custom: {
    label: "مخصص",
    permissions: []
  }
};
function hashPassword(password) {
  if (!password || typeof password !== "string") throw new Error("كلمة المرور مطلوبة");
  const salt = node_crypto.randomBytes(16).toString("hex");
  const buf = node_crypto.scryptSync(password.normalize("NFKC"), salt, 64);
  return `${salt}:${buf.toString("hex")}`;
}
function verifyPassword(password, stored) {
  if (!password || !stored || !stored.includes(":")) return false;
  const [salt, key] = stored.split(":");
  const keyBuf = Buffer.from(key, "hex");
  const derived = node_crypto.scryptSync(password.normalize("NFKC"), salt, 64);
  if (keyBuf.length !== derived.length) return false;
  return node_crypto.timingSafeEqual(keyBuf, derived);
}
const DEFAULT_ADMIN_AVATAR = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCANYA5ADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD8++PU0ceppu6jdXlH3Q/8TVzSx/pQyc1RVh64q/pa/wClIRzXJX2Fc9u+HMe14iBXvFvJt0/Oe1eF/DpT5kfHpXtuSmndO1fC4r4yTyH4kTD97zXgWtSH7U3Oa9v+I0mWl/GvCdWk3XTdq9/LY31C5Uz1pcimbh60bh619FYfMPyKfC3zjFQ5FPiYbxUyWgcx6r8OVDSRV9Q/D+Mboq+YPhuf3kX4V9RfD3/lkfpXw+L/AIplOR794ZQCFK7fT19AK4nw0wEKGu209h60qHx6nm1C1dcxnArldSBDNXU3EgEbc1y+pMCxINdlfyJgZinBra0tvWsTPIzWxpZDYrkT1BnVW7DyxU/3VzVa1xsFWGPy8ivZpP3TlluQTN8p5rB1eby427cVtXDEqcDFct4gmKwtXl4qRvHU8l8e6o48wBvWvnbxtqcjSSLu6+9e3ePJziXn1r568XTF7hs+tcuBSlM+vwcTkmB8xmPepE+an7KFGK+uhFI9+KAtTWNOamE1pYsSiijHpUdRXXUKM4pdp9KPLLdqYaDd3oaazkLUnletRzrtXjtT5jCpOysZGo3XkoTnFchdeIpI5CA2R9a6DVmMm4DmuVuNBmuNzqrVdNczPl8ZiHF6Mmj8RyO4G7H41rw3kk6DDfrXDXVjcafN+8DY9K6/w4pmhBzk46VpOm+h431qXcbqF5Ja/MSSaqWviJt4BzWzqGntIrBlyK5n+yXWdsA4FLRbmkcVJdTtLDWgUBJxWzb6kjLktXnwkaBMA4p0esuvy7/1rJxfQ6446SW56Qt2r87hViFhJmvP7XXHRhl8ium0/V0mXAk5xU8slqz1KGOTsmbrKF6U3diqn2z5fvYFNW7DNw2aD2I1oyW5fjbLV2Pg6+aOZRnv61wyzdOa6Pwvc7Lhee9edil+7ZFSSa3PpHwtcGe1AJ7etcn8S9OWSGRsZPNa/gu63Rpz2q341sftNo/G7iviE+Sqzwq2rufG3jWzEN43GOa6z4Yx/PGPQik8d6OFvGynf0ra+HOniORCF6Gvopz5qKOc+gPCCFYYzXbhS2K47wviONAK7KOTK9a+bh/HOarsySMlc1Mq7vaoV+Y+tTIw9a+2w2x5UkxfL96PL5GaduHrR5gU9c16yMyxGBipg+KqtMMDBqNrjb1biq0AuNMAPSqdzcZXg1Wmvlxw1ZlxqS7T84oewaiXVxhjk1mXNwMHBqpqOqLGc7/1rLbWEbPzfrXn1NDWMXYsyT7pOtaNjPtXk1zbXwZs5FO/toW4HP61yRepfLodpDeLuGHrZtLwbfvV5rb+Jog/LfrWrB4wt41H71fzrvp6mbiz0FbsN3zS/bNveuE/4Ta3XH7xT+NUL74hwRA4lXj3NdXNYnkZ6Wt8O5FJJfqw+8BXjEnxSTzMCUYz71dj+IStHu3j86xnI2jTZ6Jf6kkKksw4rnrjxFFG/wDrAK8v8SfE5o9+2Tj615vq3xVdZP8AWZ59a82pSnU0R0Rio7n0p/wkkaruMin8aoXPi+JGz5i/nXzRL8XnWPG/H41iXnxalkYgP+tcTy2TTL54o+sv+E0ikh271yfeuI8Z6gb61kAY4INeH6R8UJXfBk/U10r+NluIOXB475rnpZbKk7nRGrE4DxJopku5HPIzWAmh7jwuRXXa5q8Mm5iy1yqa6iykblI+lfS0YyUbWNPbxXUvWfhlGx8uKszeF0XrzTbbxFHHtOVpbvxVH2I/I1raYvrETHvNFSF8haz7hfLGBxitGbWEuMksB6VnSSC4YjORWseaxhKrfYzpLx0bGaT+1ZhxnArUtdPW4bkZFW5dCjwdq1XNbc5pVGYkeoO3XmrX2olVPrRcaWYhhV+tQxqY87qm6kVGo0aNhClxKC3T3rqrezh8sAKuMVx1veCHoa0B4gZIwM1m4u5r7Y0dSjgT5Rtz3rDntlZsjvVa71RpGJLZptvqQVuTmtFCS1NI1ktywukCbHFWI/D+3nGM1esruN1B3CteO8hCdRmplKSOuNSLRzc2j+XHzWPdWJU4Arrb68SQFVPFY84SQ1cZMHUic8YDGeBTkhPpWoYVVsVLHaqx6VrzMFNMyGiK84poBzW7JZBhgDp7VVksc9qnnN1LQoLzVqFOfXNSx2A3c1o2en/N61LlpctSNnwiHju4yB3r6b+Hd+IY4txz0r510WNbd1YcEV6DonjIabtBfIHvXzeNouq9DOo1Y+xfD+tIsafMOldhZ60m3llr5E0b4vRW7KDKo/E13Nj8XofKB81fzNLD4ecd0eHU1Z9FTa8gUfOoqu3iJF/iU/jXz7e/GKKOPIkU/ia56f43qWK+av5mvVUXY5uXqfUX/CRRvxuUfjS/29H03j86+Vl+Mu0/60fmaY3xvKPjzR+dVysXKz6yj1pJOPMBqzHqAkHBH518taX8bFkZQZVH1Ndto/xVjnUZkXn/AGqOVisfmdto20/afSjafSvZ5j6G43GK0dH/AOPpTWeyn0rT0WNmul7Vy1muViPc/hrzJFXs1yxGnEZ7V478N42Vo69evnxp34V8TiP4gjw34iSfNL3rw7VP+PliTxXs3xElO6X8a8Sv2LXDV9Dl+iRlJkBI9c0qtTKRq925DbJfMHc06OT51wc1XwT2qxax5kGRUyehcdT1n4bSfvIx9K+ofAU22OLn0r5h+HKKGi/CvpDwnc+TDHzjFfDYz+KPlue+aJqflW6jdXQWviIR9ZBXktvrnkxY3VDceLRD/wAtMUUPiM3R5j2abxMpU/vBWBf+IVyfnFeUy+OQOPNH51Rm8abz/rM/jXsVKfMXHDHrMOtb2Hzg10uj3wbaQ1eG6X4sSRh8/wCteh+HdaWRVO7H41zeyszGdGx7FYyK0YOetW/XnNcxouprIq/MDW0138vJxXZFWVjzZxsx1x0rkfEhPktXRyXQbvXMeInDQvzXjYvZmtNao8L8eMR5n418++Jm3XTfWvoHx6D+8/Gvn/xJG32tuO9Y5dbmPs8G1axh7SyjHNBUjrxV+3twwFSS2YZSOuK+ti0esppGQ2G4BNN21ZezdWJxgUwxlSKpyCVRWI1Q7SSOKmhVW70sm0x8ms25vfsqEg1k23seTWxKia7KiqfmzVCS6SNjyKwbnxFtBAaudvPEreZ1rSMJM4Xj7bM75b5GJwRVW9vQFODXBL4mctw2PxqaTXmkQZf9av2TOKpjXLqak04kmw3TNdfoeixXlqGC/nXmQvXnlXBzz2r1bwSx+wrk59q6aa5dzxq9RyOb8XeFUVSwTJ9qzvDGmNHIF24Fd74kVGhYEc4z0rE8N7ftAGOhrtUeZHluTTNiTw+JIQQuTWDqHh1bfezLj8K9LhaOKEZA6d65rxBNHdEogHvgVDpoXtJHlN1ppmlZVyR7VVk8Puqk7WFeiWulxKScfMe1W59A86HO3GfahRSN41Gzxq4jks5MHgVc0/WJIc4btXWap4Ta4lICkY9BWbJ4MeBCQjZrKSR105MqL4ic/ebircOuDruzWLqWly264CsMVjPNNGeT+tRyI7Y4mUN2d+niAcZbFb3h7xCq3CfNxmvIvt7jq+a1NL1ZrdlbJ/OuStR5lY2WO6H2R4H8RQrDGS46Dqa7HWdehls2w64x618l+H/H0lrGMvj8a2L74pM0BTzf1r5SplcnU5kDxHMtTpvHV1DcXBKkZz2qXwRfRRMq78GvH9U8aPcyEhuT15q14e8Uy21wr7uPrXorBS5OVmftkfXeg6siqvzjArq4daTA+dcV806b8RvLhAEnOPWte2+KG3G6Tj6mvK/s+cZ3RcpKSPopNWVujrT11QdCwrwmD4tW0KgtLk/Wq998brWNDtl5Hua+iw1KUVqcM0e+za3HECSw4qhL4qt0z+8X86+W9b+Os1wxSGQ/ma5q5+Ld7J/y2YZ967rMUYo+wV8bW7EgyqPxpz+KomXIkUj618ZQ/E+88zJmb/vo10Ft8WZVhwZOcf3qSjIfKj6a1DxhDDETvH51554i+JotSRHICfYmvDdY+KE8qtiVvbk1xGpeNLi8YlmP51uoOSM3ZHvUnxMe5fJk6/Wr1v40DLneD+NfMkfimUSffJPfk1v2viidowAx/Ouaph5MpVIn0KPHCLwXB/Gs7U/Gi+WSsnP1rwt/FUsbY3EH2NWP7emuY+SxH1rBYV31NPaxO11X4gz2shKzcfWs2L4nXMjkec2PrXnurXEszEbmH41n6fDPNMFG4812Qo8qM3Viexx/EGd1GZGP/Aqxdc8fyqD+8b/vo1V0vwvcXVuG2v0rB8S+H5rTdndWkad9CHURoWPjyR5FzI35muptfG8hhGHJ/E15Hp2mTPOPvYzXe6PoM0kY4Y05UVY1jUGa/wCKpZ93zMPxrz3Utan8wku2M16ne+DXkjyFbNchq3gqRAx2n8q1p00jGrJ9Di31aaQcMxp0Kz3DZyw/GpJtFkt5jlSR7iui0HTBK6grXWqasee6juUbK0u1YMu410di120eCWBru9B8Jw3Ma5Xmuss/h/DIn3AKzlCLewe0keKX1ndzKB8/51mHQrk8/PX0Wvw4jx9zP4Zpf+Fcx7SPL/TFHJErnl3PnNtMu0UglgKy7iG6jJBLGvo6+8ApGp/d1xOveDVtwxCY/CjlQ+eXU8jgeVW5Y/jWraXDtgYzU2pab9lkKgd6uaTYq+0sMGsZ2izspyJ7O58jJfipn1lOQTj0qXUNPCQlh/OuI1OaSOQ4YjnjmojTUyJzaZ0rXn2iTHarEejtej5QfwFYfh9pZpF35P416z4Z0tZFUtWvs1HY7cPD2hw0nheVE4Rs1Sk0OZcghq9+t9Ctp4yGC5+lVbnwTBJkqBz6CocdT1Vg7q9zwCTSnhyWDVRkgdCTg5r3a6+H+/OI+PpWNd/DktnEZ/AA07GUsDPdHjv9ozQfL82Kmj1x17n8676++HUiciM/iKwrjwPLExPlkfQU3FWuc8sPUiYceqSSMMGtOKX5QW71EPDMyyH5W49qvw+H5WUAqwrKyMlTqGfcXAXkGlt9QC8E1ZutAljB+Vj+FZM2nyRdm4o5TRKa6Gq2pDsab9o3dqyI7eWRuQ1XltZgvCsan2ZftJIsNcBeoq1Z6htPXFc3fzSwMQRj1qG1v2Y0nS7mX1lp2O//ALXCx5Bxj0rIvvFDJuAZvTris1ZZWhzz07VjXkc0jH5W/OlGjG+pM8Q2jUXxZOsnEh49WNalv8QLqNcGQgexNcULKXPRqsR6bKefmrpVOK2Rxud9zsD4+uLj5TIxH1NMj8USeZu3sf8AgX/165L7DKrfxVKlnL71EqSZHMdvH4ql6l2H41XuvFjoM+Yxz71yLLNCMEkD61SmmcMdxPHvTjRE6mh2EHjSeKZSJGP416B4Z+IUyopMrZ/3q8T0+2a8nXBbFep+EfCct2i7VY59qJ07K4oz1OGa2UUfZR6VUjvvMbg5qyL4KvLVFme17ZCNag9qv6Mnk3Sk8VTS+U55FW7G9Tzc5AxWFRNpopVU2e6+AHCrHXpV9cD7CR7V4T4P8UR2rIpdc16LJ4sjmt8B16c18vVw8nO9jXmTPP8Ax9F5jSYGeteR3Om+ZM2RXsfiK8jut33TmuLms4mYnHNevhLwjZkOxxf9lhf4aRtPC9sV1UtqnTGBVK4jjWvTVRmehhLYrmrdvppZhhatIybgCRWtYqnelKbsbx5TsfANp5LRkg17hoswjhTacH614RoOp/ZZFA4FenaV4kjW3Ul1NfLYqjJz5kjTmSO8vNaMEJBbjHrXB6940MG7EnT3qlr3i5PJIRxnvivJtf115pnBfg+9aYXDybvYr2qWrO7l8eOzff8A1pV8bNJwX/WvF7rXDG/Dn86fa66S2S2a+i9k+UPrMNj3/Q/GDCUZfP417H4O8VeZGuX/AFr5M0PWhuX5v1r0/wAN+LvsiAl8Ae9ck42MZVIy2PsDRPE0cEILOOnc1tQ+MopG2iRfzr5Qb4pjaEWTBHvU9l8UGWVSZcAe9Y69jz507u59Y/8ACQI/8Q/OsvV9WSSBiGArwiD4rIwyZh075pl98V45IgvmL+deZiaM57II2izf8YSLdb+9eGeKoxHOxY4ANdVqvj5J43IcdP71eWeKPFySM/I/OsMFh5xlqj1qeJUEWYdWjj4JBx60+bXIivBUV5VqHio+YxR8fjWX/wAJdKzfeyPrX08aMrDlj+x7E2oiWPKnNZN5rHkk5auRs/E7Laj5uT71U1DVJrpCRkDsRWnsWc8swdtzppvEasPvVianq7zLw2Kwre3uJCSSxFaEelyyfeDEfWto0rHDPESnuZ8kksx4Y/hUDaXLJk/Ma6/T/DzTEBc7vpXSW/geeePkEfgK3SSOSUzyRtPkiOcNTWV0wDmvWpvh6wUlh/Ksi88Fx2yknk/SqsZ85xej/NdKGORXsng7C247gCvMf7NFrcbgOBXU6PrxtYip4AFc8lK+hXxI6LxVMrKQCM1h6C3kyFs9KpalrwmJYn86fo18k0i7mGK7qW1medU0Z17ahNcLtQ5X1qnJlcjlmqzHcQ7VSP71XbXT1kbe4q5bihFyKum6e8zBmGK3ltDIBGg4HXirlnYhsBVworfs7OGFcnGfesHLWx6MKPUwrXwss2Cy1cuPBsRh4Uc1vfaIowBlR+FQz63Bbqcsp+vFQ77nWoqKPMfEHgeORWymPwrzPW/Ci2sjYXOK9s1zxBDKrBSufY1wt9Zvqkh8sEE9a0iurOOo0eQXOnbZCAvNLFaOowRj1xXrtj8L7i8bcY2PfhavXXwlmhiLGNh9QBVtJo43N30PGfJuB/qywFH2O7k/vV6U3g17Oba6ce+K6HS/BMV1twuPwqOVdh88jxVdDuJG5DVsWGi3Ea8hq91tfhohxlP0rWh+GihQQn6UnGNhqo76ngLW91brwzfrVSSS9weW/WvoWf4Zh8/u/wDx2qTfC3dkCP8A8dqPZx7Gvt7bHztcXuoDj5iPbNZ011et97cB+NfR9x8JW258r9BWJqHwmYLnyj+QrRRRDqtngazS7+SRW5p9i13j5mNdrqHw3khLERNx/s0mneGJbGRcqfxFDidFGor6mVa+C5bpQQGqy3gK5CgBWP4V6ZoMKWwHmKPyrtdNt7G4wMCp5T3KNOnUjdnz4nw7upGwUbH0NXJPhbKId+w/lX1No/hGwu8FQufcV0y/Du0e3PyKPwo2Oh4GMldHwZqPgOS1nI2NuzW1o/guR4huRs4r6G8ceBYLa6bCDg9lqjp+iW0NuAwUH6Va1R8/iaLpvQ8J1DwTJGCwVhVzRfBU88YGxj+Ir2LV9MtPJzhT+FWfD8dnDbnAXdTseU5O55BdeAZFyuw7j2JFdX4F+EL3ciu0bYz7V6jpuhQXt1vcLjrXpWg2VrYRqEVRgZrOSsWjkYfhna6TpfzKobb3xXjvjbwjHJcyYGRn0r6J8T6wPKKBwF9q80utNOqXBwuRmszeMGzyHRfAa+cCY88+lek6P4JjijXKfpXYaX4aitY9zKufwq81xFa/3ePanzM7oQXU53/hD4WQ5T9K5vxD4NhjhY7Afwrtb3xLDCp+YfhmuK8QeKftCso57dDVxT3YVOVI8V8WaHFDM4CjI9qw9HjmjnAROM16PcaHPr11kRtgmvQPB/wRkvFSTyTz6gV0qSseVU8jgdDvZraNWYV2Om+KwnDbf1r0W5+B0tvak+XtAGegrz3xB8P5tNZxzx6UXTMtTobHxRBJgsy/qK0RrFvN0K/nXiOoSTaUzDzG4rOTx3JC+Hc+nWiyKue431xG6kjaa4DxSyyRvgD8K56Dx+JBjzM/jVbUPEyXETZOc+9Kw0zhPEB23DfL3qLS9QWPGTim65dpNISPl5rn/tWx/lbHrXNUjc7Kcjt9Q1aJrbbu61w+oESykg/SrTSPNEPm/Wqws3ds4zRTSW45R5mza8Mw7WUkV6x4fuljjXcenrXmWh2rxheK7XT7ry1C5/Wt5HTTU49D0K21Daow1aEOqFSPmH41xtrdh1HzY/GtOOVsAhs0nE9OninFWZ29rqkTABlU/hWtbtZzLyFBrz2K5ZOpz+NX4NSdemfzqbHfDGq2qO6bRbG6XBCn8KzrrwFbSAsFXB9qx7bXZEP3v1rTh8SOBy2alrQ3WKpz3KE3w2gboi8+wqNPhfGvIVT+VdBF4k284qYeKuOlRysftaRyV18MU2k7QPyrm9Q+F6Mx4/lXpc3ioY5FY194qjVSemPpVcrJlVonnsfwySJiSuR9BVfVvCUNjbswAzj0rpdS8ZRrn5gPrg1xuu+M0mVlLj8quMGcFavSSaR5t4l08mRgq/kKydK0WTzeQTXVyM2rXACdzXbeGfh7cXu1vLb8hVNaHz06kZS0OTsfD5aHBXFSSeEi/IXP4V7no/wpmZVzG3PsK6u1+EscKhplOPpWY1UR8yQ+CZXIIiI/CtKD4d3My/6sqPoK+lH8I2enjiIED1qlNb28PEca56dqepLmj5//AOFYy9Sp/SpY/hi/fj8q9ylszJ0VfyFNj0F5G5Xj6CmXGMpLRHg958M1VcuN3pxXF654HNvu2Ia+t/8AhEUlXBXn6Vz2ueBYEjkYrk/SrjIuWFm9bHy9oOk/Z7xRIm0A9xX0r8MYbBI4t+wn6V5h4i8NC3mYxptx3ArO0/xJdaO4Usw29Oap+8jinCVNnlEKlVzTZ9xUYGKntj+82kc10Fjo5vQNqdetc70OqLZyn7xVzmnJdNH3rs7rwqyrgKaxZvDr7sYPFK6ZepUs9clt2ypI/GuhtfG8u0IznP1rDk8OyDGFapLfQZN/3WrKVOL1sUpSR0TeIjcL97NUptYx0NOj0OUJnDVn6hpz23LA1n7NdAlVkhzawWJ+aqNxqDMCOtZ1wzRtjNMtA9zJgZOeOK6PZWVzP23curcFcEVetdWeI/erc0HwTNqSgpEzE+1dSnwruVi3GAg/SocVsNVn0OQs/EBVvvZP1rWh8TTLwrsPxqPV/BM2nZby2GPbFc5cNJa4DAj61lKipGirPqdHdaxLOvzSN+dY9wzTbuv51Wt7wSuAW4rWht/NQFRknio9ny9DT2nMjj79DGx5qiLtkwM112oaFJMThGFZX/CLzE/KrV1x2IkpvYTTNca3P3q6a08WMqYDfrXPL4VuD/C35VOnhu4Xs1RKCkXGMzoP+EmYtuDkfjU0niqRY+HOfrXPjQp1xw1Sr4fnlGMNUeyRpyzZfk8eXEJ2h2/76NPh8b3EzfM7e3NUY/Bk7NkoxzV2HwbKrD9235ij2cX0F7OfYkuPGU7R7fmP41zWqa1cXjHBYfjXZweCJJDwrVoQ/DZ5cEof0ojThF7FqhOSPKrfTbi8k5DEH3q/L4bkhTcQQK9itfBUWnqpZBn8KzNcsbePKttHHpXZGxFSkorU8u0+GVZgmWK12mn6P5yKCOvtRp+mLcXAESZ57CvS/DPgq4u9uUbH0pSSPNlJJ2OYsfDTSqqoh/KugsvAM1xj5SPwr2Lw78OljjV3Un6rW/d6PDpdu2FXgelQHtNDynS/B8OmqvmYLfStGYxwqVRB+FWta1RFc8gfSuUuNUeaQrH+NFi6cJ1NkWbj5mOeM1m3WkrMDls/hV63s55uckVpRaS3G48VTPao5e5K8jzTWvDscSswH6Vw2qF7TIUcV7J4mjihjkXd0FeMeJrtPMdQwot1FWw8aSOaudXfcRk/nUmn+Jmt5AASPxqmLVrtgAM88U5vDEyqXAYGuiCPnap3mjeJ13BmfJrqLTxiszKuRj614ewuLCTDFq1LDWJRgLuB+tU4k0522PoGDxlHDGoyPzqSTx4u0fNj8a8Thu724Xdl6mX7dkZLms3A7PbStsew/wDCYGbo/X3qrPfXF5yrdfeuF0uG7dl+9Xf6Fo88m0tu9eRU8pDnJhpvhue9lUs3PevU/B/w5iZULjJOOozWXotrHbKGk2jHqK6u08WQ6YqgMP8AgNJ2MuWb1PVfDPw302OJN6qvH92rniHwHpq27bAp49BXlZ+KzR42yEfiaRvis8qkGTOfXNSL2U30MfxZ4XtIZnAVevoK45VTT5spjH0rrdX1yPVVJzyfrXnPiCKeNmaPJB9KYOlPsd9pXiKDywHK5ro7fWLZlGCtfOEmvXdlJjLfrViPx5cQ4yzH8TVcpm4yW59KJqFq2ORU63FqvOa+cYfiU64Bf9TWna/Ep5CAJP1p2IPfRdWvI6/lVa4FlIvzAc+4rye18WT3SjEhP0NWk1i5bqzfnU7MpRbO1vtBsrlThV5rnL7wbCxLKAPpVaPWJ1/iY/jUU/jJ7I4aOSX1wOlVzDs4mdd+GZbdiVBx7YqpH51iw5ZfwrXX4kWbttlgdf8AeQ/4U59c0nVeFkWN/wDaBFI2jWqR2NPQfFk1rtG8V6r4c8Yrcxqsjr05rwa8s2gzLCd6dflNRweNG0/K7sFfep5Ue3h8e4q0j1n4iX9u26QFa8X1nxaLdtqsOKo+JviA91Gy+byfeuCjW61y6xFyCee9UlY5MXiI1L2Oo1DxsWjIByfqarad4zaLGXx+daWl/Cu71BFJQnPtVy8+Dd3bRkrGc/T/AOvV3R4rNLSfiAdygP8AXmvQLD4hRw2vzSKCRjrXz7rHhu90FifmyPTis238UTRSCOR2GPU1Moc2xcZJbn0g3iJdTbcXBWrUOsWtopYFSa8GtfGxjjVUck/WnTeKLq4XKs34GsvZs7YTVj2nUPHkSKVBVfxrlLzxebiTCvgH0NeV3OoXs7YG/mrem217LICdxo5LFucnsj0JZjeMD5hP41p6b4bS7kBkyQayNC02YKu4n3zXbadKlmoyarQxlGpLodV4S8FWVsysyr617FoN5pWhwrkoeO4FeEf8JUbdflas2+8YXkwIDsR9c0aCjh5y6H0L4h+IunOrRqqAdsYrxnxhrVtfeYY9uTn0NcHdaxe3TfLmqUkF7cdd1F0jqjgZy6HGeMrN5WkKnOc4215Jq9hcxSMRuHNfQ1x4dmuV+ZSfrWBqXgQMjEx5J9qvnOr+y522Pn6S4ubdslmNH/CRyqNpJGPU16Rr/gny1b93jHtXmOuaKbeRgAVrZNNHnVsJOm9iK51Vrjq361WibzJADVJVKtjJJFXLXKvnFYSMIJ7M6Oytd6DAresdMRgB3rBs77aoHStrTtQ+YD+tc1nc9TD8vNqdlo/h5JIQdtWbrRHtzkK2Kl8OX4KqDg/jXYLbpeR/KK6FtqfV08LCrDQ8/wDMe2bkn8av2fiAIwVjWzqXhsldwB/CuRv9GngYlVb86DyMRgZ03dHbWerQzKOQDWrGI5lGCK8kjvrmzbndx71t6f4tkUgMSv1pNPoeXdxdpI9IWzbjaalS1kXqKwdN8UK6gl1rpLHWIZsbmWoszRSiItvJ2p32eU5+8PxrZt5opgMYNX4YIm7LS1H8zkJbOVv7xrF1DTZpA2O9eoCwhYdB+VRSaJDJ0UflRzEOMnseCar4cupNxXn865HUPDN2smTuA/Gvpq48LRsDhR+VYl94NjZSSvPbitoz0OKpRk2eN+E9Le1uI96Z5/ir6b+GsFq0cauijOO1eax+GRaybtvT2ra0/WpdJjwhxjpQ5XVjndJxPp61j0q0tQzbQQPauK8WeNNOsg6JIuew4rwjX/ine2sLASt07GvOn8fXes3xVpWxnuxoUdCYwcnY9xvPFn9oSEJwPrRayNNyRurkvCC/a9hcmvW9F0GN4g3X8Kl6H0mFwKkrszbO0ZsfJitm1092xhfzFb1rpMUIGAPyq40aQr0HFRc+gp4SEFqjDa0aKPkAfhXJ+IpFYOu5SO9b3ifW1to2GcV5Br/iRpZiqtxmhI5MRKFMg1q1gmViNpJrgrzw2Lm6PHGa7eHfcQlm5qirD7RjAFWtz5XEyUmfP9tpLPe8AjmvUPC+i4iXK/nWHoWkySyBxESTXo2laDdmFdiMM+1ZS7GKnFO5SutKiPBCmsxtEgZz+7Fd7a+BLy6+ZgQPfita2+Hqw8yNz9RWaRbqqx5W2hwDjyx+VNj0W3RsmMflXrknhO1hznBrKvPD9pyM9KvlZHtkcG2n2zR7cKPwrmPEmmxLG2F+nFelzaLCrEKeK5/XvD8ckTkHPFWo6idRSR8/6xAYbhhnFbvgPSlvL5FbByR1qx4k8NssxKqx603wjeHR75PMAwD3rotoccnqfcvwM+D9jq1hFLJGpIAPSvYb74SabFFsECn/AIDXg3wT+MkOk28MTuu3AFe+f8Lk024tdzlTxwc1yyjLoWppKx4p8V/hLbWVrLKkWBg9Fr498eaQLGeUKMYPHFfa3xW+J1rfWMscbLjBr4z+IGqC+vX8sAjPatoK25PNfY4XTYZJJgMFq9D8O6UZGXenH0rB8P6YzSIzRmvXPDdnCI1BQAj2qZxTPQw+mrI7bwzDdIAY8fhWjD4FtpFHyr+VdHBbxeWCoFSZZcbVrHlPepzp21MSL4ewnoqj8BUh+HKMOFH5CtyK6kX+HFXY9Sde/NOzOuM6NjkZPhmO0f8AKp7X4agEAoPxxXXx6w46jNT/ANtP/dxRyj56Rj2vw4t0XLKv5VM3geyh5+X8hWhJrEhXk/pWfcajLIDzijlMZV6cQbRrC1X7q/lWZqmoWdrFwq/pVbULuVlIyTXI6lb3ExYZYA1aicNTGLoil4k8Tooba2BXntxrD6hdbcjbmum1DwxcXTHO7FZS+DZLeTdtb2rdWseJWqzmz0X4Z+Hbe5kjLkEnHWvqvwR8P7JrVJGCqAM9BXyX4OvpNFkj3A8fWvW4fjZJp9iIVbaAPcUnG5y69T1/xnqlj4chZUZflHbFeB+KPiM13IyQtkZx1rkfGnxal1aSRDLnPuawvDv/ABNblWYnn3zU8p24ej7SR1MH2jVXDNuFdJpnhdeHdefU1r+HdChigVsc/nWzchYxtB/SolKzPsMLhFGNzGNrFbDAAFZWragtvExGBitC/mKhjnpXnXi3W9gcbs/SjdHpVpRpxOZ8XeIC/mYYV5Fql5JdTtnkfWun1zUGuGYDP51y9xb7QS2c1olofH4urzyNLwzEklwing16tp/hAXlqG8sEEeleT+G5PJvE54z61754Z1eGPTlUlc49KZ41TU8a8deGxZuxVcYz2rlNFgBmVTzzXqnxEmim8wrjPPSvLtLmKX3XHNbLYzppXseweEPDlvdQgOAM+td/Y/Da1ugCoBJ9q848M6wYYl2nBrvNL8ZS2O05J+lYtvY+owsKUlaSOns/hT5bZUAflW5beAZ7fAGcewFRaD8SonUJK3zfWuys/FVvcgEOBn3qWetHCUJHNf8ACCTv1Y49+KRfhm0jZeTj613EepLMBVyOZmx6VJ0rBUktjhofhbAuCWyfar8PwxtOMtmuu80DtU0cooNVg6XY5mP4Z2i8g4pJ/hfazKRjA967GO4AwOtXVkU7cdT2oE8LS7HkGp/Au0ulLIy5+lcTrfwCmiVmjQt6YFfTOR/FlT9BT/k8vLAY/wBoA5/SjmfQ4auCoyPg3xZ8ObzRRIWR12/h/WuP064+z3gjeUoQcfM1fobrHgn/AISizmgt9Iub6R1ICwW5c57c44rwvTf+Cevxb8Va1Pcpo9poNhJISjandqh2+pVSSfyFdEbyWp8ljqEKEtGcn4D0tdSjXY5b1zXqFv4Oj2DufpmvcPg//wAE/dQ8D2x/tnxZbTyvjMdjbkqp+rYr2DTf2T/DVuwN7qF/fAHO3AjX9DS9k3scsKsUj41PhOBBklR+NTw6DYxjBjRz6tzX3zp3wP8ABGmxqsfh+2kx/FOS5P51tR+A/DdmoWLQbCMdP+PYf1pqjIftodj88W8P6ZMu1raAj3FY178PdBvCQkcaP32HJr9LV8J6AP8AmEWIH/Xsv+FVb34e+E9TUx3Hh7TplP8A0wCn8war2TD20ex+Y918MRHGfsl20Q7LJ0ryT4iaLf6DIzXA+XoHUYzX6wat+zH4H1Pe8KXulMen2W4yq/gRXjHxa/4J833jbTZY/D3jWLeeVj1G2A/AsuaPZtGNScHsj8t2u5Z7jaXYAnHUV7t8HPCEWpSxZCsTj0Ndn4i/4Jp/GDwzI01tZ2OsxpyGsLvk/g2DV74b+EfFXwv1OO08U6Bfacqt/rJ4W2f99YpSi7GClc+lPAHwdtp9PikaMD/gIrp9W+Ctq1u+EUn/AHRW98O9dtrjTYWt543RgMc8V1esa2lrbsSVY46DqPwrkd7mmh8R/GL4XQafHMSiqRnsK+NvG2jHT79wrYGe1fevx48XQstwMr3HIx/Svhfx/frd6k4Xk57V0UzKXkYWg273EgGSa9T8OeGUmVTIpOelcL4VtxHIpK17V4baOOBSccClNnr4WMGlzE1r8PIJkUiOtm2+HqxAFF/Sr1trSW+AAD+FbNn4ojXqM/pWR9JRpUZIy4vB8irjayj/AHalXwnM3HzY+ldPb+JraXAJwa0E1W2kAxU3O6OGpHGr4NLdQfxFTJ4KTPPNdd9qiPTH4mmtOnYrQbqhTWpzkfhW3j/hXNOOhwxKcKv5VtvIp7gfSq0twgHXNJmqpxWyMKfT41BwB+VYd9aqNwIX8q6S6u0wwytczq2pQwqcspqlexpeKWpyXiGxjaFyQo49K8L8aWqKz4Xua9b8T+Jo1VwGA4rxXxRrHnPJ81bxTPnsdOm9jhplxMe1PiY7utRSShpGOaSOT5utKR8nzLmdjREhUA5q7Z3ZVwc4rOwWj6fSmW8jLMB0rM05uXU9T8M3pIABzxXo+j3xjVQe9eR+G7hlC4Nej6ezG3DYpn0WCxyi7M7y3Mdwo3DNFz4egukOEAP0rF0PUv3uxiB9a7GGUMoxyDUn1UZxrxOD1fwKkilgPyriNT8Jy2pYoGBFe9eSki8rmsvU/D8VwmQlO9jysRgVLWKPn8zXNi5yWwK0rHxlJCwV2Ix713Ws+CRIrYjJ+grgdX8HSwliqstaq0kfN18JUpvQ7LTPHCkL+8ya6rT/ABgj4y4NfPdxa31izFd2BV7TNfuVYB2YEe9S4djz/aSp6M+lbPxNG/8AGBWtDrkbAfMteE6VqtxKqhWYk+9b8GqXsXXcR9aydMuOIWzPY49UjYdVNPMsMw5215PF4kuI+u41P/wm5iOHz+tLlZqq0T0e4soZhkAfhWPe6KrKdvFctH4+j/vEfTNSN45jxw7frT5WP2kZGT4m0HMcmR/KvM5oE0u6JPPPevS9Y8Vxzwt8/X1ryjxJfLLIxDd+xraKZyTkou6PTvBfiyKMxqSor3Hw34nSaNACB9DXxNo+sXFveKELEZ9a+gPhzrEs0Ue4sDx3pSR7mBxV7I+kLW885M96o6tqn2aFiW6Vk6bqG21yzdq5Dxp4oS3hkO/IrOx9BOslE53x74s271D8896890y4fUrzJJPPeuf8UeJTfX7Kj8Z65rpvAtrv2OQcnvVtaHy2Irc87XOxuIxa6f1+bFckt5uuuvOa6nxJN5NqQDkgV50t2Vu+vepW55dY9v8AAfw9tbtIiIhu4zmvVbfwBb6fHkqmAM9BXmPhXx3DotumWA2jsa0df+NiSW7KkgPHcmpcXe5y6nWapJaWCkZQY/CuK1TxRAhYblx9a881Dxxd63MfLc4z70lnoN9qbBjuIP1qlY6qOFnV2N+48SJMx+YAVALtLhutXdL+HUsvzP8AyNdRZ/DwIF4z+FDemh61PK5SWpycOmpc98Va/wCETjmjz1r0C18ExwLuYfnVLWEh09TGrCkr2Ov+zYQWp4r4u8KRwq4CcmvHtd8NSW8zSLlcdOK+kNXeCYsXGa838Rael5KVjTjPYVrGXRni4ilGGx5dpHiDUdLmAR3YD3NdpbfEnVI4ApZvbrVqx8FpMwylaz+BwiqPL4+lXdHkSWpyWpeKtR1b5WLDPpml03wjPfFZJFY7uea7yz8DqXQ7Mj6V6HofhGK3hVmjzj2rOUkd+GpKpKx55o/gsQwrmLp9K2U0v7MoABFeyaT4dtZ7XAXmsrWPBe3JQH8Km9z6FYG8bo83jlMZxu6Vegvs/Kam1Pw1PDuOxsVzl1FNZsWwfxqTiqUZUzqElR6k2K3SuI/4SOW3fDDIrRs/GEROCVz707OxhzuLszqVtmPQVL9lf0rNtfEsDgfdNa1trls392kVzIYtk7fw1KNJL/w1a/teDjBX8qmj1aFv4lH4UrlWT6lD/hHVbtTG8Lxn+HNbaahDjkripP7Qgxwy1OouWJzMnheNs/uwaz7nwrHt/wBX+ldXJqEP95apy6hD6rRcXJE4S88LbSSBj8K5fWNEmjRsHPtXq1xeQMvVT+Fc7rDW8kbEbatSZjOnE+f9as5re7LNworofCHiRbVkDEZBp/jJYisgXGfavNf7Qktrr5GOAe1dCV1qZU6nsZH1l4b8WCaNFDYFdT9s+0ru65r558B6zNKsfzN+de36TeZsslucd6wlFXPssHiOaKuZ3iS+W3jfmvE/FmsGSZgr8ZNd7481tY1kXf0z0rxHUdRN3dMF55qlE4sbX1smTwoZmJzk1V1GPy0OetadjGY4skc1l61JuyOlB85JtszrO9+zzAjiuts/GLQW4AbGK4JPmkwOK1rHT5LplUZ/CrWqOWZc1rX5dSYqCTmodF0tnk3MpBrp9I8FmaRSwYk13lh8PWCKwjYcUc1jfD4eVTVHPaPa+VGO34V0cUOYx1P0qS88OSWOPlbioI5javhyAP8AaOKzb6noSpypMk8l42DKzCtGx1y7tXGHbA96sadDHf4AYVpN4SeZgqtyexqeY3p1Zx2ZoaX8Qp7YhZCWH1rs9H+I9vJhZJY0P+02K4m2+E+p6gQse5Af4scV2Phn9lPTL6RZtf8AGNzpcTcslrAJG+nI4qkkz0oYiuldK52Fv4is7hA3nx5/2WzVpdYtWHFxCT6b1r0T4a/sT/CLXGXGo69r0gwS1wroh/FRXu2j/sX/AAv0vYn/AAiNhJEo+9JJIzn8zW6o3V7nPLOlTduU+TLXWLSSZIluEkkfhURgWY+gHevRvCvwr8WeKtpsdInigbrLdDylx6/NyfwFfVPhP4F+AvAk3n6L4VsbSftKsIdx9CTXcK21SUhZR6dD+VUqPdnDWzypJe5Gx88+G/2W5RtOs6uqg8mG0X/2Y16ZovwT8K6Co8nTI7mTu9wS5Nd20kq8JFgf7TD/ABqu8l8fuxqPyNaqEUeJVxuIrPWRTj0VbKPZbWsMCD+GGML/ACOaiaKSNvmjZD65J/ma0FW+ySWC/QU9o7llwzKfwqrI4+aUnqzOCqBzyaNu77vH41O+nzO2aY2lztwMfjVXK9SuWROrCopbqNV6n/gIq8ugvnLMtO/sp4h8qqaAujnbi4mbPlWrn/aY1mzXWqs21ISB9cV10kbRNhwV/DFRthh938xQBxzWGs3HUAD/AGm/wNWdPs76xlDm88vHVUJ5roXjX+5t/Cqszbe1IDWtdcWRUWVskdWOQalufsWpRlLu3iuom42yorA/gRXIXF0NxBOPTmpLXVZIcAtvX69KAK2vfA/whrzebFbSaPOTnzdNmaBvyGRXA+Mv2XdW1W1ZdI+IWrWq4wEvUW4H58EV65DqYk5D4q2mpHj5uKhwTFqfmr8eP2O/jFpa3F7pssPim1UcmzJEv4qTz+Ga+LvEXhfXtD1p7HVdNubG/B5gniZWz+Ir+gL7dFcbRIqgjowOGH04rmvFnw38NeNE/wCJppNnqbDOJJ4lMy57qxGc0cqtoCs3qfh1pC3WjzIt9byQqcffQivSdJ1GIwjy3GPXNfd/xe/Y1ttZ0+f+xDHdRnLCyugA6/7jDv8AjXwv48+Euv8Aw91WaE280aRH5oXTay/geSPeuSUWerT/ALpoLeFlGJP1pPtjrzurjrPXJFbEiNG3Q78/lW9aaxFIAGKnPoaxZ1RrNbuxqLrUkZ4Y/nVpPFEsYHzk/jVKGKC6XKsAafJoW4AqS2fSo5rM6o4mS2ZqR+MpUxls/jUv/CdOo5bH41zc+hzKOjVmzaXcAnANHMjZY2aOyb4gbc/Pn8ao3XxC+X7+PzrjJ9MucH5TWbcaXcsDhT+OavQf16Z0uo/EQqpxJ/OuL1v4iGTcPNx+JqhqGhXUmRj+dcrqXhW55J3D6ZrSKRw1cfVeiKut+LnumI8zGffrXPSQz6jzlgOuauyaDLDNyG/Gt6zsVWEZAJ+lbRtY8ipiJzepwV5Yvb5ycj3qC1jJaux1yyi8snHP0rmYIwrkdBWcggjRt4d0fPpVee3MbbgK07NAwFLNCrNzzWLaNXE3/BLiRkRjivZ9B0sXEYAXIrwvw3J9m1CMHgZr6j+GttDqUMIOM8VfQy5nBqxh3Gh/Y2EgG0/St7QphNtjc8133iDwTttTIqnGOOK84uLeXTboEZABqT6fBYzZNnYw6OHxt5HtUw0Un/8AVVbw/rySKqORketdXDJHMoIA/Cg+rp1FPW5zr6ArqQy5rG1LwPHdI37vFegqEbjbmholbGFA/CmKVOMtzwLXfhwDvxFn8K46fwD5Un+rr6lubGOZTuVT9BXL6t4TSVS6Jz9KpSZ4mIwEZ3aR47ovhfyZF+XFelaH4Miv41DLjPtWbNZyaXIxKZHaug8N+KFtJFDfLii58viMHKm9ELrXwtFrZtKqNjHpivCvGmlzadM6qT+dfT2tfEi2bT2jYA8djXz7421SHVL4+X/EfrVra5wU4ScuU8309bueQrluvFdDDpN28fO/8K7TwZ4SjvCJGTPfkV6Xb+DbZYh8q5+lTzH0mHy51Fds+fpNCupBgqx+tUW8EzXTcp+lfSP/AAhttnO1fyqSPwjao33Afwo5+h2f2SfPmm/DVhIrbOfpXqng/wAKtYqmVOK72Lw5bR8iNfypuoXFvpdux2qDiobbOqngo4dXZT1fVE0y0K7+grwj4h+ND++VX4PvW9498bbY5trD8K+ffEmuPf3DfNwTzzWsY9TyMbiYx92JraVcHUL4Puzk17h4Lt/LhTAwMV4d4Pj3SpivffCybbZMelRLc8WleTuyXxY/+jt6YrzJpMXn416T4mYG2kB9OK8qmlC3jdqURVtD0HWtNuYI3CscCvNdUvruG82yOQgPrXu+tTW80Ln5a8W8aeSGcptyOeKcddCZKKdzsPh60U80Qkxya+jPDWn2bQIVUE+1fE/hfxXLY3iruwM8c19L/Dnxa1zHFubPTvSlE+iwFSKVrHtUVpGo4UD6irBUKuSq4HtVazuRNArFsCsbxN4mTT7d1DgYHasrM+h54Rjcj8TeIU0+FlVlJ9BXk+seJmu5jh/yrE8WeNGubh1EmTn1rL0YSahOG2nHrWh4GKxXM7RNqaZ5oySeKwZpP3xA5Nb2r4s7U44OK5W0l+0XA75NC3Pnq827tndeEdJ+0MGYZ/CtvxBbxWyYwOParXg2yWO1Ruh+lQ+NFKRuV6/Srsede7KekzRyqhG3Oa7WMbtPyo5HtXkvh/ViLwRs+Oa9b0fFxbhQcgjmk1pc2o1HTkR6PrZtbgRucZOK7SOZLiIEBTmvM9fspbGbzY9wGa1vC/iYtiORuenzVB9vg8QqlkdbdaPDdIQVUZ9q5LWvA8dxu2r19BXaQzCVeGyKkbGMAA/hTPXlRjUR4Hr3w/dNxVGP4VwOo+HbmyY4VgQa+rbjTYrgHcq5PtXOap4LgulOEUH6VSkzy62Xxlqj5dkuryxY53Y+tRr4zuYGwxYD617hrHw1RySEz9BXA618M8Fv3ZH4Veh4dbA1Y7HKxfERtwHmtnv1rcsPGUl1gBj7VzF94DkglbarL9P/ANdXdE8Pz28y/eP1pWR5c41Kb1O2g8Q3RXjcakfxJc4wQ1dD4X8Ni8VFfgn2rtZfhUklmZFGeM0uVHP7Zo8WvvGMtrkliPXNZLfELc2BJz9a1fiN4VbTWlVevSvM9P8ADs9xcHBzzRypG9KU5vQ7OTxpJKv3v1rOuvFE7qcEmtXTfAc0sIO3P1rWh+HDNjcv5YpaHpRwdWaueT6vJcagxwG5rOsfCM9xNlkbmverb4aBmBKYx7Ct6z+H8UXJj6e1WpWN4ZbOT1POfBvhV7LyyVPFd7qeojTbJgDg49a1rywt9Htz0LAV5L468UBA4VgBzU/EzvlFYaFjkPHniUytIN+CTXE6WHu7jJ5zVXV9TbULplzxmum8G6aJJoyVzWz0R83Uq+0mbK2DRWob29K5LWMrI3pXqes2kcNmQoxxXl+uL+8IHrXM3qX0Mi1TdKvfmu/8L2cbSoSv6Vymj6W9xIDjIFehaPp5tERiuKrm6HFM9G0HT4N0Z2gH6V6HYW8Q8sHaB9K8+0FzIsZBrpZ9U+xxxM77dx70nsergqqTsdpeeE4dSi/d4yR/drgvFvwf1Frd3sCzTHoin73sK9K8H2eqeJJ4Laxj3M2N0kmBEg/vMx4/Ovp34Z/D/S9HeKe20+88XazHjdcIDFaxt6KWAB/WnCDep7mLlRhH3tz41+C/7HfxX8WMNTuHs/C+lb8CXVptruP9lclv0FfUej/snvottGg1XRby77yyTsST6jivohfC/i3VGWSWXTdIQ/8ALNYftDqP94nFdDY+E9P0nZLezNqdyvPmXBHB9lAGK6o049T5mOJ9i7pnzjZ/sv8Aiq8ulV7rTYLX/ntGzMcewxXrXhP9mnwzoZim1Jn1a5QA5mfEefYV3d74iCfLGAijpgVh3nidlyWk3D/ezV8kVsFbMMRWXLeyO20+zsdHhENskNrCowI4wFH6VJNq1pBwXHHvXkmufEK10e0a4ubqOGIcEsefwryTUP2lYbzxHZ6XZW8ji6LBJmICnHpVeRxww1Sp7zPq0+JLbjaePrUg1xGGRgfjXiHhXVtQ8QZeW6SKIHHBwa9U0qz0qGFBIzTP6u3H4UznnT5VY3P7YHoD9CKX+1D16U2G4so1ASNAOnXNWo54H6KtBiQrqRb3p632eoFS+ZD3VaUPD2VaAGreDuKk84NjC0z7VEueFFRHUk5HFAFsvtXJGPrWHrPiq20mTymIkl67FI4qzdanst5HVlLgfLXnl5aySyPLMpZ2Od+aZST3OlXxoJm/eWatGf7pya1LCbT9T4jZon67CcV599naMhkPFXLe6+YZJV16MvUUyzv30dsYSU/RqoT6LeMSq7WH5VT0zxNLCoS5Jkj7SZ5H1rqLW4ivIw8T+Yv1pEu5xd14Rv5WLKF/Naz5vDerRZ/0fzB/slT/AFr0v7oPHFQNeW8bYMqg/WkLmZ5uul6rCBm2kH5VJ517AuZIZFA9q9GSRZjlHB+hp7R7h03f71VYrmfU8z/trbjc+0/WrMetDIAl5+tdffeG9P1AES2yhz1ZODXG614HuNPYy2jvLAP4CckUWHozXtdWWZQrlJF9OhH41ynxK+Ffh74maXJBqMX+kEfu7tcCSM/XqR7UlhcMsmG4YcFfSuht7lfLHzfXjrUyimjSM3B6H5v/ABy/Zc1XwPfTSzwh7SQkw6hAh2P6bgOh+tfOmraLqXh+crPG6heA3r71+1Gq2Nlr2nz2l7bR3NpMNrwuu4Eevsa+Lvj/APs+w+Fbgz28ZutDuWIjkbBeFv7p9B6VyVIW1PWpuNdJPc+IbHxU9ucE4A9a67SfGysFBbj60vjT4Ry2peWzDNHyRt5Aryi8s9Q0aRgytgenFc9lIupRnRd+h9A2PiC3uh823n1rRX7PMoICjNfPGn+MpbUAO+36mut0r4gdMyZ/GocOxiqvRnry6TFIMhV/Ko5NDhYY2qfwrldP8crIoG/P41s2/iaOVR8wX8amzRvGSZPJ4bt3Byq/lWHqnhGJlYKo/KuhXVkbBDg0y4uBIpO7rRzWHyxkeReIPCoh3ELn6CuNv4HthjoBXuWp2azKQe9cL4g8Oqqs2CR9K2jJnJUoo8c1a5Zsg1kpH0IHU11XiDTUhZsVzS/K+KpmCVmaFmp44rRW33cms+3baK0YbgetYPc6OhJDH9nmR17e9e9/B3xB5MkO9wOmcmvCvLDruzXS+Fdf/seZCXwAa1jscM9Hc/Q7Q4bTXtHUfKSVry3x54H8mSV40OBnGBXI/D34yC2hjRpwFAHU16RN44s9dtzl0JI7mizKjNx1R4ZM1xpN1gBhg+tdb4f8TCVArvg+5pPFGnRXEjFAO54rgJpZtLuCVztB7UWPpMFjuWybPbbe7EqAhs1N9oPTOa800HxeGVY2bmu0tNQS5QMDzSPrIVY1FdM1/tGetRtIDx1Bqr5nufzo8zHf86Zslco6ppMV0p+UVxGraTLYlnQHHbFeiNJnr/KqN5aR3CFWH3vamtTjrUFUTR4J4p1a5jRlDMD9a5nRbiS9v0EhJ57mvV/F/hJGV2Vc9e1cDaaSbC63bduDV+R839T9nO7PafBdnHHaRnGOK64SbR0rz3wjryRQBHYcDvXXpqsLj5XUd6TR9HhuVRNQNupSwXOayZNYhj+86/nWJqvjCK1jYh1/Op0OipVjHqdBqWsx2cbEtXk/jbxuP3iiSsnxR4/aTeFkXHbmvM9UvrrV3YqWI9jVJanzmOx62izC8W+KJLqWRQcj61xqt50gyM59639W0d0ZmcHPvWRZWoNwB71vpY+OqVJVJHeeCbXMkfFe6aGoitVx1xXlvgfTfljNetWMYigUDrXLJno0IuxR19fMtmyM15DrBMN4SR3r2XVYg9u3rXkHiuMxXDHGOaqJFdHRXWsXkkZHzGuO1i1vb1m2o3zV703ghTx5f6UR+AU3cRc/QUKaR6n9nTZ8+aP4JuZLhHcSdc1798OtFks44iQRjHU1u2PgeOHaTEAfoK2xHBo8RyAMDjik5cx3UMH7HVnR3PiEaZp5G/LAeteK+PvHrP5gEnPPQ0vj3xuIVdVfA9jXg+seI5NSvCik4J9a1jHS5z4vFW91HX2F1Jq94p3dT61694V0kQ2wfb0FeWeAdP3MjH5icda9vsUFvpp6A49KxlueSm56s4jxrdBWdM4rnvDOJr1Oc81a8bXGZm571W8G/NdLz3qonBV3PcvDuI7RcelQ+KLf7RaOcZ4qfR8LaJzUmoxieBl61ZzHidxcNpuqBiMDdxXuHw+1JNQtUGeeK8Z8bWBhkd0H3TnpWv8ACfxU9veRxO/GRwaTA+gtW8PrfWbEJzivK9UsZ9HvCwZlAPSvoXwusWrWac5LCuf8deA/MV3WHqOuK55aM9LD13Tdzg/DPiYTRqjvyPWuxhn85QRg/SvItS0640W6Ljcqr710XhvxYWwkr8/WrWx9lhcWqm7O/Uk0pHrVW1vkuIwQ3WrG7HWg9hNS1RHJCj8Mo/Ks660eCZWyg59q1GcMODmoHPFMOSL3OF1jwbHIGZUH5CuOu9BawfcE4B7CvYj3yM59qzL/AEuK6QgqPypts8+thYTT0OD0XW/sMig4G32ruG+KcVnYmNzjj0NcZrnhkwlnjBFec+JvtVvG4+Yj8aqNz5XFYCUXdI0/iB4si1q4PluDuPf/APVUHgvQBdSK7rwTnpXnlg001+u88Z96958B2iLbocdhTex1YHD8rXMdPYaLBDCBsHT0q4thEv8ACPyFWOAvoKjkkG3g4rI+ujGMVsNaFRjCrVHUbxLOMsdoqPUtYhtYyTIMivMfF3jbaXVXFGpzV68KcdSr468XY8xQ9eAeLNea6mcK2c103ibVprzeQTz6GvPdRhkaQlsn610QjY+JxuKc20mVbGMzzAnJr1nwTppwr7a860O1EkyjGTXtHhWy+z2YJGMilNnn0U27kfiAbYWHTivM9UjVrjk969G8TSbVf0rzHVJz5xPvWDO57WOk8P28ZZAB1r0G3so2thtXLAcAA15Ho2qPFIMHBr2P4Uxar421620fTdOm1C9uDsSONPXufQe9JRd9DgqWDw3rkdh4ktLOdcq0qoUOe9fXGsfsZ658YjodzoU0ejWKbXnuLheApx90dzXq37Pf7BOgeC76LxR42jXV/EGRJFaDHkW3sV7mvrpI4rOFUQJFEowqKAAB7CuuNK+rOZTcH7p5L8L/ANmnwz8OtHt7V0bV7pAN9xdDhmHfb6fWvU1FvpcAjjjSKNeFRPlH5CqOpeII7ZGUMC3bFcTrPiwrvJcAjqc5xXQlyrQJSqVH7zOr1PxKkCsAcZ6jnArjdU8WLJIcvkD0P8/SuG8QePba1hkmnukihUEtJI4VfxJNfJvxo/bw8N+DWnsdHkfXNSQbcwnEKH0PHzUrm0adlqfX+qeNIY1ZTKir/ExfgfU9BXhXxO/a08I+AfPthqMd/qMfH2e1mBP4t0/Wvzp+In7UXxC+KUz2c2pTWtrO2EsdNXaWz245NUdK+CurxJFea5FIksw3i15acr1y/OAPrUymoo9PB4d4majBHsnxU/aGvvidqKTJqr7VbdFYxNnBH06mm2vxW1Gb7DLLp97Fqdu2+KWNTj3yD1zXYfs/fDKG6Kwaf4bN5cTMF3pFgqPV5GG0D6HNfTusfBHT9M8Myi6W+imlAU2+gWpkm+hkxx/nmuW7lqj6Z0lhpqlPQ8l+GH7V2p3F5HY3ehzmTdgOj8uR6L1z+FfT3hz4vG+jQzWepWzcDbNAwFeD+FfhHL4F8RG4D2HheSSLzI7jVcXF3GmeSVwQGNfUHhvwZoq+Fo7i78Q33iYTL5iqu2Mtx2SNVOPQE1vTd9zlzPBUaXK46p9RdN+MejTXJtf7Wt1ulODFJIqMD9DXW2PjSO72lZVYYzlTkGvir4ieEvDd94guJdF8F+JrgtcFri6mLIBj+FccAfjXTeBrzxtdajb2emeAr2x02L5Q8jOhUe5fGfwoc3zWSOWtlC9gq0HufYsXiRD1kC/U1P8A28pTcG+X6183+JfiT4q+Hs1kmoeHZtRtrhtvlWpLyrgdc4x+ZrT8L/G/R/FEjpbvPa3K8Pb3UZDqfTIJBrTm1seLLBTtzdD3Ztd64eqba82/h/1rhIfEiXMeUlVv+BCq7au7TBS22quckqNnY9IbVPMUDfjPWmTXkbKV+X65rk7HUPM2qXyfStR1YplVLfSqVjJq2hakZOoNReaG68YrOa6YNhty1BcXDqvElUI2obvD9dw+ta1hqEttL5lvJj1UnrXnz3lypI34FSwapcx9JcUgseuf8JRHNGBMvlt34JzVN7yymYlJNjf7Sn/CuDtfEzKcSMrVrQeJLWQYmj3j1UjiixPKjplvJYPmjkVl9jV6z8Qt0dhj3zXG+TpWoSHy72S2c+kpWpD4V1NF32WoyTDqBJhx+gpks9Fh1SOTByAPap1kS4xtOa86tLrWtNyLu3WVB1aLH8q0bPUpLyTMN1DG3/PKckH8O1AjS8R+Fo9QjaaAiC6/hKjhvrXn/wBquLG6a3ukMcqnn0NdhfeMpNBYDVrV7eDtcEFoj+IyB+OKNVsdN8aWQmsp4ZnxuSaBwy5+oJoNI8zb0Mix1ZJmCnipNe0ex17S7mwvoUubO5TZIrYzj1B7GuTaSXRr42t3kOv3XJ6/j0rptNvhcxgEtk9CDjHvUSV9C4ylF3R8b/FL4X3Hw61t7R3a502f5reYgfMvofcV454m+HdjrKuVXY/rgV+iPj7wXZ+NtDuNNu1w7AmCbuj/AF96+L9e0W58PatdafdKyz2zlCWGM159SLi7o+0wVaGKhyz3Pk7xh8JbjT2keJGZc9sV5teabd6bIQd3HbpX25eWMdyrbkVs9civPPFnwtttUR5IkCP14A5qIVFszHFZbfWB80WniO5t5ApZgB711mm+Jp2VcMx/GmeIvh5NpV2weNgufarOg+Gydo2sRVXTPn5050nZm5a+KJY1G4k/U1pw+MCF+Y5Famm/D430I2x9qzvEHgOfSY2YqwXGeKVkQqzjuTL4sjbkkAVR1TxBFPC2WGTXA30lxbzFQ7daiMlzNGc7iO1Wo2NVUlJaGf4ouUdm5Arjiw8ytzWreVdxINc6oKvyf0oa0J97qjTjbK1PCp38VDaJvxxWzb2o4461yyNknYv2NuHjGTVe8jMTHbWza24jhqJoFlm25wK6KZzuHM7GbpusXlu3ysQF9K6/R/iVeafIqyO20epNO0fwmbzBC5/Cma94JeJWwhHpxW2h2fUJct0el6L4/j1iFVaQBse9Wb6NLxcjaTXgVvcXmh3P3sAHpzXqPhLxXHqESI8gD/WlY8uSlRY+78/T5iy7sD0rf8PeNGhwkjfnWhPo8epW5K/Ma4fWtEn02QsgYCpaR7GExzho2ezafrkV0g+YA9a1I7gN0OfpXgeleK5bGRVkbHbk16JofjCKdQrOpOM9anlPrsPjIzW53RmPQUnmms631CK5UFSoNWEkBGQQadj0rqWqGX9ulxE2R+deZeJtJ+ys79B16V6iX3cGub8UWKTWrkrniqOTE09Lni9x4nbTJSd+Me9WIvicxUKZOR71y3jyy8maTaSMdMVwNq0skmMsT9atRuj46vip0nZHsdx8SmKnDk/Q1kTeJLvVcrGW+Y1w1vaTzSgZYDvzXsHwx8EnUbiLOeSPvYpNKJ58sZVn1MPTfB99q86kqxU+tej6d8IWtdOMssODjOeK+mPh/wDBe2js4pZIVPfOBR8T7Gz8O6XKiBRhfas+Y4pSb1bPhb4gaLHpfmcYxXB6HYi5uiQuRmu1+KWsfa9TkjBGNx6VV8G6V5jI2MZOTxWl9B043Z3/AIR00Q26NtxxXYLlVwOlUdMtlt7dQCPyq4WKr1rne57FNcqGXTfuWzXknjhgJJDnBr1HUrjybZzuxxXifjTUi8knzZq4HNiJaWPtX7DHu6L+VK1vFGpyF49qrS6pHGuSwrA1bxQlurYcD86ys2ffynGKNbUtShs4ztK5ryrxv42EUUq7146c1R8UeO929VfkfWvGfFWu3F4zlXbn3rojA+dxuNSXKmZ3izxY95cMAxPXvWPoMbXV0jEZyayJld5iZDyfeu38F6WDIhIzWk/dR8s6jqSPW/AdjtSPjFemzMY7Mj2rlfCOnrDAhxj8K6W6bMDjtXHI9GEbRPKPG0n71ifWovBVx/pS9smn+OF2s/asXwldeXdJz3raOx51bc+i9JuAbNO9XWmB4rn/AA9ceZaL6YrWWTn2qjkucv4w0sXELkJkHPavLrGZ9G1pCCQA3PPSvb9StvPgYdjXkPi7T2s7oyKBwc0hXPqX4N+LlmihDvleBkmvoGTTbfVtN3DaeK/Pr4dfEM6TNHG82MH1r6Y8KfGSJLdQbhduP7xrCSZvCRN4+8BozTFUPTsK8M1jSrnSLssu4Ba+htQ8fWWsRkeauf8Aerz7xRbWt9lkUH3BprsdVOs6bujiND8YSWzLHI3513um6/Hexgb+a8m1zSXt5C0eU54xWfp/ia40yYLIzenersfU4PME7KTPfPOEi5BqIuMkGuE0fxxHMqqWH611NvrEV0gKsAaR9DTqxqLQvtTM46ioxIXGQcij60jUr3cCTqQQPyrh/E/hZZ4nZVzu9q7xsVXuIVkQr/e9qpMwqU1JM+fb3QRp9xuKdK3vD/i0abiMuMehroPGOh4jkkTBrwjxVqk2lyt1GD2NXvoeBUn9X1PoAePoTH95fzrH1L4iJGjAOPwzXznD42uJMKHYfjSSa7dXL7S7c+9HKcU820seqa146kvN6o/061z9tp15rlwOG5P1q14C8Ky61LHvBOfcV9M+C/g6kNmsrQjAGScCpPIrYudU+btQ8DtDbkyR5OOuK8v8U6elpMVU4bOMYr6/+KOnW+iWUuQu4DgACvkHxNdf2hrLKP72K2TdjzZXk9Sz4N0z7RcKSOhr163t1t7VVWuV8DaMEhEhGScGuzlj+UqOlYSeup6lGHKjkPFH+rb6V5fqX+sP1r1LxMu5Wz06dKpfBv4Oaj8cPiFZ+GdNEiy3JyZAoIRQeSc0tHsFRq2pU+Bvwd8R/GzxrZ+HvDlm088pzJcMv7qFR1Zj/Kv2W/Zq/Zf8N/s8+HkgtYlv9flQfbNUlwXLei56AVc/Z4/Z38Ofs7+C4dH0iFJL51H2zUHQeZK3cZ9K6nxt8UNH8EafPPe3SxrGMu3GBgV2whZankync7C4vYrWM5YcDof51x/iPxtaWKMstwit/CDnmvjT4nf8FEvD8Fxc22krc38iEqNmQpx9RXyv4+/bk8Ya15w0u1ttNVsjzJCzv/8AWrblSMj9IfFHxQstPhluLm4jhhUEmSR9qr7kk4r5K+Mn7e3hfww0ltpMjeI79QQDGxEKt78YP4V8BeNPif4k8YTOdX1q8vQxyYWlPlflmuHmly2R8n+6eP0GKR0RbWiPXPi5+0141+L0so1HUPsemk/LY2rFEx7+tee+HfDd54iuPLtk2RA/PMwz+Xqa7P4O/A3U/ilqERbNrpQbEkzYG/2Gea+uNW+Alp4D0CwjjhjsbRlz5rDE0xHZE4bPvjHvXNUnZNI+jy3APEVVGrsYP7MfwBtYbj7TbWwudTTHmFVEsvPT/ZX86+mPFvwr03QdBkur8XOt3BAWHSLQH5pD081lXJGe2QPeqX7Ofwsk1TSlXVdbh8OaTJ++extZdt5de7nO4DHbFfQHiyPxTHpdro/gHTrS20t4tr6tfMN6gdTtYbj+VKEXKGp69dRwON9nS6M+dPhp4Ui0TUheeNtVXSdKsG3nTI5NoZz0RUU+nvmvqzwb4stdd8NxzeEtDkgtnJBkul8pE9+uWr5j8K3Hgzwj8QZW1mWbxdfLIFWTbvDSk/M3OBgegr6l8Sax4g1HwnKng+yXT7hY/wB015EoU5H8IzgfjTp6RLzu86sJW3t6Hy34w+GWsX3jG41PxZfQaWt7ckoHIkbYD1AzwDX0L4E+Lnw/sLy30OznHn28AQ3Kw4V9o7cZJ+leA+KfhV4hvvEVn/wmPiITX96/zrE42wx9SWZjgD6Cvo/4W/B3wX4a0yG80ZLe/kYc3rMspPqQc8U4XUnZG+ayw8sJTVWTbtpyqyPL/wBp/wCKc1rHptjoh8u0uEM0szwgM4B4ABwR+VS/s6fEDxD4kivnu4rnWTFhUjiKxxqP0yfzrZ+NJ+GpZr7Wp7O/1a3jMEKQSB3U9vlB/nWP8I/jJ4J8C6fBZ/Z7kXtw+ZZoYVwT0GcGpu/aasSjGWV8lKjJy7j/ANoG7+JjWYTQbNoLOZDuWzjDzIfQ56Z9q+XbTx5428ARnTbzw4nmbyzl7cvKc8nJUHmv0C+IfjnTdH8I3eqQyJPOluXjhAzISRxlQa+SPh58flsteMWpaWb6a+uQCyvhkyemCpqKnxLUMtlOthZ3pfCbWmeLzdeHba/hs76O7lhL+WkDhNw7Ela8i079q7U4dXnsNV0cXQjm8oG3P7wc9+a+1vEdvZ32gyQtLHYQ3ERAd3WMJkfUCvjXVf2ebG38dWVtoGryalcZ866mZleIAtyMoTRNSTvc5cJChW9pKrBo928K+PY72GGdRIiyKDtk5x7V7V4T1KPWLXZHIglXseM/nXy54q+Dtu2kXT6c8kc0kfG2dwqMPQV5JpPj/wCKPwRmjllmgv7KNsplwXwO2DyfwrVVOXc8mWBjiOb2TsfpCuhy3C/MigD+8uf5VWuvBSSLuUYb2UivkXwh+3tqfia4SyudPbT2UfNKzhM/nXdyftYaPYtC+p63d2jSnCSxzJIv1IHNbKorXPJlgq0ZctrnsN14RdXKhip+mapt4PuFz5coY9wwp3hH4tW/iSzS4hvbXXbJhnMTgTf988H9K9D0y60/VIwYpgh/55ycFfbpWqaa0OOpGUHaWh5ofCd2MnzE/KoJNCvYsDyxj1HFezrokLjnBH0oOi2MeTIV/PFIx5kzxZtMvFXBi3j25qaxutU0uQNayTQt6YODXsB0rSRyzR/8CcU9bPR4+ht8/wDXQf40CZxmnfES6jULfaf55xy8a/NWivinw/qPFzbTQBupkjP8xXTLa6W/C/Z8/wC8p/rRJo9rIpXyo9p7nBFPQkx0jsby2kisL5LiJlwbZiHVl9CtfNPxc8Oa98J9Sk8R+Cbmewtt2650lSTGB3ZB0x7V9H6r4NtQrPDG0MvaWH5SK4/xA/mRNpOuqvlyfLDeKefoSaT2OrD11RkuZXR5V4K+PGl/FC3h0/XCunatjEV6rAB27Ar2/Gut03VLrSb028/31PLc4PuOxHvXiviz4Q2z+JJdOt500fWv9ZaTcCC5X0PvWn4S8Yax4evo/D3jG2ktruP5ILzBKOvYBu49qwUmnY+gqYalWh7Sg/kfR9veLqFvuXLcdR615F8cPhW/iyL+2dJVRqNvHiaDA/eAd/rXf+G7wSWpXcCF/izWtJncHV2x1pyjzI8ujWlhp3R8IXEMkMzxyoY5FOGRs8Gq/llj/jX0P8ePhil5av4l0uELKnF1EgByP72K+f8AB5ORjPbpXmVIcrPucLXWIp3MPWvC9tq9u6SIuSODivLNU8MXXhm73qpa2B/u17fntVW+0+DUIWjljUhhjOKi9tTOvhI1E2ch4L8R23yGVVB/CtDxzrWn6hasi7d2PY1wvivw5c+H7h7i0LGI+lcBeeKriWcoxYHoa3i7nydbCypytJFy80WO8vfkUHJ7VuWngNWtd23JqfwXam+uFkcZ6V6TNCsNuEUAfhVnt4TCJxu0fPfi/wAL/ZVfAx+FeTahaeVckHtX0b48hPlyEjj6V4Jrir9pbHHNDZw4qmoPQi02Lp6V0MEfArE08DC4rdUFUBFcsmrnH9kstMI4sBunWmac/nXS4OeaxtQvDHkdPWtTws3nTL710w2JormqHtPgeyUqhxngZ4rrtW8NxXcOdvXpxWL4Lt/LgRhxxXcwtkYPT6Vpofd4ejGVPU8I8XeCwvmFY/x2155C1xoN4DyFB7V9Sa1osd7G2R19q8e8ZeDzG0rCM47ECnc8DHYFaySOn8A+L49QjjjlK54HWvTLnwrba3Z5VVJI9q+VtL1KfQb5CGICnua+k/hb46jvo4o5HHOOpFM+TqU3B2POPGHgGexkkeNCdv0rho9UutJnwx6e/Svt7UfBlr4i00yRxqcjOeOa+ePih8MGsfMdYyOpxgUXLhWnT1TOQ0X4gMu1Wf8AWu60vx1FMgDMv518165JPo9wyjcAp5FLpvjZk4LscfWq5bo9vD5q4qzPrS28SWsqgl1qlrmuW/2V9rqeK+e7P4iMi48w/rTr34gvNEw83r9ajlZ6Ms1hKNhfH9+s0kmCO/SuG0dVlnHfmodc11r13+br70/wxGzSBq1SsfK4usqstDtLG1SORTgHNe//AAYVVu4PlHUdq8Jt4yu0mvbvg7L/AKZb/UVnI4U2fdPhiZI9DX5RkL6V81/tGeIvKhuFL4GD3r37SZynh3OdvyV8gftHaozPcKX9awjuXLY+V9auDqGtMxyw3etek+CdPEUSEr715VaN52rMTz83c17V4SjC2q4PatZbHXhzqV4UADApGk2g5Gab5hTg9Ky9a1ZLWB+cnFY7nqNqMTD8XawIY3XdgV4tr1615MwBzXS+KNcNxIyhutYmj6S+oTg7SQTXRCy1PKqyc3oe93nxHDLgSBifQ1y+qeJrvUWIiLjPpXE+Hre41K4QPu+Y44r6G+HfwnOqLE20nPtispWR2TzCc1Y8nsfC99qYMkiyYrI8R+ETaKSV/MV9lXHwvi0XTiTEPu5OVFfO3xYkg03zkXbnkYxWkZHlSk5PVnz7Np4+3bQM/hXqXgXRR8hK46YrjtFs/tt/v29/SvavCelrFGrEYwPSlUl0OqhTOo022FvbqM4P0q1KytCwJqJcj5R0/KoLq5EMLk8YHrXPuz09ErHnPjsj94c+tcDo9/5V+oz3rpfHmqCTzMNxzzXl9rqZXUFIfvXRBM8ita59SeDdSElqi7u1dYr5HvXkHgPWNyx5bPAr1W1mEkIYHFEtDksXWkDIQeK848d2oZJCRx9K7/fjqciuI8bSAxyelC2EeJTXE1rffu2OM11Gm+INTWEbJD+BNZ9vZrdX2PevSvDvg37RCCU4xTserQwkqqsjkV+I+q6bICzsAvvXW+HfjN9oZYbh9uepJqPxB4AVlY7P0rzDXPC8+nyM0e5dvvS0Lq4KdPofRlrrFvrChkYMCPWszVvDQuVZo1O7rxXiXhXxpdaPMsUrHaPWvefB/ia31mKMb1yevWjQ8+8qbPP7prvRZjwwArW0fx89uAsj4+teo6n4Jg1q1ZlUFuoxXkPiz4d3Omu7RIxApaM9Ojjp0+p6Po/jqKdBmRT+JrprXxBDOoyyivlV9Yv9DmKSKwQHjmt/SficysFL8AdzUuPY+hw+ZR2kfTQvI5VBDCjzB9a8W034lJt5cfia37f4iRFRmRaXKz044ylPqdb4igWWykyK+a/iVaKs0n8PWvWta8eRSWrgOpNeFePvES3ckhz+taxi0eNjqsJp2Zx+l2oluMD1rrbHSFWZCV/OuT8NzGW5GBnmvQ7dfmTcMGrex8bK19D3L4K6XD58HA7Z4r67VYbLw7uVF+57V8mfBpsXVuB7V9TalIf+EbAzj5K5ZblLY+Rv2hvETReem/aOa+YdHhOoaqWb5gWr2T9pDUnTUJUDdT615V4GVWvFY8tn0raOwQV2et6Dai1tEA9K0JAev4U6xA+zrxjj0ou5I4YJJJDtRFLE9Kz3PZjLlicN4uuprVoo4IzNdTSKkcajcSScAYr9Uf2QPg3H8NPh7Ya5q+kwWfibUbdWcxqA0UZ6D618+fsR/s5QeJtUPxM8VWWdPt32aVZ3Cf6xv+ehHcV9w6rrghgdjtHH+cDsPauqEep5NapeViDxx48TQdOmJdYlCHLMwAVcdfrX5mfHb4ran8aPFVxZpdvB4atXMe2JsGcg4ye+K9s/a6+JWpN4Y1Kw0s75ZRtbacbV7mviXR9XS1VIGyrL1bIJP45NdByS0Oxj8E6Myrttl6bSwri/iB8M4rezku7CMtGgydo6V2Vjra+XgsWXPGa2IdSGxjGN/Yq3Kke9Mg+M9Tk23EittBU8gkV1vw9+H8+vSxXt3EwtC37pSPkb9a9i174B6B4m1VNQtvN0ydpA8sJAMUnPIxXsr+BdOs/C9rbWF1bzSnHnsE2raxAfwjrnPpWFXmtofRZPTpVsRGNVnp/7LvwvsW02Ge3hXUdThIADNtt7bP8AE3TJ9q9g+KfggaHo7z6IJdf8TajIts926ed5CnqqZOEHvxXAfAXwHqHjbTbOwilk0Pwpbvm4kR9kt/J174OPwr3H4lT+JZLODw54D0dYLV18qXVTIpEIAwT97JOO4zWVOLlDU+rq8uHx0fZyujy/4WX2lfBlb3UNeuY77UX/AHMOn2+JGYjqc889q+iNK8Sav8QfBRuxpj6HFdQuPImcec3GBgY4r5k+Hc3hLwf46li1IyeIdZW5EMLyODCp/iclj1z6mvoL4geItd8SeGbyHwLPG97Eux5nXaC3TahbA49aqnrEnNoKWJjO1r9XsfP2n/DPTfBPi21uPE+qrE9qxunt4yuFwcqhxyWP5e9e/eDP2iNF8VTXVpb6fdFYFAhEamQy84xgAgfjXzU/wm1CHxlZWHjHX1tmvR5jPDIXIHfexPX36V9V+BPBPhzwxocP/COLD5LJh7zeC747k+lRT3djpzh0HSg6rcpW0tsfKP7R+pXN18TLhnMkW6IbYSfur1wwr3/4DR3+ufC3T1j1S4sbcEqYbeJQGHcZPNc18VfEHgrRLq/htbq3PiC7ULPcWsauwXPOSxwateDf2gNI0GTSvDtjp7Xdsu1JbklQEPqcHiiLUZu7NcVGrjMuhGlSfunPePv2W31DWtR1KDXI7KxYGXy/s29lGMnJ9aZ8H/2adO16xk1a/wBQvZbViVhgj/c7gDjJ713fx+8bWr/D+/8A7F1A+crr5nkE/KM8jOK81+AfxW1lvEGNQ1NotFtYm3w7CxPHHA5z9KmXJzmVGpmFTLnNOyR7l4q8BNpfg3UrXw/bRrqTW/lRySNmQ8ep618qeDfgn4lt/G1hb6jYSRv5vmSvG6u6jPJIXpn3r3X4oftQW3hVYf7LsH1Xzl+W6nBRM912kZryfR/2qrjT9Wu9UFha3OpXI2kbCu1R0XrTqcnMrjyunmEcPN043Uj2P4kfCG713wrc6dDqk00wXNsL6T92hx0wMGvkvXPgz47+Hs8kttPG8zjmPSZXZyP90ZOK+wfCvxftvGHheLUL9YNMuX3FoVcZOPQZ5r5yuv2hr7T/AIoXWofY47xYWMMCyjaypntjrUVeXSzKyqWMh7SEoXsa/wAH7LxfHoM/9qaXq8yeaNpuiEx9AzBsfhXiXxI8TaiPiRctqNvFPFaTYht2UEL+Xev0C0jxAviTRbO8jiNs88IkZSPu5HpmvlD4rfAvVYfEx1iPUre4uby8zDZyBld/909PzpVYySVkY5fWo1MRUeIjZnQ+GPAsfjXw7b6gdHhAnjyRsXuOntXgfx0+C/iu11ZJ9K8OySaZHHkG1TcVx1yAcn8K+3NB+Heo2Gj2rNq1/Eq2oBs1KlVfHQH6+9fLXj74u+MNB1a+0PWJbmPTldo/3kQRtuez/wCFVLSOuhzYKMq2Jk6bukeXfA2XVNJvrq5kubq0jjPl+XscYbvk44r6Lh+NHi/RtNkOl6mtzMg3JDcASK2O2SRit34O614C8QaXFpNpZzJfSLlxcR58xsdc5Oa4f48fAfxCdQk13wffLBAkJMlijNGTjnjA5/GtItxhdanFi6KxGLcJrlZDJ+31488NyLZ6z4asBcbgqyEsgOfpxXen9qDxTqVhFdxWel7nXcYjE0n4AkgV8f8AhPXNPm1xz4qtHubouEL3LnEbD1XH8q9T8S6QdD0h9T0a4WMACRbaQ5jm+madOo5HDjcFTw7XMrG74s/b78T2N49tpMdg95E2yW1fThkfT5uags/+CgfjC7sTLFa6PcXEZ2yW7WQVlP0zXzzq3hOLXPESazEJtPkkPmSwRuDhx3BzW3DBZWqyyLbILxvmeWRRuY+ua64XPExLopWhufQGm/t2fEKdUlfw7ohi7rJAY/5Gu50P/goZ/Z8kf9t+EPLU8NNpNwVI/wCAk4NfHtzqjtlpD29q5vVNcXzV+UMF5wT1qzzbn6ofD39s/wCH3j6RIovEMenXTcC21pBE30Djgn616lqk+leLNKKSGFreb7siOrRsexVxx+tfg94g1L95JNDsjOc7QvP4HtXrX7P/AO2b4s+EupWtjcTnVvDpIWewuSXG3PVSScGkO5+lHjPw8bhP7D1TIuIz5mnagAcrj+HP+RXPQ6tFcab/AGR4usft1kDtN4nLQkd2xyPqMj3rqvCfjDSfjR4Ntruxmd4Lhd9rJN/rIXAyUNcj4yurrw3Yya19nW4+w/LqFq38cQ43fh1rKSW56eFqSi7I7LwvYPoJgSGf+0NIlX/RrpWDYX+6SOD9a7KJ9qkdVHH0rzDwLqlnqWnpqnhK8S60+QbptIlPBzycL/CfccV6FY6hHeRq8e5B0Mcn34/9k+v1pR1N68bSu0W4XibzLe4QS2048t0YDkGvmj40/CmPwDqCXNmXewuST2wh9DX0lICfu8Z7+lUPHHhGD4meD7jSZJfs92g3xyKo6jtWdWCkjpwOI9jUSbsj4q3AnGR/wGnDrwfzruviL8JZvh7pdhcy3yyvOGV4WwGUjvXn/m8AE5rzXBo+2pyVSKcNUM1Cxhv4WikQHcMdK8G8ceCBperNKgOxj6V70023kc1z3izS49U0+VtnzqM1UY2MsRQjJXe5594Nuo7EoGYAe9d3c6rC8JbeoGK8M1TWH0W4kj6bTVRviI7R7RJ7HmuiMWeT9cjRXKzqfHmqRyLIA4IrwzVpQ90wBB5rp9Y1ya+Vhk4PvXG3SOZixFRI8bEYhVXoaelplgD0roJI9sYArndNm2455FdHbsJtoJzmuKW5kvhsc7qdu75IXNbPhFWimTK4rdi0EXceQvFWbbQTZnIU4FddOQYeXLUPWvCNwGt0A6110ch2471554KuNrKmea9HhjLKDit7n6Bg6ilTHq25dp6Vg+INHS9hbAFdBtwuCKikhDLjqKR0VIRnF3Pnvxh4XaBndVK46YFZvgvxNPoOoRq7MFB7mvavE/h9bmJtq9a8T8SaC+n3LSKCSD2FO58XmGDabaPsf4R+Po7y1ijZshh6iuh+KWjW+qaa0yJyV64Br5H+FvjZ9NuoY2lOQehr6htfEia1ouxufl69aZ8rL3dGfFPxa0T7Pey4U9TXmEOmyS8DI5r6R+MmglppXVOuTnFeP6Tpqtc7CRnPpWi2MXucudDuFGRupn9kXROCWIr2u08JRz26kLnj0p6+C03fc/Si4Hjlr4ZkkcZ3c123h/wu0e0FSa7218IxqR8q/lWxBo8VqoJ20+YDibyw+ylRjFetfB6H/TIMc8ivN9adDdbV9fSvW/gzZlry3wvcVjIa3PrfT4yfDeOhCV8b/tGW7iS5OPU19vaXa50HBGTsxXyX+0VpK4uCVx1rGO5rLY+I7W6+z6i5b+9XqnhnxQkUIDMvSvIvEa/ZNSk28ZOaitdelhUAMcfWui3MOFVw2Pe7vxlFGhw4/A1wXiTxabhiFkOD71xba7PcfKHPPvS2tnc30mMsRRyqOpv7ZyJoVm1O5H3iCfWvT/CPh028Idl3cdxVPwf4PCqkkin/AL5r0FoUsrVgmOB6Vi3qb06elznPAVjH9tiDBcZr7c+DGl2ws4nKqePSvirwOp+3R8d6+1fhDIy6ahHGBWU9zz4lv4w6xHY2MqLgYU/56V8AfFjXHvtUkj35yelfYPx61Zlt7gFux718J+JrprjXievPPNbw2DqdJ4H03cyOB1xzXsmnReXAtec+BbZRGnbvXpMTBIxg1lI9igtLlhn2gkVzPibVBbwuN/OPWtTVNQS1hJzlvrXlfi7XmkZgG/WnFPqKpLojkPFmqG4kdQc/jXFRpKkwfGBmuwjsZL6TJGc1HfaD5KklentXTFo82cW3c3/A+seS0as+a938P6ks8C4btXyxpl8bG625wM+tep+G/GRt41HmD8TSkrnK9D2ye4SGNmLDOK8z8aausjMgfioNS8c7oyPMA+hrh9S17+0Lk/Nxn1pLQ0px5mkb3hq18+8Bx3r33wfZ+XbrkA5Hda8j+H9is7RsR1r3nRLVbe3XjipbPu8uo2RJfaLFdIcgA+wrz/xP4LWRWIi3Z9q9R3HPTiq91apMh4/SoPaqYdVI2aPlTxR4Ke3kd0XBHTrWR4a8SXXh2+RHfaucdTX0X4m8JxzRM20En2rxXxd4R8kuRHyOaq99z5HGYBxV0e9/DXx9BqMccbuD07ivYZvB9j4oscoisSM9jXwZ4V8TXXh2/VWOFB9a+uPhD8ThNHApfIbGeRWbT6HzUouGjOD+KXwdFsksggIwD0Ar5V8YaRcaHdNtZlAP0r9PvGVraeINFaVVy23ngV8I/HPw2tvdzFU4ya1htqI8UtfE91b8B2JHvWnD43u1Ay7H8az9M0X7RKVIxzXRr4HaRARF+NbaGka047MyrnxpczLjLf8AfVYd1cXGoSfxEH3rtofAb7seWR9BW3pngHDDdGSfcUtCHUlLdnOeENBk3KShru2sfs5XINdNonhOOyiBIx+FZ3iCMR3AUHv6VLehkz1D4Nrm+hwe4r6o1CEnw36nZXzF8E7Xfdw8dxX1rJYibw/gjolcz3No7H5xftNI8OrSHpzXlPhXU1t5lZmxiveP2r9HEN+7jg5r5hiV0ZsEjHpn+ldMVdWM+blZ7/YeNLOG3XzZFGB2JzXqn7Nvwl1P9pLxxAixSW3g+ykEt7eyL8kmDwgzyScdq82/ZV/ZN8TftIeJIN0c1j4UtpAb7UmGMAfwoc9T3xmv108H+DNE+GHhO08N+GrJbDSrRAgCAZlYcFmPvVqFjaVdyjZGktra6HpNrp+nRfZrG3jEUMKYAVRx27/hXEeO9a/s/TZSXOcYXnvXSX9w205wvsK8f+J2sF45VJyFGf8A69a7GSi5bnyd+0J4iaPQtbeYsZJgIIwDnlj6d6+TLfV3tZjk7mU4+Y817J+0f4qa41hNPQkeSfMcD+8fWvn3UGkjb5g2eu71qo6ouvTVNI76x8RI0q73YL1K54FdRa+LrWI4SRmLdFBrxGK+aNs7yKvQ60Y+hwO7E8/hVnGe+aT4qiupCJwzAdYmbGa25vEsMrxm3iFmo+UqGJ3D0r59h8SyLtWKUZxndzmtm38WSBFPmbm6YzS3HGUoO8XZn054Y+KmseGGtmt9RPlwqQsMjFkAPoK9o0b9sq+g0V9PuNEsMGExrNAzJyR94gd6+EI/GsisOQDjn5sVbj8cBI9pfcxPTIp2VrHVHE1eZSvex9G+F9e0qLxZZ3eoXbRW/wBp8+YogYkZzx619qaL+0N8P761ZLTVFs4YUACTRFAw+mOtflNH40lVhIgcEdPT9a07Xxu4kLF23Y5UYwazjTUb2PUxecVcdy+1+yfT3xe8TSeJPiLe38Fy81nIV8nY5KlB+NfSnwrtfEWr+AdEgD2cOhNGRNCkTifGegbHevzht/iJLGuTK0R/iGCT+grotG/aA17RI/Lsdd1G2RDhVW4YKfw5rOFFxbbPTxmfQxOHp0VTs49T6s8ZfsyPa6jq+uXWs/ZNJ3NKsUULeYi/3c4rovhl+zbp1tYwarqdzc6gJiJYIU3RoF7bvWvlCb9q7xc9lLZTeIp5baQYdZOT+orofDX7ZvjnRwbaHVfNhAAAuYg6gAcAdKaoRTuXLiPEyw/sos+wPi58ONS8WeEk0rw5Ba2g81TJHkruAHc965L9nP4Z3uh+J9TaW6gura3TyJPvZ8zuBuH8q8J/4bq8dxswjk05yRgkWozz+NZlj+2h4usbeSxs/sNtJcSeY9zDBtbJ65p+xi3c5qWd1I4eWHvoz7T8f/CXQPHFpFa6tAFELExrE2zyyep4FeQ+E/2afDPiXxVe20aahFptj8oY42yNns3WvJbz9uXxbc6ObOaz0yQvEYmupo23MDxxgda4zwn+094l8G3ayabcxv8AMW8uQN5Y596UqSb1NMJm9XD0ZU1UsfbWqfBnw9ofh+WytNODmNHMJZiZM47H/GviObwzrOm+LHlvNNu0drnCNNGTn5sDnpXoF9+3h4tuIxm00VBnmTyGOSOveuL1j9rLxLrmoQ3V0bLbHnbCtthc+uDUVcPz2sb5dxDLB88aivzdT6x1DRfEsnhmWO41HbbR2okgjtGWOUMF+6SBzXzBpPxk8W+HvERub7zL1rdyqDUkMmznAxnGPrVab9sPxxMyRDV44lC8eXaoFHpjmuM8SfGTVvFV1t1PUEuXI37jCqnPpxROjJpWZpgs9oUXJYiF0z7T+C/xe1H4ji7W/t7W38sApLG20k++TjFYnxe8RaJrHiCDwtqDWgEwHn3lwEYAHj5W7Gvi1fH8unqHS5kRZABtjZlzzVG98bwzN9oLNkZxucsze3JrRU7x5ZHmVMzpUsTKph1ZdD6kg8N+F/grrkeo6L46sbohGY2dzG8zewUorD8zWV4t/aa1LVtMhh0m2jsL4P8AvbjGQ6egB5FfLi+PAQ7ttVR90BRuH41nTeOHjj3n942cqGJzVKmoqyOCtmlWvP2ktz0LXpNO1G6a+u7KFLiQnzZIyd7n19qo3WsRNapGXlkWMYXdLkflXnTeMpbx2a4Gdv3iTwR6Vjz+MNzHysLH2QVcYRjscFbFVcR8cj0a88QRw5UnYF6leM1hXuvLJmTcMjsxrz+bxI8YaRiJGJyMmsy98SGfhlU596s5DtrrxPuZsyqo6cGue1PW8KD5ma5SXVnZiAwA/wBnNZU+ozyEhW3+1AF/WNY8zcFOSe1Y9tvUhzu65x2rRsdCu76RHML7CM9a7DT/AAxEsY8yPHH8QoGfY/8AwTx+KU1xZ3/hqW43SRf6Vboz5PB+YD8O1fXfxGkjtpo7iRFl0+8h8u5jxhWRhycdsZr8sPgv4mk+GfxO0XVbV/LjW5VZFBwCpODn86/VHUfL8ReGYGjZZoScqx/usMjBrGXY6acnFpo+IdD8fan8I/iTqmkabdtB9juPkYklZYycqfyr7K+F3xe0n4lRxxv5dhr2PnTcQs30HrXxl+1P8N77wzrkHi+DJtmIguVVTgEdCfwrG+H/AIwnsbi2njk8tkwUkRiMHOQcVw+0cJs/RY4WlmGHXL8SP0pS4DMykFXU4INWbO6+y3iPjPOOTivKvhd8R08c6ahlkX7fGAJNp4f/AGhXonnsFU9O/WuyEuZXPisRRlh58kjiv2jfA+s+KYbDUdNRbuK1OHt1j/eY/wBk186eL/Ct74V1BIbm1mtxKglRHToD2r7300C+09GzjK5yOua+YPjX4R8Waxc3v2qOHUE0wmSOTaVkMR75xziuepT6n0eWY5uCozsrHhDEBsdD6VBdDfEVxkEU1r+BCQ0gXnoTUdxfwCEnzVx9ax1R9JOceXc+fPitpojvZSvy8k15Tb28jXGNxK1638VdXiub5wpUjpnNec6Zi4uBwOtbxufn+YNc7szbttAzahiucisXWtJEMJOMV6Zp9sraePlB4rl/E0arA42461lPY8yJxOlQktzXS2yeW6HGaxNP+/getbbTeWo5rgknc9Onsej+FbaO6t+epHpWxqGip9nZgvI9BXGeEdd+zsqMcV6Qt/HJb8sDuFb0zK/LK5y2h3D2V8oPAz3r1vR7j7RbggjpXkuoLHHOXjbnNdN4V10x7Iy/PpXX0PqsuxUbWZ6C67jjvTGj4psVysy7t1O3huhzSPqE1LUrXEAeMr/SvO/GXhtZo3cLnOe1elVQ1CyW4jYEZpHPXpRqRZ81zQy6PfeYOgb6V7b8NfGTXVukRk5Axya4nxt4bAMjhenIwK5zwrqkuk6gq7iFzzzWi1PzzHYdwd0e0ePtPTUrZ2A3HHpXz5eW503UzldvPpX0XYXS6xpwx82R9a8k+IXh8287SquT9Ks8KzT1NPw7eCa2Q9eK3lx6V574R1Ex4QnPtXfwyeZGDUsCwNvYAVHcMFjNN3e9QXs22Fh1GKm1hHJXxEmoDvz619B/A3TzJPCcZ6EV8+2qfatUUdRur6y+Bej7VhfYeAKzmy4o+hI2FlopLDb8nrXyF+0RrCMbhAwPUV9QeNNWXS9Fcb8Hb0r4M+OHio3l/Miv1J71ENTWWuh896/Y/btSdhkjOKhg8KtJ0Q/nXX6LpYvptxX7xrr/AOyYbOHJAJA9q25jaFFPVnnum+DTuXII/EV22i+G7e3Ks4GfeqN9rEVocZA/KsW48Z8kCQAD0pamy5YHrFrcW9qgRSoqlrmrRLav+8UV5O3jd93+sxj3qnfeLnuEx5mfxqVF3CVdWsj2PwbDt1CMds19lfCtCukr/u18h+CYvM1JOMnPpX2V8L7Mf2WoI/hrCW5wx2PIfj6z+Vccnoa+INZkMetSFuma+9/jrpqtDcZ9DXwV46h+x6tIV9fWtqd+gXSd2d/4N1qKCNMtniu2m8UxRxgqRXzzp/iJ7ZQCxA+taMniqaRcKxI+tX7PudUK/KtD0HxF4sEhcK/JriWkl1G4x1yaz4Fn1CQHBIJ55ruvDPhklkYg5+lLSJd3U1L/AIZ8PbYtzrzjvVTxRarCrqBk+wr0OGxSys89wK4DxJL511sHRjipT1uVNNI8zk0Wa4uCY1bOe1XodN1C2IwjV7V4B+HZ1srtj3V7Ha/AITQIzQckegrTmPOlufI8Ok391DkqwP0qouk3FndbpQ3XvX3Ba/s/qtqSIMHHoK8l+J/wrOjpI4jO5eeMUucunLlkmc78O7gJ5QJHGK940qZZLVcNXzD4X1BtNvihJ69DXu/hXWPPiVSccCk9rn3mXVlyo7Pd6GkMhFNjIZc5ob61nc+kTu7kU8SzRsGrivE3htLiNiFBz7V27DNV7iFZFxTuclWmprU+YvF3hU2c7yIpGD2FP8A+LrjQ76ON5CAD0PavXvF3hxLpHO3OfQV4h4g0N9NvDIu4bT2rVbHxuOwbTckj7G8E+OBrGkpEz7ty+teRfG7w8tyszouQcnNcl8MfG0trIkLS4HTk16n4gZdc01v4iVpaHzbulZnyppFulnqO0gH5u4r2LQdNt7i3U7V6eleeeK9HfTNSZ1XAzmut8FapuiRS3OKog6n+x4FP3Fz9KmWzijxhFH4VPxjcD1pR9am4Ecke2M4rgdc/fagFxn5q7y7IjgZs9q4BwbvWFA5+akB9AfAnTszwEr3r6i1KRLHRGLDgJXiPwF0XyoIZNnavRvit4iTRfDtyxfaEjP8AKsnuaLY+Fv2rvEcd9rzWqEFt2ODzVv8AYx/ZLn/aA8bLc6o72vhjT2El5IBjzOf9Wp9+9eSeNNQuPG/jSQRsZJZpxFGqjOSTgCv2K/Zl+FMXwW+Duj6SsSpqM8S3F0+BuVmGdpIrrgtDKTVz0jT9E0f4e+F7Tw94cso9K0yFRHHBAgHbkse5qs7CGFlJqlPeySXkjStwvCg1Q1DVNqn5hWpUYlfX75Ugc7ucV88/FXXBa29wzyKuFLdfQV6j4m1wsjYOcV8w/GbVDeGaDzNocjPOOO9S5WPQo0+Zq58r/ExZbi/juJ2Pm3BMp3dcZ4H5VyF1p8d3bFccgcGu08aSJrUkt5vCwo3lQoO6jjIrkYyY+j4+tXBpo5sZFxqanC6nayWb7QjEZ61nNeFGwMZ716Y0cF4pWZFese68GQ3zP9n+U9TWp55yMt8y7CAuelWU1KRFGGC/SpdQ8K3Nmu3HmehFYklvcW7YeNwfcYoA111B9+4Pz33Vai1h1ywbA/2cVznnHOCv1prXHUKdop3A7CPWmwCXcf8AAjVmPxE0fdjn3rh01AjgnPpVuO4Zl3ZwPrii4HaJ4kCsD8zH/aY4H5Vbg8THy9kknJOSQOBXn/8AaAXHzbvWpf7UWQBc/rRcDv115FZtitMx5Jfp+FWhrjuhZ3aFTwTnpmvOV1bb8qkjHcHrUn9recyq0hwDnk0XA9EHiSONisIWY4PzyMQAMY7VIuuCDARzEqn5tvO44rzj+1gylAPbOe2asNr8jeUrOEVc/d96Lgd9Dr0rpiaVgvAVec8nPfpU0muNIuwBUjUZ3M2T17152uvFlfc7npwDjpTG1Qlt64AXpntSA9Dl8SO6qYyGTDD587T9O9JH4haNgQ+WZuC+Sw4/lXANrcgOA5ORgH60Lq8jHJkDMOhNO4zvV14qyESvI5AyTkAYJqK68RbcKsmWx9454wa4U6s2CTJ8yj1qs2rMcsW3HGOtMLHoP/CQN5RYTbkOQSc/X+dVbnxVvVTKwQ7uGHXHpXDSawRyHwD/AA5qKXUFkjyflJ9+KBHYv4kUuAvywjkZ6knrzWfc+IW3Bgdw6DNcv/aAbocVBNesejZoA6OfXprhdpcKi/3e9VZNUbywDk8+tYavNMwUBj9K07XQry5VQIm56EgUAH9qHnrUH252OBkZ6V1Wn/D53jD3MpUdgMV02l+EdPs9q+V5knZnFAHA6ZoGo6rzHDIFPViQK7bw94GitNr3QMknZWA611trFFZZRz06BRxUc2qwx5wc/WgCX+zwkceVVAOMDtWfqE4UuEJ2rxzUF14g371LbQBx1rCl1Z5lCAhvm6ZBqXLlNIxlKVkLNcMtxGVPzK4Yev4V+pv7OfiQeMvhDpd3JJ5s/wBn8puerL2Pvivy6XS/tFml7bnzVVsMoOcV9r/sH+Ohf6Rqnh6SZXeEieJCcnr81Yc6kd8sO6auzov2ovEX2XQotJurSK7sNUHlSNID+6ZeQRXx54VupLW8uNPLGZ7cl1xkZWvtX9o3wXfeKIFs9MiW4uEmLwqxxweTz2r5J8aeA9V+F/jbTNQngVHjRJZ4FIO+NuG5yR+tcNWLctj7vK6tOnhozv7x658KPHNx4b1a2u4pW2BhuUnHH0r7a03WYdW0q2v7dlaOZAQVPc9q+FNY8KnQ0t9ZsN8ujXiiWNwM+UTztP0r234A/ERmtZNDupA+TviZjkn6VVOTi7DzXDwxUPbUj638D6pv3WUoPqrA1uatZxKGnaNZA0ZjdWA+YY6c15j4e1TZcQTxtgq2Gr1Rma6CMDhcZ6DrXd8SPgv4UlY/IT9pS6vfB/xB1O6tI57fS7i4cRq2cKwPIryef4mXL2+DcE8dMmv0X/bM/ZzXxZ4L8S6vp6KskaLeoig7vMH3vzFflzJ4UuMlShTHB2isnHuejXxk9oMZq/iCXUpSdxO73zWr4dt3ZVc561DpvguRpl3Bse9eiaV4Z+z24+TgetRoeNUnKbvJmzpce3TwTnpXJeKl/cyEV3lrbbbPbiuR8UWxNvIMetZSZcNzzK0nKytz3rdt5DMPm5rD8jZKcLznmtGzkIO3OK45tHpw+EvLdSWshZeAvvW7p/jhkQRu+fxrLjtxNHjGc1RutGlDEpkfStYHLVehs6j4qxITuyD05q7oXjALMpD159f2Vwitndmsq3urm0mG4t1rs6FYfEum0fWHhrxULqIBpMV1sN0JlBBzmvmnwj4ueNkUtjHvXsPh/wASLNGuX/Wpsfe4PGRqRsd2snUU/JIIPeqVrcrNGCDmrSnkUj2tGjA8RaSLmFzszx6V4zr2mPYXxdQVwa+g5o/NVgT+leaeNtF3eY4XP0FGx8/mGG5o3RL8PddZlWFmzxjmt/xdo6X9i7BcsBXmHhe8aw1BUJxz3r2OGRbyy653CtVsfAYim4M8CWN9L1QqTjmvQNLuPOtwc54rnPG2n/ZNSMgTAz1rS8Nz+ZbgMccUmcpuscEYrJ1q6MVu2Dg1py/u65LWp2uJhGpzzUiNLwLYtqGrISufmr7Y+FOljTdNSR0wAo5xXzb8F/CbXN3DIY85INfUGp6knhrw7tOFO36VlLVm0VocN8b/ABuLW1njEmMAgc18L+MNYfV9Yk5yu7Gc1678ZvHEl9czoJSSScANXjOl2JvLoyFCcnPNLY1hFtnReGtN8qNXx2p3iS9McThTg10GmWQhgHHauf8AFFkZI3xxSO+UbRPIde1mQzFfM21g/aJZmA3sc1q+INPeO4Y7cjNUdPiDTLurqjseVU5uYmt9NnuOQW/Orn9gTMMYauz8N6ZHOoyP0ruLXwrFJGDsBz7VRnc7j4eWhmvoyBnkV9kfD23+z6SjH5cLzmvlz4SaS81xAxTg4r6ttNuj+H9x4+WvMk9ToieSfHPUI2jmUMMYNfCnj6IXWpSbRkZr6g+OHije06h/Uda+a1t21bUCW559a6IuyuChzs42Hw5JIAVB5rY0/wAKMSu8HHvXpVr4dhtrUM6A8Vn3k1vaE42rir5mzoVOMNyPQfDsMOMgfjXfaTb21qoPy5rzVvFSW5O1h+GaiPjnr+9xj3IqXFmqqRjsen65q0cduyhwOK8yuL4XWqKNwI3Vlaj40MqEGTI+uawbPxBt1FXLDGe9UonNUqpn258AbWBjb5wM4zX11ptlZ/Y0HHA9q/On4Y/E8aOsR81SFxXu2m/tDIkaD7QB9CazlFnNzH1d9ng8soqrz6gV4z8XfAq6jbzOqAgg8gD/AArB0349RS4/fg+uTXRn4n2GtWbI7ryP71Sk0x3Pifxx4Vm0LU2lCtjd2wK1fBviMqUVn5HHJr2L4kaTY6ssrKuQec8Gvn/UbUaNeMEY7c8c1vZtHrYPE+zZ79o+ppdQj5ucVo+Zt5zXjfhbxdsaNWk/M16Zp+rJexj5hms7H3uFrKotzYMw7mo2bOe4qDdupC+3vRY65W3I7yFZYiOn1rzDxp4dEyyN5YPpXp7Pt79ay9XsReQN61cThxFJTi0fNyGXRdSH8IDV7T4P14ahZojsDkY61wXjTQDDIzBMHPXFV/BGsSafexozEDOKs+GxtDklojrviB4cS4haUJyB2rzvQZ5NPvhGx4zXu91FFqmmnHORXivirT/7N1TK8DNB42q0PRrG4EsKnParBYdua53w1eedbrk54xW5uI+lKwFLXLoQ2rc81geD7M6hrS/Ln5qf4ovPlMaHJzziu0+DPhtrq+hkKE5bJqRn1J8K9LGn6Oj7cYXNeL/tYfEAWOkzWMcgaSb5NoySK91vNQg8M+GWLkKFTO49uK+Idfa/+OnxktNB09mke4uBAjDJABPzH8BUxTuOWx6N/wAE/PgAfiF48fxlrVuZNC0V90e5QUlnzwvTnHWv0s168ZIdiYSSTrj9McdMVjfC74c6b8JfAemeGtOjVUtY/wB7IoA8yTHzNxTdQvPtV5Iw+6vFdkdiFG5Bd3HlxAM3IHX1rmNSvGXPzcflWpqVwADz1rmNSuNsbEntTOqETk/FF+LeKRi2OCa+Pvjl4xazjvmR1wvylmI4B619LeMtUMrPGrgLgs30r4g+I+sWvjb4kRaZbv5ekWchaaTOVkcdc+tc87HuYSk5u5d8D+B5fF2nza3qG63hMLRWdouOBj7xrzjVbOSz1BtwwFJU8enqK9X0v4qCa+TQ9KsmRWbyIZVA4PT8BW1c/Bm18UeJpLEazbrKgD3Hng4PGSRt6sKiFSzsdGIwEq0W5K1jwT7YtwmUKNtPJTqD6GrNrfGOORmb5VHT1r0b4kfAfWPBSz6jZh9T0XoLwx+W4H+0pAOPevI9xjkDF/8AgHHNdykmfKSotGo155m0mNQnbbyfxqVfst5lZIug43LmsQaiIN20EPntSJqEitkklz1NVcw5HsXrrw7p10SAPLb1CkZrJn8BQzMfLmx+Faa3nl/Nuyx7NViLUPMA34HpjvRcizRzTfDduSstVLjwHeQZEbFh713SXG5N/Yepp7XTStjfgY4pgebN4Rv1UZTP5VWk8O36g/uSQPSvUWmNrCHzvOelV5L4SEMVGD1DYoA8vbSbpcfumH5H+tMbTbrp5TmvUVktVzthBfOB8uamWSFJVWW3TOc9OVHrQB5K1rdQqcxuPbvSeTdbT+6crXqlxZ2kgLMATj7oGT17mmW+lWd0vzqYiRx270AeWlbpWH7p89KsLHeyqQLd8j+6DXqz6VYNGoZF3KclwOtTQw6dDgjywOpyT9KAPJEs71Q263lAH+yaeun3zZMcEikc8ivaGh0zbJst2lkwe5wMVX3W0WSsXl445Oe1CGeSx+H9VuY2IgkYr7Vaj8F6sy4MLIPcYr1MaokLMuw7enykCg6/zvLrzwFwCaoLnm1v8OdVkYE42dfmxWj/AMKyuH+/MuAOi44rsZtYWQ5Y7FbjkioW16KNTtlyFFAjnLX4ZxR8STFm9K1Y/BFnBGSVVivXdUsevxtIoDMjdmpW17au1vnJPJb0oAmh0m1tSTHFGu0dama8jjYbFjIC54HSsO+1wCNyu0eZwRWRNrBds4AA42jNA9Ttl1lfLCqVLHkj0pW8RQrEQki+Yf0rgv7RZm3KWHYd6Vbp5MAFjj3ouh2Z2FxrLSLkvn3zWPcam0hO0k89qzVmP3Gk2nOPmzXU+FvhvqXidDNHJbWtuo3edcSqoP05qJStqb06DqNIxbaO51K7htYFMs8rbEVTk5PQYrv/AAn8NYdVhnjvbq6t72Ftk0bqBtPpX0F8E/hfoUPhqGOSC2ub7due6g2vIjeuc03x/pMGheLgkkmb27i8xzgL5uON31xXJOXMj3MPh/YytNe8eeaf4btrXRZdKaONJF4DlQGYetYnwa8UTfCL41abPGziF5gksZOAUJ5zTPiF4mvdL1u2ZYRFGgGM4O5fXisTxJq1nqmqafqltE8d0mBK2DjjoawjNR2PVq4WUoe0a3P0q+IF0kUVhq9pEtxHtEkag4DqR93ryea8c17SdN+KkMF3dWrWd9CsunmFjnZg5BIz7103ww8WSeOfgmxkKy3mmoHIOS2Omc1ynxWtdU0vSNH8W6Dyl/tjukQZ/fJxu/EYreo27MjAQjLmpSdmU/hhdJo8V/4W1qL7Ra2zeVJFLz+7PQj2qv4s8DXHwz1iDVdPLT6PIweOdMYQddufT3qD4rapc+D7nwn4zubfyFukWDUIeisp65HrXqug6tY3GlxQXe278OagoEEs33ISw4RvT2rKWr0OqnWlSvF6o7PwL4iXWNPt7pHBWRQW9m9K920PUWmsLdhhvlwa+P8ARln+FvigaZOzS6HdHfbzE8LzytfTHgrVDNpiqpyoOVI7g110nbc+cxtPW6On8aaQ/ijwzqVlausc88DohcZXJHQ1+Xnjb4WzaDrdxbXtsIrhHYOFUbc57Yr9U9NuPMO1sDHNfOP7W/w7Mml/8JJZW/yx8TlR930J4qZ76Hl8zPhy38Mw27AhV/Kn39ukUO0AfgK2p23NkDr3zWFrDt90d6wJ3JdNtPPtyAvFc74s00Q2r/Lg813Phm08y1XjPesXx9AILZ8dcZNZyV0bQPArqPy7lu3NRbgsgxz61LqM3+mNn1qpJIo5B5rjcdT0Iv3TpdHnXeA3NdVb2kV2n8NedafehZVUniu70S9XbgGuiETgqPUlu/DKTR8KPwFc1qXgsNk+XXpNrKsijlT+FXGso5lAO3n2rqMDw5tJlsZAQGGK6HQ/EctjtVyR9a7rUvDcUq8KM+wrjdU8NtCSRkfQVXQ7KOJlSdkzv9B8ah1AZx+Nd7pWuRXUa/MATXzWJ5rCT7zAD3rq/D/jFoWRWcgfWs7H1mDzJStGTPoJW8xeCD+FYXiLT/tFu574rL8P+KFuNo34zXVSOt1b4BBJ60j6KU414aM8QvLVrLUt3QZr0jw3eCa1T588etc34s0/y7hjt4zVjw/dG3gArRbHwuPo2uUPiFCjbn71j+F3AjA71reMrpZrViSK53w/eJCmdwzT3Pm29DptUvPJhPOTWd4d0aTWtTT5c5NVZpm1K7CL8w9q9o+FfhGKMxXEycDk7qiWhcdT1f4aeH4fD+mxzyoFIXJJFcX8ZviKY45YYpAUAIGDW9408cR6LprW8DAbVxxxXy5408Rz6teSYdjuPrmotc6Yxb0RymtXkmsagzEkkn1roNB0kQxhihzVTRdHLfMy5bNdZBCI0Azis3uehSp6aj41CKFxgVQ1SyW4ibIz6VpMBtHNV550jQ8qaR1SirHlnibw8m12K7a87uIvsFx8o4z6V694pvInR8ED6V5bqMRupyqdc+ldELnk10tTa8Pa99nK4P616Vo3iZW2hmX868y0PwjeTRhgjEe4roDot7pyhsMPoK0ucJ9n/Bnw+MQuUOABXo/xI8QJpukvEHC7Uqn4Ps49D0cSOMFV44rxz40eOt3nRiXb1HBrh5bu5v5HiPxS8RNf3siK+fm9axPCmmmRg7DJJyay7qR9W1LcSWGa77QdPFvbqSO1a3srHXRgyrr1x9jtyo9K8f8AE2vSrKwySPavXfFFsZoW5wK8X8TWDLMx681cWhVk0YH22a4k4ZgD7mrtrZ3Fxk5/nVXT4V84A8mvRPDelx3G0ED8a6VY87U49dDuCvc/QULoMytkBvxr2q18JxNGCEX8qmbwap/h4rKWgHj1vHfWqgBiuOnWr0esanHgB2IH1r1BvBqDqtQv4KU/dWpKOHtPGWp2rD943610em/FvUbPaGkcAehNW5vBakfdwfpWdceCsD7mfqKWgHUr8ZHuodkp6j1NcV4m8Wm6cuDx25NVrjwlJH90Y/Csq88MzYIOfwqh3tqT6R40eC4G5sc+tet+FPHRbyxvz+NeAT+Hp7Zty7s5q/pOq3Wny4JbA9aTtY9fC450nqfXml+I47heXANa63SSKCGzXzdoXjySNVG/H1Nd7pPjwSBQzrz71nY+uw+Pp1I6s9XzmkI3cH+Vc3p3iiK6VfnUVuQ3i3CjBzQkz1IyhJXTOb8VaUs0bttH5V5FcW76dqJdTgA59K99vrcTQsPWvJ/GGleVMzY7+lXc8LH0OZXR2XhPVDdaeisc8etcr8R7EMfOVeaXwffeSFUtgdKveNNtxYkg5xTPh6sXGdjnvCNx8u08HNdVd3QggY55riPCsxSYgeta2sXzTN5SnJPpQzIpw2smraqAvzAmvqD4TeG002zindcBRk5ryH4Y+EPtFxHNKhx1r1zxV4wt/COgyqrIpVM9cVDLicn+0l8Ul0zSpNNtm3SSjbhDk4r0z/gnh8Cjp+m3fxI1i3C3d1mLTlmTlR3k5r5j+FfgTVf2jPjNZRLGZ7KOYNO7HKJGDk96/W3R9ItNA0Wz02xgS1srWJYooo+gAHXp3rWK0IkVvEV4bWxJHEhGByD9a5JmMVsOOW5NXteuzcXwQNlI+cVz+p33zEZxWuyNoRKuoTFlJ9K47xFqJhhcnpjmti9vsK2WwK868VakZ5jGXKop+Zh0A7k+gqW9DshFnhfxz8V6lb3dnommnE+pjfKw/gQV83+OlsNGuIdPsgrTRAtPNnlmPUZr2a98NeLPiN8Qtb1ix0e5g0S2HkxareI0Noqr1IdwFYfQ1d8L/Cn4exxx6v4q8SfafLmy50ewluA3PRm+VMfia5ZK+h9bhYqlBSscH8IfhLrsuly+L5EXS7CFCIb+7BRc+iddx/CvoH4FeGdcupJrzR9PhbUJzifV9SfcirnpEgHJPrivUtB1TwD4yj0+aC41U6dZoFtbe602AWyY7lFcnNO+IGta5JbnT/Dd7Z3aupK22nCa1mx7KUCn6bqUYW1PVp42GIj9Was33PL/ANoywvY9NltNQluma4GMW1vKFz6fMgBP0Jr5u8L/ALNOr+KpJp5rXULe3HKgooZx7fNX114C+G/hrxZ4jsdO8WnxFp2qzMFEOp6aUSRvTdnJHvX0Je/sv+F/DNnLqOi+HbC51KBGMccbTWry8dNwfGfwrWEZXueRjpYOhD6vHWXc/Jrxl8DfFPheZmj0PUbu1yQJFty5H125/WvNbiG7tbh4J7aSCROCsiFWB9wRxX3P8dPFEF5JLpV7o/izwTcbG32pvWlidh0O5jnH0rzX4f8A7NGk+MdQiu5vGWl3Usi5awy5uSx6A527j7DNW6mtjglk0o0fbSeh8x27MBlhkketSxsVx3PXrX1h8Qv2Q9RstBnl0KKO9vQw228UBiIXPOdzHJr551z4T+OfDMhW+0OZT2VUVifwBrT2lt0eHHBuorpnOec4jGPyzTJL6ZGBLkDsuK7fw/8AB7xRrhX7RpMlhG//AC0uV24/4D1/SsLxn4LufCesHT5G+1yqoy0akqM+5qvaLcwlg57IxlvB5h5zxk5Oajk1FS2W9eMVrR/D/W5IxL9lYhhwMgH9TWPqnhvVtJkRbmykRnPygAE/pmq9ojm9hK4r6w8jFgxUDsp5p7akzQqB87H73Hzc1SGmX/8Az43OM9oW/wAKabWeE/PBJHz/ABIw/pRzozdKXYtpesCSSqjsF6/jUjXzzKuXZtvb0qtHbs2Dhj69cfnVjy40wGZVOcH8afMhezle1hRevGhwSPWmrqTJlcIu4Y3d+uaWSFVX7y/nVaSJOctj9KOZB7N9S42qbUOxmYnOckimnVi0ZUjy8/7ROao4TaQWBx71C2WHy9PrT5kLlb6F+TWnYkDkVWbVJG+6+1f7p61Qdjux3pI45p3KxxtIfSNdxp86Dkl2LbXzSdR+NV3unz9/A9M0Pbzw48yF48/3lIpsdrNNII0AG44+aiVRLU2jh6kug77U0mASwx0OKcJHYjJbnvXcaZ8FtUurEXtxdQ28GzzCyIWOPxqz4Z+GtjrU0sbaizFW2ptXG79aydaPQ3jg6ktbHncjleMnPuaTqu4ntmvoyz+AFn/Zk22wae4KERtIeSe1cbD+z/4g0m+tnvLa2hE0ojijmmXLsTwAM1Lq6bHVRwDq6NnAab4H1zWlVrTTLiZW5DbOPzroR8DvFYjEs1paW8eM/vbqNW/Abs19z+AfgPZQ2lidVkxdMqoYVk2rn0HNdh4w+Enw9+GPh+41u98OW99eqPkjupd2W7EDPalzXjc9HC4On7ZQlqfNHwH+AdvFp0dx4hfRYZJWBiW5u0Ejc/UkfjX1lY/Aa507SAI/BcOu2ci4229wi5U/3ScV5t8I/EvhufWoNPfwbpWoC6uPnkuYjJIoPZR1GK+0LXwzbpp5jsrDW9NiRMKtrcAL07Lvz+dFP34noZlg1gK0dLHxdqHw3/4QfxRCNNg1XwRHP94a1NvtM55UFM/zrofjn8KjqPge21jy47+4tdrWmqaMzXMWT1RgoyM+44rb+IXgvXfB+sLqmmav4g1a6Mn/AB6atpMzxopPJMj5jwPqK9w8AaJbDQ7LU9Rgh0fVJYds/wBmULaT56b0QlB9anlWqOrE1IxpwxC17n5N/ETRNXlA1G7t8eTlSFB+X6074fTreQXFjPbeZGV3eZg9T0r7J/as8E6daeJI7uBIY0vots0cagwv/tKwyPwzmvmdHg8OtcWEvk2tqo3RSnGW9q43DllqzVYmVahycp63+yv4mSz1q68P3TERODEwY9VbODj619K/B2zg1TRvEnhW+hSSSxuS8ayKMgE9hXwD4X8bQaB4+0rUbK8C+ZIIpSp9Twa+zo/Hh8EeOtG8RxAPp+s2ojuIxyu4cH8q64yTPBq06kZe6tRf2qvBq6p8J7+Exfvbco0e3GVwa+f/AIFfEv8A4R2Z/C+uZfSpT5O6QZ8pv5V9ofEq3tPF3gG8ltHSaJ41kUqCeM5r8/fHFvDpXxIfTVZV+2xmSNj0D+lRU0eh24JJp06m59VeKLPbp0enXcoubObD2F9uyyHHCMR19jXpv7PN9dapY3elyTK91athfMPLD8a+Vfhv8VIxYv4Y8RlpLRm2QzOSDE/QZ+navW/h7PqWk+LUWKVmWJP+PhSP3ifwk+p96qMzmxmHlFOMj6+jtLqzk2TJtNGq6TBrWnXOn38QltLpDG6nHcdefSrHh/xAupaPbySMJW2gMreo9BVu6toZ4vMgZo5P7ma6LXR8xJcuh+anxe+Gt18OfFt7YOubUuXt5MD5kzwf/wBdeR6o5e521+iX7SXw7/4TTwfPdxwbtTslLLtGCw781+epsJJ9ZkjYElWwcjBrmlGzEdp4Vs9lirFe1cL8VbsQwuA2MA16dYwix0vP3cCvBfi3qxaaVQ+RzUM2ieOX140l1J83f1qv9oY98/jVeVmkmJ96nith34zXPI643toSQ3ZWQYOK3rHX2t8Dfn8axHsPlyKzrjzbduDW8GjlqQlueo6f4s2gZb9a37TxcvGWFeJ2l5KzYyfwrobPz2UH5sfWtdDDlZ6/D4nSTuGBp8l7BdoRha8ujuLhMAbuKuQ6pKuOWBoUkDhLsdPqmkw3C5UYrlbjTnspiy8CtKHXGbAY5FPmukmHrVcyKjKUWP0PxBLaSKGcgA16z4Z8UC4RQzZyPWvDbjbHJuBxW5oevG12/NjHvUbn02Cx1lZs9X8U7ZYS4ArhrvWhYxH5qfqHjBHtcEqTivLPEnig+Y4DcdsVaTDH1ozje502ueKllgOWrmbXxRsYgNxXH3mszXi4BbFVV89Vz82Ko+Ukk3c9x8F6xBJexvI2efWvoDTvHVvZ6WEiYA49a+J9H16WxILMwArrbb4hzGMIspx9aTXUqJ7L4w8YPqUjjzS2TjANcpZ2JupBIyk/Xmua07XRdvukfn3rol8QQwxhQVFc8ux6lFxSuzpIYRCoAGAKdJdKgJNchdeLlVMbh+dYV14wMjFVb8jS5WdHtoxO5vNbjjU/NmuW1TxIXLBTt+lYwuJb5+Gxu9629L8Km8wW5qlHU46le+iOUuGutRcqoPJ+tdd4L+F8+qTRPIjHJ9K9H8J/Du1/dl0H417h4Q0DTNJjUuq4H4Vr0OLWT1MHwV8C45raPMXYdhWl4m+BMKQNiPt6CvSR8RNP0eHbGyjHHUVy2ufGa1kDKXX86kdkJ458Vpo9g0UbqoC44r5K8f8AiKXVr6RVctuPZq7L4keNpLyaWMSkk/wg15xp2mPeXBlkB59eayWiOiFPmLnhvR/uyuPmrs41CKAP5VWsbVbeIADAHtVjeN2Kykz1YR5UQX1qtxCw6mvOPFXh8fM2zn6V6ZJIsY5OK5HxRexMrrx0qomFaKa1PGLy3NncZAxzzXSeHdeMLKCcD61laqpup2RVzk44q1ovhS6YBwrDPrXVGWh40tHoer6P4mRkALqfxrqrXVYZkH3a8f8A7JvbFQcNV2z8QT2b4k3Y6Ch2IPY1aJlBXaM1IqBuymvO9P8AGAI5PT1Nb1p4qikUbmA/GpZR0bW6HsoqJ7RPRT+FUotdgk/jWpv7SiYcMv51OoDJdKik6qv5VQn8PwNn5QD9K0jqCHow/Ok+2I38S/nT1A5i88JxyDO3j6VzuoeDQM4Qn6CvSGu4gPmZarTSW0n901QHkNz4fmtT8gZRVZbi6s5BlmIFes3FlazKcbR+Fc9qHh+FslcH6Cg0jUlDYydH8ZTW7BWYjHqa9H8O+NhJtBfr715PeeH2hYsmfwplndTWMwyWyKR7OFzBw0bPpnT9YS+j4YZxXP8AjCzWW3Zq4rwv4qYbVdgPxrsdR1KG6sWwwJIpWPqHXjWpnFWNwLOQknaRUviDXFNg3z9vWuS8Ta0LGZwGxzXF6x4uaa3KCTPrzVI+LxkeWeh12l+JUt5HO4Zre0LV4r/UlLsMZ9a8KXWJNxwWHvmtjRfEktjOrbyD7mqcVY84+2PDuvWmm6aCpTO3jjFebfETxJP4kuDawuWVjgjPFeVw/EybyBCJscetes/BHwnN8RvFWk6bC2+e8mAfocIDkms7GkbH2v8AsM/CWHwL4Dl1uSExXupHCuVG7YO9fRur6ktlZyEAZ+pqlpNjFoOk2mn2qqsNrGIkCgdhg/WsfXLpp9sJ4LHJraMbakatmZHny3mYnfIfWue1i4A+XGWJ59q3NYuFgs+DtCrXEtJNdXCpGGleVgoUA/hz2ptndTiVb1pLiRbaAZkY4G44H4nsK5m18cfDvQ/Ey6VcX1v4k8Q78LF5g+x2z/7TDg478msX4/eCPEOuvYaL4X1GOGSGJm1OYyMgVT/tAHmvJY/hLo3hGO2utduYoraCLJ8yU+ZcueMsAThPQEAnuK55TfY+lw2Coypqcp3bO2+KHxa0Xx3qT6bp2nxeJZoG8t5GVvswI6iNVZVVR6kc14l8dvFV7punaZps96hunUPHZ2SKkFuvQHAA3H610Gta5bP440/wr4Uj8qyysUlxargSTEZwSOqqK8+0/wCHuoeLvi+1heNdXdnDOQ90ynBVTz16DPHHFYybex79GEKKbbPY/DnjC38A/C2xu5F+1zGMZVmAYsfx4rg7v9pax1bVNNlnsJ4FtnJYRtk7u3Ib1rtPin8GZtT0U/8ACPzi3kiQH7O8h+YLnpivHfCPwR1pdStdU1FII7CFGnkPmg8AE7SMdzUtzuc1OOFnF1ZPU+gfCX7Y+v6TrWn/AGqSPxH4eknWFLe/iBkRgOSj9R1x1r234jftSDTfClrL4MN1bT3GTcR3J81bf6E1+b13fXdr4o8PRrNGbK5vGlijQH5cnpX1BZxrJb7XVSjDlSCfy5rfnly2PGhGhTxKnUV4kbfFp/GGvW8njxJfE+ngmMxqgWTB7AjqPYV7t4R/Zl8F3k+k+KfB89zpEyv5y299EZUGR02sAQBXmHw10TwPpuvJc+ItPvS28eTd2s3EB9SmMYr6Y1TxLd+E/Bt5r1jeW/irTLVPMRkhVbhU9MDjiinveTPWzPH08Ry0sErfkeXfHTxrf/C3RTFexaZcavdbhaT2ZeP5R/E0eMA18reFfG/iLV/GUE7abH4h1G4fYZGSTeq5/h+bHH4V9FePvjp8OPjF4fNjq+gztfqh8ie6EaqjEdm3fzqf4H/s2aHot0uttqMeoTSplLSGcDywfXa3PFTNuU7I6KGHo4XAynWp+8Qax4Z0/RbWO71i+j09Gx+8uGAwSM4Gcnj2rw34h+LfDja/F/Z6jVLWA5mkiXy0lkHTcccgfSvsXx58HvDuq+Ebq1jlXQrdnEk9yfnLAdsydPwrxn4ZfBHwLceLJI71pNWcljb2vnBgVHV3C5wD6E5pTunyo4Mvp4X2csRK78jzzwFHbeJNNutRvrOSWVmYxWtnAzoiAdN+3H8q+ffiXevrfi27mtNPmtooz5UayE8Y78V+qkPh/QtN0WTTFis9L0+VCPLSRYhjGOCSOa+W/G/wB+Hdx4mtrLRdSKSSSFriaa4+ROc4DEgH8KmUXtc2wMcPWnOfI/uPIvAvgux/4Rq1/tDUIDqDJ5hAk+YL6VyvjLXfDmqWz6ZEskjJJiWYKFxj2xzX23D8HvDNvp1vHZW1jcm3iwskZWR3wOvHWvln4yfs0aouv3Op6ZPbG2k+fyJFKle+BVO8Yo8ujSoTxDjU07GR4Vv9H1LVbPSbaziuUaP/AFzRDj26VzXxY0m1j8Uafo0NraWqSOpdhGq8Z6k1V8C+G/E+g6+s1lbSMYzzLtPlrnsD6V3uk/DO78U/GvRNO1+cXUt2Vml2gABf7tY87aSPRlgKMKknfRGF4k8LeDvD7mC8ubITtECm+IuDkcHI4pfhr8N9N1DSfPvtNsbuSWRijoo5Xtxk11X7Wvwli8NfYbvRrQmxjLJIsalmUj1NeWfBzXH0zxVb+dcNFaxoxMav1444pym4ysc6y2nUwzq0zpPij4H0PRLGBY9KtbOSSQYcxZ6VZ8M+EdI1qMLZ2ljK0eFfbCM5/Oqnxu1o+JLrTha7miCltp4OfYV6L+zr8NdY1zRC1mlrAGuAJZplYSBfY+tONTmla5nVy5U8IqrOP8VfBrwzdxx3OqPb2iQkny48RM5x0x3rB8CfDbQNPvLu/eeG1g3fuocMTj1OK+pviF+yjN4iurKXRri3gSOMif7TK43P/erhPCv7MM+qard2cviG2sZ7Z9szMgZD/uk4zWknJOx04LAYSrQ5nPUy/wDhm/Q/ibpQuoofOUHaJbZgGBx6cV4+37NF4vjC+0rSJVnWy5f7YM8/3QQetfd/g39n298I2T/YfGd5Ir4fyoYY0hOPcZJr5y+OWk6/8M/i9LfWd1dbr0owmkRUhlbGCM5xVTVlqYYWlTlUnTpT+8x7n4beINN8Kz21xb6e0a25QS7iPK45OD1rxXwj4eEGuQRfalWKOUEy7QSRnsTz+lfoLoekad4y8MRTTxx7pYQtzHE4YK2OehrybxP+z1oXh3ULW5spJ42knB5/hGfpUyhezOrBVIe/Tqx1NLS3t/sYTTrcX04QYUowLceuAK8h1rWfHOueIGitNHZGtZfkWKEMUYdyx6V9h6TosiwxRxIpVEC+YR6DvxWV8TJI/BPgfVNTjRPN8sruVT94jvircLrVnJgqipYhxdO92eKfD34S+N/GGsW2ra3rD6fFFKrI8svmEkHkAA4Br6Y8TfDvw/N4Xng1a5Edqdr3l7cuA745xyflH0r488C/FTW7jXNLtZdSuLDTopB5q2wCkgnnqO9fXN9pN18QtHuLXVFFro08ey2t428ySQEffkOOT+NTCXNGyPTzSjVw9eEqloo8L/4Wd4a8G+OPN8JadDewWiiK1jjhLiRu7Z+8a97+E/xO+KnifXIbi/0RLTQSmXedPJjT3ycNXg/xc1zwT+zPpel2tjaJf66s3ntmQedhegOAdqn6181/GT9tn4i/E6NrWPVZfD+kbdn2HTW2b1/2mB5q6b5N2c2Z4yhWppRjd92for8bviHo3iDS/wCybn4h6DoOHBm+zrJOxx2ODiuU+HvxGttH8R6ZpGl+LdK1uzk+aUvp4towvs4yS31r8pLf4l6tbRyh5muYmyDFMdzfXJr0jwX8dtT0Tw79iWNN7kPbySpjy+eeQO9XKXU8fCOUqfsD9SPix8GrH4haXfXGi3HlzlCwitZlkidhzyjfdJ9RX5c/GnwBrHgjxZNb6nbXNqZWOI5sj5s8hQR/Kvo7wp+0E2oeD113TLk2esWYWOfTzcFDIO7Jk9a0PFH7Qlr440O1iuobLxZpVx8ktvqkJ+1WLn+NZFGcD+lYz5Zns4RVqF4SV0fIOiaal9p0yiJobmHlWxtYH/Ir688BaxD43+ENkLht8mlTJJJtPzqo+V+c/jXFeN/hre6H4ds9XSK3l0i6O6O7tZPMQH+6xx8p+tcx+z340Fj491bw8/FrdqyMjZ/i4PB7UR00OKu3Ko2tz6mtZL34Z65Zafc3JvfCeuQtFDOAXRCwyoyD1Br5B/aE0+6sfiJZzorb4QCso77Tya+h9XtdQg+Gcs2l3k18LaUwz2MrbjbspwGQ9vevJvHOl3+r+Gba/wBSiJvLWJo1lZfvg8gU5bnTSiuR1Opn6hpq+INEg1qwO92QGRU746mvRfgP8SrmXVodDvD5m5CsEwPzcds15P8AAXxF9rg1DRHfLwSFotx4I7rXouheH49C8faZq9sgiXzgJYv4RnripS1JqVYypuEj7f8Ah/eSy6UQ8jMyMRnvXd6bfXEa8N5i+ma8y8Gw3htZJLUL5cjZPNdtp+m3e4GacL9CK9COx8TVXvOx0U9xbalG9tdIFVhtbKnGDXw98TvgjJ4X+I19LEheynbzY2GMYNfa3kBWYeZv4rkviJ4V/tjQ5nVd88KMyALyeKiUVYxPg/xtdLpVvJErgY4wK+WviBftfXrkHPNe2fFjXpH1u9t2BieNihWvEtWs2n3SMCa5DphG5wjW5jkyau2+3ijUEWKQDOKbb/MeOa55HXBWZt2Fj9oyAMik1Hw+VjYmPitPw6m5lBA610OrWsYtm9cVcD1HRUoXPLrK1SO624716ToOlxXEK8VwFwu29+X1r0bwjnyVJreWx50aajI028LwsPu1Xm8IowGBiumVht60qsrdcVkdXs4tHEXXhV4QCvFUJdLmt+oLDpXozBMY4/Kqs1vCwOQp/CncxlQizza4td6nPBFYl3NLZNxytenXmjwyAkYrjfEOj+XG528GtYyZyzouGqOL1DxM6qVDEfjWF5kmqXCqc5Y+tO1q3KTEZwK2PAtilxqUYI7itbnBUlJ6XOs8IfC6bUlRvLYhvbNeiR/AtjBkxN09AK9u+Cvg60u4bcso5xX0ZD8P7D7KBsU5HoKXM0TGL3PzX8S/CGexVykT4HpivLtT0e40eZgd6gdiK/T/AMbfCm2ntpXVFHXsP8K+QvjB8OxZNOdgyM9MUc1xNNanz9Z+IXhUAMTirLeJZZmxub25rD1GzNrdOnSr+i2f2hxnmrUVuaU+eUrInbUruYcFgPrTLc3Uk3O6vQdF8IpcRg7APyrfh8BqMERg/lUuyPYhgKlRXOP0G3k3KWzx616Zol0LONS2PxqrbeEXhxtTH0xV0eG7g92qeY1WVVDo7bxoLFfkZc1Hd/FC6I2rJx7Vhr4XmbruNTR+EGJGQ1LmN45TUK9144vrpjmRiPcms+TVL25zyefrXU2vg8d0LVqW/haJeqD8am5308otueeRwyatcGR92M55rorOxjtYxgDNc5a69bQRrtC9KJvF0ag4Kj8ay3PDjKMUdabkL1wBVS61aG3XJYVwl54zzkBsfjWQ2sS3smA+0H3o5bkyrxSOq1bxSMMqEZ+tcleXVzqTFUJyfTmtfTdB+2MpeTP616B4Y8F2+5S4yfpV2sjhnW5tjivB3w7n1G4R5UJye4r3/wAK/B+OWJB5XOPStnwzotjp8ak7VCiu4t/GVlo8ICup/KpMNGcHrnwhgit23IM49q8l8TfDWK1ZmC4x6Yr3bX/ihbTBgWXH1FeX+JPFNtfb8MoJ9xVoORvY8K1rTjp0jDcwA965xvE0lnJt3cdOtegeJLIXzMV/8drgNQ8KySOcK1WivYVHsi7a+Nj3f9a0I/HBUffx+NchJ4VnRcgOKzLrTbq2HDNxVDdKUd0elR+OD/z0/WpV8ZO3/LT9a8jW4mWQBnaug0tXmYAscH3pWMkm+h3v/CVytj5ifxpV8SzN0Y/nVCx0QzRg8mr8fhx8kAGpckjdUG9SaPxBO3fNTJrz5+Y5psfh1+cgmkbQ3j5CmlzD9gyZ9QWZeeayL/Egyq4q41jJH2NRSQsvBWqTRPsZR1RQs9WNo2CdpFa0njIww7fM+XHrXOalYsAzLkH2rjNUvJ4ZCN7Yq1Zm8cROCsa3irXvtsh2ndk9RWDZ6fNqDgLuOar2pe8uAu7OTX0L8Ffhmuu3VurJndjPANGxyVKjmzy3T/hzd3UKsInP0FF98P7yzUuYmyP7y1+inh34C6bb2KeaigkdlFUPE3wBs7iF/IUEn2qeZkWdj82pra5tZQrDB6L16/Sv0R/4Jm/C+dtP1fx5fq0sZY2mnrJgDP8AG2K8H8Zfsy6pe+PNE0q3gcLqd0tuGUDjPU/lX6j/AA58B2Pwx8D6R4a02NUtrGER7wMGVscsfxq47i1R0Mz7YwWJ4HeuWllM1zNcEZC/KtbGtXTRW5QfeasG4/0ezCj733qtmsbs5zxNdMxSEHO48jmuD+JXxE/4VH4XtdRt44bjxHqkottLt5wCIyTgyMvoK6q883VL65jhk8tlhdzKeiYU818c6xa+J/i5qOp6yt0bpNIH2Czkd9olk3feHHGPpWFSbWx9Tl2DhUfPUlZI9P1T9oy10/Uk8OLZtqmsyMRqF5DGAtxcEfLGo67c9c+leSrofiTxZJ4i1vxPavIluGNvbu2BNdMdq4x0Cj8K6Hw/4HtPh6lvqGsXn+nW2Y4tr7mubyTr1GTj8q6HxJ4r0fTZtK0G51SMai8oe4Vj91+uGxXPdvVnuuUKEuXDxuTfD/RdO8FaXo1pOkAvdPha4u5OhaaXsSfarHhfxPaXFxqkkFsEj+0MoVWyfxI96+a/iF44k1RdVW2kmjmutRZhIrEAxqNox7ZFQfB+w1/WPEEsWl3LC5iTzikkh2vjsfWs3P37FSwM6kHVk7XPo/4ifFq08H6eont2nuJoiEVWAAPT696810nxvLJ8LZJFTyWume3RFPOWJycn2rz747a3e3Gr2+n3yRreWygSJEOD71n3DX3hIeG7a8mSTS7lvOSLptYjqfzoUnzMwnhYU6C11OQ8VXo03x54Xts7YoXQ844ya+v9O2SwRk8rgYOetfE3xTvlb4hCa3CtHaPGoC9ARya+wPBupDVNBs7guqKYVZpGOABjqT2qz56W9jqxIsS8R/j3/Ctzw34i1jw5MZtMnMAZcPDNzE6nqGU8YNeT618YNE0OZrfT0bVrlTgsrHaD756j6VyerfETxB4kUq8/2G1bj7Pb/LkehPWsZV409wjTd7p2PSPiF4d8L+IdaaW0vbXRNWu2Be0MiGzL9yPm+UV6V8Cfgz4l0HxdZ6pMNK1mygjZo0ttXVo92OOAcj8K+V44FjUjy1AP3iTuP5kc1YtbiaxcPaSywN/ejdlP6HFcMcZGLvY+inmWInQ9hLVH1z+0r8TPEen2MXhvVLOx057pPMmNozSB1zwNzdT+FcN+zrdWEOtaheS6xp2jXscIWO6vpAFjUnsCcE14VJNNqL7rmaW5b+9PIzkfmTSNYpgrsGKmWOUp3sawxlOGDeFhDV9T6N/aA8V+ENR0qzitvF9vrGsqxFzPBbu4IwPuqMKK+db86cGK2mtzSt0/eWpjX8dpNU3tBH8vlqB/sqP8Kh+yndjyyfw4rGpjXJ3SJwmYVcLHkSue5fAXS9X0PxRZ6hxrdqUYCHT7yORk44yjPlfyrsfj18VLOz0G3SC0uLa5vHMVxb3UBjdVHBAJ6/ga+YbbTZbe4W4ti1pcocpNCdjKfXNanjbxZ4j8Z21iutXn9pSWcflpNIi72X03YGa7KeOi48rIi4YjFe0qaHvfws03TNR0eODTYZo2jAZ4LqQPtz34J4/Gt/UoNI8BeN9D8QXNtvvJ5Psa9cc9wK84+AXjDS/CWk6lJLIh1CUqI4pH27wO+SQOKw/j54kvvE3jLTJrC4K2EEayxiOQHy5O54NdPt4KFzOdFfWZWl7h7/8AGbVLSx0U28rrFNfSCGNZMc568kehrn/Df7OPhWGOC4sbSJ7gAM0y4fLnn6V82eMte1zxdZ2MN/cy3kttKGWR249M9e1e+/s2eKtO8OeH9Sk8Qa15IDhUFxJgYH90U4V6U5ahUoOjhb0qhP8AE79nuPVfs919rgtobOJmkZVC7j9avfDfxh4S+EPg+KI3pu7yWQM0HmAsMnGeM8fWuM/aC+J2peIZo7Hw/rEH9jv99LdjvPoW9q8Qh0yR23XDSTyE5yzE4rCpiqdF+6bQftMJ7OvK59m/Eb9prwj4Z0maztLiTU9Turc7UtcMsRYcBs4/Q18jL4/1HzJmcybZmLHa7IQc+zVmS6bJu+SMLnk7EwD9f/1VC1hM3ylGIHtxXBUx05vRHFhKn1NONNaM+ifB/wC2d/wiug2emnwrJeyW6bTO9+3ze+MVa8Q/tfeGvH2my6Z4n8EyPbSqVEi3AlMZ/vLnGPwr5nks2j6ow/Cq7QnkYxn25q1jp7HKqcY1HUW7PtrwP8ObXxZ4Btn07UnsHmgKhrSYAyAHKb8H71eK+Ifhl8U9F1aWY2WoTopKJOZhJlPXHb61wvwx+KWt/C/V4bmxuJ5LBWzLYb8K47ivbPG37Ymk+JfDEllY6Xf6deyELIk2ySMJ3UHfkV6ca8Ksd7Hp4PFyw1blcbpnJ+BfCvxK1rUYbiO11ELC/wAkk8hESkHnPPNe5+Nfhzr/AIi8I3cN7rRvbu5iGLXaFhjbHTPr9a8+8A/tZeFfCel22mvo99DaxDDGNg7c9etN8ZftxaTDDJH4a8N3V3KeBPqTqqj3AUnP4itlOnyWbMswxtX28XTglY4KD4N6h4D+zX2vTJFbPKvmtasAIgD1Yk4/Wur+K37X2neHdMTRvAzteX8cQj/tGZSEi46gYGT7189fET4ueKPiVcM+u6nJLBnK2UXywL9AAOa8/m2nO0nHuTx+FcPt+R2iPHYqWPUZVlsUfFGqX3ibULi/1K7kvb2ZizzTMWJJ56noPauFvlMLOCcgV2d0uA1cjrymJXYVdGTb1PFqwXLoc7jdKyqPlPOc17b4Ls7fUvBcERt45WjGCWH3a8MZv3mT2716JofiGXT/AADK1ncKk4uNjANzivQlscuFlL2nunp2iwwfDvxRaXk1kNQ8P6kAkqkfdY8E57DmvaLr4VxeD7jT9c8I+ZYTud/mqTJEcjIDA9VNeKaP4sj0/wCGVvfXduLx1ba0bHknPBr6A8E/FrRvHvwzbRv7XtrDX57ZoIrbeA2ccDHc/SsND6V1K1o8qPTvBPjK213w7qNpr2mw28bAjVdPVwYZFxjz41/hI68V8ofFr4Z6h8E/ilp+t6ZcLf8AhbUMTWGowgYKN/Ax6lhTLH4uapodvbof3WraQWtbqKdhunjJwQc8V1tr4usPiZ8N9Y8K3MU0kkCNe6VJGSfKcclMemapTT0KeCqxvUHv40vNK168ntJ/9E1CATNA7fITj5h+dek6XrUPjz9nktFaxy31vNJ/q+ZEABzu9gK+WNH1yfWvB/38X+nnypByMrnB4+tez/sz+Ln8Gvqr3UXnaXeRPCfOcBASvJ9jT5veOmOHUqF46s8N8IXsvg3xDZ3wJQSSkOD3ycGvqC3mj1a1inRgsiYb5e/fNfN3xahtrKaW4th/orEvHsIwMn1r0n4Q+L11jw7aOJA00I8t+5rWErnj4ik7u598fB3VBfeHxk5ZcHnr0r0uGcdCMivCfgTqEkmisF6cHrXtdgxkXmuxeR8nXTjI01VFfjvVllEkZXavHPPf2qhLJlkwKuR8kd/xpnMfCf7W/wACV0vxRL4hsYWFpeHc6qvyq3cGvkvxFpot4yOnGcV+wPj7wjB428O3el3WMSJhX2/Mp7Gvyh+OHh+7+H/iq/0XUB5c8LnazDBkUnhq5JxszuoySWp4RrkY+0HAqnZOVk5FWdWuBNPwRjPamWcfzDvXHJM6FNXOk0u6+zqDnB61LqniDdGRvrHmkaOM9RXLalqMjSFQzVrTsbyxXLGxvQ3SyXO4kda7rRdUS1hHTpXmeg2NxfyLt3DmvVvD3ge6uUTKsc+2a6JR0OD293cn/wCEkeQ4UUJql1N91WH4V3ei/CuVlDFG/wC+RXV2vw1jt48ug/IVnyor6xJdDx5Wv5v4WH0qRbe/b7wkr1+Xw3a2Y+6v5Vk3cdtDnG0fQ01FGf1hs83+wXzdQ+PcVlato9zNCwIavRri5jyQMEVnXG2ZSAB+AqkkmHtJy0PAPEXhuZWYkH8qzvDV42k6mm/+EjrXsPiLRPNViBkn2ryjxBpUlrOz7CCvpxWuhzypT3sfYnwR8fRRRwKXUDA6mvqvQfFtte2qfvF/Ovyn8GePrjQJYw0jYHvX0D4R+Pnl26B5uR6k1Mo3Ji+Xc+4tW1K1NnIS6kEV8k/Hqe1kW4K7cc9Kral8flkt2AnByPU14V8SfiodW81VkGT7moUdQlNNWPKPE5U6jJtGOat+GcLIu6sG5uHu7ouTuJ966HRYSCpxg1t0N8O7O5634dukhhVhtrsrHVosAMq15Zp9wY4QC1asepvHjk4rB7n1mFxihGzPWre8tplAwoNXo1hbBAUV5Lb+ImjIwxP41rWvi5kwC2fxp2Pap4yEtz0nyYzjAU1L5aY+4pribbxgrd+fetGHxREw6j86DvjXpyR0fHTYBR+lYg8QxMOCPzpf7fi9RUFe0h3PlNfEkhXbuamtql1L90MB65rL0+HzZVDc5r0DQfDyXCqdoNaPQ/LKVGdbZnG+bdySdG4re0eGaR1LBq9Ai8DrLGpCbavQ+CjGo2pz+FLmPS/surLUq6LN5CoW+XHrXW2visWqDawz+NY6eFphxz+GKsJ4Vkb7wbFLmuaxymZp3HxGuAuA5H0yKx7rxleXPHmMfxq5F4OO7oa0rfweiYLLupHZTyh9TkmvNQvG/ix9at2uk3dw3zbufeu6tPDcEPJTNakOmwx42ooouj06eVxjucTbeD3kwWyfrWingmNV5UE+9deI1UAYWn5X0qbnowwcIrY4W68CxsnEY/DBrkNd8BoqMfL/AEr2gsOwzWbqdvC8LllXpT5mYVsHBxeh8reIvDpsZm+XAHTik8OzbZFRhXe+PIYg0gUAdelee6XCVvMjpmteh8ZiKKhLQ9b8PmNo1G0H8K6VYYuMKAfpXHaDMLeNSW7VtS6uqdHFYSKp8ttTaaJAv8P5VDJHGF+6tYX9ryScA5+lHmXNwdoVqnlYSqRiaEyw9woqhPHAfQfSpY9HupeqtirS+G5MZbcKrlZk68TktWhQRtgcV5t4it/mbAr3O48OxeWcmuM8Q+GImViBk1rFM4qklLZHk+jsIr5NwwAa+x/2cdet7K4tjIVXpyK+StU0oWMpcLjFdh4A8ePos8R3/dNanMj9XNL1CC+tY3jcMCPY1ZYbshRz14xXyD4D+P8A5NvGjygdP4sfzr2Lwz8eNK1jULLSo5PtGpXUixRQorMxY/pU8pd9LHvvgLwzb6jqy6pPbiX7HkQsyj7x7/hXqJXamS249/SqHh/Sxo+k21uf9Zty7erd6sX03kwsQfmqthGBqUn2nUtp+4gzXPa7eOy7EUsx6KKj8aeLE8G+G73W57aS4ii42op5J96+Q4/2nta1rxyt35n2LTbXezwRgkbccbqidRR3Posuyqtjo80Oh9O+I9NOg+DL57mZob3UsW/Bw21jyo/DNeJ+KvFnhf4cXMvh+ytTHpuhWv8AaF0VIzJIx+RSe579TXlWrftJeMfEGrhLe7+2afbXH2pU8vLNGvUD04rl/EWi+I/iU/8Abaxt5fiC8zIseMJGh+WuaVTmPo6WVywv8d6Gl4h8f3PxR8ReGDo+mSefo8cmoSQyEEZ3Z3Yz1xXLaXpc/jrxp4l1PVILmJvs00xXYUAk6IBnHevW/hz4KfQfHur6iyLHbhEtII1UZwgwx+hrX1LxBaPZ6/dCWDyfNaMFSBg5HH/1qz1e5rLFKnenSRlah8MtDm+Emnf2vp7S3unWgctanbLnIJBIz1pPAPgvw74ZvTqel2twk8kWFE8hIRTz0xXB/HbxdqlloOnx2l3NBbTqfN8htu/joMdqu6T42l0P4fw6nbCO+uIYFLwzyEtjpmqTimzL2dedHfc1PGnwp0vxd4/mvNQ1CSMyxJJFFABg7eoIFeSftDyW0PjfQNJgDfZ4YgCpPIyev6Vdvv2gNYn1VbqOwt1u5IxbBF5BBPb3qlqX/FQ6pL4j1i2xfNA0cakcRlR1qU1c568KtBRjU6I8K1q2W31i6CEuiyEBmPJr0+88eXOreGdG0m1la2gCBJkUkbj6Vwcdj9slkdvmcsXJx15q9DIYZrOIjb5bZpyatoeDNa3PQ9KtY7dV4AHTaucfWtq3nH94cfpWLYuPLANalpCmSfX3rwajfMz0Y7GhFcJMMo2e1adlZNPggYxzVHS7FFbHTnPWuntwkYVRwK5JDuyGHTXXmrMenlm+atSyWPgdfwrVW1jO35CfwqQ5jn1sEzgLk05bJQ3Kj2rd+zxtdCNQQ3firS6TjOEyfpWchcxzf2RWbG2pF0mOT7y5HpXTQaMJGyyYrSh0i2jwzjcR0FSO7OHbwvAVJSAhc5IxkVHB4dHRVb5em4Yx7V6ZHDAq/wB0HgLWdNZr5jAA46iq5na1x8zONj8OhuT1HNS/2GGyXIGTk8ZrqG044BHy/hS/2WGTljn6UK4t9DmTocajdzzx90f4UyPS0jbIXP4V1aaV8nKkiqsunhd2PxpPzHsYf2FWPGKZ/Zo3E9zWytnlflpn2Vo8np+FaLbULmFcWKkbSgP4VlXOjpJn5f0rrprdetU5LVdrHOKPQXMupw11o/ln5TWXcWLx9s/hXaXkCqxJGa5+8miUNkgCto36C50c46lc57e9UbhefetO+Ty2yp681mySEH+daq/Uu92yjMpPbNUZFO5q1jNH0B571QvsdRWi0E9jFulPP1rmfE0Ja3JHbrXT3HesHXWBtJc+ldlPdHNUV4s4CX5i3b3rf062RvC7zRqqSR3IWQ+oPesScCTOBgdK6/4eyWrSyWl0I5EmdMJIRg88/WvWldrU83Dtxq3PZtN+FP8Awk3w/wBPl02/FvPt3OspzHIB268Vj2fwf8QabDPqCrGY7OP7VG6TK4baeVBzkcdK9St7zTfDGg7ZytnYbdgKkhcEeldH4F1qz1rwrIkRBs/LeJT0Djnnn/CsrI+iWJqQTsjx28+G4bXtCv4VnfTtfTA80fNFNjO1s8dhzmvdvhX4RGi3Wh63ZxmRllWO6t9oxsJ2SL9O9P0mXTrzwza6M8itdGL7baK+Mq0Z5H0rV0HxpFpV7FAXjWD988rKchTtB4xTjFRdzZ4ytUjypHzn8QvDKfDP9oTxJocURh066uCYo2wP3UnK/rXsdx4L0vX/AIQ6XZ6DMItYExEkLMCx28kkfSuc/bCis9T8ReCfFdjOkjalZeU0ykHe6N3Prirv7P8Arek3XiIJqLxxie3ePzd2NkgH86090xw9WoreR5b440ee+8E6gHXFzp5yyLwdoOCQPauI8J69e+Eb6KWxkKh1DPG3Ru/SvoDw34AufEepa9BHerdebPJG0J+ZzEwOCD+FfO/xA0Wfw74ih05BIkttuX94PmOD1rOJ6WOUZNSXU/Sf9k3xCNa0J2cKsmwMVHavpC1VdpCNjnNfDf7DviJ1sZLe7lzOQdq57AV9j2OpRx8OfL9Oa9Cn8J8JjKf7zQ6K6Vlj3BskVYspMIpJ5rHm1izWNAW8yRj8gz3FQf23MWAER59BWhxcjOsaLzCG5298d/avjv8A4KAfANvG3gtvF+kQN/a+lL+9WIf6yH6e1fWOn6y5XbKhC47jpU94lnq1nNCwWaKVGjkjcZDKRgjFJ6ozacWfz9SSMkxB428c9T71pabNukXnNe2/tj/ACT4O/FS+NjGx0TUibq1bAwATyM+1eEWmbdxnrXBUijqp6nRXSq0eMc1yt7Y/6QCB3rpI5PMXJOap3VtubcBmogOdPmOy+HOmxyTw7kHbrX1x8O/CNi9nG7qvHNfGPhvWzpMyEfw17T4e+NLWFqsfmBcDtXUtUYcrifSOsXOm6HA23bxXkPi74sWtnvVHHpxXlXjr41S3cTqk/LZ7mvIX1K9125JLMVJzySaVi4RlU2PWNY+Lb3EjiN+tc9/wmF7fOfmbFZmi+E3kILKT+dd1pfhGNVHykUj6DDZXKerRkWt5dSYzuNbVrDctg4YZrobXQIbdQePxFaMdtGi9FOPapbPoKeVwp6yOYm0uSSMlvTvXnvivRxukyufpXpmuaqlvGwG3IrzbV9S+1OwzgmqWxy4ynSjGyR5VqmmvHO21eBVOO6urcgbj+Ga7jULHzFLMP0rJh0jzpQFXP4VabPicRFJ6GG+qXrcbyPqTTFsbm85O4k+ma7MeGvu5XFdDpvhddqHZmrOSMbuxwel+E5S2WU11tr4be3hDbTXotj4XSO3D7OntW1a6HDcW+MDP0qGz67B4NVEeStHJbkAjgVZivFb5WbBrs9a8JlCxUdfQVxt9pM1sSTkY9qg2rYOVPYn8ncu5W60xo5U5BYVli8ktZMMc1pWuspJgMcUbHn8zhoL9rli67qF1eaPuw/Gr6m3uVGSBRJpccg4OKnmNFVmtmVRr8vZ2/Oj/AISKUdXb86fJooHSqs2j8Zzildsr28zyrRyRMp6jNep+GbpY1UnBx615jpMDbl4xXb6TIbdRWkjzMPNwsz1aw1tI1CkLXQ2mrWsijIUGvJotQYfxfrV2HXDGeCfzrOx9VRx0bJM9ejkgkUbdoqwqJ1+WvLbTxQ8X8ePrWvb+LyuNzg0WPTp4ym9DvW2gDKr+VG8ccYrlIvFcbAZK1OPFEOOq0M7I1qbOmWWnCT8K5n/hJofVaZJ4qiVeqipsV7an3Oq8wetMa4VVJJri7jxkiKdrgVh6h48Gw/vR+BNFmc08XTj1PQrvWYrdSWYe3Ncb4g8YKqMocAfWuB1jx9uDAS4/E1wWseMHumID/rWkYng4rNIpNRNzxN4gN1M2CCM+tYum3QMgJODXO/bJLmXBJz9a7fwh4bk1KVOOvrW3Kkj5OriHVlc3dOuZplAQE/Sul0vw7d3+Plck+td94I+Ej3QiJjPbtXt2hfC610q3EkyAEDuBWfKiVN2PD9F+G00iKzofyFdXD4Fis1HmAA49q73xJ4g0zQIygZcqK8V8YfGREeSOBhntijlRhKTbOkvLW2s+MqMegrnr7UrcHAlWvMLrx1qOsTEKXGT2yKs6dp9/fNudpPzpnZSwdSrK6OxkvoJGI3A/Sqd5bQ3EfAzmrOl+EZWAZ2b8TXRW+hxWqc4J96XMfR0cpulzHjniTwuJFZtjY+leb6jp8ljMdpPHvX0R4ont4Y3jIUNXk9/pY1CZyFwOucVXMzgxmDhT2ZyNnrV3bsEErDPAPpX3v/wTZ+Eb69q198QdWj3wWJNvZBwfmc/ebNfEmmeDbrxB4lsNF0+Npry8mW3RVx1Yiv2r+DXw/tvhP8M9D8N2sUaSW1upmxhS8hHzEj1p3PnXG0rXO9EpXLs25v1riPiD480rwjpst3qdwFRWA8iEhpiT6DqPxriP2kfi/N8M/D62emuo1q/X92zHHlp3Y5NfDF1LrfjzxBFf6xqE6201ykT3UrZVcnGBg9KxlVSdj7LLchliaPt6srI+0PiF48/4SbRglikcehTRbpA0eHlfH3T6n6V4V4G/Z1sm+GOveJPETSWGo6ndiOzWE58pNxxgD1r0jRb7QNbs/wCxdKmR7WzmS2lEKsPmxzzj0HUZrnb/AONVx4g+KWk+C9K8uHwvp93GhaKPJYrnJJ471EnGW56OHjiKClSoKyRmaX+z1beDtB1aSG+mub3UkWzFxOgUxK3XH1FSTyeH/Bc2n6Et0x/sa1a4uF8s4SPA5Ixyat/GT9pay8OeK7zw/a6V9ua1mjdZtw5YfezzXh3ijxZd+Ltd8Y+INGs3lt7i2W1mhZR+7UjkgduRUXS2NY0cTiXzVnod6fiR4f13wX4xvdMvZPtUKPIpkUozbuAVJ6/QV4H4k1pY/hrpGmMG+1zStdyyZI8xT39zWv4R8DTX/wAN/El5NbXEV0rotueV39B0PX8q9p03wbpC+CfD9nq2m29zf2sSxGR15DMM8+9Z6s35qGFbS1PD/jF4auNA0XwvaR3El3az2/2lZGJO0sR8v4V6OvwLTVvDdt9kvHspp4EErMcqwxnGPrXe6to+jX0miNqNp9p8pjbRQMMptIzzTvGXxAtPAfh9r17NriONgiwocYXpxntSscssXOaUYLU8B0n9nW+S8jup9Rs2tbe4xL5e4v8AKcjmvOfip42vodavtItSlvawsVBX7zBuvPpXtnhj4tSeIND8UXa28cBjma4SKPGduO9fNnjeylkvbfUnbP8AaR81V9KFblOfEVKk3+9G6HcusMcbOScYyat3imK6hlPzLuANZkNrI0yFRgLW8trNJAFC5fIP4VHMnoeRNa3Oz099yp6YFb1hFu6muc0vHBHUDBrptP6g9q8iotWdMdkbFlCdwINbsIEKlnOBjqazLPEals4xWfq2oXN0wiT5Y/UGsIxT3IqSOkj1SKOYYlX9TWnD4wt7fKu4P5152kLRMCh3t33VV1NnQ4QqG6nrXQqSZxyqSR63Z+LLORwd2GPG7NdBa6vby8CRT3yTXzLceJJ9Pbl1yOnWo4/iJeq2dxUexp/VXLYSr21Z9VreQHlXX8KcbgMvUYr5s034pXULAFgpP9811ml/EO7usbzle2K55YaUTohiFI9vt7hF4yCe1KQN+7u1ee6T4kMkikycn1rqbPVvOkALZrklFxOlNPU6FlDJgnFZ91J9lOeoqaO43Nk8Cql4ytkk1BRdt7wSW+e1Z99fpbqxbaKzJdS+zZTdgVyfiLXpNp2MXx1xWqXMTJnQzeJbaEfNIo/HFZ15440+Nfmnx+JNePa5rVzeTELuBz61ymqT3eDiRie/JrvpUFLdnHOq1se4al8SLIKRFMoPfdmuek+I3nfIkqYz2NeJzSXLsAzH8c1LZw3UjkoM4rtWHglc5HVk2ez/APCRTXycH6MD0rJ1CR7pcuzBweDXLaTJfxxj9yzgdQpFdTp91HeRncGjk6FWBrKUVHY1jKW7FtbhmjRZ1y3Tee9QahCkchxzmpdRtzHHlMZ7Vi3l8zKAxxt71zNanbCQPGG3Y4qlcK0LbWPUZFXdPmSdiCMnFR3ytJJluQvApm17oxZv4sc1g64v+hy59K6K4jCknpWBrf8Ax6yd666e6MpbM4ZUHSp1V0aMxEq+Rgio487sqM8811PhWxt7zWNPiueI5JVB5HPNesedRfK7nc+MfEWqDwXpmm3kQRwVy+QSy44Na114juvDfwvs7W0upLe9WVXYYGShP8qf8XNBmuNd0cWkErxFFQqiZwFPHSvUfEnw80rxJ4d0tLzNtdqESNoxgkkYweKyd72PpFVhGC5jx3S/iNqNrb6G108wlh89BcsuQ6OMYGPeuo8G6Zr+saebqzfeLi5lQh8lifLyR7ZFdT4s+HMeiXnw90y3RruKGV45Pk5IPOWr3nwN4VshJaeTFHAtrdu33ep2YINNRZtHG0qOyPlf48afqkPwb8D3lxd+bZfapkigCbWjbjPPesC3sbiHw/b6ppshNnIqtKqk5jkxgkfWvpD9sPwjbn4J+Hrq3hVYLW/LFFIKjd1/WvkTw14mvLfQNV0qCZgFk3p14Hfj0pS2MMPXVerfY94/Zj8Rf2b8W9FF3dsIJ28jfITjJ6A0ftufD5/CPxCTW4kLWl4ZIiyrhdwOeK81+Hpu77U7fTjG8N9Nh7OUAq2/PDD2r6g+L2g3PiL9ni4sPEExu/EGl3AlLSfeUNx1/CrjsehjI81RST+Rxv7Dl15+qNJJLtl2kLHnqDX3fY4ZgGG5T68mvz1/Yr1mDR/FXlXAXcisu6Q4xg9Qa+1Lj4mWttJ+4u7GOMd2mQkn8666ckony2JwtWpNtI9GnsVjhDW8RZs/Ng9sVm6ZrV9a8JAAOgDY6VzOl/FS01RTb/2za28g+bfHluB1HAqreeJoJGaW31G3IySCJVHH51pzo4Fhat7crPXNL8RPcMqXVvGv+1wK2fs8c+GWPK9f3ZFeA2XxF0u3kYXmv20WwZKiQMT+AzUNn8fNG0+6Z49UnmjU4CiMsP1FHtI9x/2dXltFmp+1h8Eo/i98OLmCOHdqtiDNatgBiB1Xn2r8ktY0GTStSntp4jHLC5RlPYg9K/ZDQP2g/C+vzJavcPazP0knhwh9unevi/8Aba+CMei+KF8V6Jaq+i6ku+aS2wVSXv0Nc07S2MfYVcO7VItHxokewnircMCyZ71JeWpt2KkEEdj2qG3ufLbrXPHsdCkmh0mnErnB9sVk332i3B2Mw/GurgkWZQc7qjvtOWaPjvWyuhTpqSPM5ppnucSOf1r0LwbAjbMgdua5fWNN8liR2p3h/XTZzqhbAFbrVDwbjTnqfROh2cXkggKTj0rdWMLwAB9K868L+JBMqgOMEV6BZ3AuIgc1k1qfoWGqQlH3Sfd61napfC2iYnirtxMIoy1cH4v1kJGwDVXKViayhFnNeKvEDPMwDYH1rB09WvJN5PHXrWNeXzX14VB4zXUaPbeTaFsZ45oeh8PiKzqSdjL1qYREqKdoFv5zhiKzNcuA90V966DwwuVQnpVR2ueBWbubN5CsKAnBx7Vs6A8c0agj9Kz9Ujzbkj0qn4f1Aw3G0nmqOW9tT1O1hWSzIwOB6VStrn7LcFDyKvaNJ9othznNZuuW7Qyb0Xp1qWfV5diuVpG6YY7pQcVg6t4ZS43YWptG1UsoU9q39wkUZGc1J9rFQrxVzxvW/CLRsxCk/SuPvLGayY4DV9DXmmRzqcKM/SuS1jwisikhck+lK542Ky693E8ej1aW2bDEke9a1r4m6AnFW9b8HshYgMDXG3mlz2bHG6q0Pm61GpRZ31vraSL8xFTNfpIuM15eupz2snzliPrV6HxIeMn9anlfQ5fbNaSNfTvDTBR8pFXZNNkt/wD9Vel2ulxwyhWUD8KNU8NrcRkqufwqr3Pcp4HmhdHmUcwjYhmxVyIJKud2Kt6p4fkhOSCPpWDJ51u2OQPepdzgqUZU3Zmq8Dj7pP4U3dLF1LGqdvrRj4bB+talvqMVwvO3NTqZxlbqV/t0qf3vzp39qydywq+trDNzkH6VJ/ZUbCpuzXmn0ZlnVJP7zfnUUmpTMPvN+dbH9io3Sj+w1HrT5x89Tuc1NeTtkZJ+prLvFnlU9vwrvP7Bi7ij+woscAU+YwlGcup5JeabcSMT/Q1lTaXOjfdr2ebw6jDpWXdeFlOcLn8KtVEjilh5HllnaskwLKa9o+Gt5FDNDv4xiuTufC+zJC4/CobdLrTX3IzDHTFV7RM5JUZRPunwD4w0yztY9zKDgdcVB8RPi5b2tnKInXAz618b2nxF1HT49plkIH+1WF4i+IV5qQZTKwz6tVKzMrtaHX+PPifd6zePFDIxDEjvWDo3h261SUSSlyzcnk1j+F0S9mVpDubOeSa948JaPbpAjALnFB9Dl+DVZ3ZmeHfBMcaqWQZHPSu3s9Jit0GFA/CrUaLGoCqB9Kfv6AVFz7ijhoUlohygKuNv04rH8QaktjbO5bGBWlPOYoyfSvJ/ib4kMFtJGHGTxSM8VVVGmczrHiJ9U1NokfI3Y4NX0jFrZvI45C53Y5rlPCFq15dGZgSSetdrryeRpLhOXYbAvc54496aPhqlR1Ltnvv/AAT3+FC+MfiLf+Nb8N9k0fiAkAq0p7Yr6q+OX7TFn8Pb610/RvKvtTaYNOXY4QDqo4qv+zX4Fi+FPwA0uxuGW11bULY3jROypM7sPlXrXmfxq+BN5rXibTNUtoobeKRF+3Qs4yp6k8nk/Sonfoelk2FoVKznij07w/4f0H4k+H7/AMR6sV1STWCW8uZgRbY42r6V4P8AH7w7D4W8Jiw0PbZC3kEgBAZj7iqkHxpj+Ffhy78MaFB9o1cXbRQIQXAXPXGO9dtqv2bVvDLyeILKMX97ADdLI5/drjpjtWTs1qfSctXC1VK/u9EeLfC3XvEvhr4f+JtatNwtjOluJGX78kgIYg+wrs/gj8N7jVvDGoapI7fbp5cw7W+bco459ya9g+FHhnQ7z4Y6SRp0c+nXWps0dvICyyqoxu+g969C1q+8KfDTwxPqV2I9P0yFwoW1iyMnoMDLUlHuZYvMuZ8tGGrZ8haJ8GfEWp/E6S81q2BtoZ2nuGzldw6Lj1rs/Bvg1/COm+JL668uJNSmkuCpAwiYIUE9q7G2+JXhzw74Ph1zUJZLO21i5ne23xF2Y84OB0H1rzj4xePNH134LpLodw8jXE6WzLgpIvJyfpRyxSMp1cViHytWWx1GoXFrH4Rn2yQ7Ba7o+QoOCDke9eZ/FDxJdabf+EJVuWjsLi4DzSLgB+B1rjPij4mE3g/wvpyGRL+ztcT8lAvHT3JGKjs9Bml1T4eW15dPeaVft53kyMSVJ4Zay1b0No4NU4qVRkXxG+LOsW+tXlnpd4RaYUxNGOhx1zmjxxea7pvgJI9TAvbW7WPy7tyM7iM4xmvU5v2fvCs15fWjTXQe5zOgB4RQfu/pWt488IafrnhK00fz3htLeaLa3G4KOMZPSnyszeKw9OUYxPBPD3gHVW+Gtzqen3AgurgsJI8j50rzz4jWn9n6poOnM4dorcMSD3PWvqzxdY6R8L/hqbVS8sKDy0aXgsznivjzxdql1q3jS3nu12oq+VGCf4R0FJqyseZiKzrSclsdBpunpuRsZPpTr5JrOZQBhc8Vd0n92u5hx2rK8VahHNIELbcHNckdzhlsdFpkrSQK3r710ukuCwRjzXGaE5WyiGOnf1rp7ObZIjD8a4p7msdjrbhWhtGK8HFUbSETRHzPvHpV+GZbm34IJxWfqGoLpMLyPgBRnBHWso7mEiwdHCwks2z/AGs1hXtvbwud9yAB3Y7a888S/ETVtVuGijme0ty235MdPWt21+G9rqGgSXct3cahdPGWEjyHb06CvQhFO1zim30K2rav4biZhcahCjjrls5/LNc3ceIPD4k/0e8Wb2Ukf0rjrjRY7eZk2IXQ4YEc5z0yetOOn27R8x7WA7c/yFegqKRwOrd2sd9b65ZwxrIVYo393DZrptD8WWUyhIflP91sg1Q8LfD0X3gpbqZmhuGyY+DXLy6Y0MhjZTHcxniQd65aiUtDrg3uezabrq+YuTsPbmu50S82uGzv3e/SvnvTtcuo4wkw+ZeN2c/rXrXw11oapsiZsup9a8mvTsrno0paHq9nJO20gblPX2p+oeZs4BrV0q0Uxgjir1xb/uyNm6uCx1rueW61M6hs5rgNf8QLaZQHcx9a9O8Z2vk28rBNtfOvibUXa+ddxODgV0UY8zMash2qa80aO7MoUckVxt54kvbpiLX92p/i9as6isl0oDj5O9XdH0NHvLdbpkt7dj03DJr3IRjGJ5cnJmC15qUKiaZ28sH7yr0qez8UXlvDMyyd+NwAr23xN4VsLvwa8VmiNhcrt5JIrxG30uedJJY0yYeHX5RjHsa66ajNHHNyiLp/xKvrCbcy5J78V0Fr8TNxRru3eMtyG5wa5mztf7evkiRDuYhW4CivQPElrpltoo06O1S8lWMDcOqn61nVhBG1KU2aGneMrLVlCCQBu27NLeLFK22MLu/vZrya30m8sJBu45yORwPTrXYaXqk3lKjgEjvivPnTVro76cujOusVEeRIoBx94d6gvGyx21Ba3Es64eRVSldk5VOQO9c1tTtjaxl3bZ4rA1Y77WVe+OK37r+IVz+pDdG49q66fQUtjkbVQvmEnlQTUug6y0evafLIxWKOZWYLjoDUcytDFKwHPSsiNTHIhXjaeORXqo8yOklc+uvDHxG0XXvFFn5cs0NwsRRY5AQCc+/FbGpePJ7j4i6f4dtYo9sUiu8p67sc/jXkHwj8Banq1zcX3zWclvbmeKeRSVPt+laHgO21zxF4wv8AXbQma9sv3jkjhsZGBWbk7n0saEJa3PpW78Z+Hm13TbMalbm6t5SJIy3zEkUmk+PJV1W8s12CDybuVXDDKuMgE4718pWFjqHiPx5yrW97NO0okkj27WHNfQPhX4T3UnhzW9au1aV30ppxMpIxIW5pKTOqngqEGnKRu/GjxEupfse2oO2SWOaMlieS2Tk+tfEfha6Nvr6vKCYJMBxngivpP4waDqfhH4A6ZKknnWWtSqzRSE/uwvpXzNp8iwb8g7YwCOelX01Od06dKo+Rn0h421I6YnhLVtPtmH2Yq8dyuNwAwduR2r3/AMbySeMfhOfGdw4D6o8cL2y/dCqMZx65zXzx4Tvpte8DW+hQwxXj3DEwSSYXZgZwCa7zwyfEcHhPTNF1HCWMMzLFDn7sh479afQ9KnTjNKbZ538NPC97qHxOl8O6aV+0zHEZkkMY557V9Y6f+yn4weMB5dLj4wcmRj/6DXkOq+FbTwJ+0D4dlnvW0+0u7WLzJo5BH838XPrX1DeeJPhvacXPiK+uyvB/0qZ8/wDfOK0jGNtThniqyk/YxuiLwf8As+6/4W0+9iW5017i4VQJdjnbg5P8NcNJ+zf4zuNeu90mm+RLIXErSvzn0UD+dd/o/jb4aXF8kNhczJOx2qXnnQsfTcXwKv6xqngWwvPL1DxbqEbhQz2aanNII8/w/KTj86pxi+pxRxGLjN+7+Bwb/sg63nzn1nT4e74jYlR+IFXYf2f/AAvpyiHUvHyRzDqvmRKAfbLV0X/Cz/hNpjBRZXGpn+9IjS5/GRqguvj54L01TNpnhVwV/vQQp/Lml+7j1NubMJ7J/cQWvwS+HyqMeNbueQd4ZA23/vnI/Ouus/BmkL4bvtEk1+DxJpMqHNvKEE0Y9RzXG2/7XhxttPD8ER6YklAx+SitOz/aPttSZf7S8M2c3O7fG6gj3znNVzUzlxGDx9aN5ps+Iv2lPgT/AMK11R57CRpdNuSXt3xxjrt/D3r5wvle3bONr45Ffr3468K+Gv2ivhrfWlhEYNSgUyQxPjcsg7A479K/Mj4veDz4e1KS2miFrcxsY5YcAFWHBquWPQ+YqKpTlySVmebW2sGJsMcj61pR68pXBOPxrEXSXkkyqt+FTvosu3AVqVkdChUlsivrWoCbJrlJLvbNkdQa6WfQrh+PmxVeLwlIz8qzVasiPYVW9Eb3gnWJGZBz+de5eHbzdCnOfWvHvDHhlraRcK1er6TCbG3GTgYqZM+vwEZ0ormNPW9T8mFsnAxxzXjHjLXmkZwH/Wuv8X68sav8+QPevFtY1Nry8IB+XPrQjmzDFL4TZ0CL7RMHY5Oa9B8oQWPHXFcd4QtR8uea7e/Ty7U4Haok+h4ENYtnnOqNuvG+tdd4Xb90lcbq3F4ee9db4VbKpzmrWx5dXc624j8yHGcVx14zWF3uBxzXbYDR81y/iCz3KzCnc59tTv8AwHrgulRGftXc6tpIvLUsF7V8++Fdbk0++QF8DNfR3hHUYtXslXO4kUM2ozcHc8vuvN026IGQAa6TSdW+0RqN3NbHi7wt8rSqh9eK88WSfTbjuAD3qWfZ4HHa2kz0Hdu75qNlDDoD9azdJ1QXSY3YNaO8Y681J9fGpGaujMvtJjuFbKr+VcfrHhBbjcQvT2rvmbrUDIGzwPxp3OWtQhNao8N1rwX975CPoK4vUNAltmO3dxX0hfaUk6nIX8q5LWPCokGQmfwpqT6nzeJy1Su4nUaivkkSqelX9Nvo7uEKxDGm6hZmazLqMgjtXK2uoPp90VY4XPegnL8XF6NnV32lxXIIAGfpXG6x4RLFiEz9K7K1vluFVlYGpJNrselK59LOhCsrnieqaFJbMflYc1iSTTWrdWwK9x1DQ4bpTwAT7VxmteDNwJC/980j53E5dKN3E4238RtHgE4Nbln4lDDlwfY1z2p+G5YTlVZcViSLPaOfvYquVHgyjUo6M9Tg1xJMZK1dTUEkxhhXkcOvvE23JH1rStfExXq361m4CVePU9RWYN1Ip3mA9Oa4O28VdMtmtOHxIrAcio5TWNaLR1W4d6btHOQD+FYMevI3dasDWkb+JT+NVYvmT1NCa0jbqo/Ks650mKRfuY+gpf7WQ9GA/Gk/tVP74osgaTMHUPD6SKcLXIap4fZd2F6elekvqEBU5IP4ViatNC8Tbdpq4yOSrTjujhdL1I6bcBW6LXrXhLxvlUUtxXjesMu9iB+VN0bVprSZcEgfWuizaLwuKdGSSPrXTNWW+iXDc1peYduc815L4F12SeOP5v1r0tLj/R924ZrJ6H3mGrqpHmZW8QakLO0cse1fO3jbWm1XVPIVvl3etej/ABI8SfZ7eRPM56cV4rpzHUNW8w8nNNJnzeZ4r3uRHpPhGz+y26kjHqa9q+BvgiHxx8TtJivo92k2LG/u89AkfP8APtXlegwiO3XPYV9c/An4dagvwc1jUrMeRf8AiC4XT45pFyEj5O4egJrP0ODC0Y1JxhPY09J8e3XxR+P9ldOcaLaytHFucCOJAMKPxArb/aA+JN5HpdyPDqSatfSfu0e3XeIQeN3A49q878YeG7/4T/C2Xz1VNckvAzSwY+QdAcj1HvXR/BlZb74Qx38k7NdtJIz4xvZQTxx1rFvoz7fE0aEeWvT1S0PKPB9ronwt1O31zxSq6lrDxm5WCYnesh+6CBnJzzXb6prjfEzwWL+S5+yR3yMJ1AA+bPY46Ad68/8Ai54J1PXtXsNRtrcubiBmXcDuAU8sW7fjXVeA7638QLY+FtPgzp+npHHPdckmZzyMHr/Ko1uzsreznSjVb1KEfxw8R+CNP0zwvpd1A9lpzqsDMAQQTzkj6+tdB8bfHl54n8K6Jok1u1pqd1djzIdxAYHADLjtVqb9lXULfxc06apbT6ZbXWJmZQGGOdnHA/Cu48Q/By+8S/FOw1i6Kx2On2sbwxxrnzAOMYqbSehzYjEYGMoyjva587fFbRfFNjPpfhu6glu9P09BHZGOM/xAEjI710Hib4RzLpHhC0srSZ7yYK98ijIQDHzN+tfTGqW9pHrljaSyxPeBJJvI4ZlGBgtxxVL7VYx6laxfbLQT3EDowNwu5sngYB7Gr5O7PNlmFSokoQ7nD+MPBvhvxFHpzX+kwzNAY7YspIyOmeKzpvDml6XrukRw2qlNP81baMjPl8DmuN+LniK6034taJpQuGt9PtXjkmWN8jGfvHHauY8a+NvEHir4of8ACOaHqKQQNcgQvCRk8buuPajRaGaw9arbmdludLZ/FO8vPjJNpMrRwafbwPCcDgtjPP51zHi34133hrxVqmmyafbX1kuPKEhPynHBpPhP4Pfxt4u8UHVrg+bGNruH+ZmzjPT2qPU/2eb291+WGbW1V542kgMke5sA/dP4VPvW0N1SwtOS530OZ8b/ABB1v4geEbS1vrZYftt0i200edvBPH4V4/4osWtjZkyCWaJ2y2a+qbj4Y2/h/TdLsZ7gTwaTDJdE+XtDuRjGM18raxAIPEGpqx+TJkAJ+7ntQ4to8mvUpyuqfc2rW/P9nox4JFc3q1wZrgAnJz61saLnUNKGz5yvHFYuqW7W95hwQc1x7HC72O50HK2MWeuPSupsbd5iuFH41iaBGGt7cKOqjNd5pVmSyYHyjrXFWfLqbR2E+xusAHlKzfXGKxtU8O3OoRkGU7T/AA5Jrs/JPmMAcrj0pIbUtnK7vTiuSNTldxShdHly+C0SUiRC1bmj2txo+5LSdoYscwyfMhrq7zTXX5xFyemKzpN0bYlhx+Fdaqpo53FI8/8AEnhmXVNQ863toY5erFR8pPrWavga/mu0muUtdi9UXAJr0v7NCWZguCahktI1y2cn8K6liHy2Rh7GN7tHOXl5q0lmLRJY7W3jXaET0rGttDuPn237KW67lyK6e5jMjlUXmm22nySsARg5rN1OrNORW0OXfQ5YYyrNvIOQ3HNdz8Jrd7HUlZs4zUsPhmSZl+U4711Wg6ENLmi4+Zj0rlrVE1Y0hHU9s0GZWhBK5rSv7iGNBxis7w7a+Zbxjocc1tT6akq+9cB1XseZeLJBdQzovcelfOPinw/NDqUpZW5Oea+kvFlr5Ny6Zz6VyN5oC6vEwdQWx2ArWnLkZnJcyPAZNJimUeZnb7ZFLHpth53yqwYDGWJNekX3gWSzZv3W5SfQVg3Xh4Ix42sPavSVVSWhzez1KVrZlVHl3Nwo/uq3H5VIPB+lXEhlnWeWRuu1tufrVy1t5IcAritaOMsFHVqPauIezRk2Hh3TNPYm2sSh9WbOaLjT1hRzHtWNuduO9bDW15N8qIB7mhPC9zcH/SJQiH0xSdW+4+VLocO+kPcSF9jEZ9KuW2npHgPCfyr0DT/Bdvbx5RpnHUkkYNaEnhFLgBowwP8AtYrGVVWsbRicLHp8ewER4qG5h2qfauwvPD8tnyRuFYGp2pjRvlxWamb2SRyF3w7Vh3a8tXRXijmsS6XO4Driu2nqZPY5m6gG5QRhWOK5zUUjhupEA4HIrptQYLCwJwynIFchJHJcTPKfWvVjseZP4j7J/Z31Vdc+F7wFiXhLxsT6ba7b4G+CY/CulTzmbzZ7yVmPAG0AnA5618vfC/4gT+GfAup21nN5N3JcKV3AnK969z+HnxebU/BOoC8dbW/t4XMLrwX9xmiUrM9ijQqzpqUdmesab4dhvNd1G9u7S28+GT9y6ph1BHevSfCtrZah4V1bSC2xTbiNtn+0M4r5W+FfxEuLDwv4i1O8ujdag/MSyNlmHT+tddb/ABgOiaTfrYM0eoSXULGMg5K7cNwelPnVjs+oYipJqPQ1f2w9Jt9J8C+CNIgc/ZLWKST5+5AAr4e1O4hXUjLHho2AQBfpX1b+2V4+g17w34RMMii4azfzox1Ria+Qo1WW2mG7MiYYbhyxoephThOnpNanqHhXWLvTNEEcRcTWc6zKQe3pX1a3xm03Q/Cuj3NzpcepT3TKyHAxEwAJb618c6TdPJDDIzERSoN+PbrXskcNvdrp/huOL7VBqCK1pK74WN+5zSWh7dNRaTkelftKanb61a+C/EVoVaNp8McZADAcH05rAhml8pVxtXsAMDrXafEX4ZvY/DS1sb3VIFsoXi2eYhMiz59R1FeueFv2WdNu9Ctby48T7RNErkIirjI9S1OUXJ2NsPWo4ODclo2eD+G7tIdWge4RvJDZJ4GPfv0qX4gahHD4uuooSwjQKN7Kvz8ZyOnFfRWm/s/eCtF1COZ/Ev2po23eTJcRYJHtUvi39n/SPFGoC9fXkhCDaTCsfK9ud1HsZWJ/tbDe25z5eh1GR2AViR74/wAa1ba8f+Pp3yOn+FfQFr8EPh3oCiTUvERuv+mTToMn6Jkmuu0LQfh7BJGNK8H3OqOv3XaxZkP0ZyBS9g+prPP6MdIxufMej+FL3XJi+nQz3DHqIITJ/Kunh+Hvi232htG1Ep1JNm/+FfWWkXXiGOQR2Ok6PoFivRbmTe2P9xCAPzNbct/q8Yy2v6GreiWp/n51aqglq2eZUz6tL+HDQ+cPhPq2o+DfFNsNTgntYLlvJkeaJkXnp2614/8A8FHPhKbPWdG8WafCyw3jeRdFQMFsAq3HY19yXtvqmr2kkdxfaDqkZHELRMpz7HccGuX+KPga1+Jnw1vfDt3CLa98vdDG5DbWXpsJ610KNloz5jEVfbVo1Jxtc/JnSPD/AJiKXXB7git//hGoCo4GfpXU6x4WuPDOrXGnXkTQzW7lGRuoIqKOH8qzdz7rD4WlyqyOZ/4ROJuiD8qkj8JxqfugfhXUKoPUUNtQUtTZ4WnfYyrXQoYFyQOPaqOuaklnCwQjpitDVNSS2hb5q8s8XeJhtkAb6VcVqeXiq8KMLI53xh4gLM6hjz71xFq7TXQLetGpag11MxJ70ukoWuBxWuh8BXrurUZ6j4ThURrXTal/x7sB6Vh+FYT5acV0t5amSFjjtXK9zsh8B5RreVus9s10nhWb5U5rF8SWbLM2B3q54VLqyA5NaLY8utuelQtujHPFUdStlmiYdRVy15h6U2ZdykUmc55zqETWd0XQY2n1r1X4V+MjDJHGzY6Dk1wuvaf5iswHNY+h6lJpeoIC2AD61S1QH23a21vr2mgjDOR6V5h408FvbPIwRgOegrY+FHjAXUMMbuMHA5r1vWPDcOs2O9U3EjqtI66VRxaaPkgTTaVOR8233rpdM1lJ4wCQDW5448CtaSSssZGM9q8zkE+mzH7y4pXPrMFmCi7M9D83coqNm6iub0vxB5ihXYZrcW4WRRg0j6iNaNTUJSSDVNwDnIzU80nGAc1UZtuaAauTeD9Wi1mzSMnJx6VmeLvD7Qu0qKfXivPPAPiiTTbxFMny9OTX0Np8EHibSVwFZ9vaqPyqnVlTasePaVrEtvII3JAH96uvt7xZ4wc5rC8YeEJ9NuGdI3Xv0rG0vWpLVvLkbnpzSsfa4HHp+7JneBhTZI1dcYWs611EXAHNXY5N3fNI+njKM1czr7Q4rhDhVJ+lcnq3gtJMlU/IV35bFN2o2cgfjTucdbC0qi1R4dqng142OEauavNFnt2PDCvoq60uKZTkL+Vc1qnhFJASFzn2ppvqfN4nKr3cTxS1jnjbBLAV1Gm2L3QUbmzW5ceF1t3JZcDNaekaZFGwIYLj1qro+drYWpRdjGXw3dMCyBqjm0e9t1LYY/QV7L4b0uCbarhTu9q6XVfAdo1k0gVenpSOHnlDRny9eXs1jwxNU1155Oh/Wux8faFHazOBxgntXK6L4dN4wwOposdlKM62xH/a0zDgn86rXF7cSLj5j+Nd9a+AyyZKkH3FWE8B/Nyufwo0PWWXVpo8hk0+5upD8rCtHTPC80ki7lavXbfwLGuPk+vFbNn4VggIOFz9KvmVrHTRymSd2Yfg3RTahM9BXa6tfiz09t5xgUR20dnFkYGPavP/AIheJvJt5FD9eMA0luezK2FpNM868f6419fsivlQazvC0e66XPrmse4nNzM7nqfet3whGGv419T2qnsfB1Kvtat7nt/gfQZvEWq6ZpdsjSTXkyQhV68nrX3F8aLy/wDg3oXgLTtIE0GnaeEa4aJcCRujbj+deTfsN/DdfEHja58R3Mf+j6THtiBGQ0h6Y+lfZvxGs9Pm8L3z61YtqWmbM3EQHIHdx9Kz5ep6mCxEKeISkfP3xu0eD4naFZWGk3MRe8h+1bQxJAAH9c14y1zrHgLxT4Y8F22pbbcXAkY7RjDY3AivXfGUej+B/GXg/wARaJKsnhO5iaB5NxYIT2J6j6GuD8UeE7fxn8TG8QWF39osLaAsJIGGVkAyoJzWEkfe0IKEUmvcs/vLH7QGvXOk6HLa6ZDI8kmII/KGW5OD/OuQ+DGqRfCPWni120aYWcgu7vY2Wztyi5+tavwr8RTeKJtabUmMuo2k2VViCUXPcZ60mk+Dbj4y+MpUsrCbTtFE/mX95OuWmYcYXHUcdqzaYoOnThKjV2PeV+Mdp4c+FcPi3UtJzFqd888drCRuVS3U9unrUHh39orwnrmuaxN5V5awSIpiuLhgF2qM7Rj3rx/x18C/GWqanb6JpDte6fbxmWO1mfYkKk4BO4j8q1IPgHeR+A7bwxZWkN7r1w5nmuGc7IVH3up/QVb5r7HlvD4GMbuRheE/iBLb+IvFfxAuLGe9sbpZrW3wflTqAa8e8IaXN4+8dwRm6e3EzNP5qOSyYGTg19Zx+FdN+H/gxtKYQvZxoXlVmASWTGOMj1qtpHhTTfDPg23kh0e0sr2W3Z3e3GJMOM4z261Dg2dEMdSo3XJ5I8V+CfgsePfiVrmoa1I9/Z6ejQCWUkbycgc9yMV2fh/4L+G/DPia/wBat7i6nubGQ7Ukb5AzLx27ZrotW1C3+F3w5bULSGNWSLzJI4iP3shPG7A615TqXxM1rT/hdLqzXUUWs6vqBKwcHagHTGfSmrI5ZTr4mT9np0PT/CWi6X4V0W5vIYNk9y7yTSd5MHNee+H/AIu2XjL4jQ2dtYfZltYZg88jBmYD0HauY0zxR4pt/h7c61cT+faMWQxOuBFnj5feuS8B+A9a1Pw/q2v6XdfZbuBjEGLEMwIyaht30CnhYJSnWeuxseJfjkdY1DWYI7Iiz2G3EpfJ4J5z714R4uthdWj63ExWOciMIevoea7bx/4Uu/BPh/yL2VXvbiRZWaJycZGea5treHVvDdhp5n8uZGyVzzyarU46tKnFXps5zwrfy6fiRHJXOHX1ro7uCHWHE2MYPTFQ6losWkyRpCNq7QD7mr/hZVmuJI3wq+/euKorM89O6N/weAsuwckGvUtMQLABjlq850eOG31EiL8a9K00p5KEnHFeZXNYGrFCI4hlcVetbRZl+XaDn0zmkhiPljIHQHmtvS7URqzDbnr0rz3ozVsz5NLkMWPKIB/iFUbjw/DNHhomz/exXcW6qVLt+WKJrcTgFPl9sVpFsyaPLrnwjFtYh2jPvWVL4dCry+cV6fe6K8zKpyRnsKpt4MaRsKWroi2RZHnlv4fErACPnsa6jQ/BIZ1eUbscgYrttN8KLZqMjc3fIrUbS2t3BiO2McsuKUpPYXKjl7zQ7eFQVjAP0rIjtc3ycdDxxXUXzGS4YLwvpUFvZhbgNt5rlbdzZJHW+HG2xKSe1bUjFctWNov3cAcVszt8uM1S2GzhfE0QuLklhj0rGsbfZIfl4PtXR62oacg81St7bbkmkXFXQyPS4ZeJIlcNx0qpqXw9srpSyqEbtha2LdyrAdq2beEyYO/ArWm2jOUUeNal8Pnt5GKrwKp2/hnccNDgr3HFe5XGliTJcKw/3aoyeF4Zxnbt/CuoxPMrXwlb7QXTcfxFbNr4PtGUbYf1JrsF8NR27bgc+1XP7PWMDAwR2rGRaOP/AOEfit4/lX8KqXGnlfmVa6rUreW3YMseVrHvptqrhTnPNczbNktDnLy1Vo2HU45zXF61YrtbHJ+leh3g8xd2MVyWsIvzEc009R2PLNYtfKJwK5u9BXJ6V3PiSH93uUY9a4PUpPm69DxXq0TCRlyWcckbq33mrmrmxFqxGBjP1rqbqMTW+S2DnmsXUGI4VNvb3r1Ys4pJdTe+Dvh628V61qOjzSm2ee3LwSZ+6wOcYr37xD8MJ/DPwYuEkFu1/FKJmmVcO0ZOMfyr5l8Ga0/hfxVZakmT5b4YD+6etfdE3jTRrrwlaG8vbWKS+gV1glGQVDD/AArXRo78LiKlNKK1SPOvAPwxi8RfDvTJy3kXwk3o4B+7noa9S8RfBNPEV8tzZmNbw6giS7wQJE2DJA/A1u3GoWOm6XZtbLGYJSqRCAAKe5Nd5Y65ZWN9pMTf8fFzd7U3dOF5/Snyo6Pr2I5246bnyF+1pHp8nxOOjW0KwDTYIldVUgElRkV4NqekRpYz3QiK4GVKjivS/wBqDUnm+NHiu6hYy273axpJ2bA7H0rzFvGH9m7rG9jWeJh26rn1qGbXbSk3qTeHbiO7mthE4UMhwvXkDkY969T0ubd4QtoixXUIJd9q6885+6K8atbG40toL9E2Q+aGAz/Ce9ei6JqU8Xhuea2bN3YXIuIzjJC5zwPSkelTfNGx9U6w8fxP+EFmb27W0vbZAxEjbf3ijG0+9av7PPxk8PaT4Vn0rxJoX9p3Ng+yOdIVlO38W4FeQax4sSLQvDmuKqm0uJka6tlPyM3GSRX0Fa+GvDNro934m00Q2Vtf24E8SgeW0Z6lR2NUmw5aah7OotDqbn9obwdb5WLwe3ljp+6iz/TFWtQ+Lngy4sY9U1Lw3KyNgAFEkGfTBPFVfCvwF8H+JNHtdStbjUbi3uF3q7T4x7df51d8Qfs4aRJpK2dpJf28KP5vmowbDeh5rePP0PFqvAQlyaqxiXH7Smg6XH/xJPCo3Do0gSMD8hzXP3X7T3jPVpHS0Fjp6Hp5EDO4/Etiun0f9nvwzp0gNyl1fseczPx9eDXc6P4H0TReLLS7eHH8W3J/Wq5ZSD65gKL92HMzwC8l8c+PLjdcS6nfA8gNIyJ+AyBW7Y/BHxXeRrI1tFCMfx3OT+j19DW9jGiqQACOgUsAPyrc0+MzQlflJFWqKtqznqZ1bSnTSR8zSfBrxRZEPGkcjLztS5IP57q7Dwh4W8aWci3Goi4a3QYVmuldk/XpXtK2bRyE7cem2tXT7ULgsQfUGtI00upxVc1lWjyuKR8eftCeBW8TL/a8EZ/tW3XbMyrgTL6njrXzbIBDlSQMHBGOh9K/Qnx94RMOsS8Fredc7cDkd1r4m+Pnge88BatJdwW0jaXcfOjqudh7qcVEo2PYyzNIxp8szipLuOME781j6hr8dvGcMMmuJ1XxZ5bMVkJH1NcvfeILi9yIyTn0qdTuxGaU1F2ZteJPFW7fh/1rzPV7ya+Zz/D9a6vT/Dd5rEoLhwCecitbUPAzWdufkzx2FWj4vFY2VVux4/LGUbB6Vt+H7cPMtJrlj9nuinv0rd8I6f5ki8USfQ86nds9J8L2YWFOMCuqa1BjPpVPRLPy7VP1rUbgY7VySPYjpGxxGvaAs2W255qto2jiFlIUiuzuLcOp3DI+lYd5dJZt8prSLOCrHU1VjWKPGKrTSe1Z8esCZfvYNOa48xeOao5Ha4y8iE0bcVxOq2hhmMijp+Fdn5uM5rD1q3WSMnGKa7EPY3vhr4ubT7iJWlxg+tfWngfx/bzWaLJIp49a/P3+0n0u6DLu4PY13/hn4qPaxqpl5HbdinYqLPtHxJDY6xCzLt55rxHxl4Pi8yR0GR2xXL2PxsIwplA+rE1sx/EK31RcM68/WmbRq8mp57f2UumykqG4NWLHxA0ZAd+frW9rAhvCSgUhvSuO1GwMbEpkfSpse5hcw5NGzr49SS4QHfzSs2ec159Fq0tm+Gc4962rHxAs2AzVNj6mhi4VFueYXIfTboMoYAHtXs3wm+IARoYpX3dABup2qfs+6xqUbAeXGfw/oazNK/Zt8U6bdLNBdW8ZU5HPWmfmh9IX/heLxVpIniXcxXuK+fPHXgy60W5dvLZQCT2r6L+Ga3vhvSVtdSZZJlGCUOa1vEFhpPiKB4bq0DKwxmg6KdWVN3R8babr0lrMI2OfrXb6bqP2qMev41s+Mv2c31C+87R75bZCc7Zug+lSeH/gnrWlhVnvrabH8QBpWPqMFmiVlNlHccZPH40bvTn8a7H/AIVbdj711D+AP+FOX4X3P/P0n4Kf8KLH0CzKhbWRxqsV9KeuDnO2u0X4X3He5U/hUVx8N7yGMlJlYjsMCp1D+0cO9OY4S906K4U5A/AVz11oMkOXiBI9q9PsfAGr3Uh/dLGg6sxHNai/C25Y/PcR49MA0tTirV8LUWrPHLHxJPpMwD7hj2NdFcfEpmsSokGMepruLz4MpeqRJOv5VzF9+zS1058rVPJB64BrVbHymLhRu3BnivifxEdUvSBzk89a6nwZpmY0kK12cP7KiRzB31YnBz0Nd7pXwfh0y1jiW6yV6tijU6MvrU6b/eHHxxoqgAKT70rRj0UV33/CtUU83WR9KVfhvD3uM/hU2Pq1mOGirXOC2Aen4Uxvl5xivRU+HVt/FOfwFS/8K9s8cysfwpcthPNMOup4v4o1yPSLB3dsHHFfP3iXXpNbunYElM8Y5r7S1f4H6D4gGLtrl1/uiTaKoQ/sx+BIwA9hLKf9uY/4Vok9z5TMceq8rReh8RiNiPun8RXT+A7OW+8QWltGjSSSOFVFGSTnivsGH9nPwDD/AMwbf9Z2r0f4Hfs6eDpvH1hPaaFFH9kP2hn3sxBXp+tWeCnbU+lv2dfhzF8NPhjpWmmPbeSqLm5dhhyzc4P0r02aMNbyRsA6upVlflGB6giljwyjHT8KdK/lxnnAFWthqTU+Zbni9z8DdMt9YuobSW5GhXfzyaVHg7JeoZAenNeQN4M1vwz4s1dfDOmPdCY7ZLPUbiOKViP4kTPP619c2qlvMlYcN0OcVyvjbwfpPjC2EeqWglkj5iuEOyWLHow+as5QTPpsJnVaK5aj0PCND1Dw/wDCzUmk1nwG2jW19hrvUJLqOa4kl6/MMnansKn8YftUSXLNb/D7Qo3htyA97NEEhQ9BjHWtGXS9Q8BX9z9v0TSvFmjyDES3vySxn3dgR+JIqGPxrqBvodLl8F6b4WsLxCY7ie/iW1I99ikMf+BVk42R6sKkar59ybUP2hNH+HXhdJL++j8TeKNRAmuvsG1Fhz/DuGc49DVT4a/HTTdS1251O+0W90vRrpRFb3kshkjj4+YN9aqQ/Dn4LNPNBqGqabqusOS8i2MpjhX1Gc7ade+BYvitp40fT9RXSfB2nkBLWzdGknI9TnOKyd+ppy4fls4s8u8feKLr4wePptRs7a5Twfoc6mRrfO1wG5Occ9Kwvib8SNW+K/jez03w293baNvS1hEcRG/gBm4HNew33xI8LfDKwj8H6BGZp8+SllZw+ZI8h43PxjGfc1b/AOEz0H4fae9pqeo2K66sRllTaqyLnkqMdDUnR7aMUkqbfY8b8QfDm6vfH2lfD20v7++0eNluLyfnCkDLAsP613PjL4K+ENT8W2kHkXG7yS7KHAQY4Bx65FVtd+Nml+GfAk93os8b6/qD/u0KkyfMe+eTj34rgNC+J2oeGNJ1rV/EMlxeeJ7pQtqJkJCofYHHWloRy4itrDQ9M8WeEdIuPD9n4ZZJBpZdUkSMjLfjniua8Xaxofw9s9P8IabbmOa7wwXOQiAjLMe/Ary3w/8AEDx14w1RbtLpJY7BTcP+5WMKvcZzXFeNPEGseLrrVfFUxMIjK28bRgj64pcyJjg6qfLVkbHi6ax+IutRjc3khml3Jwo2nAXFeP67G3h/xo+QUSOUYGcDb2rovh/rX9l3V0XcNbmJmxz16/nUttb2/wAQJri+nj2ssigBR2pc19DmqQdFtN6FPXNQtLi7trYlWeX5xitCHT47Nd2Bu6ivPNaBsfETrBuYwy/Jz2B7V6nZxrqNjHcJ88brkhfX0rlqpnKoJR9SzpchS5hBCgMe1ei6bhtsbD5SMZrzuGx+xNBJg4Jzg9q9B0WT5Yz1NebWjdJkRdnY7K1V44Y1VgR0rbtdmz/Vnce9YVjKZdqnjFdNaqu1ccmvLknc1LVvbzuVB4Q1pR2YibluO1RwkkBcc1YkzhMqSAauIWLcNvHNhdpJzya0F02KFVI5PfNZy3QEfytipI7xlUZkrZSsg5WW5FjVxkjH0rN1HuEzg0641BI8kDcxrl9Z15oWOXwOy1LdxcupK9piXJqbywDXM2+uSS3AL8KenNdFFceeq1myjd0X5PlzW5NbmRSR6ZrK0mAcbRlq2ZkkCnjHFUgOQ1S3PnZNQwQEdVwMVp6kvlgNjLZwa5y/1Z42KJ174oexa0Lw8sMQW2mtGym8sgFgR7muMi+0XDM24gt3qpeaxPaTeU7FlHU0JiauetRkPjoQR2NPLLHn5eK4zw94kjljWNWwR271uTXnnMBuxWyl0Fyo0SVk5x0qKVlzxVFbwhiu7inBg38WaiUrlcqC6ZPLbcKwLiFJt2RgVsz48s81j3cixx9eawkM53UoVh3fNx2rjtY/dKzD5s1115NL9o+6pjbrmuR8QY3PhQvuKuPcTOH8QSboGB4715zdfNKwx3r0fXIi0bZ54rgprcSSvxyOa9bD6nLJ6mYy/Kfbk1z965mncmuq+zmUYwQB1xWZdaMfMO1SQeelekYJczOeaHuOo716JqjatqGm6H58W+3jgEUEyozfxdD71x0cOLuOGPaZmbHzdBX1l8CVtrvwzY6TfiKZoZWwrKDweRj8a1Wx24assPJ3RjRS+JfDtvoekJDHM0cTXcDFs712/NnNbXh/xprKyaDdz2kjWZvZnSQEsc7cMO5wBXqMvhtLjxtp948MflpZyRKmOmfrXU2vw+gsv7LntISyQ6mlwY2Awiuu1vwNHKz0qeOopax1PkL4zWsN9a6DcpF8ss8jyMQdxyc8kivEvHGn27Xay2zfvwvzqATjHSvof9qq+stFe6sLeVIr+xvJFaBWG5QTwT+FeJ/DfGpQ3j3a+Yd2TIeQfY1ZyympO9i14Zs/7U8JFbgqDggHin+E9Skhju40Y/bI/uE/dkQdQfwrn/GOr2Ud01vpLtGF4kMZ+X6V1Gg2v/FP2+o7dk0QzkDqO4NZPc9Ci9D0a2t7HTPB9nBftJdaLfNuXYfmtpf4Sv416drNpq8PwdtNMuZRGuzzrabdtMqKc7T6HFeS+DfseueGb/TtQcQ26uZYHzjaevFeheHNevPEvwnuNKufmu9HuA8ErgnzEXkDB9ao7Piin2Pqz9kDVTffDmK3nu0e4Rt32dshlHrz/OvbtUimmtQIDFj/AJaByefpivjfRvH1xDceA7rRkS0a9PlzLGu3Kj7yn8a+s1b7fZxnzfKJ2thf5V2UpaWPjc0oyjUdX+Yqwq3Ux4/lUjIHPTaadtZs4YjnoTSKx3YNbniCN+7Uc1e0mfyZgOu6qjL1JqazISRSeKolpWN+b7vA96dZynepFWYlS4hU55xzTobdVag52kUPF2jnXNCkWNjHdQjfEy9cjtXhuueT4g02Wz1C1juY2BR1mXJFfSsMe1dwxkDPNeG/EzQRoviaSWNStrcDzB6bu4pMuMmtEfmx8fPhlD4X8XOLRVjtbgllVRjFYPhDwEt1MuRnPHOK9k/aksfsuo2crOrF3LAentVD4Xxwz+SzKDzk9KiwpSk+pr6D8MY7a1Ehh7egrjviRp8Wk2suAuQOlfRl3JBbaTlVA+X0FfLPxs1hmE6hu5qTM+e9Ub7Zqr/72OK9A8GaT8qEqeK4XSoTcXxYjcd1eweFbXy40yuK55M7KKR0trD5cYA4qfyi/vVqG3BXGM1HdslrHk8VnudvNZFDU5Ut7ZsnBxXlHiXXilw3zcV0vi7xGsauqv0rxzXNVe4uG2nI+tbRicNSZ1em68ZpAN2Pxrr7O88yHhs14/pd4YXBLc/Wu90XVAYx81acqOU6gvmql580RpyXAkXrUF1MFRgTSHocRr0GJHNZ2n2byYw5PtWnrkmZDzVzw1CshGVpnfhaPtHZkR0yfy8gn9arR6lf6ZJlWYr7E16THpsclvjGOK5/VfD6sD8oxU8x7NTLLxukO0Xx40ihJW59zXVW9+l8vGORXkd/prWrEoSMdMVPo/iWWwkCybsdOtaaNHz9WhKjK1j0i/0kToSowfauZuIriykJ+bA966XRdchvo1GRk+tad1pMN5ETgEn0qGFLETp7H1a2f9qhQfU/j/8AWqTjvRx2quVHOR7Tjr+WaNpNSUU7BcjaP1pPLHSntSUWAbsUcUbQKJO1M30WHdkmQM1SurkIrZB9sVaXnNUbwhQ2Rmk1oPmZasbpmhAfp2qeWT5RgVStiPJTNWJjhQKhajuM87b1o87dwP5VCTmlTvWmxN2Tqxp6896hRgvv9amV93agQ7bnuTRsFKtLRYLjTGKFTHSnUc9qLACqaXbQue9L3FMbECBmXdyAc7fWvor9n/wyLDw7Lqp4uL1sBj/CgPSvAtJ02TV9StbOIFnmkVMDrgnk/hX2Tounx6Vp9vaQrtjhjVAB6gcmgkvKgj3EdznNVLhjM2wHluKtzMFjOR1rMSNlm3KelWBYuv8AR4Y4l6KOTWPfSbYyfvH61but7ZJrFuN0kipnPNI0Ww1bSC6VxNEJEYYKuoIYe4rx3x58Nf7JW6n0yzl1PTXO59HN4yAc5ymVP5cV7hJCLWDOfmxXE+KtWjsbOe4mI2Rgu2SOgFTLY9HDVp02kmfNVvp/ws1nUhLqelahoF9A+2TTJj+7kb/fIwfzrp9W8B+ItSu0fwb9g8F6JMgSTy5maWRP73cD868bX43ata+ItSkkuHuNKu7hlFqsKO23OMqzAkV3WhWui+PLeKOT4g6lY6Wx3CyuI/Kx6qJOAa4r3Z9pKM0lJs6p/grofguxiutH1uZfE8j7o9QkzO5c9SqKf51n2P7PlnpGsS+JPE2tHWriEm4aKWPaJpeoDFm/SqGoeE9V8JRXdv8AD+/sdTM6lmmVjNdIP9/O0fga4fwp4H+JGqPPNc3V9pNjG3my3GpS7VZgc9GPP4UiYxnOP8Q9M8P/AAV07WfER8WazIpdn85NPhj8uKEduSa0/iD4T8PePNc07TZbW0vmjBeSeGUL5SY4A2Hr9a8f8VfFHxP46s7fwhpjG4nLeTdXtucGXngZ7Cqlx4lf4MeHJ9HtbWaPxRcjM13KQ20f7B9Pai440K8n8fvHq958PvDnhjQ20PR7Y2SalIIpSHDSup69e1eO6ldaBqfiQ+F9Hi8vTdOco6t8yyMByc965Cf4xeMY0WU6jufy2gjmeIFgGGDj3q58LVi8L2+qTarIYrqaMTASA7yuTk/n6VPNF9Aq4WvRi3UldnP/ABO8J6f4W8NuLUL5s9zvXA5UY5Fcj4N1GLw/pc73YKLKPMBH8QHFera0th8SprWBYWubOJTJJMCQFPQCsX4geAY5PDUUVgRCLFS67l5ZfTijl6o4VUXLyVdzz/RdH03VdSudQSOTO8lN3TntXS6LcLodwttcECxnbEZP8BNcV4L1SXT9VNtIQ1vIfnVsjZ74q7eeJEuvE8GmSKHgE3yyDp+NRKPMjGUXGb7HqD6aLhY4Q+8tkrJ2ArW0dxG6xKcleCaytOsWVWCSYjGcKDxWrptuYmV0k+8OVrz61O0dDk5rS1Ow004rprDLbccYrkdIuBGx3DaT3NdVazDaMGvHqRZ1RaZsiRo2Lg/dqwHa4VWJzntWU0+1QM5zUsF0zZUHG3msdUWaDTLDwR9Khe6KAtiqj3J3ZPWqV5qAHBrVbFk2o6wIY2IbBHauB1TVnnvDI7/L6VZ1rWN0hRe/FYrae1yrFeeKrlMpSOt0mzW+t1fG0djWraSNp90sb/MByKp+ElMWjiNuZA3rWneQ/aLqLaNp6E4qLDR3XhN1vo2lZMDNamqO8IynIrL0mc2NmkY4GPStHzluVwzYp2LscdrV+wOGGDnNZOj2a6pNcSsMdhWv4i0q5WcyIoZPes/SZHs3b7q7jyKGBZmtUtYmAXmuE8UXSQzAN3rv9TulWFuVJI7HNeYeJLWXU9TRFJCA5Y04iZWtdUbT51Ktwfeu30vxEblU2nce9cBrGmtZ2plQtKFFVvD2uN5i8mM55BrSwlJnsS3xm56H61Otyyjg1gabqCzQjByepq/5/HB6Vi9zToWp71guCay7i4ZlbJwKfcSZ5zWfcS7jgH61L1EU7mbcu0dT3rkdYm8slDg810t4+xTXH38nnTMSK0ijKUuhz2rsJI5Bz0rg5VEcze3eu71b7r4HNcw1ikjNvyrYyOOtexR0RyyZgw+ZHMSGwp5YY6is/WvFBkY29haNNNjBIU8VqTTLb28zMPLdOhJHNdFo9rbXOmxTRxJvdcngDmvQirkc3KcH4V8Oi6mW+uHYXCt91iQM+les+A/EUOk+NNCR5Ag+1r5oYnaB2zXlXjS6k0bVFigDRMw3vtbg113gNYfGdjcrJDuu7ZVkQqSCcHp+Na7G8IvmUp7H1P8ADXxzeeL/AIjXdpdpFHFZ3DQo0efmXkiu91j4iLpbTzQI93p72bvA0H8ckbYZR7gV4P4b+G2q+HbpPEOnXO1A0NxFKpLYUnDq4HJxW6vgLxJd2OryPeXlq9jcG7js1AZJbdz87xkHgY6jr7Urvse2sLhqkr81jgf2wfD9l4os9N+Imjnz7XWIY4LjC8xXC8YbvnHrxXgvh/Vj4YUabLCJTN82MgHd6Gvr6y+AOvX2j6n4eurqRdN1RPtOl3akNb3DgZVSD0Y9O1fHnjTQNU8J+MGtdRtXtb61lEckD9QQcZGeo9xxVanLWjCjPlg7o1bXwDLqM819OVtVPzJDxg/Wtez1qxm0m5spZEjkiUoY1PB+lXteube80EJJcNDLLHlNnXP5VwfhC3k/4SG3/ceYVbDgqfzxWb3OuiuaNzuvBe9tHurSQMpERmhOOeDXttnfwa58PtP1yNUtLhnSC7VTjeoIX868y1JDpN5Z3KgD5WXZ0ByPu/jXR+HQr+FZY53MWnX0he3AY4Rgc7c/WmdnxI94+FfgOfVPiFpVhbKYNG0YvMJ5GJyCM4/WvqW0ulKZkTcFYfMo4r58/Z7TVpriS6DMluMiVpUPzDAAAPevoCLzI7dmVfMAGdo6D3rupr3T5LNJNzUL7F1W+ZsDjNS8t90YrIs74+ZJG3Y8VoRzGTvitDwmSsjKMls09HG0c5qPa2cHkURjaxAHFVczbOj0y6Cw425q8l0P7lYdoxWMYq4sn40zF7mxa3SmYfMAQeM1yfxY0X+0vD5uBIoNrly3+z3P4VpLcFJgwFWrqzi1zS7qyuBm3uYmif23DGaBH49/tEfExPFXjSeKxbfp9nIYY3GcNg8nmt74S6odsJLelcT8bvh3P4L+I+v6II5NlrdsI93JKk5BzW58NY5rJYtwxyKxlJIR9E6pqRbR/vdFr5R+L1y9xcSgZbk19G3V4ZtLK5xkV4p428PNfXDELkGoclYDx/wvpryzBgMc169pFr9lhUsefpWbovhV7LBEdaOpNLDGQAR9K55anVTfKaUmuJbxtk9K5LxB4t/dsqmsLVr66ywG4CuQ1L7ZLu4c1UUXOpoQa/rL3TNhuSfWubMbScnJ/GrzafcO2SjHmrMOkzbchGz9K3WhyvXUxP8AVNwK2NL1ZojgtiobrSLhh9xvyqktlNC33GFVcg7e11z5clu1RXmublzvFczbw3Eny81bbSLl1wqn8aVxpORDd3n2iTrk5rqPDK7dhzzXNweH7sSZKE/QV1Wl2c9qgLK2Pes5HuYL929TsornbGOajlkWVSGP0rnxqDK20nBFWo5WmGRzWbR9VGvFqxDqWmxzLwPmrj9U0ox5ONprtZt23kfpWNqCb+/6UK6PKxUYVFc5nTtXn0yQEsdtej+GvF6XCqryAZrzy60xrhjtB/Ciz0+7s5Ay7iBW3Q+XqxUXofob5ppVlP0qOitrHKTeb70eb71DRRYCbzPejzPfNQMcds00sfTH40WAkkkFR+YaTlqTBosBNGx5qletw2as+Zhao3Db91JgTQsPJjGc81ZlY8VhWd0WuvKJ+7zWvK21Rz1qbAMZjT14qHOWqVauwEimnZI6Uxe/anj65osA5XIp6tu61FRu20WAsCnLVXzPelEvvSAtrSlgoJ7VU80+tHmE8dc8Uh3PXP2f9B/tLxRLqLIWhslxyOCx7fhX0pGoVeOTjniuC+D/AIVHhfwXaq6/6TdDz5D3GegrvV4VjVWEVLuZm+XGM0i4iiA6nvU8cYkZmPI7VUuWO5h0xQBSvpiEPasuxUy3RY9O1T30hZcZqTT4RGm4+lBqtiPVJgqsCfoK+a/2kPGX2HR/7IgkWK5veDJ/ci/iP417x4r1iLTrW4uJJAkcSF3ZsgBR1r8+vij4yg8ceNtRutRaZ9Lt8BYYsgnn5QKwqTsrHu5bhvbVbvZGDoMnnas8zFLeCUNHEZB92NQct+NenfCGJb7wXFCvzSwTuu7b8rDcSOvHNcNpWnprmo2V1cWTw2N1cR2kNvIACUHJr6B03R7XS7GO2sYFtIk+6iDAArmitbn02NrqEbIyobvXrm3nt/BHiOS01a3bM+iXSxDI9UO3n8K1rDxd4k1BrHTPG2nrp0M2F89djrKR2bGMCqOqaHY3fiDSDLff2dqMrMsVxCNsh4+6eORXlvxE8feD9W1BrO/j8SW97ZuY3u7OTerkHBypPGaGY0Y+2SVrabnuV58Qvh58PtT8gXFnb3rjEn9nwBwPYsuRmsjxdpeieONPk1bVbA3UEiiOwiCmOZwTwTkd/evAI7Oz+zrrHhfQry9jtW3vca1tZcnoQi5zz7VJo2qeM9U1lteke4vUtnV5mwyxqgPIUdABS5jolhXGPNCXvI9Jt/gvoMd1a30lvIjxDcLfduRD6HsT75rg/wBoTQ3tWstQtwscbL5ZQDB47+wrt/iZ8ZLTQ9Ntl0yeKfUZVWRVwMIvcHmrnhWGTxdarrWt2CxTXEflJCxDKyf3sZodpaI4ozxFFqvX1R83fDy/1TSdRa6ty5sS2bo4JBGexrrPH3jiCxuo9LjUTw3MY3eS2ChJr1Hx1pOg+A/Bmptb2S2/nZCIucux9K+efDvhm98QX8t4UeS3tyJpWUZ6dKiV46HYlTxl62x6DceDNPazW4W0QTNDgnHJGP514Lb6bcT+ISLbieOUyjPXg9K998ReNLfSZtOVkU204y5YkMnH50210mymsWvY4YZJSx2zKBuA/CqurnlNzo3lJaM8/wBD+IV83iK1sWtAhkO2VeOPevVLaQy3HAHoAorzjxt4Vg3w6rbytbXkbg7iSAa9P0u6jvNCsQgaKdf9a3G1vcVz1FdM46mykkX7PKgOw7966WymWSNdpAPfFcv5imQKOG6mt6xAjhBLAGvJqQHCRs43KCW6VZjlUR571mn5lHNTRyKVCmuSUeh0qQtxcDB2Nk1ianfGKM7j81ad2yRo204b61yGsXrGTyh8zscYpWsVzGXI73V0MHJJrqNL03bFlx29Kg8P6KsI86bhj/CR0ro2uFWFgAAFGc1WttDJtGPb64mks6yRHys4LDtXR6Pq1tqgDWsonA5xnkfhXC3zre2sjo2Bk5rzxbjUtH1RbrTpvLnVvl5O1/Y1pGm5E+1UT6igu1kTAcFh1wamF4VXhuRXnHhf4lWeqW0aagI7HUBw6ZCq3uDW+fEtl5nySI3vuz+tV7GRpGsmbuoaoZLfa4BP0rl9R1230y1knup0t4k5LM3I+grE8Y/E7StAtXAZbi6bhYVPf3rwrVtS1TxnqgmuS3lbspCc7VFXHDt6sipWXQ9duPi9YalcGGwtprzbx9oYYX8O/wClS6beTXUheT7zHP0rz3TbGTT2jMaBwzbcYIOfpXpPhu4CRnfF5cu3IyM5pyp8q0JjUT3NGTT3uI9p6MOa5DW9Bm0+481Fbywc/Su5nvDG0fTLLkZ61VuZoL6EqwBzx0rDlZrzJmHoutLtVSc9utdVDfBlGOPxrgNYsJdJb7RFkoT61d0fxAt1GsbuA1Q4NlqR2UszvwDx3qvcSBQG3c96hjm2xjDZ96hupN0fP4VnyhzFS8n3Bj94VgTxqsjFPmB7ZrTOcsCCFx1rHu5A0u1Tw3eumETFvU5/WkEzHLNGq9SDWVex+VauEcsduQ2a37q3SRvLO58/3axNStY8RqsbLKrYYN3FejRiZSaOWk8Oz6hF9oWZSIjkxuPvCkm+IVlpcMcSW2+YLzEo4XFbfxJmmsvD8S2EHkqcea4649q8+8I+DpPElxlpzBEPvNIPmPNeiomtOEXG7NfxRpWo+ItOXVBbKiDkKmCQMegp3wd12TQtecyRtJAY28xemePSvUbOxh0nT4oQ4dI1xvYdfwrjZIbC38UstiI5naNpDHGw6gevarFGXN7rPon4C/GTSvFNrcaZdIIAreSUkOS8TcZ/A19G28f9j2hh+0/NpsZeORypEkBHOR3BHavz88A+ENb0G+k1MH+zo5zsjACkFm6cZ/WvYdP8X+N9H16wk+yyyapYW+wQs/7u9hH8O0/ePJ6c80+Z9j0IYWNV+5Kx9M6Lr+i6TpdrA7RyaHcsZrZmmx5Lk9EY8Yz2615v8btH8DfEC6nsfHuhXGnXoT/iW+KbUgLJgcLIw4/PFcFqV5qWs+H7uZNCj/4Rm6n3XOnJKWn0yXu2wfMqk+gNaXgv4XeINWtkMOtWHiHQ2+b7B/aMikr/ALpBOfrS5n2OuOBpQXPOZ4ZZfCnU9B8RZLJqunr8kckcizd+OUJravvh5f6LfG8s9FvFvG6xraud49uK+nH+FXgfwxDDdLquqeFbs4zD9rKpuHOAXXGPpTvHPxU1/QvDuzQPFlpe4UKst1exB1HqMDJpW6sp1PaTSoK6Pl+H4Z+PfFR+0SeGdUsLKN9+J7Ro0Yf7zDFesfDj4f2fg/S45vEoS/n837RZaJBh/mzw0mOFUe/WtjwhqgujLqvjvxfNrlzjdFptrM0sY+pU7RVjT/GbeKtSlnWyFhpluwjt4UGXY56vg9PSmrXNajlFNR6HvPgtp201J7lIkmlO5lhUKq+gAHbFdjFIzRlY5NjsOtcdo7strCpbnaPm5x0rpbVfMba7bVYcmu6Ox8PiG5VG2U5C1veM5O5uuR/Ktq1bfh16GsWW0WO6KK25McGtexOz5Q1UcppqrMvNM3FGxViPPl8n6U1Yd2WbgimYyLNu24AFgv1OM0s128bbcbhjtXmXxyvvEtv8PdRPhfV4dE1L5f8ATJ7kQKi55+Y8V8a6lcfELw3428HjWfHU+tRalOrL9i1DzosBsEHHH61Rk9z9E/te7BUY9a1NLkedlCgk9MVz2loXjjG07mVfXniuz0uzSztTLnDkZAPWk9ifU+Pf2tvhnpt94wTUUt1jmuI/3h/vMO9eAWfheHS3wMDBxX0p+13qk2nraXJXAJKg5r5UXxFNeSHjrXJLc6Y8tjrJbqOGEruUjpXO30NvNIWO001vNkjyS1czrV5LaZ+Yj61OonynTwWMLr8gXNV77w+J1J28fSuKsfGEkM6rvzXb6brxuoxnnIqGtRWTWhyl94biycxg/WsebwjFcdI1Ars9auDztQ/lWTb3LhgCOnPSrVg5WYK+AVwNkQ/KrMPgIdPKx+Fdzp98AoyqmteG+hXBZF/KquP2dzzV/h4uwkw7vwrA1P4fxKCWgx6fLXu0eo2jjBCj6Cq99a2d5GRtAPvU8zKVFnzr/wAIiIJiVj/St7TdDibAeMfiK7zVPDqq25BkfSodP8PSyPhYz+Ao5johJR0Zm2fhS1k58tfyqS+8GwtCdqg59BXcWHhO42j5WA+laX/CIzuoAVs0uY9CFaCR89a14SeO4yikfhUdjo86ttIb8q91vvh7cyMT5bVWh+H1zC3+rP4ilzIFO70Z5Ovhm4m4WMn8KrzeA53blG5r33T/AAPNgZT/AMdrbh8BtjJT9KOZHQoqS1Z842nw/cdUb8q0B8P2VQTET+FfQy+BnUErHk/SoZPC8iZDxcfSnznFVwul7m5RnFQl9vemtMPrXbY8InyDSMelVjMPpSGb0pAWCw9cU0sPXNV2l9aQyCmBY3ehoDepquslKZT2NFgJ2b5TVGbOTU3mEg5quzEtmkBg2s23XGQtjiunY/KpJ7Vykny+IQR3GK6k8xrntRYBNwzxUqnIqoW564qRJffNMC0hpxcCq3mCmtMBRYCy0uOlN86qbSmm+afU/nSAutKTSeZ/nNU/O9TSiQHvmgC4snOM4/Gur+GXh8+KvGWn2ZBaEP5kuP7q81xauVbK/jX0V+zP4XZbO/12aPJnPkwMRkY7kUAe7W8CxKFThMfKoHAA4qW4ysfsetLbxkKB6DiobqT5ggOSTzTAfG22LPSsq8YgknpWlN+7QYrFvZi2R1osBR2iaTk8A1bvJktLQk8KvOc0yKMIqnpXLePPE0Gg6XdXlzKq29tGZX3HHQcDNTLY6KcXNpI8A/ao+IsllpsHh+xnX7XfMGuGY/cj+lfLulw2y6g5ic31vZhr2+mYHHmDhU960viF4qu/GuoX+uTRuxuJDHaq3VsnAAHt61fh0y4utJl8L6PpQmm2xreXSuFKueSD6/hXnzfMz9CwlJYSgjsfBOg6z4ludI1vVpbeO0iYzQWsSYbnpk49K9mURrbu7jCouSx/uisjw/pP2HT7O3OFaKJUKoDgYH1rK+K3iL/hHfDDQwnFzd/u1xnKr3NabI8WTliq6ijxfxlrWp+OPG0J0+eRGWcCBo+PLCn7+KbffELwlrnjZrfxdoJkmtiIHvbGTZ5xH8TKa734ceG49D8H3/ie9iLT3CGC0DEHGf4sfWvkfxxrF1b+MNQjYKrxylHJGS3fmseh7bqqM+SnstD7x034peEvCtjbWq6be2GlyJiK5ZI5YZB7lcn+VJ4p07VfiNoLQ+GdRtNJ0mYZZUUbpfrjpXjPwJ8Ua7pOir5EVvqEXllpNPuCNrr6pnuPTvXper+IvE/gW6bVo/DUNxp98ilVsXZ0Q4zyuOPwq1scUoOMuaD1Oaj/AGZorHT7u91G++03SjzFijyI8j1O3NUPEPxtt9GTTbKwRCIgsdygVQFA4wM85rqvDfxt8Q6/qH9lv4dzczAlCoKBB2LAjkVl/ET9n271yFNT094l1ec77iNm2xn3XpSs+htGfNLkxjNXT9Q034gzL5T2t1ZIuTCfnfcRyMVq6f4X0/RbVoLC1itonJyqjJOeteYy+EG+B6WOqXNxHJPKdsyxSHcc+1c5d/FTxN4p8RN/ZLm2jmIhiRVBCKTjJqbrZmNTAzlf2EvcRifFj4eTabql3c2Dy31gHw8jHcUY8leKq+DdF1Pw/o41NxL9hnb545AcIB3wf8K+mfD+h2+k6NDaXRt5biTBmLEZlc9TiuQ+KXhXUNe00aJoi26KwLSxkhSB2xS5eqEsYpRVKorWPmHU9Uu9Y8SYSaRrVrhQsbH5SM17tHZ21pbpucR+WMhR/ESOgql4W+A8tvos7agPKvZBtjX7xUjoRjrXCXvivXtB8QQ20m6GS1YRCORQ3m84yfTNZyXcVWlDEaU3segWcUt9fNMFZR91cgjFdJJbNDHHGr+ZIDkkVQ0K+jvreW8l/dOeDCv3Ub0B71UM1w0/mCQgK3zYP6VxzR4ck4SszpYp3ibawOemKlF1sbLDgVRDrKrSlju96jaQlMqcsa4ZR1OyDuip4g11LeFyH2n+dc/o915kj3d0rAN0GKreKzI1xHEc5J5X1p1zqk1pprIq/ugmAvXk1caakZVJ22NSTxZIXdII8xxjJLA0y68QSyaRK+14ywwpJxk+wrmo9YnsbORhDH5/AjOORnqSO9WHklu1TzP3zYyXk/kO1dUaUUjm9o3pcmtr6LTbPddyebcMvChqrbYb6KIJIN4O7aRk0y4nhtbZnaBZZ+m5skAe1ZVjqEcczu0m2cA4VQRg1fKlsZSuw8RWqtcRxOojAHzSk9fasXS9bukVwzskAbYnzcHHtUmuJdXEKzmVmfO4jmubY3MVwrhTgfwkHBq12JvJGu93a3Wrxi4OIy2C26unt2XTbhIiSFPKsp7GvNpI7w3jlbcsknOVHSuns4dRmtoy4ceXyuFOTVOwWkzudPjZlkuJHZsHejYOeK6G11i3ma1InMdq/wArE53Kx/8Ar1wtjqU0scUD7lKcNkHoan/s6WZSgJaPOVODWbVzRcyR3F1qbW7SQvMs80R2xt/F9D61JaO0sZd8sZF52ttI/DNccvnW5hecEyR8GTnpUDawrXASScLGpwrb/mFTyIvmZu3F7PHbTQujPEW25dhx+tc6Zn0nUEDKYg/Tkc1YhuJVkImdprRm+WXcCR9aq6lbm9m5lMjRnIPtWM4pI1jJnoNjcPJAjbuMetX2kxGrferM0O3cabDljyOavDbHv45A4rz3qzsXcZfbri32xjax9K5+aAWsgQLufHOa2bqJpFYxvsYrnrWRHDNIqTTAkqcfd4FdsVoZSepUks2+YkIFbrknP4Vn6lHHpmjTy3bq0KfMs+CSD6VutbteXSiIB2zjAPX8KoeNNDXX9FbT7K6WB5AA/wDsHvkV6FGPUzupPU5Hwbeaf4qZ5Ls+fJE3yxSHCkdjg9aX4iapZeHIYZooNt0ylYzDhQPesbwnoieBtTlbU3kilwdlwD8jL64pfGF4njfS2Gn28l2lvk+Yo4J9K7Oh1RilLyIfDvjb+07F4rlZnuEHDKCd9ctHM2i+IzdCCaO2lDLiRCACRTPCv2u11CGSOOQGNsOgHOPeu78Vx3GtQx2sIHnMfMVCOSAM4qbs0nFRd0enaTrsH/Cqra+u42uFhjCsqdeDwa9F+GnxM8PeOPDZg13fHLayLELggiSDP3JFYHI+vtXj9vrkdt4Nt7Wa1MlvfRiNolByGIxkD61w/hPXLzwL4kZoo1eLmCa3ugdrxnsw9fQ9qGzpwuH9rBtOzP0G2afpd1D9t1CG3upEVYr4yrGLxQOC2R831zXHXnjTw/4cuLyGeyfwzrb7jBJMhitrv0YOilWH4ivDdX8O+ItU8P2Ud3Zre6Ip32epAtI1irdUYKCSvvXWfD/4X65Iok1ZbHxHoBTCKt1JKAPRfmyp9v0ovc7qeGpQjzVJkl54++InilvssOi2Op2zNtWVLETwke7E4Fdd4N8BQaPHJJq/g+C+1J18zeEiCL/shA+a04fBngfwX9nvJNbvfCkbH5bZrqSKIn0w/Fcf8WvH2oNcR2Ph3x1po02ZcFjMrTZ75KoCB+NM0jU9s+ShGy7iat4w8Q61qieGbbTNL8G2k5IZnKPJt9do5H0qlfanB4d1Ww8MWEM8duku+WeTiW6cHlsdQvsai0q60T4d+E5NajtbjxJrMxwL2aNmgV/72X5IFcZpd1e6t440W/vrg3V1dl3dj29h7ULcqqoqm1HRbH2jpcyyWsDHPzIp2546V1dnIska5jHA7965DQo8WdtgcbB/KuvtWCxKVXJA6ZrvifA1PiZQnf8A0ohQEUdgKvWrDcMHNZ8zbriQuu0+mas2Db2wKoxZ1MGTEDjNJM25SD3qKzk/dgHmpn24yBk0zJniX7WEYHwN19ATkqvK5z1r4y1/W5vDuk/DHUhavei2id1hTOXIfpjGK+3P2l9F1HxR8K9X03TLSW7vJgAkUIyx59M14V8IfgZ8VPEOn6fYaxfL4U0C2XarLAn2sqTzjIOKdyOUTV/jj8WtZ8MjWIY7fwjojTJajyyDcOW6DHJH5V9s+ApL1/A+hRXtzNdXBtlaWaZwzEkd8Vw/hT4L+F/DukJpj2b6v+9Fw91qUhkkaQdD7V6dp0a2yxIqhI1wAqjAUDpgUyeU8D/aw8MLrGhWQxhw/Yda+YdP8AKk3zLX25+0JpIvfDlvcr92B+W+tfNsirF83GPyrnluI5f/AIRO2hhwRjFeSfEnT4bXzPLNew+IPEEVnC4BBOPWvBfGerPqVw4XPJqSNTzrT7K5utVUIGYbsV9DfD/wRJdQIWQ9B2rz/wAC+HzLexsY8knPIr6r8DaZFaWaNIAu0DtWcmjohTqPZHH33wrjeHcU598CvO/E3gtdKLMq5x7ivpm+ngkVlDDGK8r8baOLlXK981mtzpVGpa9j50vtaksZig4FSWniCSc4Ofzrb1jwRPNcsRGxGataR4Bk4DowP1FaXH7Kr2KtneSOQQG/OuhsC0mBg8+ta9n4JFuoJBP5VpQ6HFFjHBpaEuNSO6KNjov2xwpXrXrHgv4Zw3Eau0XPHaoPAPhNb66iynGfSvprwp4Nht7RPkwQO4rCRzSk+qPMofhZbxwj90AcelPh+FETvkKPyr2C80mRW2hePpTINPlhYfJn8KkjmZ5PN8Jo9v3P/HazJPhb5bNhM/8AAa97+yllHy8/SmDTGdsbR+VTctTa2PCofhq548v9MVZX4duvHlfyr6AsvD4YcoPyq6fDcfXaOfai5p7aa6nzsvgNk6p+lOHgNZmIMfH0r6Am8Kqy8KB+FUW8KkHIXH4UXL+sS6s+BmmPY00ynvVbee9LuB617RxE/mZo3471BuHakaTb70rATs+fek3GoBNn2pd+e9FgLKZp1Vw/vRvPrTAsZwKhZucU3zD3qJpKmwGLqkiQa5AScFuK6UuPLGK5LxPIY76zmHG1sZroFmLwqQSQRmgCXd8xp28etUzKc0qymnYC35g+tIzg9eKreYaPMpgT7l9aNw9ar+ZnvSbhSsBZ3D1pNw4qv5gHejzMtwfeiwF+GN5WVEGWZgo+pr7f+Gugt4b8H6ZpzjBjiDOMYO48nNfJfwd0M+JPHul2xG6KN/NkH+yvNfbNrt+UgcY444PvRYCyuI1Yn7oFVIfmd3Iz6GpbibcCgGCabIvlxhehosBXuW4PY1jSAySHnOKuXjFVOKqbvLjLnqfypgV724FvbuxIwozjufpXyJ+1J8UbeaO58L27vNNIBJdMrHCj+7mvdPjP8SrPwB4bmvJZQblgVt4T1eQjpjvXw5pGj3Hjy8uNS1K98i2ubnfL823zuenPYVx1ZvZH1OV4XmtUkth3hLTLO2htdZ1rUI1EYL21rMwAGOhxXovwL02W6sdU1mcsP7RumdRxyg4B+lYPw18J2ninxfrd9e2sd1a2uLW1jkAKADuPevddP0uHT7VYoQscS8KiqBt9hWUV3PSx2JSvTiWfLS2j35ARRnPHFeAeKtXm+JXjuKxgk32/nCBAvPAPLCvQfi54xHh/QWsoZgt5dDaOuVXuaw/gX4fj02xvfFt5GSsaslqr4656j3JqHeTsTg4ewoutPdnpWpaZBHJDpqbY9P0S33vgfK0m3vXwR420ddb8XahqZOY3uGLKvTrX2h8TvET+E/h3MryD+1NYYll6EZ6j8BXyfocfm+KY7fAkjucxuGH3uOtTJ9DqwlFypurI67QPF2m6RoVpMbtLRlGExndkdhivdPCfxovtP8M2N7Lpr61oUnAurUnzIfUMDycV8heJdCn0vWHtB/qZQZItwyB619Lfs1Rz6D4Knjv7qFtNupfMjy3+qboyn6003ewqlOmoXZ2HjbxRa6tb2/ibwdc/aNThT5rUwNude+4be1eeeF/2i9U0y/uYfEELXELE7Yo49rI3uOTj8Kn0z9oK68JeJLzSUsrW808XLRxxBwDjOBggf4V6Pqkuga5zH4aVfEFxHkW9xCFJyOofOKq9y3FUopVocyf4GTH8PNH+KGmRaxrubi5uP3kZtpCoReygECtHU/A+iab4Yez09I7AxrujmABbeOm4968wTwj8T5BLoVvBNpGnCQtlXUbQfRgc1N4fW0+Et1eHxKuoahqKt/oyJmRHz1IyTk/WjTqc0qc4/BU07Hnfi698ZR65am+S7a6hlBt2WFiHHbFen+BfiANEtdSufGZXTr9MN50iYkZD/CFGc1y/xG/aY1y3tlg0vRF05phlLq6/eSqPYH7tchoun658StMluLy4gnkm+Vp5xls+wHSovZ6HTU/fUrTjY2fGv7T1/ql01r4UsUtISdv2y4XfK49VXtVXw4l54i06O9vUL6gsnmKzRAM5B6cnvWlonwn/AOEZjS5tnS+ug2ZVm2hdo9M10Wj3dlrMdxFazxwXsYZfLZx8rfnSfc5Va1qCNSz1rw/cSW+n/a5IL1ufsOw5Zsc9qdqWlzxKvmR+XCxyIzgN/OvnrUF1PR9fe7nmkF5HNxNEwyee3NfQngOJ/FHg3+255ZHkZiuJzk8Vi48xw42jGjaSldsrtEwukhY7gBnrU037sEKMY5qvfW5t7ln+dSpHPrmno/7ve4b5zxurhq02jjhU6HP67alpFmYciucupxYyPIfm2LuXI4Br0S8hSSHk9uK8u8UQzNJJCdw57elRSfcdZaaHMap4uuLfe8MKTzueM5xU/hf4pNbt5Oq6cySZz5kOSKitPCzyXGWJwfWt+18P20a7pY1LjjpXbzLY5lF3Ojh8RWWq25MSfKecMuDVbFvHIXWDJbrnvVK3jjiGEXaM1uaLpSaxK8Tb/lGcJil6HZCJlzX0I+RoEC+1MW+spMgwLwK6e9+GrxWr3CXYx1EeQT9TXNXHgm/kmCxyIHPZgaDsjSb6FaXUreH/AFMKgn/Zpy6nMyZ+UL7rUbfD3XPtaxK8ak9x2/Ouu0r4byQKv2+9U45YKozTsX7J9jkHup9xdcfgKk/tK/jUdVGOprvNRh0rRYsWtuJXxjdIcmuM1CV7mY/LnvxyBQc86ehx3iS91vUiYYrpo0PGVrmI/CN7at5r3Essmc8nivUY7EZJ2gk1fh0hWTLr+VRKaRxezbZ57pFxqMe6J87OvIxiur0i4mmdg7ZPc4rQutPSNMRrtPrVK3iW3uBxtJ6+9YSfMWouLPStHdf7NjyPmHBpt9P5LByxRejEYrH0vUiFSNRxU13e+dG8WM89u1cXK+a518ysWoZkugyk+bGh/j4yPwqlNb3ETXLxZe2bAC5OMUWkctvIgWTeG4IrZjsbq80+aNE2ndweOn4mvRpwbZyzny6lWxtrWz0mS42CCdQXWRzwD61y/hh21Ke51Fp/tM1xIWYgAAY4rrNQ3XFiLd0A8sfMy4Ibjp1rw/XdcufC00LadthJkOWZWYDnpwa9OMeVDowdaVkXfjst7bWNsFDC3Zj5kir+hIrE+GCXNjp08+8JbP0jU/zBrp7XWI/iBti1G+ONvzQeXtVj+dZ/iy3TwjZefZRmKNSA6KMg0XPRcHR/dyG69rOm2ckd0sgjuFHzrFj5/Y03wTqkfiTxZaXaZjjtmG9H5BzxiuO1THiMpNZWsrTMcE7eK6b4f6dd+HYdXa4g/wBKWHzkXPJwc5qRtJx3Ot8TX1xHrVvZaRKn2y1uPLW3DKGwTuUjcfrXpPin4aw+Kraz8SPaeXewxj7fZ9DKwHTGeteSaBb2virxp59uyyPfQiWFk/5ZzKM4+vFfQGreLJdC0Ow1A4zep9nmmcfLBNjALfj61WnUlTlTtGD3K/gf4qf2Bp50/T7Nlu9v7iwkkx5mOqH3+tdVpfxa0ObT7y40AQ+H/Eacy6XfSeQGk7jJwK+SdUj1WPxV5uoszapbzCUtG2M4bIKkcc19N6T8LtD+JFvFeardXYvLpVcXcbKGU4+44Pp60rt7HqzoU6NvbPcpXHxM8X/EFv7OvfBthrBztWSS3EyKfVZMla6Tw38KbPQdOl1O/wDCNtf6rD+8VXkVIF9j24960vD3wq1TwHI01l4pvprKMEra7VK/rxXkXxD8ceJfEniCXS9Q1uSy0wHZ5EJAZ+fVD/Oh7GyvUdqGiLvjbxxqeuSSW3iPVbGy0m3cCLR9LIKlv4V3Djj610XgDwTZN9h1cb3uWBKrn5Vz6V87+NNJvLPWzHJai2tbfBt0XOG4+8T3NfXHwd00jwfpZk+Y/ZwR6VdP3pHDmE+SCcHoe16GS9nbd22DmuotIyVHzbSOmayPDtjM1nDsTapXrXTQWqW0ZaTLYGT712bHx0ndmNdK/wBobfgnH3h0qTT22yjFV7y4TzT5Y+XrTILh9wK8GrWxD2OohnKrmr1v5lxyF4rK03Mygua6S1kCKAFpmD3Kc1kEw7Afj/8ArojhLR+YqlW9x/XNaN1JuhxtqvZKclG4zTAjtiyyKWbJzWh9oEbdeapXCiGYLjNLJIuCSMUXC4njCxi8T+FNQsnI3GIsvHcV8O+LtYexvJbVW+aMlevNfbi3hj/gJDcH6V8nfF/wKmn+Lr2eIbVnbft7DNc8zalS9pOx4jqT3OoOcljVO38By3socqRz3Fek2OkRRnL7Tzg10Nu9tbKAqL+VY8zPfo4WlFe8zm/CvgldPVGdc46cV3kKvDEEQ7VrNbVFVeAAPaoZNd2rgHFZnevq9PqbXls3LSY+tQTWsMwIkYN9TXOTeITzl6oya/uPDE/Q0BLEUIo6CbTbBOWUZ9qpTraw/cX+VZB1UPjhifrSHUVjblTTOGeOprYlvJ2P+rHFQaXp9xqF4qDJBPSnrdpdMETq3WvX/hN8Pf7TuoZnXcOvOKDy6uMUtkd/8I/AJW3hlkjIPHave7fR1t7dVA5HtUfhnQ4dHsY0CAEDsBWyz7mzjis2eZJuWpmf2SrckAmlGjp6YrTDd8fpTlw1QyLGQdHA7ZoTTArdMVsMvtULr+FSMbbwBRirAiVvSoV+XOKduIoAl8pV/hB/CmeWvJIXH0pu8niqmp3q2sDknBAoYbn5hecT0NHnEdTVFZj65pfNNe2QXGuB3NJ5wbvmqTTGk8/8KALvmUedVLz/AHo8/wB6AL6zelL55qgtx707zie9AF4TFs9qZ5nzcmqvnHuajabkUmBR8S3CiOM9fmrWs7gG1jO7qKw/ES7rHcOoOan0y48yzj56D1pAa7yA96b523oaptIf8mk8w1QFzzi3ekaX1NU959cUm71OaALnnD1o84etVNwoyKALiyj1p3nYzt5bHQdao7gO9SRNtbIb6igD6I/ZT0Yz6hquruuTGghQnpk9a+pbdQsPA6c15L+z74TOg/D2zaRdlxeH7Q4Iweelershhgxu+ZuBQAyMCScsegqteTncSOatLGYYQWPzGsq6fOee9AEQYzyHngc9aw/EWqR2dvKZJPJhiUs79AABWrcyLb27uxAVRk18o/tF/FC91+9bwb4ckLTMR9uuMkrHnov/AOqsqkrI7sLh5V56bHlXxG17U/jh8QJ2tAf7EtH+zxSE5CgdSPc1jaVoVhr3xMt9BZHOm6dAU2K5X5u7HHU1FpvhnULrxza+FNP1CbTLe0g8y5mg/wCWjHnPNeveAfhRF4RvrrUJb2XUbu4PM82MgelcPK5O59rUqQwdLkTOn8N+FdP8OWcdpYQiCBTnpySe+auatfRaNYz3c8gSKFSzM3p6VZdfJVTnJzgHtXiHxs8cG+uDodi26GM/6QynG8/3M1q5KKPCw1GWJq67HMSG++LXjtI4922VsfL0hhB9e2a93i+xwzW+m24MOiaKgeZudjuB09/WuJ+H+hv4D8NJdGPd4g1QhYkxyiH/AAFcp8ZvH8egaWvhjTJ8ufnvZlzkt6c96yj7up7NZqtUVKHwo5X4tfEBvGPiKSUNi1h/cwpyAQP4sVhfDnRzd+JPt8pAgsVaVmxxnGAK5zSbWbxHqAht1B7uzDIQeprs77xZpXgvSU0+1ffk8RR8y3Evr7CsUm3c9CtUjSpqlEwPiWqSaxoyJjzVjZnVRyMsSM1d8B/Ep/BuqSWckK6hpV5lZrYjcQ3qBT9D8C6z4omutZ1X/QvNG4IR8544FcRpyx6V4oBcywiGTmToRz1PtVs5Ix9suXse1eN/hReeLPsuv+FbFH06+iEktvGyr5Mo6g9812PhqxvNe8ELb6n4nbTNQsf3YWSQLsYdATnOKzfB/iJvD3h+WHTdW82G4+ctkfKT12+9ee67qM+j600ltYT65LM29ndWYqf5VcYoznjHJezk9jtNU+IHjrS4HdvE1mYbZcKYkJVwO5JHJrzfVvjdNrEiSXzG8uFfBkmJESe6gCp/FWj+IfHlnHAmg3Foo+ZXldVGfTAasnS/2f8AxDcMGmZYB/dG0gfrRysyjXpJXkXPEvhm/wDHelw3sRszJH91VkzuX69vxqPwDdSeCZm/tXUVsbct/qAC4J+oBrutB+BVxZ26pLeTGMc7FYKufoK6eD4P6NGA89us7D+8d355p8jOSWPunDocvffFrw9cWlxawrd6lJKuzNvGy4z7sBXmdn4FvLq4kuYfOtlZsqGPzY9yO9fRtj4M0uzXbFaQIOwSMVZuNDhhXiMY7bafIcSxjjdUzwWP4dyrGXmLMcZJJ/xr6H+FPg8j4f21lIFXcS2DjvXP3Gkx3TJEvG5sHIr2bwrYpY6XbxKuxVUAYqlE86rVlN3bPLPFHhwafqDSXIYrgANuGOKxrqaCa1dFjP7jnd1zn2r2Xx14ZGo6XNcpGXZUOVUZP1rxCK1vdL3zrEyxBCEhbjJ7nmuepTuTCRlXhllVYApEjnj/APXXnfiCS7sdWeCcKyg8d/1r0nUIftlu04RxxyFcKua4C+tJPtYZ1xk5B3A5/WuFw5dTsUm9zS0PTVuow571PeaUuTjipdDvFhkETH9K6Oa1EkQKDJPXiuRyadzpikzg/wCzGViADU8UMtqwkRzG46Nk5remtmhkOUyKieSBV+fvxW0ajNYvlHW/iS6ihUMwlHTkDP0q4fFTbc+UAw6VlyRW/wDCwwKFhhuG2CRdwGTzW6fU7Y4iMUbA8UM2GKDf64qhqHiS5mU4kIz71BLDaQqpeXoPmwDTPtWlqo2qST6g1XMDxMbFHyZryTcQxJ681I1mluGL5JxU8mqBV/dIFTtWU1xPeTY5K5rOU7HHKpz7EqKZpMRDkdK6Gzs/Lt8ycuRVXTbCOHknn6VpSXCRRnnj6Vxzldgk7GJdQJvJ3ZrnrtP9JBUZGa37oNdSN5YyMZODWDJgyNnOB7dK0jqrGUnYswakIG/3Rk1rwzZVZY/3gY4IzWJc25ht2XyW3MMLID8oz61JpazabjzgeSGAXpXRGnc5pVDrEZYv3iw7ZccqR976VraHeT3CmCC5aGaTgIwDD3z6VgabLc6tqxgnVg+RthxyV7V6n4f8JxaLbtIyE3EnzfMeVHpXoQhaxzyqHPXmiDT9PaID5uWZuOtfNOvagH8Qan4euIld2uM27tgYz79q+s9ZhLQyfLgdxXyr8TtFEfjieYLjzFBB5rWS0OnD1HTfMix4b8H3+g61DHq9vNbQQ/vBN95WHbkE/wA66P4la1pVpYtb7xcPcJxDGQce5q34D+J0cOnto2s/NKkRW3mJPzeiGvMtcWXWtSmkkhVJJJOFjTB+lY25T3qLWMfNLoVfDL3ei3X2d232kg3ROucfSuh1jXLjSbq2vrRo0GfLkMnKlTwc8Vpf8I3p1l4fQC5VJt2D5hGVb0rjryW8laSxlVCjHAk4I2+tDMZLlloez/DG1l067m024t4P9KX7Zp95Ci7fdQQePpVn4geNrjSrp7BLS3m0nUF23aXGWTz+hO7PykVwnw38fLo9n/YerGRfJO61uOMqR0NaF14ibxlqUn2K0upLaT95qFokIkIYcGRB2zT6GtCKlUcmdn4T+Gc+hzQarqmgy+JNCba8V1pt1vaDvjauSfpXsWu+E7PU9NkutJ12fTvMg3LbTTKjA44BzjBqL4Sw6db+G4IvDOqrdKh/ew3EOHRj1DDqKqfEHxJr9hDc2t/4f0O40phu8ya7Ee/6KfnzVL3UFSrUxNZRWyPn268JePL6do31C5+zs5RV+3ZZz7KGyfwrrvDXg2y+EunnXNalF1rcwKW9nHl8Mf4nOT+tdR4J0y3mkl1J1gtZpUIjstKjfJHp5jH+VeU/GTXtUtZolvWWG5diINNgbebdOm5yCck1Gx6rqqUvZbWL1z42stZ1C4S8n8++Iw+R8oJ/hXHYV9cfCjS/7P8AB+mIX3nyt3Q9D2r4L8C+EdR1u+hmEbNEHDPLgkHnrX6KeE7FbPRrGFQP3cCrx9K1ongZk1GKSZ6No87/AGSEY2qF9K3FJZMgZ46VjaLHm0jI5AGK29v7oY4NdbPmfM5LUEYXLLt2+1T6bb4YsRnFX7qxZ7gPI+QOgxU9vGN2V4quguZlm1YkDC4rTt2l4AFVLWNu/Na9jb7hyKpbGb3HtllUGmvEV2kHBz1q81rtxjmiW0bauB1ouQ2RXUizQh2XDqOvrWYjvISWGFqzdK6sEPyrVK4uBH8vakWtrlhZVHygA14x8edFa5jjuoUJccNtWvU1uAGP8PpWB41U3lmYkXezqePXiolaxrG62PlI2s6sVOc/lUn2efAGWH41tXnF1KkqeXIjEMD1zUS+wFcjKc6ltzKFvL3LfnTPse7qWrdjbaTuUEVKGhbqgqTFynbc5o6ajHkk07+yYeDgmuojgtnP3R+VWFtbXoSBQReRzC2MccZITkCuC8Y6tNYrJ5aEEeleztp9sy/eWuT8ReEbXUVf5gCfSmjOVzwnQfHd6uqAPuxn1r7T+BPxItoLSA3BVSAOc18xS/DKKC48xMnntXQ6Ja32lqFhkZQKb2BH6C2vxU05o1Cyjp6//Wq3H8RNNduZ1H1NfDVlrWropBmb9aLzxbq9qhZZm/UVkVc+97Xxhp9ww2TLk+9bNvqlvMvyutfm5Y/GDWNNvQxmOB/tEV674X/aJkkt0WaUEr15NKx1UqPtD7RW7jOfnWm+fG2fmX86+abP45JcKCsg/M1qR/F5pFyHz+NTys7P7PnLY98e6hjyWdR+NU21q2VtvmqPxr55174wSw2jlGyfrXiWvftFXun37ZkIUH1pWZhUws6e597jUoNpbep/GvPviF4yis7WVVkAOOxr5f0f9qR5oQrvk/U1g+LvjVLrAYB8Z+tNxZhCm77HlHm470ed6mqZmNIJCetevzHKXTMPWmtNVXzPekaT8aOYCz51HnVV8yjfn0p3At+caVZjVIybfQUed70uYC951I0h4xVMTehzS+caOYBNWYyWMgHUVFpE/wDooApbqQtbuM44rO0mcgMmehpFW0ubvnEUecT3qqWPc0b/AHoFYsNJ6mk833qvv96QvinzCLfne9J5p9aqeZSq+adwLqyEV0PgnQZfFnijT9JiDFrmZUO30zzXKqScAd+K+m/2OvBP2rU9Q8TTxlltV+z2xYcbz94j8O9MD6g0fSU0mztrSNQsVvGsa7RxwMZqxJcI0xOcqtW58RwbVXHGA2KyZm8tNo596AGXl55jcdPSsyZtuWJxUkshzz0rG1K82KxzlUG481Nx2voea/Hn4jXHhXwndGwbffTfuoFH948Z/Cvim6t77S/Eei6T9smhvb2US3lz1Zmb616x+0t46v4fGWg6dYCJ5pX3FJgdoLcDNYOh/DXxBqnjy217WYrKCKEAhYQeSPauSo+aWh9rgKaw9H2kup2Hg/4SHQvEkuuS6xdajdOu0mQAADpg4Neg+W6x4JG7HO2oGuhbwktIkY6nOFFcf4w+IFr4R0+S8uZQcgiOPI+duwp25UebOU8VOxW+JHxEh8I6XJFHJnUZlKRqrYKDHJNeW/DvRI76ZvEesh5LG3fMUZz/AKRJng47iuUkv7vxfrw1HVSyQzyfdyOnZa7aHTNe12d7aCy3CIBbYWoIjC/y3fWs7OTuetFwwtPlvqyfx98VIvD0k1xlbjxBOuyGJWytsnY4HGa+e/EWpTxytc37NJJOxZjuyXPqOa9yX9k3WfEmppe6pqkehxNy64EsxP1BwPzr1Dw/+yf4Gt0ie9mudYuI8fvLl8E/8BzipdOUjOOLo0I2WrPl7wdpPiLxVHFHDCdJ0c/eeIDzJPau7tfhXPoms2+o6PYvql0B8wuGK/qa+udF+FWi2Cxwafp6oijACjkfjXb6X8ObS3UNKMf7IAJ/Gt40dNTzamY3d0j5Ntfhz458UzETSwaPbuoXyYT5jj3zXQaT+x5pV1dLc6tcXNy3UhsAk19Z2+gWlooEUaoPpzUv9l72+VSKv2aRySx9TaJ4lY/BPw94W00R2mnxlVHBcBiKrJ4Ptl4jto1zzlFAr2/UNDxZylueOmK5JLXyZCoT9KfKlscbqzk7tnCx+C1Xn5k+lTL4ahj4IZv97Fekx6ckkO5hk/SqdxYIv3cZ96dhc0u551c+E3B3RjCn2GKzJ9BblScV6XI6w53lQPqKyb6eybljk/7IosQm0eY3WkyWcm5QxFWbWzS+hwclvSuh1TyjuKRsw9K5trlLWbKRuh7iiw7sqw6II9YjjKcZzXpWnwCOJF9q5HTdVhvr6NDGQ/Ymu209QqjjmsnuS3oaaQrJCY2GVYYOM5rxr4vaWNDdZoGZUXn5u/517WmNtWtU0qK+0/E0UcuV24daTV0Tfl1Pji50m71jJ3PcwsPljUqF/E+lYE2nw6fI4kuEM0XW2U7gPZT3r0H4seHpPC+oeY7H7Ezn5Uk+UfgBXKRx+HobUXKfaWmY5Hlo4UfQla5Z076HRCqc7GnmzeYEMGOQG4NdPpOoNJBiQ57DvWVdXK6pIDZx3DSEcNO5XIHpwKi/tYRSiF08uZeG+ctXj1INOx6dOSaOlmgVweM59qxr3RkuF5ByvIwav298JAADk4qySG4PeseblZ0W5jj7m1eMEFyoPXmqYt7cQgtM0cysOQPvD0rqdRtgx+X8ayJbNdxYJz9a3jUsZum+hWf+zZrfCNMJpOX3E4GKpGYeYhOBGny8A5q39jnbPlREn2qYae6qBKuPwqvbX2F7PuQ+QbyRDEcJ/Ota109YQNy/jRb2ojVcDge1X/MCocdcVg22zZJRQrbY149KybuUMzANn15qdbj7U5xwFrMuFWG4aZwWXoRmlr0BysgjtzNcKiFicHgGprexa8le2hkYvt7gYz6dak0tJ1lkltIyVUZDcDFdHoOmm4lkknQy7V3bSAhBPUg969CjTe7OKpMyJ9FeE+VHthjXAkjfJbOOvTpStZosMiInm3MgCxpjkfSt7VLa1vrzbCs85YAKvPXp1Br0P4cfDltFhF1qUSSy7t0QblkFehGBxymV/h34BfS7NL/UsvfOMx7hgIvpiuiu4fLZ8DA68DiumkhHPp9KyL2MfMe1a8tjC7bON1aM+S4xnIrw/wAaeHf7U1ZnQAOq/nXvmrRjYea801SNINWLsARjHIpnRE+ete0sw3bAptkXoa674T3Okt4gi/tj5rkDbbyNwp+vvXQa94PXUrxpwREucnHOaw7jwvbW6gZPX7wB49+KXKmdlOtKCsmdl8YfCp/sIzabYRMZGzNIqdB2wOhr50tlmsbs5DM4P3fxr6A0nxdqel6a9jHcLfQbcL5uQ6/Qng11GnfDLwl4ot1u2tGnnYbnbziTuxyMVi4O+h61HEw9nyy3PmvXUbT9PF1cQZLD923pUPgHx3Jovia0uJrqSxVSB50LYwPQ+1ej/HDw1p2kSW9hp8PlNjLLuycdutcX4T+Euoa5C1zHbb4w2Az9PfpRqpHTFcsOZH1np3izw3Npaanc7bFLhQXvbZikbN2JKnNePePILXUta+0ah4us7+0Z9qLZvLKY07ZyeD9K8ptda8T/AA+vbqxto3ltFYq1pNGzwkfQ1v8Ag/Tde8V6oJoPDFnEM8MqMkIP97HepbNcG40b1G9z1bWPjZpXgvwX9l8L2zNOqeWl5coEDN03AHk1xvwl8Kr4svp9Y1OeO/vJW3SbjuYt9D2rb1r9n3X9ae0nFzHNdHhogxREHsM1oaHp9h8EfEQXVZlk/cksY5CxLemMcUF8ka0W6T1PYNO0C00bR5SsEMUEa7m2KMZr2vQwrafbOowpiXH5V816f4yu/iF4bu5PIbSbCF/nJIw654HWvpfwnIk/huxmDKQYFwVPHAxXVTsfN4unKnpJnaeG2AtSpPet5VG3GK5nw385lTrtOa6hPlUY9K3PIZTm2+bg81JHEpxgVDMP3xNWICFPJxmmyS3DFgcCtbT1I6jGBWbFIF461rW2PKz3quhEu5PnLVP8vy881myO2RtPU1biV/KLNxikZ3Kt8yLMSy7qzTcW3mHzIsLU9xuaRj1rKuQee1BrEdPdWYZtsWfTmuV1zWFm1q1iQABSDt65rXmZVVyx4xXGRn7V4gjPUb+tQ9TogtDzX4yW1v4b8TXAYKkU371fQ5FeVXXihEbbG2D1r6L+PHgdPHfg+R4QE1G1G6JgeT7V8sWnge/ikxKuG/iDAdfzrBpXJlUtoWpvFlxHko3A96z5viRNat8/T61v/wDCETSQ8jn2xXnXxA8OyabC534Iz0IpcqMvaI7PTfick8ig4IPua6iLxlHcxjCn9a+PYvEV1Y6mEWRmAb1r3rwDcXOrWUeVPNJxsONpHTa546exYsuTisGH4pGabEmR+ddFqfg9ryPmIt9a4/UPAhs5DJ5XA+tTYHT6na6T4utL3G5uvvXR29/ZsBzxXkNvdQ6a+0jBFaUfjCCHOD+tVYpQR6/BeWoHytj8aZeC1uoWBNeUw+PE3YHP51o2/jRZ14H15pcpXIh3iTQcszQ/hXEXFxqVi+AWAB969Ii1SK5H3ByO9RXGm211yUU0rGkbx2ZxOm+OtQtW2uWIHTGa63TvihdLtBY/nUM3hu2bkJiqbeGlVsrxTOqOKnDqdivxAF9AUcc49a43XrOPUmLbOvvR/YssfTcPxpy2k6cYY/jSsbPE861Miz0Mq2FBH510Wm+HTN1/Hk1XjeeJuI6v2+rTR/w0alwnT6nL7qN5WoN9G+u4+esWPMPrSM+cVBvpQw7mgLEgbFDSUzg9DSNgUBYfvz2z+NKrevH41Fu9KAxoCxPuHbmjdUO7FKDQFhbhj5L9uKytHcNI4z3rSm+aM454rI04GO5denNJ7DN0seuaTcagUkd80u6mtgJtxpdxaoVb14pwx65oJsSUo5qOnx9f/r0wLVrbyXMyQxKWkkIjUdsk4r9JPhL4Rh8F/D7R9NCKkkUCtMwGMsRnmvgz4M6K2v8AxI0W1VPMXzhI4HOFXk1+iP2hltUQEZboR0xTI6i3V15jFR9xehrPmO7NWJjtUKB9TWZdy+WpyM0yijqFxsUohyxrkvGGqRaTotxNJ8qIhd/oBmulZD8zAZP1rwb9ozxxb6H4eNkzl7nUQ0UUCcs3HP8AOpeiOvD0/aVEmfNnjCz1/wCJ+sw65ptvbPFDLmKYvhsA98mvXbbUpLHT4Wu5I2uPLG9lbgHHPavPfgX8OfG/m3SDRruPTpz+7kuGCge+Dya+itF/ZxuNRZJdYu5J4x1gQAL+PP8AKueEXd3R9BjcTGKjTT0R4TrPj6bUNWi0rSIJr68c4LRkkJ78CsKy/Zt8c+OPEUl94i1RdNsVfMSyv5km31VQcD8a+4vDXwg0jQVCWtrb2pxz5KAEj3brXSR+ELC16wiQE9WOf161pyXPKjjvZ/CfMvhb4DeHtDt445YJdcmX/lrdYC5HsK9N0nwm0EKrDBb2US9I1GAPpj+teqNpdgg2pApP+yMVUl02I5/c8VfKkclTESqO7Zx8HhOK4JEu2ckd+g+lVb7wCLdi8LLGfauy+zm2/wBXFtNQzyXDA4AU+4zVdDDnZxtu97pB2gBu26tS11+WYgNjd3qe6t7pskBD9VrKkSa3bLW6k+qipKumdNBPuwSc1qWtyDjcK42PWFVQHiYEe9aFtr0ahdqlfqaYWOlv54jbsDwK5G+jh3BhgCn6tr2+3KrgH61hG4aTBJyPrUvcC1NqHkrtVs1lXNxNPkDIrRjVJO2PxqTyE5G2iw7nLS2MkjEs1VmsyvQZNdbJZqegqjcafwcCkM5S4t9y9MGsHULPdn5cH1rs7qy2ZIFY81uNzbhQGxz2jaesOoRSOe+K9BitWhXnv3rmGtFZSQdpHIrs9FcX1jGz8vjaahpE8w+Lso6108UO6x2g/Nj1rEhsGjuAQMgmukjT92BjnFSTueY/Ez4d2fjfw7d6c6LDcP8ANHcKOVcdPwrw3/hDdS8IwxWGtzi4tjlfMtztU/Wvq/ULc8MB168VzPiTw9ba7p8sE0KNuHBK96li2Pk3WLW4tbgTW80kdlAhRWjy/J6AkCsa4WDUoUEhd74csznqOw6V7dqvht/D80dvcwwC0Of3hGPzrzrxB4d+z3MtxDbu4dvkK4wB61xVqfMjtp1Ohy8O2xKo/D+hNaFnMkzZLZPpTb7R7gQpcEbmVtuDgDHrUFm7SX5RFUxHqykHBrx5waZ6kJqxpLZrcs2BgUsfhn7SxZZNuOuRUtncNGpSBxjP3vWtGGaS3ZJml3FuQmOKyfY6IyQtn4RCwkmXP0qtc+F4nlUbm+tbTakWjPlfMMZOO1ZH9pSTXCg4GeRRZjuitLo628nkqxJP3cnrWJcWkyySIo3HOO3FbtxNdSTJHHH5gzkn2qS8iMdxvWBgrLndGCT9enStYxZL0VzlI7doJOcqrddvI/SmvBA9wIpEZWY/KzA4JrpL7T7eazW5ikdS4yyINoY5+9yOtb+maJDqsCCWHzjEAqng/jXZTo9WcVSokc7plkLXy2jDRzciaNkDIy1s3uixzXEFhphxcSHcrgElAR069K7KXSpfLhttPgjkkwN0m3GK7TQfDNrpuy4a3RrvZhpOK9SnGx506l2c/wCCfh7F4dVpLhhcXMmCzMOBXZ+Wfr7jpVlVPOcD8KZKdq81sZXuUpm2qax7rkmteZuDisi4A3HNMaOf1KEsp44rzbxjb+XIuBy1erX0e9K4fWNPOrakIgDsTq1KxsjhLHSZL5vukDvWs3hmOOPDR5z7V3Fvo8dhCqgDI70yS2M3SnYtSPJNZ8OCNi8SbgOq4rI0281Pw/N51lI0LqeUxwa9qbQkmJ3CsPVvDMeH2JyPajlLUzj9S8Z2+uWMrX+h211qBUJ5xHb1rr/B+teFYdIgsrbVLa3deqSsFIbuBnFcRqWitGzbDskXkdK5bUtIi1CQklYbgDklFw361ny6ndGvJw5bntfjO30iHw/dzCW3dmQ4eHYznPtmub8N/Fzw7oel2cH2bU9RZAFd44wiqffNeSppt5p8m6GSSMj+KFz+uDxWdrE1/cK0LX1wg6nbI2D+tZPc7qFSHL7OZ9XzeIj4gtlt4LlrETJkfZ5AJsGvPvEXw28NeH4/7QvZrm6u5H2h7+5JZj3zXgmg3t9perRXS6pJDNEcrK+5x9CBXpXjDxdceNPC5WXWNPkkhIfy44CjyEeu4D9KTdlc6aKVOolGdkz1aHxLoHiTw+/h/SHClQqskS4X3wa9u+EuIfA8VnuLNbM0ZJ5/Wvjf4G3Zt/FkT3KFIZAU3MMDP54r7L+F3kXlnqSWzq6xyhTtbgcVtSdzjzSj7OVoO56H4TkCyTf7WDXVK/tXK+H4Wt7qRdv8OeldOgI5IwK6T5t36le4/wBbjFCt8wFFwcz8mp44FfHNUSPjkw3XFbNo3mKBmsyK1XcuORWtbvHCOv1piexdt7UHtuNSXknlW5XGD2qD+3LOzTMkq/QGufvPGFvdXBVAXC/3TSJVNvoXWPyc9aoXB2g5HBqlJ4oTJUQMPc81VbXkbcWGB9KC1Boz/Ec4trR2DYzxXM+H123MlyedgJFaWuTjUJFUfd5IpLS3ihtooAdrSOGaoOqK5UWbjUFh1LSYpQTHOCjrxzu6V59458NJo+sSR+VsBOQuABj1rc8baotrrFgUYDbdRgDPvXZ/Fzw0dS0JNUgXEkIDHHcYpcqMMRDlimeCXkkdvbknA4/z2r56+MviCOOKZcjPOK9R+IfiePR7WUE4IHNfJfjTxW2vasyByU3evWlaxx9BvgPwrP4o16MqhYM+P1r9B/g/8BYIdFgklwj7QSMCvlv4LtbaWIJREu/gnjmvqLTfi1PaWSxIzKoHGKxkzeFOcvhPQdQ+FVhbrgyJx9K8j+JXhqz0uzlKsrdelXb74mahe5Alc5965fWri91yIrJuKt1qLnoQwtWS2Pl3x3rU1nfuI1O3JxisbRb+a+kAcEfnXvGp/CX+1pC7Rsc+1LZfB02KgpER+Aq7mn1GszjNH8Ni6iVuh9wa6zT/AAYqoMtj6Vvw+EZ7NAAjfkKlaxu4VwFbj2pORhLBVokNp4ZWPHz5rTj0FVX71ZVzdXFqhZiR9eK43XPiYdHZg0h468ninHXQ5Z06lP4keljRVXvR/ZaDqwP1rzTw58SJPEVwIoWLknAPNeyaH4F1jWrVZEjk24z0zQ9zBNmFJZQr/EpqrJHDH2U13p+D+rsu5o3/AO+az9Q+Gl3Yr++VgBRoJyaOIk8rtHn8KrtGJOFj/SuguNFS1YjOT6VFHaO2Qi4oKjGcnoeTUU0nNNZsV1gSZxTWb0/nUe40bvWgB4fH/wCujzM96Zuo3UAOL0BxTCaBQBJvp6vnvUO6lXn2oJux8zfIe9Zlu6C7PGDV9/u4zWM8gj1ADoM1LZrHU3hS1GuMdc0tUtiHuPpy/XFMWloEx+R60+OMs2QRx69BTIxjrXc/CX4cXPxM8bWGjwArAzB7iQKTsjHX86ZJ9Cfsa/C2a3t7zxlfxFFlQwWiMO3dh9a+lvLWSRpT8qAYVcU6w0210LR7LR9PQRWlrGI0VMYAA61VvLpLWPG8E9hTSI8yK6kC5wc5qi1v53Jq3pthcapJuRGI+ldJH4XNum+RSW/u+lXYOZnDzaZNdZSMeWP7xrBl+D/hu81aDVtWs4tTvoB+5a55WP8A3R616jLpE0nCkIPeqVx4ankGfORsdiKQ1UcXoYsUdpZqEgijjx2jUAD9amW+KrtCMfckUXGk3lqcmLcvqtVGmMZO5Sp9xSBycnqyczPIxOdtMaRv4m3VF9p3DPWkEm/OeKAJ45lU/dq2rK65AzWb5g5FSw3Bj4xQIttbRydVxUB0+PJyBU8c4bA6Zq/FbGUcDP40bkmK+mr2XNVJtIRusYb/AIDXUixb+7+tNawI7Yo5UUm7nDXfhiGQZMZ/CuU1jQ57WbMJOPevYm0/dwf5VlajoiyHdgY+lIvmPE7mG7jYllyfaoorxkOG4Nepz+Hkkz8o/Ks668Fx3APyEUmacyOOtb4buSK0hMrKDuxmprjwDNCxaKTb9az5tB1O16xmRf8AZwaQcyLasrdGp20MMdayWkmt2xKjp/vCpYdQHXdRYOYmurJWXOKwb3TQ2cCtz7crdTULSoTjrmlYnmZyb27QnJH0rQ0O/FlcBGYBJODntWrcWaSL93rVOTwxJNH8oK55BWkSdtp5E0iAHIPetWe38nlTnNcb4Sv5LO8Szu/kPRHk4Br0Bl3HB7Cla+gzDnj3oSfwrIkj+Y5OK6K6tiuCoyCayrq2PJK1DVh3OZ1nQbbWbdoruESxN1BAIrznXPA89jc77dfMtcgfL/APTmvXdpJ256Uya1jmjKuuRUMd7Hzjrml28l1cZYgL8qqSMVzEGmoFnMNulvt+TOB83vX0Br3gy0v/AJo0WNw25i3euY1PwbNDIW8qNbdl5YLXJUoqR106tjy+30RbexZyqs45VsVBqistioWPbIo+Y9Pwr0NvDTPa+Ssi4dxhh7c1DdeDWvJpgccY461yPD6nWq2h5/Ha3ZsohAzRvIp3Nnt3q3p+grqFtIIbeQeX92U/xV2knh51jiDzQRgKRgleMUabpcPmxJHeqqxoQ2XABJ9afsUP2rOK23MckLKBEyME2tgbh3q3N4fu7iRpUfYkb7RJkYx1xXY3sek6fDE13PbP/CGXnn16VLb30UmIdNspL9u8nAQe5zjNbRpIznXdrI5jTvCg1KSOJpGWGNvmyOPwNdbo2gwxTSx2SbBu+Z89avw+Hp7yGNL2SNQH8wxQjGD+VdDDHHByFAz+JPvmuqMVHY4pS5hljp6Waj5V3dzV5SdvP8qhaYN7fhR5nXmtDMkaQD2qCRgw45pGO7vTW6dc07iK8nQ8Vm3CDnNaUp4NZN9cCFd2Rx2qjSPczL9isZVep4HtWbDbx6fH8wBkbkk8mnyNcX9wxX5Y6sx6YkfzSNux0FNIrmZTWCW9bP3UH61OtnFDkBfm9auIpbhBhfSlfCjkVeoXKLRAZ44rPuoVfIx+laU1wvQcn2qBbWec/LGaB3OI1rRopWIK4PriuPvvC7sSNu5ex4GK9lk8J3F4cspH1NWbH4dRsymQl/YClZGinY+dLnw3dwMfLVn/AN3/AOtTY/CWragu0af5w/6aKB+ua+po/BtlAPlgUsOvAq7BoakYSH8FA/xo5IlqsfKtt8GtTvGDGxghPXLH/A1pQ/AW8YbpJoUJ9EJxX1GuiOo/1JP1X/69TQaO7SBTF9Plo5Ij9vJanzVp/wCz3dtjN8ViU5JXd+lfQXws+H914P8ABbpavNcB5y27bz/PmukOgzKMCDjFdx4Z07ULXTYvslzCkmcmGXOD+I6U1GK2LeIlUerOD8P+KtRh+JFvpFy0ggkiP+sUjn8a9ZMzRL97cKwVXxHP4lhTU9BsGsznF9by7ip/4EOM11rW6qSGjAGOQwyfzoiZ1mpanK61r/2FlKqshJxis5vF1yMbIlT3xmuj1zT7T5Ga23ntgVWgjA2iLTM+7Y/xqrmcbWKNn4h1GXJA69MLWxYw6hffNI/lg+prQh89YQPsqRD8P8aVLi2jYtcSqwH8CqaLlvXZDptI06KHFzdqznsCaZY2Wh2/K75nP8K7qZN4i09GxBao2O/Q/jkVJH4uMceFjQenP+Ap3XQpRlYtzW9pJGfJ0+Rf9ph1rJms4mJU25H9Kc/iq4uuDKoA6cEVk6lrFy8R2So3YgGkJRad2UZooXvNob5AfWpG02Obc0cvK9K577TJDMxcbs9cEU9dUSOJshieoAqWaHJeP0ezksdzDcblTnd719LwWMeo+G7dHCyQ3EAVjxjpXyX4wvX1fxNpVknz4cFlPUE19BfD3xmdNVdNu8yWpwoyeR7CqhqVi4fuYs/PT9rux1bwP46u9Gl8zy5DvhbjDIemPavGfCPgG61m5indGJJ6mv1B/au+B1j8TvD9jqccavdWB3JMoGXQ9j9K8H8L/De20HCFFO3vgVFSXLoh5dg/rOrOH8C/D+4sbdBsI47V6fp/hEbcyM1b9vHHboFRB+Q/wqdZieOn4VyNtn2lHBU6a1Kdv4etoR0z9atx6Zbx9FWlaXHfNMab8KR1+yjHZE4t4U6KB9AKdsjPGOPwqobj/apVugP4qB8qJ5LWBl+6PxArOvrexgjZnRR+lVdX8QQ6dGzO46eteHfEr4zpYwyxwyKCMjg1Si2ebiKtOnHU3/iJ4q0zT4JgGTIHHJr5T8a+JhrGoMluNy5681R8UeO7zxFdOA7MGPqa6j4T/DG88U6pA7Rsys2fu/41qlY+MxeJjVlyxPaf2TvhvLrepQTzRny8g/r71+lXh7w/pPh/SIw8SLtXqABXgHwj8P6X8MfD8c8+2N1TkECuF+MX7ViRvNZadL8/KgKxx+grOWp5q1Z7/wDED4uaN4dhkSNo9y9sjNfO3ir4vv4guGEC8fSvEINY1nxxfedNLKFY9NxNeneGPBXkxI0nJ78Gly2PdwmXzrPmktBkE95qDbtp59q6Kx0G4kUF+BWxZ6fDacCIfiKvLKFPYD6U29D6mll9OmtT5TZvSmliaG+tIfrXafnFxy0tMH1zRQFx9GaZRQFx+aKb2FC0rhcdSikoqRBJytYV58t8h9625CdvFY+pfK6H3pG0djbgO4dcVJ+JqG1bdCCeMip+PWrjsS9xPxzTk/SmnH1pVYcjqO9MRas7eW8uooYE8ySRgFXGcnsK/Qn9nv4Px/CfwSt1chX13UFEs8rLkxg8iPNfPH7HvwoHi/xS/iPUYi2l6Wd0asvyySdh+FfZuqapIFYZUR56AYDN7CmtzOWhXvrxbWKSRm5PPB6/QUnh/wAJz6+Uv7ttlqD+7jxjePWtXSfCZuIkvtU3AnmK3b+ddlbxCOJRGAEAwvHP0rQi5Jp9lHbwqqBVCjAwMGmajEPLY9D71NZyB1ZQehxUlzCJIyppiOc8vcpIPPtVGZX7HpV64U27EE8dqqNeZx8uaQFZZnQnJ4+lE1nbXy/vI8fjVn5LgehFQPH5Tcc5pCMW78JqWZ7diPasS40q6tWOVYj6V2yzHIAPFXreFJyA6qR9KRVzzVUk3YMbDHtUyJIzAAYr0a80OCZfkAX6Vg3nh+SL5h07UBczbG0bIL81sRsAABgYrHKzW7EZ/SpY7xxw3WqEbKuvtT9qt0IFZsd0O5qys2enNAFhohj1qvNb7kI61KJKcrZzRYDClt/Lb7uajMI7rW1Nb+YOBVCW3MfWiwGc0AJ6Ypn2Rfb8qumOmNETSaAy7rRra6jKvGrj3FcdfeB907G3by1/ugV6J5RFONntXPrUWKTPKrnwXdRrlJ9xHY1z99p19YsC0JIB+8uK9reEc8A/hWfcWEcmeBz2xSKueZ6UrXWN/wAuPUV0yRqsKhT09qu3Xh9NxZAVPpis+SyuLfuXXsKLDK11Yx3IIdd2als9UuNL2w3Aa4gXpL/Gn19qa08g4ZMYqP7SGY87SPx/TvRawrnRefHcQiSI+ZGed+eKozqGyD06+1Y0byWTl7ebyieSP4W/4DU/9rRTIPNXyW/vD7pP0pNXKK13GYW3AdapyXBxgGrtxJ5i9dy9iORWPcMcn/Go5UguRXLbkbntT1iU2iEgfMOeOtUrqQheDVq4lCW8Kj+7WMguY2qaLZXylXiCnsyZBrBm8AWF1uZbi6jk74laujmm2nPrWaZbi5kb7O23aeWrMfM0c23wwtfJ8pr26JGeS2aLf4c2FpCw+2XJB6jA5/Oune4kRNrS737tWVdbnbImzjnbmlylKbKtj4T0uzkDC2WbH/PYZrchZLdQq/u0/uooC1kw3pbOWxjjrUn2r/aq0i+a5pNN6fzFN871NZ7XR4+b9adHcZ6mmK6NDzgPelWXdVITL6/rS/aAp4PX3q+ViuX1bd7VFNME43AfWqjXwXOetQGx1bU2/wBGtWCf326GtFHQLjL3UlhXGQzHoAayfLa8kzI+B/drqdP+GuoXTb7iRYyeuQDXT6f8MYYeZJC/16VcYhzLoecFFhXYiZFOg0m7vG/d27Ee4Ar2Wz8FWMH/ACyU/wC8K0IdHihbaijb24rTlRPMzyqx8G380YyBH+RqSf4e3Y+dzvHsQK9httLBPIUAewqzdWsa2rDaM49KnlQczPGbfwUsce7GW75xTo9JWHgKBiu9a2B3DHH1rn7y3EMzDFKxotUYp0/knr+FbGl2CW65KjLdc1AEG6tOPGxaLFBJpEDjcFwetItnHCPlGDVhZex4qSTG0YNAFLGKVfXmpfL9qcqbW9KALsC+Zb7sZPfIrnNSuLmG8ASd0UHPysRW/by4zGG5PT3qjqXh/UnuleOxmkUjOUXdSex00OXmsznvhz4v1ab4lXWl3OoSXFkkZYRSEcH2PavcY74XEJ3gHH5ivmDQbe/0z4qGe4t7iyjdmHmTRMikY9SK9XHjaW0uGTz4NueGaQAH9azUl1O7F0HKSdM7DxFeTWcaSIQUbpnmuebxVcqowyr+VQ6hrVrqtgLhbqNsffHmrgfrXH6p488OaTGfN1SFpB1SI72/HAOKHJIijhpy05Wdr/b13ckK0mFPpimTzGMElgB/ekNeOar8ZhIjx6NCwY8efMOn+6PWubt9A8d+O5vMhtNUvlY5L7SkWPqeKzdR9D1qOW396crep7dc+JNLs1Y3Gp2tuO+ZBk/hmsu4+J3hezUA6kZj/wBM7d2z+JXFcZpX7MnjDUGAlSxsA3LfaJQ5/IGuys/2UhZwCTVfFlvaeogjCL/48am8n0Oz6vgafxzKy/GXw9EpMcF9KfWNAv8AWqU3xp0uYMq2F8B2J2/41rTfBX4d6adl142Mzd1SdFx+Waot8M/hasmB4jvGx3WVm/pT98wlLArRXOavPippysXNlfYPuP8AGse8+NGnQxuRp94SvPzMB/Wu/b4dfC48HXb1h7lv8KpX3ww+FS20jf2xcuccKzsM/wDjtJ89hRlgb7M8W8K/FxdW+IUV1HphOxiyiVx2H1r6s+Fvh+/+IXh2TWFjMW2QqqqfQ14V4X8A/DyPWJVsYZrictsRlMj8n/gPFfdvwp8KW3g7wbY6fbIYwU8xg3XntyK3owe7OTNq+H5VGkcZYtcWdo1lqUReJl2PvHQeteE/EPw9J4Z1yRQCbaTmKQcqV+tfaMmmwyMTIgdTwVIHNcV49+FFj4o0uSCECJhygxwp9q1nBNHk5bjfq9Sz2Z8b+cwznik+0t2NaHjjwzeeD9Xks7tCjKcAnoR9a5v7QeufbrXC4tOx+iU6kakeeJqfaj3OaGuNw9KzfOPXP61Uv9WisYiXcA+5pWHKSjuas12qcs2BXMeJfGsGkwvl1woz3rjfFvxLhsIZAJF4HrXzl48+KFxrEzxRSYU5HBNXGDZ42Kx0acbJnb/Eb41SyPLFbyBjyPlY14VqWuXeu3pLuzlj93OaLPT7vXLoKgLEnrg17/8ACD9nefWrqCa4ifBwenFaX5T4vEYqVaRxfwp+Dt74ovoJHhbZnOMV9s+CfAulfDXQ1u7lY45EXOCBmuk8M+BNM+G+hi4mWNGjXPQA18x/tEfHhrmSays5MLkgYY8VnzXZwvuTfG74/wA15cSWOnSsFyVG015z4J8K3fiW8W7ud7mQ5OSa5PwL4fuvFGqLczEyB2znJr6m8HeG4dGskGwBsVZ9Nl2BdR80kanhPwzBpNtGPKAPfNdZHIEG0YA9hWUt3t4zgfSnrdD+9mpbPtqdP2cbJGo05HemtcH1rNa696abnd0NQanzrx64o49TTcijIrrPx4dx6mjj1NNyKMincB3HqaOPWm7h60hOaLgP49aMZ70wHFG70pAP+7Rupm71pdw9aQDmYbTWTqWNgPoa0nOV4rM1IFoCBRY1iaFjJuhX1xVkyFeM5rJ0eXdGOeBWm2N3WqRWjJFJ5PbGa1/DHh+58Ua5ZabYRtJdXUgjVVGevUmshRu4zgd/SvsL9kT4QHTbWTxnqcQ82YbLKNk+6vd/eqMJHvvw/wDCVt8N/BGn6Faqg+zxgzSKMGSQjk+9dx4U8MjULpL6+DEL80cTdPqadoOg/wBoMLy6X/R4/uJjO4j+ldRozFvMk4AJxgDgfSqS1M7i6pGJHAXAVTzgd6ovcOrIi8c4q7dtmXb6nNU5kHmQY6lqsRHYSOt/Ipb5W6VvMu6PpzWLFGBfBs963k+ZeaAOb1SENIR37VgzRtExyMV1+pQgyBqzpNPS45JwaAMGKYq3Aq/tEqg9DRJpLQtkDINTW9tJuxs4pAVGtNxBFTRhocc4rYWyXyxxg1TuLQjnHFFgGx3IXgmrCsknBXNZjRlW9KkjkZW60AWbrR4bheFwawr7w6yZKAn6Cugju/xq4jRyLyeaYHnU1vJb8EH8aRLh078V3d9pKTLnbkH0Fc5eeHSrEx0AUI7w9zViO8ycVTmtZbfhlpisR3waqwG0kwwKk2pIMViLcMvep4bxuaVgLkmlq/Kmk/smkiuix61ZW46c1IEKaYE6imzWZ24C5q6lxmpw6t3osBy9xb7SRjFUZIdtdhcafHMucc1j3GltGSQMg0mhnPOvrUEkCntWndW5HQdOuapMhAyBU2HdlCbTo5Acr+lZtxoqnOAR9K39vY8U0pu69KVhnG3OjvyBkCs9bOS3YrgsrcEY4P1rvJrVSvC1n3GlrIMgc0h3OOksn8z90WiYdApBFZ91b6gu4tbecP70QOfxroLyGWzuMhSB7VpaZfbWw/G7p3osM8uvb9I22tujfoQ4p91enagDZAXqDXqWr+HtN1iBluYFOerr1rAh8B6auEcm4/unOMD0rKUUK551NqB5AOTTLW+eOzdVRi5OeATXfXXhCCx+aO3Tb7A5qKLT9oACBR/sisnEZ5pNJeyKf9Fkkz6Z4qmIdRG7EBGezcV7FHpYOMrkflV+38K295j91gjqetCj1HoeGQ6fqeCTCPzFTf2dqBAJjA/EV7NqXhGOEDYm78BWS2hiIf6vH5VdijzNLG8GcjH0xTvLlVsMTXoj6Su05SszUNJWNlJXI9hTJucpHDITzk1taT4YudRYDayL/erf0HQFvbhTsO1evFei2thDZwqiRqCO+2topCOT0nwNb2uC22R+5eukt9NSMAbQFHT5RV7y8tk0/t6VfkBXS1C5J5HvipFiFSfjRHEWb0qtgGrGOg6/Sp47LdyeKsW1qASTzVxYTt45oAqxxhRjFR3kYMLCrflkE8U2aESRnP4UWFc42RQkhU+tc9q6BZyRXS3y7Z3Hese/tftEZ7sOlZPc1izni2Gq3ZzbiVqtJCY5CGBz706OMqwI4oNDSxk+9P3Fe3FNj/1YNEg+U0ATLIHGB1FDVVVtuD61ZXleOaAEt4zJdKFxnPeurk/4SGNk+yLZyRbf9XIXB/SuYswfOJB+Zee9Om17UorxXjvZIAONrDg/nSexrTjzM5z4jf8ACw/FWj3Oj/8ACL27iRgVvLe7UFQO2C1eWf8ACg/HLYdtFk29SHu4+cf8DNeteHfGGsa14kudMuvENvYwoS/nbI9w/wC+jXVXtzIv7tviBMfQK1sOPb5a5pJbn0lOvUoxSjG54r4u+FXjaaGxtNN0OOG1VAJI0uYwd2Oc/NTNH/Zn8T3iiTULmx0qFeWJYSFfqcYFe4iO/uLIunjOX7MBlrgQRZ/76ziuO8Ta/wCDtMt2lv8AxPe+ILtPm+zNellY+6oMCpdjWni8RJ8tOP4CeAfBOm+D3MOl6M3ibUVPz3l0yxxBv9ncR+ma9Ihi8WXEe69vtN8PQdkgjMzAfVsKPwzXzNr37SHie4H2bRo4dFsVG1BGNzY9c1wGqeO9a16QnUdXvbhj1VpCqfzrP2sUejHKsTiHzTlY+xdQ1LwppIJ1rx3dXRH3o0vmjX/viL+tc9cfG74WaWxS00uTU3HWb7MXz/wKRga+U4JBK3C5OOCSp/pVu3t52Zjgrx1LDH8qzdZ9D0KeQUl/EkfR93+094ftV22HhhiccFmSPH5Kay2/agebO3w9Gfrc5/8AadeBfY5WcHczDodqk4pbiwGMCcKfRkZv6U/ayNJZRhILfU9wl/aekjyf7Bj9x5xP/tOqGpftSbbOcJoSpJtIBSbJH5x14jNp838Eqn3wy8V7p+zv+zfL42li1zW3MOjwuGWEgk3BBzz7VvT55ux5GKw+Fw8OZs9K/Zu07UfFFmde1fTGsYJJP9GSZgxcdS33RX0jHrUEN2IG6gYBHAx6YrF0+GOCQJDEkUEC7Y1QcBR0qOFfOkabvur0oxcVqfAYmt7Wd1sdobyNiMcCgy7ug5PvWfZr5kY5yRV6NNo65qjlOQ+I3w50nx7prWt9CFlxmO4TgofXNfIfxI+E2t/Dy8PnxtdWDH91dRqMY98f4V9yah8sBOKz59JtfEWky2N3GLiGRSpWQDIHtzWM6akevhMyqYbS+h+Y/ijxvFoe5JJdrL2ya8S8bfGRm82OGY59ia9z/ba/Zg8T+A7y413RIptQ0CRizGBMmHv8wBzj3r4p0vw7ea5eeUgJcnBP9K5/Z8r1OvFZtKrpEdrXii91yT77Nnpya1fCHw71DxFcxjy22t32mvXvhj+znc38sUk0Jwcfw19cfDn4F2WiRwtJABt9gKmUnHY8d1JVNWzxz4Pfs2r+4knhzjByRX1NovhvTPBOl+YVRGReOBXR2tnaaHalUATaPavnX9of4xRaFYXEMU2GwR96ue7bIa0OA/aW+PH2dbi0tpSByOG/wr42tGuvF2vB2Mj7m55JpfGHiefxTqsskjuwZuPmr074M+DS226ljyOCNwrZR5Vc9DBYd16iPUvhn4Vj0eyiZowGwOor0VboquPlA9hWJBIIVCrgAccVJ9q96XMz9Iw9FUo2sbK3R9fyqQXXvWF9sx0NP+3HuaVzq1ehstde+aYbrvkjFZDXm7+I1U1PVBZ2cjs2MCpZnUairs8p3Ubj2pm6jd6V2H4+P3HvRupm71o3UAP3UZFM3UbqAH0U1SPpTvxNABRR+Jo/E0DF7GqN8paMgVd6d6r3Ue6PpQNPUqaP8q++a2lXLVhaWxSZlI71vwpu69KDVnafCXwHcfELxxp2kxq3lyPmVlHAQckmv018K+HIfKtdMtEWKztI1jGxewGOfc18+/sb/C2TRfC8uvzxbr/ViFgMgBMUY7j619iaLpKaTarGo3N1ZsdTVrc5WxbqJLWx8tAFVRgcUzTYjDak+pzS3rGSQJ61JIPJt+D0FaEmc0nmXmPQZqvI264i/wB7NOt2H2yYnsMCoWbF5EvXvTAn6XHsK2Ld/wB36isy4A3ZHerVkxaP2oAZqPzYNVoO+a0riMeWfWs9V25FAEqgGniNf8iox2zUgNAEwUY9KjlhDL1qRKcFDdaAMW6tQOcVRkUr2rop4Ny4rJu7faaAKIbbUkVwVao5FxUXJ6UAbdvdCUFSeaWS3H0NZdrE/mgkYFboXK8+lCAy5rJJRtZePpWLe6DtYtGcCuqeIVDJECuMZ/CqA4SWzljYgjIqDndjpXZzWS/3QazrnS1ZSdoFAGACR0NTRzEdTSvZmNiBTGgNKwE63R9anhuz64rP8spSfMPakTc2or4ngnNTfaEbgjNYCuQetS+c64280gua7QwyA5XrWbcaXHu9qRLxu5p32vPWiw7lO401GXKnGKy5rd42wRkVvtcBqZIySLjbSaKuc630qNo++PzrVurQD5l5rNkwrENxUWC5nXNqk/DKPyrGutJeJ90ZP5V0crLj1qBiO2PxpFGJDdSxqFmBK9uauabHFNe7l6sPWp5oUcfMAc9MCl0u0Ed4u0Y4JNTuBoy2KSIBjIIrmdS08WcjEDC1262jScqOMVl6ppuV+ccUWA5a1jaXawX5PWtW3vHhIGz5fpVuTTvLt0MYYqw9KzFWKFtnnu8zDLIx4UU1ZDubKyR3a4K1SutFSTJQYxzTISYdhHRq2ofnT60Bc5G4s/LbBWsy/wBKe4kiCptGa9DXSBeNt27qs6locdrZwqEwwJpbhc5jSdNSxtwuMtVw4z1xVhrUxr1z+FQsh7LWqC4z8TS/jT/IZu2KelkzHpmqGQqu84BrQtrPaAe9SW9kq81ejjApiuRiHHOOKmC7V9KkVd1P8ugRTZCKZIvynvV1ogetRtGCCKBHCapCftT8VS+zkdRkV0eqWv78mqYtTzxWL3NYnOahpaSLuUYIrMWI4xjkcV2M1r8pGK5+S32StjgZoNOZkEK4XBFNnxt4q0Iw1RTRHigdyoq8c9RUsOd1PWM9MVetbAyFQBzQD2HaXbst7G3Rc812/wBhgkX/AFEbcdWANczChhuFVlwQRXYxYMYz6UEXktj57/ac0vTdK0G1u7e1itrl5trPH8pPHtXzSt8GfJZizHjLnj8zX2T8aPh/qPxA0uGz04wiWOYSFZn25HtzzXkUf7MPibjdcaeBn7pds/yrz6sXfQ/QMpxVCGHtVep5/OhX4bqh1eSIPc7kt1kOHz1HWubitZYYyI49oboCQMfyzXvd3+zZri6PFaAW7kNv3CUbR6k5H8q19E/Zz0bR4FufEutRpEnWKNljj+hY9fwqOWUtD0lmGFopuOrPna30szIIy7SynnaB/Tmu18P/AAd8T+JFRrHQ7xk/57SIYo/++jgV9H6Ba+F9H2xeFvCk2qS9FuRBiPPr5rkY+q5rpprnxAo8zU9X0vwzZKMkIRNMv0kcgD8KtUV1OCpndTalE8f8L/sp6tcIs2qara2C91h/fE+2cbfyNdbH8B/h/obgat4iMso6xtOkf6Ak1Z1jxz8NdNnaTVPEN54ovF/5Z+fLKp/BSEH51m/8NKeGNJ+TRfBjFR0LrHGP5E/rWiUIs4/b5hiNY7GtB4S+FFjlbfSptTcdTHBcT/8AoKYFQX2n+D2jK2/gC8kQfxnTSP8A0Jga5TVP2qNekz9k0DT7VOwkkZz+W0Yrmpfj1491edVt3t4A5wIo7UsD6dTWicX0MZ4fF/FNv7z0Hw34K8KeKtcjsIvCNxZStyXmszGuB75r3fR9Ni8P2EdpZLHbW0a7VhjAGMevNZPwvs9QtfCsN3rUivqVyvmSFEKYHpjNajTtJMf4UJ4UAYFd0IpLY+WxVacnyyZqxErYytnJbinQxiOFB0Jp3kiOzjUHljTJHHmRhTkiqPON/SfuuO9XuOgrP0kndID1rQ7nJxQBXv8A/j3NQ6H/AKs4OOalvGDRFVOTSaPH+5J75oAn1TT4dSs5beeCK4hlUrJHKuVcehr5r8T/ALHPhG11yfWdD05LfzD5klqiDYp65Ar6eZvl4qpMvlt5g65qJJMD5D1SXRfAcLJKqwsnVTgY/CuE1r9o7SdPYxx3Ee1TxhxX0x8eP2c9I+NGg3CQTtper7CYrmPhS2OjCvx8+Pnwf8bfBbxRdaZ4jt7mFdx8m6/5ZSr2IYHGfauWVMrmsfWPir9qiz+wyiOdckY4Y18Z/Fr4ozeMNUm2yM6Mc/eNedXeoXQUhpHH+8x/xqgWklwOpPpmmoJFRvJ2Ok8H6dJq2rRIMkbulfV3hOxXSdNhjVQpA9K8Z+D/AIX+RLl0weOTXt8Unlrt7D2rGUj7/KcN7OHMzS+0Nij7Q3c1n+eB3o+0D1rK59KaH2g+v60faCOp/Ws/z89DTWnPY4ouF7amibv1OcV538S/Gq2NjLGrANjGK1vE3iOLSbN3aQBu3OK8C8RXV14ovJWUu0eexzWsdTwsyxipQ5Vuev0VDvpfM9a6D85JaKjVg1LQA+imUUASA09SOe1Qg4pd3oaAJjj1pOPU1Grepp2aAHfjTJuUPNOprglTgZpFLczLU7bw4r0n4W+FH8ceNNH0SNHZru4VG2dlzyfpXn8Nu0l0qKGLyNswo5Oewr9HP2Q/2eR4B0WHxVrsQHiC+jzDC4GLaLHB47kVSVxzasfRPgfwpa+G9KtbK0jVILSMQpt9uv611bEKCaraa0bQL5XKAYyTzU8x/dNVpHMzP3Bro9zUl658s88dKhtV/fZI5pl+55rQLlC1+aacnvVVJN+pKAfujFPs5Cslwe/Wqdm/mapKf7vFAzduVJVT6Cn6e5HFNuf9WKjsbhQ4G7mgDXf5lORmqEg+Y1eL5Xk1TZcscigCNeTUgNRlNvShW5oAsrUq1ApzUy0AOqtcW6vk9as0jDKnmgDn54QrkAYqJYdxPFalzbjcT61Ase00ALbw7cVeC/KMdahVelT9hzigBNpqNou5qX8abJwvXNO4GfdMFWs1rksSK0br51x0rOa0HXNMCAxq2TTfs6sfu5qz5JWmbTQwIDaIcfLT/wCzYmFS4I61MtSTYz5NJQjgZqpJp5jzxit5aVljYdM0COaNrim/Zt1dG1rG3RahksV4xxQMwWttvvTDHt7VuNY46DNQSWZGMrSKMhl9s1Wms0kUgr171ufY938NNkscD7uKTQHGXlg8PAOV7VkSM8bHg/nXoZsVbO5c/hVafw/BdDlMY9qiw7nB+c9a/hWNrvVghBPyE1qXHg+IKWRtpqXwnpbWOsMx5+UgUBc2Psfkr92s7UbXzEORj8K7DaoUZ+bIyahkt4pBgp+NFgucBaNPp0owhlQNkNt3KPqKZrWoR6pMkhjt4rhBgmKHbke9dXcaG0cheLn2pi6G8zZMCqT1JGKAucNIBO6lIdiqMHaetadjZyXCgKrYrrYfCEX3mK59hVyHTUtVwi/jTsFyjpumpaxKT96qfiJgsKnPOa2WbbkE/pWHr2JFjXPeiwXOd+aRiMHFTRWuexq3DCi8461Y2DHHFUiimLcd6kjhCntU5T6UqqKodwjjzmpFjpEwuadu9DQGgu3bS03d707r0oEI3tTNvOal2mjbSYjD1KHMmaobBng1r6gm3mst12tUMd7Iryx5Xk1gXEI85uM810jLuxWe1qPNbIqS09LmR5eOxqGa3ZtuBit/7Gpp32VeOM0x8zMW201mOSK2bGzWORe+amWNRjAx+FWrWAySDaM0WDmZnXsYW+QAdxXSRriNe/Fc3qBI1IA+orqYFDRDPpTEcf4wvbCxjVtR8Qv4ehZtvnJMsZf2ya5VfEHhE/MPiVcPx/FqMf8AhV741eCb/wAbaELHTVjacSB/3j7RXjEX7Nfi1D92yXsQJx/8TXNPmvdI+nwNKhKn787M9gbxFoEgDRfEcm2QYfN9GSfxI4rmdY+I3w68O3H2mAyeKdVj+5Nva4IPszHYPwWsPTfgp4t0PSb6zNhpd6s0ZCZdS6N6jIFReGv2cdZuGQandRWMfG5IjuY/lwKzTntY7Y08HDWVS5U1z9o7xTrQKaaIdDg6ARr5suPrwP0rmYdB8XfEK8UlNQ1Qv/y0uS4QH1wcKK+kfCPwX8OeGVVxZR3twP8AltcZb9K76ztY7cBY1EajokY2oKtUpN+8YVM1oUvdoR+Z8++Hf2X9UuoY31LVIbI94YOcfkMV6Jo/7Mvhm2UG8Nxfvjnc4VfwwK9PgUIx24/CtCEk49TW6pRTueTVzfE1HZSscfp3wN8I2qjZokThehlYtW5ZeHdF0W4C21hawbR/yzgGfbkmtu61SOxtwAQZugX0rmb24b5pHOZH71qoo4ZYyvU+KbNu6vFhhI8zcPU8VRtW85gRyM+lYEkzSAZc5q/pN95MwU9K1ONtvVnWy52w5HSqjti4B7ZqeaTzNjg5BFVo1Mj+pzSIOn0kjczA9RUl7ceSrc4rKiuzZxjbz61m6jrBnyooA0Le7eeQntWtprbQw71iab/qgzda0rSYrMV9aANfzOtRtJu461FI4XnvUQkxk9KYD0cQyYYZVuP88VznxO+Evhr4w+F59D8S6dDe2cikIxUF4j6qccGt9mEq9csKtWsxztPTv6VMtQPxm/a0/YZ8R/BDUp9T0qOXV/DDElLiJNzxDrhh1xXy7oulm61OOLaxOedq5r+jfXNLtda0yeyu7eK8tJUKyQ3Cgqw9MV+dv7SX7DNj4d1G78YeCLJjZKTJdabgDyvVl9qxknY6sNFSqRTPm3wfaDSdMjTGGA6HrW79u7ZwazBmMbB/DwexqKSQtkZ6e1cD3P1TDxUaaszX+2Z/io+1+9YhnI70x7pguQc0jolLudALj3qjq+vQ6ZbszuufrXK6z4vj02EnzAW6YrznUfEF14nvvJhdiGOOKvl6nk4rHQow0epb8ReILjxNqX2eHLhmx8pr0Tw/8PV0rw+91cKA+3OCtafwj+ELSSR3M8ZJPJyM123xcuovD+gPbRbV2rjp7UX6HwWIryryvI81oqLzPSjdnqa6jhJN3pSqxqMY9aX8c0ASbj9KRmPrTKKAHBqcrVHTloAkD/Wl3VHSrQBOrGpYx15wMc/Sok285+tev/s3/BG6+NHjeC1IaPRrZlkvbjGBtz9zr1NWo3YHq/7GP7OKeJ77/hNvEdpnS7WTFjbyBcTP/fI9BX3p5IWIs3LY7AAfgPSs/Q9PtNLsLfTNOhW206zQQwRqMYA/Gr9xN8hUdAKvlSMx+gzbd4PrWtcHER96wtFcfNg961rqX5MUyWR2fLNVK/b94RV23ICkis67bfO1MRn2xO6f8qy9NvI7W6uJJnCLu6mtS1x5kwJxXNNCt156nn5zQUdidQt7u1MkUiyLjqDVWwkX7QMDocVy3heF7XVpYNxMbLjmuitmEd3jHGc0AdOpO7NRydc0+M78dxiiRRtoAi27qZ5fNSZ4xRQAqVNUK+9SqwoAcPypwxz3pm4etG70NADLiMbetUMYYg1otIGU85qhcfKcUASxpxkVL9eKjhHyg5xTz9c0AKceuaZJ92nUnY0AZ8q7sioQoH/6quTqKrFfSncCJ13D/wCtUPl1b21HIu2i4Ffy807btpx+tIzelITCjdtqGRzUfm+poEXFcetL5g9apGX0pn2g0DsXnmXvUJmX0zVKS4NQNO2eKQzSadB1wKb5yN71mmc9zSG4PY0rgXmlUdhSfalUdhWa0xFV5rk7aQGhcXiFDyKr6LhrqVx2HFZM1wzqRnFX/Dv+odyeWOKVgOi356dadu/D8Kp+Z+NOSTrTAuxyckZ/Sp1kXB5X8qzfNPY0jXBSlYDSa4HY4/Gq7uW61RNwaT7Rnq1MCxJHuGa5/XfvRqOT1rXM3vWPqDBrrBOcCmgM9dy9eKnDYHJxUyxBuQOajmjIHSqHcjaTPQ0sZznNRhSCe1PVfegLkv3aXFM5qVVNAhuMYqVRupBGWqeGLFA7iRxnmpHXAFSAYprUguZd9HvXispowWziulktw649ayLq0MMhwOKVgM/yhxUNxbgYNaAjP0qO4ibaOM0uUtGeIwKNo9KnEZboKtW+lvMcsNoFVYLlGOEythRWtb2axoD3q5BYxwjOMn60sy9hxVWC5xeqtt1LJ6ZrpFk/0dMDgisLWbYpO5I6102gWKzWMUrnoOlZS3GZskbfaUboCcda6CGxiVQWOT9KytSAN2uBtANace8gY5pDJJkiEeAg/Gqa26Ben6VcmHyrUHHOaoLkbdOBimhDuqV4SqhscGkjU9QKA8ie1Uh8HpVma9Fqp2jc3bHas28vFtI8fxGq1szSKZG700Q9yWVmZizncxPJqteEStszjb0qaVgcAHNU5pSsjEDJqgKn2d1kPXFXLdRGwOeaZ5hkA3DBqSPOa06COmtpy8EffFW7eMeZurPsRuhWtSGPbzUiCfO1s+lY4j8y4C8kZrWuGG3g5qjbx7ps0CNuFAsaAVMsmyZCTgVVD4xT3+6D3oA02bcetMZvSmo26NTRkdqAASFWyeKmjk2uCvJNUrj5VzS2U5ZSDQBuK24AHvWZcWqLM25VdHG0q4yCD2xVmOfy1p8i+fESB8wphe2p8T/tWfsovZi68X+EoGNuT5l5psajj1da+LbqUQZDM2FyPmxkfWv2pjVLiIxSorhgQVcAgjuDX58ft7fsg6lY2V1458Dws9oD5l/paDOzPV1A5P4VyVKS3PqMDmzprknqfIF54qt7XIDAn2zXI6142lkVlhHPrzXI2MN7dzlJCV2nGC3PXof8K62w8OxeWDIctjmuWXunrrFVMSvc2OC1a+v75iSznmtHwjqj6XeJJKMEHJJrt28P2+0gIprGv/DKdVAz9KPaLY83EYKrJczZ794D+NFra2SQlkyB1zXB/Grx+mtQyeXL6968iuPtGl5KuRiuZ1XXJrxijP8Aqaajd3Pnq1OVN2Z9C0UylBxXSZW0uPBpysO/FR7h601nxjFBJMWHYmk31DvzRuoAm30u+oN1G6gCfr1pysFOfxqENUkasc9h64JoA6Hwn4cvvF+vWWk6dC1xd3UqoiKMn6/hX6nfCb4b6f8ABT4fWuiWQX7eyh7u4UYaSQj5s+1eF/sN/Av+wtIfxzq8BF/dKVslmUDZH3cfWvpLVLo3DF1LbFG0FiK1inuS30Nnw+D9laRuec8dKlmbcrZ45NJpC+XpMZ6ZFPlUeV05qyCrpM/l3LJnrW/M+5cVyiOYbrI4Nba3BkXdmgTL8X+rNZ0nzSsatW0h2mqu0tI1AihCds8oxnjNc/Z4a6uV7h66CPK3jr0yMVzsbeTrN3H/AHjmgoltStvrSH1Fbvl/vt2K5u6fytSgf1rqEBMJI64oA24W/dLg9qk3fKar2OWt145HFWGBCdKAIhzyKXmhfrihuO+aAADNO+7Ue6o5Jto64oAfJMB0NQPcHHDVBJLUWSc5FADmlZnGG71PO33R3qGCM+YCVq9JFlhxigB8PEY5p5x65pijbxS5oAM0hYUE0xqAGyKD0qvJHjmpzTWoAr7TTDg8GpmX0qCQbfagBkkRbpVWRStXI5ME85pzRCTmgDIcmomY1pTWZ67aqS25HagViv5lNL9ec0kibeoxTGx2oGRySGoTIV75qUx57VHJGeMCkwG+YW60hak2kUnrUgDtxzVeTGDUzN2qFxwaAKc3U+lbWhptsV9Sc1h3QO1sda6XT4THaRr0+UUASvlcUzcafJnHJzUZ+uKVwF3baRn3U0/XNGM0wF+9R92lVT9KUR/jQAKm48daxrz5rx/QcVvKvtg1iyRlrqQ9yaaAI1qXZuHJp0cR+lSmPOKoCp5HpTlgz2zVpIcnFXoLIdxQBkrbHstS/ZGP8OK2Psa+maVrdMDgUAY62zJzj9akxj1rS8lfQfhTGtR6VVgKFKq7jVz7PjtSxwc0WAgSOkm09ZetXvJC84zTmYKvFFgMR9GUdKWLRlOdw4rVLZ7Uhbg9qB3MeTS44GJxQqgcAVospbrUTWobvimFymwPpiomU1f+yhfelWAZ6UXGmc3q+ltcJu25xyeK1dJby9Pjj6YFaUlurQsOvFY1rNtVkH8Jx0rKRVyO6hMlwv1zWrHGFUcYzVBE864AB5rVW3xwetTYLkEqjAxVd4e9XriPbioWWmJshtpGDFWGRVXULyOxheVzgL0FWz8mSTgVwvjDVDcXH2dCTGOSRQVHa4+HVW1K9Lk98AV0a/JEMGuJ0Bf32efxNdq2TDx2FMTK7SDdk8BaiS4DsQOSOadwuS3GabHEAxYdDTEOb5uelPjb5gKbtNWdPtzNOvGQK06COjsYwsKZ6mr0jCOPrg1CoCeWKr6hNtIx1pCuJJJuJHWn24xVWN9wyasxt8pwaBExuDu61YEm5Ac5rJaQK3Wr9pKJEYdeKANa3b90M1JuFUrVjtIqUtQBJMw2VRhmMcp5xVhm4weKoS5Wb2oFc1pptsO7NXNLmMicmsjzPMtzjtVrRptvBoGamTHN7HpVmXy7yN4J498bqVZWAIYHqCKrXSEgOvUc1LCwnjGR83rnpQB+cH7bH7HLeCby88beEbHzNIuH8y7tY1yYXPVuexr4WuvEjWsjRn5dp6Nniv3/ANSsYNUsZ7C/hW5s5lMckZXIKnivyf8A25P2Q5fhZ4gn8Q6JD5nhu8csPKXIt267Wx/OuOpT5j1cNjZQXKfLH/CYBTjcp/GpP+Em85eCPzrnE0GSS42D5jnjoa3T4daysxI4wSPpXLyWPSeOnYyNc1ZGhJ71wU15unLY4zW54gk8ssof8M1y2C7dzXRCOh49es6jPqbcaA9N/E0nHrT5mc5KHpGb1qP7tGfwp3JH7vQ0bj61Hux0NG7NUA/fjvmnLJ+FRFqFYZpAWV5xjmvYP2avhBcfF74i2Vi8cg0q2Pn3c/8ACqKc4PPevI7G2e4uooo4zJJIwVFUAkk9ABX6ofsp/BlPhL8OYRco39r6kFuLtjjcuRlUz7VpFXB7HrD2sGjaNHaWkYhgijWKONQAFQDFZd/biOxx34rQ1i43MsXA5yccVS1BwbTnrkVqYm9bqE0uED+7UcjdBU0X/INiP+zULcnp2oGZUy/6QW7VejmKoKrXSlZBigSfLyaCTVsJjIrA02P/AFjVDpMgy4zk4qaNT5zg0DsZobN+4rntVf7L4khyMLMuPxFbm7GoMffFYnjKHZcWF1nHlzAH8RigYzVx++t5RwM4rqLRt9uOeorldSJktUbHK4/+vW/pMwe2TB6igDotN/1dXJOUqlpv+rP1q8wylAFcDimtSl9tRs27pSAHbiqcjHmpZGKiq+7rVrYCLcS1Sfw1GoO41Mq5xmhgWLYfMKnGWkOe1Nt12rn0qRV6nuakBe+aGprMRTHc96AFamSNxxTC34VGXx3oAdvIp24t3qs0nvTPOHc0AXMjvUMybhmofOB6GnrMG4JoAg6NxUiSehpcK3Q803yynOKAJVfd15pslqJB6VHz2qRZG78UAU5tNPHGarSWOzqK2Ff8acVRh70AYJtfQUhtfatzyV9KRoV7UgOektTxgVXktmHaula1U/8A6qglsBjj+VFgOZMTE8Cg27MORW9/ZuCflpGsdqnjFFgOUmi3EL6nFdTHGVjQf7IrOksP3yKBzuzW/wCTtVRjtUvsBnyRH0qNoz6VptAG7Un2b2NKwGasXtTlhzWh9l9s0C19FpgU0txnmplhDdKsiH14p6xenNAFOSEKjH2rEji3FmI6mukuI9sLEjjFY8cJ29KpIVyDAXpSZqZ4H7JTobV2blauwxLWIu/AzWzHD8vSltLQRrnHNTNhc8UWAryYxgc1DtIqV+W4oWMt2osA2OPdnIqRYN3apoYzzxUm3b7UAVvs47ikaAAcDFWHYY5NVpZgOhoAgYbc1DIMg84pJZi3Q5qFmLdaAF3LGOWqJpy3aneWzHpUkduW6j9aAINzN1NSLGSetWRan0p6qFoAjWEY65pJIQFOOtTL34xTZG+XFAFAMWB9aw/L8u+lT+E8itiRjG5rPm+a5D9+9Qx3Fs8x3GcZrXWQSt71k2jf6Q3HStOFdw3dMVJQtxuZtpXGKiYBVOQKdJJ5hOe1ZN9qG7McbZPf2oEyvrGobIWRMZxXnF87tcsc555rq9SujtKhsmuWZTJcPxSZcTV8PwkyButdfJ8sfWsTQ4BHGvY9617rO35RxVIl7lacHbgc0yDdjB6VG022T1qZWV8Y4qgHqnmELW9ptn5Kg9zVLT7Pc25hkdq21XaBViY+QkKDnjtWbdzHzOtXLqTENZLsWkyaRJbhbgVYQ8VSikUVbjbPSgCtcNtbrg1b0+XHeqF6ec0tjMNwAOKAN61m+Zs1YZ/wqhbyANwc1YdulAE4YetU7pvQ1KjA5yKrzkc460CsXLH5rZ6k0uTbMRTNP/1LD2ptif8ASD9aBnSLh1wTmo7dvLcqTTYW4xTZcxsrY4zQBdOFbgkk8Y4x+NZHi7wfpnjrw5e6Fqtv9q0+7jMckbAHGe+e2K1wdyKRQpww9c5FD2A/Jb4wfsm3nwe8cXkLJ52kyky2dxgbShP3QfUV82fEbU0095YEIyuRxiv3K+MXwztPil4Nu9IlKx3BQm2nZf8AVNjsa/EP9o/4P+KPhb40vtM1y0mTax8u4ZflkXPBBHBrklHU19pLY8JvGe7mOScE9q6Twb4Gn1y4QCNiPX1qTwz4WfVb5FQE+uBmvq34X/DqDR7GK5nTGFycgU5NRWhNuY853etIzehqKis7F3JNx9aN3qajyaX71UJj8ijd6GmbaVV/GqKWw7calhTc3TIPeoSPbFbnhXQLrxJr1nplpG8lxdSLDGFG7knGSKAPo39iH4Jnx141XxDqEMh0jR3D+qyS/wAKg+1fpEMrHkfd9MCuD+DPw4s/hV4B0vw9bRIJYow9zIBgvKRyTXb3D+XE2OBitooyluYd4/nXpJ7VT1Rx5eN3erkIDMznk5rO1bBA4xzTJOvs8yaVH3+WoadpDGTTQPQYqPdgkVa2Aq3C5aqzcdBV2dc81SmJ2ilYVi1pLnzsVqbcSsfasTSZP9KrfkG2Nj6ikM53Gbxj/tVn+OLdpvD90UGWjHmL9RzV5W/0hvrVi+gF1aSRsMqylT+IxQBynmi50lJAc71VvzFbWgTfuFHfFcxosrPoflPxJC7RlfTBwK1NHn24ycdqQHfaUwMZya0jt8s81zujzHaRnNbSy5XBpXAhfqRmo8bcnNKzKrmhvu9abAryMahb5ealkqJ+1WtgCNcsSasooyDUEK5qyg7ChgWVGFPvTGbFG4bAKgkkHrUgK0lMkkGKryTe9QvMcHFAEzTDnnNQtNVZpDk1E0vvQBO81QtMe1V3mqJpCtAFs3BXrR9rPY1SaTdTS1AGgt43r+tSpf8AYmshmPahZWX2/GgDoFuEbvipNynHzZrBjuT61Mt4wx81AGztPahdy5zWfHqBGATVyO4WQdaAJ1b1p2RUXXvS4296AJKUDNR7iKNxoAl2L3FDQqw6VGretSq+6nYDLmt/9MjUDJJrYEAYdKpIu7Uo1P1rZMfAqbdQKf2alFvjtVtVx6Uu2pAqeR7Unk+1XMe9BAoAqLb7uop/2YCp9vocUqr1yc01uBnahCPsrgVmQWxOMrxW3qCj7O3eqMK7UFaWFYZ9lj44qRIUTkD9KdRkUDH8Y4GKhkGe1P3j1qMzBepoAasRBORxT+F71FJdDbwc1Xa6NAFtpQveo5LsL3qjJcHtUbSFqALMl0CODVSR2b2p20tjNSrDuoFcrrGfWpUhz71OsQ4qQKFoGRJFntUqxge1JIwXFRtLjpQBYLbR1zVeWT8KjkuNo64qvJJu70rgSNNjoahkmJHWomqOaTC0XArTTEse9VGuNsoJ4FE0hYkisfVJ2jMcgOMNUsDoLMiSV2HT1rQWVY09awLG586Pchx61YaRgCSePWpLItW1LyPkiPztVGEHYSxyepqvdEzXRbqO1T4Oz0oEZF8paRiBkVSjtw0gNaV1hSeetNt4QWBAo3KTsaVhGEjGKuzZaMAVHbx7UHFSSMNuc8iq2Jfcy2j3SEEYqxYwtJMigZ5pwwxO4YIra0WzQ/PjnrTQrmhb24hjAIwakJp8mOoFM5xVBchuOY6yu5rRuJBtNZTN8xAoEPBAPFW7ebrWduOaljm29eKVwJrzLLVW0k2yjFTSMWQ85qtbf63mmBvwtyCKtFs9aoxMAoxU+7pQBZj4yRUMnzNSxnPFTiMdTQBLZ/KpHqKZF8lxnpzTrc4c/SmY/fEe9AGxHN071YuMtBnriswSlFAHFXIJ/MTbnNAFuzk3wrk1O3ygEiqNm+JWjYe9aDDdHQAKxkGM4Hv0/GvL/j18E/Dvxn8J3Gla9aJLIy/uLtkG+Fu2PavS1YqwFOvIftFuyE5BHB44pWA/KKH9lS5+F/ia7tb1hIkblo5MAB07HjvUPjXxJBodm1tCVDKuOO1fo74x+G1j8QdJubC5IhvgreRcKMFWxwTivy1+PXw38VfDfxtdaZ4gikwzkw3CriOVT0ORwTXFWi+h0UY8z5TzUfN0peaaDilBzTIFo/HFFIRmqsA7j1pynng1GOKeudw96Y+hZWMsRgnPYgE4/CvtD9gn4MpfalP441KIeRZsYrNMAbpO7euBXyr8OfBN54/8YaZoNjGzz3kyxYXqFJ5P4Cv1z8A+C7P4f+E9M0CwjUQWMQjZ1x+8fu1VCNwlsdLbg7ctyTz05qrqTssbAdTVxvlGe9Z15JuYc85rUxKPMS4P5Vl6h80i/XNa8qlicDisi/zvFDA6zw+2+129OM1FM226dce9Q+G5sbFNWNWUw3inoG4qlsBEzfKRVOZTtqwG6jPeoplO002BWsZBHdrz3rqZfmt+OeK4sy+XcDHrXWWMwmtRk8YqQMREH2hy3HNTOwwe46GlulWOZgDULSBRQBzlzbi2vLsBdqytv/Gq9m+ybnpWnrXyqJgMkVz0UhW6ZM8su6kwO30e5B4U81rm6Kqeea4/RnMMyHdnPWt/zOTmkgG3OpvbyZzwauWeqLcDBbn0rI1CLcm7pis23uGhmX5uKbA7Fs1Ex5AptrcfaIQ3fpTm+VhVLYCaJdvJqePBzzioVORUq9DTYCyfKOKpyOealmk9KoyOTmpASRqrvJildjVeRjQAjSGoWkNKxNR8mgBGY0madg09UNAENKBmrCwNIemalWyZv4aAKLKaYy1qrpp7inDSt/GKAMgL70oUqetbQ0NhzimSaQYwDtzQBnKcdaljnZTUv2Nl6rTfK9BQBZhus96tRzhicnFZYjOemKlTNAGrxxS7Svc1SWTp81Wkk3ACqsArfWhX29TSspNMZeMmhgFvIDqsQre7CuUt5CurRfWumBJWoAkDZoIJqtJIUx70qXB2ZosBPgikqo164b2qaO5WUgNwaLASmmmQL3p7KNoOOKiZPbFAFTUZh9nbBqjHMQo57Vcvos27cVltnAB4FWtgLLXHvTWuPeqrNt6GmmQ0AWPPNRPIetRl6TlqAFMhpm3d3p6xlu1PWPb14oAjSPrk5qRYwacZI06moZL5Y+hBpXAmVF9c1IMLWc196HFIt4W70XFY0WkFRSTbRVUXG6mtJmi4yaSaoWlPamO2cU3d6mi4Dtx96ilk6dfzpzNxxVWaTdgUgJPM9TUFxJ8hOaYSf8mobh9kdAEEjjnNZGqf6vJ9a0WbNVbyPzISOvekwH+G5AYZO+Ktahd7Y2GBWRo8hjWTjHNWF/0y4CMeB1qSxbSBpBnGSatzKI48Z5qyI1hVcDHaq1z8/AoAyZo/MbpV2ytSOSOKkjtgetXYo9qn/CqENxtHXNRMu4k1NtPNNC8EscCgVyP7MyqGx96uh02Hy7cZ4NZWnsDdCNxlTXRvCFQFelWthEL44xTG+6aGODxSM3BzQBRvM7eKyWYq7VqXjgL1rGZ8yHnNK4D8mlDcioWk20I+5uKQF7cfLOarwt+8qQsdmKbCo3ChsDUjbpirCt0zVJWxViN6pbAXYMbquZwtU7f71XG6UAELfvKR/wDXk0R/KxNNZt0maALMxIUYpbKX96BTbgkRr71Thm8uYYoA21fZc5zgGtaFjswT9K5+4Y/I2eK2bGUSxgk9qAHt8pPFPhbd8p4FNm+uaZG21hQBSukNneBwcKf1rmfi98IdC+NXhGXStXhUy7S0F1tBkhfHUGuv1KDzIw3THIqPTbnzECtjA4OaTV1YqMnBqSPwwpQcU1qbXGWS7h60bqjFLt9OadwJV5qzAi5IIJ47VWVTwe1elfBL4a3XxS8faVoNrGziaQNMwx8sYOWPX0qhn1z+wV8Gf7N0qfxxqMKm4nBisfMCkqvd6+w41GSyjA9OKqeH9Bs/DOg2OlWMSxWdpEsUe0ADgd+OtXtu0Mc1ukrGblcp3t2U4BrOWbzJOvNM1ORtxI6VnQTneaZJsSEhaybpd0mc85q+sxaPmqjrvakBd0eQxTKDW5rUfmWfmryV5rBg/dsvFdHDi6sXjPO4YqkBiRNvw3XIqSTPrVS1YxM0TD5kbFX8DYCOtMDC1BNpz0NWLDUZI4toPFGpQ+YpPpWVbsVfGcilYDaaZpGLE801pCOc0xT8uajuCfLJFIBt1H9qhdMZDCuGjuGh1ZYHODkr711sVwQTzXH+N4/7PvoNSQfu2YBzjpSYHV6WxZlY+uK6JTlvwrz/AE+/aKeMg/Kx/Dmu5huBJEpyCakVyaZd0TCsWddvQZNbDN8prJn/ANYx79qBmxoMpa2INadZunp5cIx3q/GT3rRATo1SlsLUEZyafM21R2psCCV6pyPinyvnvVV29akBryZqJs0/ac9KcsfPNAEO3d2zTlhLHgYq9HbA+9WYbTnpQBRiss9qtQ2I5yK0FgUYqTao9/woAqx2KelTraqnUU/dt6VLHG8nbFAETRqBwB+VAUDstWV07dyz09rdVUUAVi3oBSD3AP4Usny03dQAjRI3QYNVZLNeTjFWtw9DRxQBlyW+KZ5J9K02jH+RUbR56fyoQGd5e3tUik/SrLQ0xoM9KoBqybepoaVdp+akktyBUDxlQRjNMCG3x/akHP3mxXVD7vA6muUt/l1K2yP4s11i5C49KhrUCvcQllzVOGQKWV2x6VpSDcMVUmtFYjcKAIJIz94HI9qazfZ1LZwe2akl0+ORQFkZT320xdLTeCzvJ7E0AXLGYywgtVhvmFRxw+WuF6elSYNJgVLtf3LjNYr/ADKO9b1yh8ls+lY6odtWtgKzDFM71ZkhJxxTPLPcUwIvLyRmpFTbmnn92ucVn3V9tyAeajqBYluVjHByaz5tQPIziqM100jdaiAL9TTuBZa7du+KhaZvWnLA3cZpRbFvakAxWY1YiYjOaFtDUqw7enJoAdG/1p4YN1poU+lKFIoAU47U1qPMX+9SMw9aAEbpVWT71WWORxVeRSvJoAZ3qve/dAqwv3hUF1HuYd6AKSDPFW7exaXdkcYqe2swzdK147Xy4GIGeKQHKx6f+8dFGSelNsrF7WZvMG1vTIrftY1BZmXnNQ3aKzbhRYdykzfLio9tOk+XpTVy7AdaAuOjXn/61TdquWened94bRVySxhSM+ophcxY+d2fSmzfKoX1qZlCyNjpTHjMjKPegRoaPbrIpdutbAU7cGsy3RreNcdDV6K4LdeavyAr3A2NUandVq42uM96p7tp5qHuBS1L5VJ7DrWD5q+YSOBV7xHfCGE7XxnisO3m3Lwc0AXJJAcEGpLbLNyKrYLf/rq3bKV7YFAFs8YpY/vU3dmnxfepAXEXPNTR9RVcN2p8b7TnpVIDTtzzVxj8oqhatuI5q833cUwCNhzUMsgjbOakU4BrH1O4K5AOc0Aaf2xZABuqMsBKO5zWVpaO0oy3FacrbZwDxQBqTfNbg5pljqbW7AFsClmP+hgjmsfcWYduaAO7jmFxCHFVxJtcg8U3SN32MBvSo5htloAvSES25Gax7eTyZiB61qW7BoyM1j3B23TbaAPw+49aX8c0z2pV7jpXEajqctN4+tPX5iKALVrGZJAOQPVeor9Iv2Gfgx/whvg1/Ft/bhNU1YYgVwPkh9cDua+OP2Z/hLJ8WviZpembW+wxv59zIq52opyc+lfrjpekwaXYwWlvGsVtAgjijQYCqBjFbR1FJ2RGsOFGTuIGP/11BdMI4zzWm8e0ZrG1AljjtWpkZd4u5SCKxD8khHat2bBU1i3S7W56UDLkLBkowdwNVbebC47VZDcjvQBZj7VtaXNghe9Y0a5Aq9ayGJgw60ICHWbcWupFx92QCpYXDKVzV3WIhd2AkH34+ay7JjtHOSetWAtzFujIPSuauB5NwQOldTKfmwTxWBqkI8zcOlQ9wLFtJuUCnXH+qNU7VwBxU9wx8k+9AGcxxiqGvWUeqaXLAwyT0PpVpmPSopGzGR3pCZyGk3T7Uik4lt32Nnrjsa9I06ffCATzXl/ibfo90upKS0Wds6+voa77SrzNrA4+YMgII9DSEjfEgwQaz7j5WLHoTStMdwGMCkZfMZB3JoRRsW7f6OpB7UyW+aMHmo5JPLVVHYVRQNeXKxjoTzVAb+lyGSHzD0NSTyHNOZRbwoijAUYqpIxp3AjkY1D1bpmnHLGpoYGY8jApAJHEW61Zht+emasQw+tTqgWgBkMSrU/6Uirt6VIls0ze1ADKmjtHl9hV2CzSMZPzGrPCjHSgCvDYxQ87ee9S/IvQYpJJAo4NV2kLUAPaTrxioHk680MT3phpAQP96m05qbVrYBQM0baFp+D64osA3y80eX+NO/GmlgveiwAY/UUm1e/FI0vvUZc96AFYKPeoJFUCn7d3akb5VOaYFLyw1/bkcYaujUHb+Ncv9o231uAeN9dSvTrnmoe4CY96ZIu7HepG+uKbj3oAgaPbilX3qUr75o20AG4N0NH40BQPanY/GkBFKuYzzmsyNdynHrW0se/INZuzY7gdjVICNY+uar3DKgOetTTTCNeTWHqF2QetFxXIr6+K8dqyJJWmc5OaSaZpnINTWtsd3TNIY2G1MjetadrpI67c1at7IbQcVpoqRIMdaAKa6eqqMrT/ALJGAeMVM0ufQVGz5XrQBVkhHQVBJCV5FWlPzHtQwDDk0E3M8/rTGPykVZlhK8iqcncGgLkX3c0frQIyalVPbNAXI1GfanrHu6809Yz6YqaOLNA7kAtxkcU2W3wwOK0EQLVuG3EnUVVhmdbw5PTFaX2cSRFBzkelW4rVPTFWobdUbIFFgORmtjbsykbfwqtJCfrXa3FjDcH94mTVX+yII2yFpAcYuntM5BVgvrV2DT1hOAC9dR9lHTAI+lH2cL/CBSAyoYH28JgVFdAopyMVufw8isfV2CxtxzVWAxGG5jUtvCfMXIwBTrKz3fM1Xo3SN8N2osAOvp0puMdKts0ci8GqUkgUkZ4oAe0ny8mqcxHaiSZexyarPJuzUgc34wmMduhzjLYqhYE+WAad41zILVM4Bk5punt8ozQBoJ94CrsP3apAfMKto2VFAEtSxfezVfOParELc9aALHvTlpAvFPjyGoAvWXatGT7tVbGNduasSY9adwGZ2qa5+8kMtyQOea3J5AsROegrFs4zcTO2OM0wNLSoh3ovDtuAR0q7bQiOM1n3xImFAGurYs+naqVrGJplB9asLJ/oOfaorD/WD86AOssVxDjtiqty22RqsWbfIMHNV74fPxQBLZfdINUL5ds+RVuzJDYpLhAzc9aAPwt3DI5pc/N1qIfXNOVd3bNcRs0TKu49at2tr9ocDH14ycVVjjOcgY/GvbP2XfhHN8VPibptg0LPp9u32m6bjARTnnNVYpaan3F+xL8HV+H3w1TWLuIf2prIEjbl+aOHqq19LR5Iyfy9KoWFtHZ20cEMQhgiAjRFHAUDitGME9q3itDnbuxJh+7xXP6l8jc+tdME3LyKwdZh+bjrmqAxWfcpxzWXdx9cjHpWqsWCc1Vuos9aAMdZCrYPar1vKGbFVJosNxU1p988UAbMSEqDU8fDDvUcP+rFPyQRihCuatrIrgqwyCMYrE8s2t5Ig+7u4rSt3wRmoNVt90iyr261YyC4brisq7jMisK0vM82P3qhcKeeM1D3AzY8q1W5STD1qo2VkzirG7fDxQBlTHk/WoGkBBGanuMqxqkzDnJxQJmZq1ql3azQuMpIpU1r+H4zY6PbRZyUXbjvWfeZMfBrVtMfZVBPO2kI1FlDKC3Bq3YqJGLHovSsm1O75c7jW5GnkwgdDQUR3ExVTjk1f0O18tDOw5PSsxY/tVwkfYnmuikIhjVBwAMUwI5ptzbiaqu+5uKV2LE8U+OItgYoASOEu1aFvbheTSW8BHarZj2ge9ADeO1ORWZsKKmjs2k5IwBV+3gWM9OaAILfTyfmY1fVEjXAFBYduKazYoAVpPwqvJJ070kj1FmgAaQn2pq555pWoVTQApHvSYHenbTSrGW7UgIWjqPy+tWWX8KrSMvrmqQCYAqN296a0melNVS554pgDNScv0qQQinbQvagCLyj3p2FUdc0NIfpUfJzQASSADIqjeXBVcA4qzIvynms+4UnpzTAzvM/0615zmQV3YX5BXCSxmO+s+P+Wgrvo/uCoe4Ee00bakKmkIxSAZto206ilcBAvrTlUdqSlzRcCVe1Y1wwjklycc1qb+2cVzGp3LLO4z/F61QEN5cb2ODWJdK8jZzxV6SQ8ZOfxpojHOaBEFnZhuSM1q29sigEcVJDanyRhaVFeNSCp49KAuThhGuQap3V4ex68UySaRsghuPY1nTSHlmBGOmc0DH/AG52kUFsZPrVuC8Ey8n+led694yk03xJa2StAlsEzM905jUE9DnHauY8Q/EnVNE/s7beWMzQ33lXH2F2k82FsbS3GB9RQB7occEUlZ2n6olzGrqwKkAg9etaHnLIBg/pQKwMu4c1A9mrdDzU+5fXFHmL6g/jQFiutmF96X7OB2qz6c/lzS8ZbnJXqBzikKxWEIqTZ6VJ8pYgMCR1pyrVrYENWMtV63j2jniq8a4PFWN20CgosgjtzT/M98VQ+0Z5B/TApslwWwM4oAvSTY70zzs45qgWbjNW44ztBoAmHzd6Xb75pq+5pfoaAEcAKa5rVJP3uOoJrcuZtq+lc/P++vFXqCaALcDJ5OemKrSR+YCQamlUQqQflxUYZdvDUAV1kaLjdmo5JC2TmnzhRyDzVKWXb7UrgKz4zk1BJIPWo2m96jLZNIDn/FQ3fZyez5plj2qfxMu6KAn+/VSzb5sfjQBrKM1KG9KijapPvd6AHq3PPNWoQM8DFU1GDVy360AXV6Yp6dfSoqcnWgDXtX+TGambmqdq3y1OZKAKepSeXbv61Hpce2EHrmo9Uk+ZY+7Gn2zFCAOgFO4G0rDy8ZrKvv8AWcHNTibdVW6O5qYGpHzZY74ptiPn96M4tUqewVd3PFAHQWKZUVHffeFWLVl8sAGq95jcKAC0+8aSY/MRS2/c+1QXM21jzQB+F3Pt+FPUjjNRKcdeKljwrD5iCa4jr5UXtOjLzKACx+nQd6/Ub9ib4Qr4A+Gq6xd25TVdX/eEsAGWH+ED0zXw1+y78J5Pit8TNMsHDCwgkFxcMF/hU5wT71+s+nxxWttHb26LFDCojREGAFAxWsVcxm+hfWP5txJPYcg1cjUVVjO7vVuPtWuxjYkxjGKzdTtwwJ71p54qreLmOlcZzU0I7VSmjG3mteaPrWfcR8dKoDEuI/mpsKfNVqZfmqONfmoA0of9WKkC7qS3XcoFSlcd6BWFjYqatbRcRlD0xVMdeeasRtt6VSYzM2GEtGwwQeKqTZ5rXv4W2iQDPY1mTAHOKTAypc7jzipbf5uBTZl+akt2xJSAoagCszelZVwfyrY1RTuz1rDun/dtzigCF23AemfWtVSFRcelYyOHCoDzmtVvmUDsAKBWNHSEMl0w7DrWzcS7VJz7VW0W38uzaVvvvUsdubi4UZzk0DNHRbURI055J6VYkbzGPPNSsBDGsaj5RTYYdzHAoAihhLPzWnDCqqOOafb2e77q5PetS3slj56n0oApw2rS9BgVejs1jAJOascYwBikagBuAo44o3FaZI2McUi/SgB+41HJIcDnNEmcCo9pbtQAnJ70KufenLGT1FPWPbQAwR57YqVVx3oooAXHvR0pKOxoAr3LYWs8As544rQm+bg1Vb5aAECbe1L+GKarDJzxSlh607gLRTdw9aNw9aYDTHTWXaKeze9Qs1ADWqlMuWJBxVvPBqpMSuSaaAz7lVa/s8n/AJaV28f3R2rh3zJqFrgZw4Ndwp+QVm9wFbjvmmnmhmqNnH0pXAVqTOKiaQdjUbSe+fxpAWNw9aPMC5qqZMd/1qNpj600BbaQNnB5rkdQnEl5IAc4NbzTFQea50W4aaR933mzVARgFjipljPA96f5AXnNTRpjH1FAG9bQjyUHU4qRYVXOAKWFQsagelPoFYRY0H8Kj8KVkVlPy4HsP/rUUh96BnnPx0sY7j4c6phFWRFDBgoJ6/SvM/gEtsfFV5bXdvHNHNZpKFZQw3DocH+lew/FC3F14J1hP+mDH8ua8M+Bs7R+NtO3Hb51qYz+BoA+mFsYdo2xxqP7qoFH5VJ9ji/55qfwpYeRUoGKAIDYxH/lmtNaxi/55Kas0tAFF9Pi2ngAHg4OK4/T/hPoeheIpdb037Za38+fO3Xssscmf9lmIH4V3LZNQup9KQmUvs5/vcdADjI/GkaIp3q5n1pr4xVISKin5hXl3xT/AGofh38IZjaa7rqHUlP/ACD7UeZN/gPzFepzMu0gj8v/ANVeafFTwV4a8UeHdSh1TQ9PvJHgcCWS1TzRx139aZQ/4d/tC+AfikiDRtcjhu3Xf9jvh5E2PUBsBh7ivR0hEnKkFeoIIII9etfmn+1Rpk/w/Pw4bTpoYpY9O/dW9vAMxhW+8SACQa+xP2P/AIoa58VPhTFqOuR2qzwS/Z45LcEF1UcFqBXPcYYdueM1OcYAxiow1KDmgYpwB1qKaQIuM1I33TWXdyFpOtABcSb1ODWLJMY7xTmtOTATOax2kH2hieKALN1eLLG2WrPNz/tYpt9cCNAOmawLzUDJJtQ8DrSuButcbs/PUDN1zWMl8F43c1Ml8W6HNIC4x9KYXNRfaM03zB60AUfELH7Ijejis+wky2DWhrRD6e57qQayNPyZAT2NAHQxg807dtpisNuc9qhlm460ATNcKDgmrVrcKzAA5rlb65fJKnGKtaNqBkZQzfrQB2MbblqSq9q4detSOwWgC/bSfLVjJKmqFu5NTtIVU5OKAM66fzL1RnO2r8K9SOayY2868cjketa9uDtx0oQEqr3qCb7w+tTnK96rE7pB9aoDVP8Ax7qKnsf5mq758lB7VbsY/ugDmgDftvuqajuPmkNWLeIogz1qGZctmgBE+VSBWPqU+1uK1myq5rntTk/eenNAH4iggsKu2Vu0kygDcfQntVONe9e3/ss/Cd/il8TNLsjE8llC4uLhsDARTnmuKJ2XPuP9if4Pf8ID8NRq93AqarrGJMsoLJF/CBX0dHCFOQMnp+FV7NIdPt4rW3QRwRIEjRQAMDircTFuoxXTFaHI9yzDn0q4tVYzirMZz3psRIe1MkXchp/Hak/hNIDHuI+orNuE4NbVwgycVnTJ1qgMC6GD+NVo/v1evUK1ST72TQBq2oJUfSpJcr1ptlytSzjIxQBWyc1LG5qHuakj+9QBaP72NkPQisl0K7kPQdK0w23GelVLuP8AiHXvTuBi3S7aqx/6ytW4h3R561lkFWI7UgE1KPdDuHOK4/Urjy1fn612c7B7cg88V5r4rvfss7rnBIzinYC/ptwLiYEdq6G3TzXVQMkkCsD4f6bJqFm10UyjHaK7nRdF8jUFd+FXkUgNRo/IiWMHAUdKsafHtbdika33SEk8dTVm1+ZtqjigCxs3EZPNXrSzOdx4FLb25xuZcVa8wKoHSgCwuxQAvXvUw+UVneZhuDVuGTcOTSAnzTJJOKUMOeaikNK4CBuak7dcVDuA6mn+anc0XAcV3d8/WkC7f/1Uw3KL/EPxxUT6lFH1dT+IouBYY4o61QbXLaPksv6miPxDZzHasqgj2NFwNAD3o/HNQLeq33WUg0rXQXuKLgT0HgGq32oH+Kj7UvdqLgElVmXdUsky9mqIyDuaoCNo9vem7T61L5g7YNJuDdhQBEVPek21KQKNgp3AhIxTXGasbRSMoouBWVTzUckPmA1c21E/yqaYGZFa/wCmwkcfPXVDAQc1z0Lbr6LHrmt0MNo4qGA129DVaSb3qabG2s+Vvm5qQHmU+lN3E9qi3elLuLUAPZsDmofOycZp9MMIbvTQDJpD5T4PY1iwTNtyRzmte7jEVu5z2rLiiG0VQEqSbutTofmXGeoqIR4xjmpYwd68d6AOhj+7TmpF+VaDz7UgEpexpPxNH45pXAwPGEAuPDepRkZ3QOP0NfN/wtl+x+KvD0nQs0kZ/wC+ulfT2rRedZzqeQyEH8q+WPDs39n+INJiHHk6k6Z+pouB9Zw4VcZqX8c1BandCCKmUH1xVALS9jSfjmnfw0AM55qKRTUv44psgOPWgTKzfLUbtxwKkYEZ4xUMhAXk4oEijdzBVIzXnvxAvWTRb1RyWUIMdckgV3F8w5rzfx1JHJ9kgYnbJcoSAeSq/Mf5U7lHyz8QLh9W+JOu6pdMsllodibKCIYwTtySc19JfsbWZsPgTocrAK140lwQOOrHtivjjUPGmjyf8LTaa/W21W5uWEFvIjZlU4AK192/ATSjofwh8I2jKFdLCMnHfIznpTFG3Kep9gaUHFVo5ecE4qWgY92+Ugc1ny2uXzuxzV2oZM0AZdzJhWGc7eKwZIXmcso4rXvmKrI2O9Q2PlSW5ycNSuK5zWpS+UCrP81YUzbeh5bqa6HV40kumU/MAcVkvp28EqSppDKEb7WIBzViOT3/AFqjcWstu2TyKSGRlbOaANdZadvzVW33NnPSrGPagCHUGH2GcYJ+XNc9putQsoyyqw45Nb9781rKAedpFeQ3ErxyMobox/nQB6jJ4kt1UKZVJ+tVzrEc+drj8DXm1vIZJMFufrWzbK1vyDgH3oA6a6uAy8HNMsZjHMp7Vnwzl1G7P51NG2WGDQB6Dpt15kYwe3rV3dubrXMaPcFVAJro4GD4INAF+HpT7iTELZPaolNVNUmMdqwHXpQA3TfmUv6mtqNvlFZGm/6pAeuM1sIo2iqsA5mO01VVj5yr71Zm+VBVGE7rlfrQBttxGtaemsIwHPSs1stjFaFuv+jkHg4oAvz6woB2nms1tYd3xVKUMGI7UyOMlulAG+twZLcMaw7ohpjmtSPK2nTisaT5pjzigD8VrOEyyADluy+o71+on7E/whHgL4Y/2zcx41PWcOQw+ZYf4VH1r4d/Ze+E83xV+Jum6YUP2GJxcXLYBGxTnnNfrbb20NhaQWsCLHBDGscaoMDaBgVzQibzfQauc8Z/Or1uT3qtGhZuRxV2GOtjAnj5qZWFQcL0PNCt70AXFan/AMJqvG3vU+flNFgKcmMtmqMygZOKvsuWOaq3CjbTAwNQXOSBWZzu6Vs3yDFZBXLYoA1NPBIFTXA5JqGx+XAq3KvWgDOPWnRnBokX5jTFwD1zQBaBzQ43IRUSNQ0gFAGdNJ5cjIePaqVztxnpVzV4/MjEy9VrHkmDY5/ChAI8hxtHfivK/HzN/bKIv3pAFA9ycV6bIxIzXn/iiz+1eLtJRh99gP1qmB6b4V02LSdDtbdFw2wE+5rdhhEeX74qnaw+XhQOO34VbbL7FB61ICTXAjgJzyaq6fqfkXI3nCmm6lMPM8tf4azGUqc0gO9/tSNoxsYHNQfbdx54rjYbySJuvH1q4uonaPmpXA6pLheuakW+VP4q5NtY8sfez+NV5dbOMg0XA7g6qEHUfjVabXkHy71yegrgpdalk/iOPXJxXHeJPiZa6SskMTfbLvtEpJA+ppAes3HigBiE5YdQAc1ian4+hsV/f3CxfU/4CvCbnxf4j1+Q7JWt4z0SHIx+J5qO28NXdxIWuZMserMxdj+dAHqV58X7BCQty0p9I1P9RWPN8WklbC28r+hJ/wAKw7LwVG2P3Ty/XGP510lh4Hk42QQxD1YZP86AKi+Nr28PyW7Bf9rNXLfXLh2Bbcp9jW5b+DY1UebMB7LWhDoNjbKecn3oAj07xFKij5mP1Jrfh1wyLnOTWHNb28YGCBVZpz0VuKAOqXWfX+dOXWB64/GuS89/Wj7Q46GgDr/7V3dG/WlXVD3bP41yP2qQ9yPxpVunX+KncDr/AO1M9DSjUvVq5D7Y/wDepVvnX+Ki4HZLqXo2amXUj3NcZ/aUnY1IupyetFxXOzW9DdWxTluFb+KuPj1R1P3qlXWSvVv1ppjOtWVecGo5JNytg1zsWt7jjNWW1QSKADVXA0LLLahFg9Mmt/HQCua0eXzNQU56Ka6br7VLAjkB2+lZkv7xvl5Oa0rr/Unn2qjatHHCXZd5Y+uKkCLyXUZxgUL3Hekk1JTMI1RgfcVKrBsAjB6/5NADdp9KMEVYCYFIy5poDM1RsWpGcZIFZsEu33rW1aPdAo981nLb7cHvVATRybvapY+ZEGerAVFGtTx/66L/AHqANxfu0n44qRfuCmY59KQCfiaG6dc0fiaPxzRYCrdKWiYDpg5+lfJupA2Xia729LfVUbPoCa+s7ld0ZGetfJnj9WsfF3iDAOxZ45SfxoA+r9NlEtvGwPysgINXR7msLwnMLjQbKXO7dEvI78VuqoIpgL+NGPxpyqKcFC0AM8sn2pjZGec1Nz6ZpjLjqMUAVJc1TmrRkjyvFZ9wh2mgVjB1aQqhI6Zwa8V+JGqi3t7+8eRVj0+zmmyxAyxBA/ka9e8QSeXbuR97BxjrmvkD9qDxkmh/D/VUado7rV2EEKLk7kBwx9hxQD2PlC9s/wDhKPF2iX6puOpXKxnO7G7d0/Kv168P2n9n6Np1rgKkFtGiqvso7V+Vn7POlReKPHGgaX5e6W31GKdV3dUzk47Yr9X4l2/KOg6dPpVER0LURLsatqeMGqkLDd1qxuHrQVcf265qJuhqRW685qKQ9fpQFzC1JsIwPQmo4NPHkq27B60mqSbl29y1atooNuoYc4xRYDnpLFfOd2Oc+tVLhogMcAir2us8L7Yh9a5a4SdWLHPNKxRLeKki/LziqMcADH5c1JHv3HOalAxzSATHYDFI3yqeaVpAOpqNpAwPNICldzfu3APavJL9v9MnA7Ma9N1W5W0tpZGIUBc5NeR3V8JppXB6tSuBIt15bgg5IrptHuBeIoJrhfPIcnsa19D1T7LcKueCaLgd2bfaMAZqISmNueKtw3STwA7u1Zk8mJDVAdLpsx2qc11FlcEqOa4rSJiygV0tnNtXg0AdCkhbH51naxMWeFAc7zUkMx7ntmsm8uDJqiRk52jNCA6SwU7Qe44rRWRt1UNNb93zWkqjrnNUAyZyV5qtanddCpLxyF46Umkr5k+R2oA3YwSwxWjDlU5rOjPz1pR/MgGaAIJI1Y0RQjePSp/LI7VJCNrjjrQAXxWO3Cisu1h8yQY9ea0dScvgYqXS7PdyFoA+eP2H/g8vgH4cf21dwGPVNYAKs2Nyw9gPrX0hy3PbtSWlnFp1nBawIsdvCqxxIgACqBgCnCoWisOUuZj4zVtW2r1xVSNsNVxPu0xETS+hpqzHPWiaM9dtV+d3SgDQjm96seZ8tZSyHircchYYoAlZ8ZqvO3y05iV5qOQlloAy7z5lNZO3kmte64U1lHlsUAX7NulXyPlNZlsduK0VbKn6UAVJk25NU2bBNX7jpWZMTkgUASxtmmyuQcYpsMhXg0yZ8NQAuRIpVuhFc1dZhuHU+vFbxkP1rF1nqJAPY0ICtv4J6d65W8gWfxpobE8K7Z/Kt+ST5Mg9q5PUfMbxVpGzJIclsemOapgevJcDyy464qxa3UYsnkb7yjisLT5vMhIZuc9+9VbtpIyVDHaTUAWJJvOkZ85yaYxqoGC8AkigyHpSuBKzbetNacY61XeQg1VuL2O1hMkzqqr3Y9aQrlt7jHRqx9Z8TWmkxhpZN8naJSSSfeue1DxbPfM8FgojDcGXrn6VUs9F8yTzJj5056sTk0DKmpatrHiQlIybK0P8CkZIp2meD4YcHyzK3UsTzXXWOh7gu5cL/drdtdPji4AAxQBg6f4VkkxuJRPQYrfj02z09cBNzdy2K0YVHC9vpVxNCWfLHkGgDGW9SPiNAPpQ2qSf38/lWq3hVWJPK1BL4T/uljQBlyakVH3930qA6oTnqa0pPB8nUbqqyeF54+hYfhQBUOov6Y+ppovnYninvotzH6t+FRtptwP4CaAHfayepxR9qP8AeqBrGftG35Uq6fcdo2/KgCdbr1aneePXNMTR7tv+WTD8KnXQrtv4G/KgCP7R6Gj7R6mrUfh+8/ut+VTJ4aujnKsfwoEygJ/Q5pwuCK0F8L3DfwsPwpx8L3C9mH5UCRnfavelW43cZq9/wjlx/nFNbw/MnJGfyoKKwk/2iPpT1uXHRifrQ9o8P3kxSLbs3bFO4HTeCpDNqEm7sldr61xPgaPbqM3sma7hlzjHpRcCKVd8ZGM96x4WDRsufmQnIrZmjO0dqyr60lSQT26h2HVD3pAVXmuIf3KR+ZFJwW7ipoyV2x5wF6DNVZNSKZU20wf+5t4zWjpWnzTYmlj8tTyq4waAJwpCjvSqpPatQwr0x0oFuvXGMU0BhahH8qA8c1Vjh3c1ratD/qyOee1Vo4zt6VQFXyPxp3k/vofZs1a8vHNQbSbhOO/pTsBqhdvFNKNUgznv09KX8/ypAQ7T6UYIqUn/ADmmO3HPH40AVLrd5bFeoFfJHx08cTeA/G91FGty1vq6rDL9nhEny+pz0Ga+uJyDGf8AGvlf9ovw1r9/4os7jRr57JRgM6xLIGGeVPpQB7z8L786j4R02XcXHkqAzYyfrXbxqcV5/wDCGymsfCNjFckGYIASBjP4V6HGApPrQAoU0vNLn3/KhlI680ANo5paNwGaAIZmwvPFZ0xG081qN82e/wCFUrhdqntn3oA8u+JmpCw0e8kVsGONmH4Cvzs/a016S+8YWdg7lobW2idV9S6bifzr9APjRblvDuolW/5YydP901+cv7T0RHjTS7k8i50u2Ye524/pQJnrv/BPXwdbal4v13xBdWyzNYxJHAzc7XOckfhX6Dwrweo989a+Rv8Agnlof2b4a6pqRT95dXhXd6qor67Q7VHNCESxrye9S9R6VHGwOeakwD3qh2BflprEhWPtTtvoaSRT5b9+KBWOYv8A5powOTnNbdof3fSsGRi18oB6VvWL4jJ680AiC409riRn21m3WisyblHH0rp4Z413BsDd60+QRiPouPrQyjze+tWhb7vSqTKRXb6tZxsuVXrXO3Gljdw2ypA5653BarySbIzuzjHWtm40513HHmgc8dq4nxlrsWj2crYKNjAz6mouBxfxC8VHc9rC+BEpZ8dq4PTdSW6gD7wwblTnqKz/ABTfSTaXfTszedIpFcr4I8QMYEtJWxKpyN3egD0Bpst15qSG4KyKd3Ss/wA5X5BAPfFNlkwuQelAHo+i6i80KDfnt1rZ8ncNx5NeXaHrzWMil+VzXeWuvJcRrghT1p3A6jS8qwUCuhtW9xXJ6XqClsbs10tvICq44qgNhZPk61hwymfW7gnnaQtafmbYWOc4Umsnw3++aSU/eLZoQHW2spVQK0Ybk+tZS/LU0cw6VQFy4lLg1d0VNu5iMVllvQ5rY0v5Ycd6ANGNhu5rStW8xRg1khu9aenjK0AXXHy02MfMDUkg+Wmp0oAJIfNmUdq29PthGo4xWZZ3EayHcR+NabatDGvDrQwKMjFuSecYNQNU8gwtV2qBWHQyfNzxWnDhl9ayIvv1rWx+WmMllj+Uc1TkhxnitMJuFRSwhRQBlbcNwKsxNQ8e2hRjNADnPSo2+6ae31xTG+6ec0AZt4flIrLKnfWpeDIrOZTu5oAnh+XFaEbZWs+FulXEf5aAGXH3azZozuzitCblScVTmXCigCupGaiuDwMGnsaimI2UgK8khUdapXSGeJgRxSvJlsdSKTcdpGc5q1sBzvmfMytwVOMVz4m/4rCDI4VGx+VburL9nuj/ALXFeY+NPGB8L6xZXQXzRJMsJQdwxxQwPadNmLZYdP5VPeMH6Gs/RZBJYJJ93zBkZ64q00g2n274qGBBu28Ac0hkPHr+OKqanqVvpcLST3CxYGevJ+leca54sv8AWpHtrTda2Z6hTl2/GpJudV4g8cW+n7oYNtzP02r0X3PY1y6yXmvTCS5YlT2XgCq+k+HWG15eF/uDv7n3rr9O0xsYUfu+y+lAIh0/SRCoWMAD19a6Kw01I1B25bvU9nZpDGPX6Vfjjz2oKBIz2G2pQtH44pR9aCbgCU5HJq9Z6k8ZAbkVSx70bfegLnTQ6qsmARV2O5ifrjNchHIUPWrcN8V6NQO51PyScD5fpR9hRupz9axIdSP9/mrsepkfxUDLj6XE2MquPpSro1uP4AKij1IHq1Trfo2PmFACDTIF6RqPqKk+wxL/AAL+VMfUUXPzKKoza5HH/GtAGotrEf4VH4UrW8WBgAfQVz0nihOQDmqcvid8/KuKWoHWMsSjrmo/MiXNcdJ4jlNV28QTN3o1A7iS4i46fjUEl5EoH3TXESa5M38X61BJrEp/5aY/GjUVjtpL+IdcCqlxqEWBjaa41tUkPWXP41BJqbd5P1o1GdRM0cwOAM+1Z0zCFTkYrAbWDHyJcfjVObWjJuzJuo1A7nwHeeZr0secBk4r02OMFR+lfPXhzxQND1y3uj9xWw59Aa9+0/VIL+3We2dZInG4MpzTAsNAG7U37OFzhcmpBPnPtS+YG6nFAFU2shYZbIParSx7QMHIo3LzzQGX1oAXGO36Ude2KOD0NL0700Bnaov7tT6Gqe0lBgVpX0ZaE4HNZ0bDPXtVIBFjPORUctqJioYZXPqRVncPWkdvlJHJFUwIH8PL9+K6uIs/wq2f51Wk024t8n+0rlh2BA4/Wtq0mLJgmpJFUr93NSBzCyXK5/02c/VRTJLy4Qf8fsp+qCui+zRsCNuKo3mnp5fA5oAxWvrjp9rYjuDGD/WqdxpcepSeZcSJKw/vRD/GtNrbYenP0pm1u/8AKgBkBexQLC6oo6Dyx/jStq11uJFxHn3iz/WiRTjrio/JBoAkXWL5mwLiH8YT/jVuO+u2H+styf8Arkf8apxxhCanVj6UAWPtF4ejQH6qR/Wm/ar+HJH2c5/2mH8qRZOvFKW9qAI/7TvwSTZwt7rM39RUVxrU/lnzrWQAdNsin+tTs3GKzr5sJnHSgDzn4pa9aS6HeRzGWMvGygPGSCcHjha/PX9p5A7+FJ8EF9IUE+hViBX3p8XLwf2TJHgsTkDd06V8U/Hzw3Lr2l6JPHcxRfYdJRmjfOZN85UAVVgPsT9jPQRoPwF8PlkMb3Smc/LjOTXvAXdyOfxzXk/w20d9D8E6BZW1xLam3sYU2Lyv3QSME8c11ra9fWJHnQxXY9YyUf8ApRawrHWiMdjz9acqlfesay8XWVwoV5DbP/cl/wAcc1rx3KzKHVgyf3h0/OlcZKpIycVHNcL5Mozghc1J5iEHBz/L86q3mPs0xGPunpTA521XzLqVuy8VuacoaPbWLpoAjZ/7xrZ05guRmgVi1dWqlVJ9asQ2SSRDrTGXenSrKTJDASWxhckc0MZh6jH9lkIycGs66zJGSnBrmNY+IlrdapJBE24RttLEHrWtY3yX0IImCNjPHepAhmjEELvyH6Z5rwn4s+JEub8aekhcx/M7YAr0H4xfFGz+G/h2aW6lV7mQFYosnJYjivj2H4jy61JNd3SsryMWLbs/hxWcmhpM6TxBm9t3hiOTjkVw8li1mwmiY5Trirs3juxh3kK0svZeRXM6l4kub5WCgRIx6DrU8xXKei6Lry3tsrAhWHDLWq1yJI+vNeO6Hqz6XcD5iY2+8fSvRNOvvtkQeJvMQ+hpqS6j5Hc2kYMdp5roNDvGx5ZOMdOa5aOYKRng1p2twUdWB4q1Z7GR6Fp928Lg5z+Ndtpd40kanNeZ6bqCzR5zXZ6HfB4h83HpVDOtvrw2+nzvnGENR+D2BtM5z71g+J9QMOiybW5Yhav+ErjZZrnjOKEB3ir5oGDT0hKseM0zT7gBQTWhJIjqCp571QEUf3hW1Z7VjHqaxVb5q2LUfuxQBcUg1tafHiPNZFvHuat2BfLhFAA7bjzUUsm1eKbI/wA1Vbhjjg4oAglmbJIOKhWZ5GILHH1p6wFqtQaeWb7poYG/J92q71NyahkBqQI0OGrStJu1ZgB3VctWw1AG3HkikkUkU2FwVHOKn4x1zQBnyRZ61FgDpWi8YxVSSEr0FAEDY71GwBBqfyz3FQv0NAFC6X5azXFatwpZTisx8hsYoAkhGKs/dUVWhbLVZY/KKAGSfMuKrvyKnY8VA2O9AFORBUDjKkVbmXAzVORsU7AYc7lbhhQJuCCaiviReNUe44qgMrxM223Mw52HJrzrT9Dt/F/jGBrj5orQeZt9W7V6B4gO7T7gHpsPevOPhvqyLeajJI3ztJtHPpSYHr0kyQx7UxtHTFcr4y8dW/hezdwRLdsPkjDfzFWLa/k1q4NtZPlV/wBbKoPH0PrXMa54FWa6kkZXkZj99jk1BJymj3994k1M3F0WllblUzwv4V22maUEz5i7ZM8irHhvwjHpKowXL92rozpW19wHBpDsV7HTgMcbhW9b2qRpnHNRw2pjjBFTKzd6QWJF+bgdqmj75NNUfKDSr3oGSfiaPxzTVcetLuHqaBWHrS0zgd6TcKAsPam7ttOHQ1HJkrQFhyzc9f1qeO7K9DWc2V9qb5jUDNlL9vWpk1A5HzYrn1uitOW8bPFAG9NHNdY2VSk0e75IXP5U2x1j7PICSD9a6Oz1qGQDkZ9qoDj5tPv4snyGI/2ef5VmyzSo210dT/tKRXq8V1FKvyn60kltBcKQ0Sv/AL+KYHkxuD0J/Wo2ct3rvr/wnp9wzHyhE3qtYkngmRnPlXIA9GGaAOYKZ6n9aa0IboSfxrp5PA97Gm5Zkb6DFZdxoOowtg2+4eqAUAZD2u7+LFV5rU/3s/jW2uj6hJwlq3vu4qU+E9SZdxh2/iKAOW+xq38RBpP7PC5If681s3eg39ty8Bx6rg1nSb4dwKsp/wBqgDJkCxuRnJFdv8K/EEtnrosWdvs867QhPAPrXByBzMwVCT7DNdB8P2kHjCxBRlwT1BFQB9EKp2gnilOexzUS3Occ04TK3U4oAdzSgkds0mfQ0fjQA4MfTH40u4036mjaPWgBSdynPSs5owkjDtWhjHSqt0u35hVJ6gQ7RSe1MMg3elRSTfL1q2BatZBHMR69K0ZZAqZ71z8c375MHvV+4uSwAB5qQH+cWY8U2Q+YKjjbNTxqWoAqSW4YcVUlhC9RWux28YzVd40myD1oAxG5bHpSbfStGSxCHOODUUkG3GKAKiKee1SKtPMeOtG30oAbTv4aTbS4xmgBjVk6nJtRq0pTWHq0u2NueRQB5D8UGa4XYemGJ9uOtfInxI02TXfjB8PNCidtk1taiRF7r5hb+lfWfjqbzprk9VWF/wCRr5/8JaSde/bC0+Mpvh0fS4mPopEfH6mncD7K0+IW+EHCrhQOmMDA4qzcwiZssTgelQ245yT09BV5QG60XAo7AvylQ6+jKDT44FVgYXktX9Y5Dj8ulWvJ9qUREdBSQFpZ9UijU7YbxfXAVz9ecUs2tt9jkSWF4GIxtbGPw5qFJpLcbgcY+lJfXUlxYssnOSMdKoAsx+5X061pWLYk54qjAuyNVz2qxC22TrmmBrecBG3Ncf8AETxMdJ8L3siP+82YGM9TXRSSN5T847V438btW+zeHPKLf6xx39Kh7geY2+sGPLO7MScluR71k+IvjqvhmGSC2mM9zjARST+Zrz3xJ4gubxZILeVoohwWXvXCyafuJBbe3c881NwIPGXizVfGWqNe6ncvNJ/ArE7UHtWbayiGzCdD05xz71du9NEcfHzd6wZJyz4BzisHudES2pyxJ5/GpR+84x09qqR+uc1ZVsKayk7GpBqFwlhatKxA47msrQ/iFdabdebZybWB5VuQRWP4/wBSmV0t9rBAOvSuPt7jy3G1ufrWDlqdVGy32PqjRPFln4osVmVBb3P8aqeCf6VrwXTQ/u3OCP8APWvnHwj4xfR72NgTgnEiMflZa9u0/VINSsY7i1cNbt0XPKn0+lddKa6nNiKKUuaJ3mlat5JCk5DV6B4euwy8V4tZ3jRuOcYr0XwnqRkjUbsnvXT6HAjqfGV95elxDON0gFdFoMhSzix6ZNcD46vNumWZz/y2BrsdFmLafCQchlpjO802/LKF3Y/GtaG4LY5zXEabNJHJtA49q7LT1IjBancDRDfdroLNQ0KEc1zHmDd1xXRaHdpgKz0XA3rOEFR2NX5j5cQGapx3SRtkMuKqXmsx7sLIppgTtJ83Jq1HZm4A28iubbVgCTkGtCx8RLCoBINAHS2+kkYq/HZxw8k5rAHitFjHIFULrxduzhhSuB132M7elRNZVsRqNvSlaMMKQHPSWpXBAzT4UIatWWAHpVcRKrGkBNCflFWVqovtUisaVwLHHbmlwD1qFWNOD4ouASxgjjAqjNDt5q8X3VDItUBlTr8tZU6fMTW5OvFZs8PXigCpHwfrVhj8o9qjUc49KR325yeKAGySY6mq7S+9MuJh2NVGmO7rQgLr/OtUp1CqT3p6zE5qG6cBODzVAc5qTbZyxqDcNoOam1hflDe9Z4kBAGeOlAGfr77bKUtwuOTXyl4J8WanrHxEuvD9vE0Fmbtg9x6jPQV9D/E7XhpOjou7DzttHNeefCn4fSRa1/a7oUZ5TJu+tAH0v4K8N21rYi3hjCQr129WPcmtjVPB8ctufs5Jf+6KXwq2zTN3cnrV1tQljm+Vj+FSKxy1tpZt5DHJEQw9RWpHYpt2la3V1CGfiSNSfXFDWtvLhlYDPakM5uaxCE46VUltvauubSkkXh8VC/h1m+7IoosBysa7flp0i8DvW9J4YuFwVdajk8P3jKBtVv8AgQ/xosBz7ZWmNKRWvJ4b1AH/AFAI9mH+NVpvD9+oB+zMfoQf60WApxzeZx3qKeSSL+Gpzo9/G2Ray/gKuW1nNMu2WCRf95CKLAZC3zcc1ahud3NT3Whv1jhc/RTVD7Dcwn/USf8AfJosBdZQ44qGSNscLmiJbhP+WEn/AHwatKJWGDDIP+AGiwGZIjdxiotpXoa1ZLd26RP/AN8moDZSf88n/wC+TQBmkODnOPxqeG6mj6M351ZNg7YHlv8A98mp4NDnlYYjZR70wFtdauYG6kj3NdJpviA3HyscGqNv4bGB5mSKtf2TDa4Zd3txQBoTXBbpTofm96zlmO7Gw/iDV+Fvl6Y/CgC5vAxzUUzCQjqB7cVHvPuaVfmbnIoAsRrhcDj8jSSqqrxkn3Ap6/Ko5pkzDbjNAGdIu5mGBj/drI1TS4WQN5QznndXQbRxzmqGrfNCAvJzQByjabHAztHGvvjFS6FD5WpCcrgoOOlXWRlyGXr7U3Hlfd69+Kh7gdDDqr9S3NW4dVOeWrlftDetSpfMvegDso9W3cZqePUhnk1xa6kfWrEOosW60rgdot4GA5zUq3IauTj1IjHzfrVlNSPrTA6YTAd6gvJM27kjntWMupkY5p8upbrdwT2prcCBpGbFM3sq9aIZRIowaSRSyjBq7gMExWRecVcMzMwrP8tvOQeprUWH7tICzANwzU5bauc9KZHlV9Kr3U3ykDigCld6w8cuFXPPNWrfUDOOmDWLLGfMLUQ3HluKAOlDCQYJxTJIT25qpBciQepq0snFAFaSNvSomHvV8oCCRVaSP0FAEGMU1vuml5zQfuntQBSmfaprmtcm8u3kOecV0F1IArc1xHim6K28mDSA841hTeC7Uj5nGwficf1rgP2f9Jj1D47/ABQ1lkDeRLHYRv2XaMEflXoVxcrZ25nfhVfc3HZQW/pXOfsk6e03gvUtfZd0+s6pcXJkx1UOQMe2KvoB7xsCycemOlWVqJk7inxmpAmPT0oXr1pVGaUCgCzDCjZyO1Q6kqqsSAYBOaljbHHtVK7mL3aJnOBTuK5YjXIyTU0P3jzmoFO1cUsbkPTGWbhcwyHsFJr5x/aAvmmuLG0RsbVLN+NfQ17qGy3dcZwK+aPiOx1LxHcTN86KNn0qGK54reWYWRs8g81k3FkRuK8V3OpaSFVio3L1BrCNrl8Yx61Izlb+H7PYzO3LBa8/j5Yt6mvSPGjfZdJlIbliFrzyztZJs44FYs3iSRnFY2veJotBw5bewP3TWzqMbafZvKxwAOteJ+MNebUbp0Dbl7GuWcjpirnpd1480vxNbIs9rGrYwGrldSsLJWLQy4HXANecR3ktvwrsB2q3/bkzJhix/GsfM0TtojdmuPssh+fj1rqfAfxKuPDN+qSv5tm+BIrHoPUeleYSXjyeopq3D8DNXF6Eyu0fa+nanFqFvFPbyrJBKoZGByTmu08JXxWYLuzivkH4P/Ex9AvF0vUJC1hM2Ekc/wCqY19OeH74W95CQ4KvjDZ4Nd9Od0efKOp6B4sk+1acik/cbNdh8ObxdUsI7dmy8fAFcPqb/aLUjORTPC+sTaHeLLG3Q5rW5J9Gado6R4JXmtqTZFCAOMVxGg+OIdStUkZlz3+taF74kiWMjdzVAaF1eLDnc3FZUnihrdvkbGK5vUNaaVzhsCstrh5G+Y/rQK5258fXTZXP61DJ4suZMYOPoa49ZRx83PStbTdHur1vlRgvrQM3IvElyWHLfnW3p+tyTMAx/WqNn4TZYwWJz71ej09bc4HWncDbWVmUHcefejcOcn9arW8hVSM5xVa5umkbavX2pAfRCyoBy1DTJj71cnJr23+PFMPiD1fNAHSzXSdmqt53PWsEaysh4PP1p/8AaBbHP60gNszY70qTZzzWSLnOOaljufeiwGtHIealV92azI7n3qxHce9AF2l25BqFJd/eplbg80wK0kJ7VRntSw5rUZwM96p3V0ir1FAGPLH5OaqyNladeXQZ+DVRpPegCGTvVGb5fatRgrLVWaHI6VVgKQdh60jOSOae8Z7cVC3HfNAGdq/NnIT26VyUepbON3tzXZXyiS3cHnivItV1D7LPOjHbtc0AYHiiP/hOPiVo2jb90EaGWRQa9y07wxBZwokSBYVGF+Xr714f8DUPiL4la9qjjcloFgUjkBjyRX0/Y2qzsqDpgE0MCTQ7Jo7ADb39KW4tmEhwtdFb20cEIUdBUMluJGJxUgc59nPcEU8Iy425rc+wKx/+tQdPAoAzInkX+Krccj/WrItUX+GpBGvpigBkbFhyKlWkaTA4qFrjb3oAs7R7flSGTOO2PTiqhuvQ1H9pPrQBf848Y4/Gl+0gdf51nNc+9Rmc+tAGr9qXseaPtSenP4ViSXJWmG998UAboukbt/Kka4j9PzxXPteMvQ/rSfbn7n9aAOgE0PdRR9pgH8ANc+bx8cGoG1BqAOn+1Qf88waa11D/AHVNco+pN3JP41E1+w5U4oA7FbqEZ4UUNdQN2UVxjalJ65pP7QkbufzoA7Zbi2f7yrx0p4uLb+6p/CuG+3yd2/Wm/wBrFf4s/jQB3Ty2xxwo/CmH7M/QgfhXEjWyoP7zH41JFrhb/lr+tAHZ/uf72ahmjjbGBXMf2w64IfP41MmtPxk0AbhjRajaOMdAD9aox6gJl60sl4I1JJ5HSkwItWaNkHTPbArHK8dMGpJ7gzyF89e1Q5JqQGNGewpjIfSntKV//XULXS9Nw/OgAKmkDOvelWZWbG6nk54pWAI7xg3PSrUWoD+9VCSPHPSoPu5INMDoY9QH97+lLPfhowuc5965wTNu5JphvmDgZoA6u3uVTbg1oxybl61yEN83HNa1rqRHBNO4G0uPOTJ71qqnQisOG5EkkfPet1OgxVAPYjb1qnNj61aYHkVUkU89qAM64UjNUXyp4q/dcAiqE2e1AE9ncsGxmtaObKjmucjkKvWjb3PY0AbccgHU09lG2qEUwbHNWxIMDJzQBDJEahmUrGSeKvNnbkVm6nOI4SM0AYWoTHDYNefeKrrzGEatznmup1K82q2DXAancfarp+46fT3pAcd8WNUi0P4ba5esQHSxlMYz1ZxsX+Zrs/gX4cPhb4Z+G9PIwYrKMsD13EZJP515N8foJdYm8M6DESq6prEFqyD+KOP53P5mvo3TbdLa3RIxhMAAegAxj9Kp7AaB5XNJGeaX+A1GjUgLSmrEMe41VjbNXbcDPNAEkkPygisSRi2qOOwGK27iYxoSK5y1lM19K3vQKxrk/LUXmbWz2qWT7tZVxciPcM07jItcvPJs5nBwAprwnUo2up5JHXl2Nep+JL5vsUke773ArzqeE9KkRyV1peGbIyp9qwtS0tY8sqcAc13U9vuBzxWPfWo2uCOCKTFc8N8dKsixRZwC+SKwI1hjVY0HANb3xAbbrjwDgIK51Ynb7vFYTaOmBxXxI1Q29q0KtgHOMV4hdLI0jMwJzXuvirw+98zFmzXB3Xg993Cs1cD3OlaHnfltk8GhYD/dNd3/AMIXLnmNhUq+CZBzsb8qQ7nAralj901J9mK9ia9Bj8GSd0NO/wCENdv4DVILs8+WFlOcMPdete6fB/4keZFBo+pSZljIEEp5+XstcU3g2RRwv6UWfgqZblHRmRlOQw4xVQk4szlFNan2fDcGfT4yT29DUMWFmUt0rjPh3q1xNoUNvdvvniGN3tXWNLt+brXoQlzI45KzsdNpdxLY3AZHYxt/tV2i3nmQq27kj1rhtNmElshY810tlN5kIGc1dxFppi7Gnwq0jYHNEcIY8DFdN4f0QSMHdeKoRN4c8N/aGEjKa72y0+OxjAwPxplmIrWFQqgYFZ+oa0Q5VTQFzXn1KOFTytZE995jbgcCszzpJ2PU59K0LXRbi+wmGRT1NAxPtxmIjjyW74Fbmk6KwxLKCO/zVb03QrXTUwdrt/eNXWkH8IAA9KAJ3kZupJ/Got+31/OpWhPcUnknsDQA2OYhvl/nVyK8NVPLZe2KRsr/AProA2YL4E43VaW6zjmuaWYq3XH41ZS+2991AHSJPU63W2udj1INxuxVlLzd/FmgDoI73HQ1KdSOMZrn/tBbHzYpROV75oA2m1DGfmzWddXm/vVfziwODioJMnvQA2aU/Wo/O9aim3L71XM3NCA045A1PdCy5rOjmIPpV2ObcuM5qgKsy9cVRbvWjcLhc1mSUAQXHK46DPNeAfE28Ol6xeDGBguvPaveriUBT82DXh3xd0iTVvFGm2cJw18NjYHOO/6UwNf9lPQZ7Pwfd6ncoyy6lePMrMOSoOBX0VpTfvBXJeFtLg0TR7Kwt0WOG3jEaqo/z3rqbORYW64qHuB0TTcDHWoxcbepzWXPqOMHPFQPqm7+LFAG59o3U0yk1ipqYz94VYTUE/vCgDQaQ+tMZ2bvVZL1WP3qlWYN1OKAA7h3pjL3xVhRu6DNKVPpigCoylqYYivNXcY96jkkXHXmgCmyn0qKRto4qSaQ+nFVnbNAEUjk1CzGpmFM8v0FAETMaaXNWktjJ14p4sc5xzQBUVt3U4ols2ZQVGc0+S3ePkjirNqwb5WoAx5IWQ4NROrdhXQSWIfqPpilh0VpmwqH9KAObVWPXI+lPWF5DhQzH6V2UXh9YuZWCj8DVhFsrUH7rH6UAcdHpN1NwE2j3FTr4Wlbl2x9BXTtrEMWdkefrVWTxC3IWNV96AMyHwdFJ/rGyPpUjeDIB90kUs3iVlzl1FVZPGkcAw0qn8DQBMfCkadGNNbRliU/N+tZN18Qrdc5fcfRc1hah8RWZCEiz6FjQB08jC3yA+ce/SoIbw3O75tw9RXnF1rOpa9cpaiZkjkYArGO1ehWNotjaRQp92Mbfcn1pMCxj0qKTKKWzgDmpaiuI/OiK9Ce9SBlvPJdElW2oP4s9aiaOBTkg7j3q1LaeVCsfJx3qo8AbgpnHSgCrcwuP3kMhG3kL61qWd201upbBIqssRVdpPHpVm3h8qPAFAE/me1RtjBNL5ZPtUMzCNSScgUANkCr1PPaohDuG496p/bGkYt26AVMLzgcYoAmXKE1LHeFW64qutzG/BOKUqvUNigDe0/UP3ijd+tdZaXgOMmvObfcsgPUV0FrqXl45p3A7QsDjB602TaF5NYEOsjIJP61NNq3mJgHmi4DLqQGQ4NQSYZeDmm5LZYij+DpVAU24firEbnioWX5qcrUAaEUxWrMeoKuMnNZyvhahlkGOlAG7NrSRw5yK5XVtaa6cqOntTJvmzyfzrMmAGaAM3WLllhZufzrk7dt0jSsNwX5ip6EDt/KtXxFdELsU/WuY17XrLwtod5qWozrb2VtE0ssjZ+6BkAY5yTxTW4HHafG3if9oi2gm/eweGtNaeReoW5mbIDe4HFfQ9ohWJR/9evBP2YdGup/DN94q1VG/tXxLePeOZF+dYs/u1P/AAHHWvoKNeBik9wFk4Tmqqv+FW5PmUiqLfKTQBagk+brWjDIKwlkKtwcVMbwqnWgC3qN8FjYbsVmaT87kg5JNZeraqIzjfVzw9fJIM7s0Abl5L5MRBNchqOqJE7ZYHHaneMPFkNiroJVMnTaDXlWpeJ5bliQxBJpPYDqL/VhqVx5Y69sVTk0925VGPrgVzWl6k63yOWzz3NeoTXEVtokV3woZfzqo6gcHcQiEEuMfUVh6k0IXG7BNT+IvEXmyOI1JbNc2trcXD+a+786mRNjx/xwhk8WXIxkfSsY2s7f6uJiPpXpf/CM/wBoeIrm6uDlN3yg10Efhu1VsLGoGK86rJM7IRPC5PDt1cZJRqbH4LlP3k/Svfl8P2yj7i/lUMmhQjpGuPpXMbHhn/CGuB/q8/hSL4TkXpH/AOO17iuiwMcbV/Kpf7Ag/ur+VO4HhLeEpscoPyqI+E5V/gx+Fe+/8I/b45RT+FQzaBbcfIv5UXA8G/4RWXp5f6U2PwtIsgzFj8K9zOh2y8lFP4VTk0u38zIRam7YHnWn28+nbDsYJ34rqra9W6h3DHFdL/Zipau6QrIQOBivPZrya11KV5Y/LUH7uOK6aVXl0ZhON9Ud5pdyGtyoIJFdToMgmTaDk15bb3E8i/abU8rzt9a3/C/jaFblS5WNgcOjetegmpHNr1PZtJ08zMOK6uNRZQjDAfhXN+HfENldQo6yKCa1NQ1KLZxIpqgOjhY3lqQj+2RRa+H2kbL5f3rE8G+IraK4NrcyoiMcgnv7V6L9utY1BWRCO3NFxWKljoccP3kz/vVobY7dDtVQfpVGbWoMH94g/GsW88VW9vuzIvtzRcZvyzqqlmYfnWPf63HEpAdRjk84rj9Q8ZNIxVGwOcEVyGo6rf8AjC/Oh6S6qRj7TdZH7sen1oQH061mW7U37Ef7prrG0UsuRIuPXFZ80VtbyFHuV3emKYGBJaHj5SBVWa1OBxXWLpqyIGjYOD6Gq82nbeCuKAOTaApUZ9hXSvp47A1Vm0kt/DQBz0jFelJHfPG3rWrNphA+7iqUumsOgoAmt9QVuGbFX0m3LnIrAazlj5C4ojvHhbDGgDo45MnrVnyw6+tYUOpLxlsGtSxvBuBY/KaALEmmNLHnbgfWqM2mGPJP8630vI2AXIx2p0iqy5wMUIDk/IZG4GaljYqemK2prJZBwKoy2bRnheKoCGT54+OtZM5KFhmtlVxkYrK1CP8AeHigDFvJgv515l4y1CG18VaTcyLkxOV/SvRdQ+VTXzD+0x4ufwzpYvIwd8cy4xnjNMD6MtvHlhawhpbmNABuyzYA9q3/AA94407xCZEsblZnj+9yf618xfAL4W+JPiLYR+JvGEstlpDHNnpp4ecf3m9B9a+idO0O10+4UW1tHayJ93YMHHTBqWB2LXDSKvPH1qpNdBWwWzVeaV44wc5OO1ZM2rKrEP1pAbYvVGeQKT+0sfxVjb0uI8hsVUcMpPzGgDqoNU3NhWya0IdSbjcePrXnzs68qSDU9rrF1C2GO9aAPSYNUB4LVow3isBg5NcDZ60j4B+Rq3LTUCMEHIoA6WSVivpVKRyaltJxcKATVp7PcoKjNAGTy1KqFqutakHhaVYCOoxQBVWDPWnrbr6Yq4sNL5OeAMmgCssNSxqoJyauw6TNNk8xr6+tWY9Jgh5cGRqAM1rUTLheKbD4ffduJCj3Ga3VCxL8qgVXmmZuM/pQBB9ntrVc4Lv7nio5NSkjUhFCj6USL3qFoGf+GgCpNcPKSzsR+NU5J0XOT+tai6W0h5G0VJ/YNu3+t59KAOamv06Dr9az7i68wYJx9DXZNoenJ/yx3n3oXRoM/u7JR7mgDzuaNZf4Xk+maqtpDTH5Ldie+7/69erR6KGxhUjH+yKnk0mGKPIXc3figDyaPwfcT8rbInu7D/GpG8B3JX70A9lGa9BuIvLbgY+lQNk5XJyfagDiPDXg24XVpZpCqpCvylRjJNbzWMsDFNu7FdZpsK28SnGS3LVV1S2RXMwHB6ikwObaF1+8uKaq9citjajZxVaax3coeakDLlQno22qrWsjH71aDxMpw447Uzb1xQBRW12n5qk246VKynNMb5aAI3GBWdqTFVCf3utabHj3rNuF+0Tt/s0AZyrtzUZzVyS3PPGKrNGVyaBXIWVl5BpYZnbq1P2ng1Fb/eK9eaBmxZzjbg1bX1U5rLKlQMHFOjumibluKANWOZt2C2KvQzHjnP41kxTLPwDg1MsjQkZPFNAb8bgryc0/+GsuG72qDU39oALwc1QEzfeNC478VFDJ5mTUlAEuQw61BJyDin7toNVZptuecUAQTtgGsbUJ/LUjPv0q1fXQRGJcL7npXG+JNais7We4uZ4ba1iXdJPO2yNB6knj/GgChfXDXl4AmHOcDuPx4PHueleB/ELUo/jr8RtL+H/h3UPtOi2Trc69fQBthZTxED6DHbjNcl8QvjtrHxa8QP4B+FsMs63DeVea0ykMy9GCdNqfhzX0d8E/gnp3wT8JJpds4uNTnHmX14QcyMeoHtVAejaDYRWaW9tBGIoIEWOOMAAIoGAOPzrqUj79qy9GjCxlyMc8Drx9a1Gbap5qQGSY9cVl3D4br3qe6uFjB5xWLdXypk5zQBYmn8tc5rG1TWxaxkeZzWbq3iBbcEA8muI1PW5LqVgDQBp3+uNNIxZ+PrVJvGN1ZxtHC2AeM5rDkmfHU81UkU+tAD76+nvJDJJKzsfeqoJ79frTvKPYcUnlnPPFG4CpP5Lq3pzXQX3iqe/0S309Cfl64rEh09pmAxx2rqdH0GONd8gJwM1S0Ay9J8OvIvmTZJP97FO1pEsYSigBunQV2lrp/nqSF2xqOuK4LxDL5+oSKDlVOBXNXmorzNKcbmLHEu7OMHrU/PrShQqil2Y5FeU22zsWisKMt3pWUsvHNMU4PNSFgq5pXArrEVY8VLgKuW4qtPdbehyaqPcSycDpRzFWLkt8sfAbNUpL1pTgAVJb6TJcvnBNbVp4fVOWpcwWMCOymnOQGIrStvD5cguCPrXR29mkK4C1JImzn+lTzDsivZ6ZDFHtxkYqjfeF9OulZJbdGVvvcc/hWksnzcU9lLc1Nx7HCTfC+2td76Vdy2rnnbINy/T2rzjxP8NfEtjctdW8K3S5yZLfr+Ir6DjU88U1gegHX3rWNWUSeSMnqfO2j+LNW0dRFcl4JF4wylf510LfFC9CgOxYD3r1DWPDlhqq5ubWOYepHzVxGsfCGyuEZrCeW0c9Fbkfzrpp4jozCdPsc9J8TpAN/wAwI9dwoX4zalGoWO6kA9CTiuK8aeCdb8LkvND5tqP+XiLBH4jPFcfHdOOXNdkZxlsczi0z2qP4t6tcMNty2frXU6P4y1O5UNcMzq3XmvEPDredcR4Pf1r1S2vFs7ZS3yqBzViOk13xPJZ26R2zGS8uGEcSDk5PevafhR4RjstBiaNAblXzdzdTIx5JzXzh8Pd3ibxJNq0uRb2fyQBvulvWvsj4c2h07w3FKRtS4+Zs8Zz6CtktLiNzwvr2qafDFBqUzS+cNy56qK07xi4d859Dms++tnl1DziNkfGxewFTSSDy8bsmojdoCSz1Oa3YbW4rorTxAJF2uAT7iuOjYg9auxzFcfNVE3O1WaC5XnbTTYo2fLYCubhvWXHzH861IL4hRzQO5Ym0p2HTf+FUZNP2k5StKLUG9QfrVlbxJOGVaBnNTWIx93P4Vn3GjiQZ2812cn2fPJUGomggb7sgBoA88uNLkjPyhvyqOGaSFsHdx7V6DNZqw5VXFU5LG3bh4PxxQBzlvfFsdq04b89zkVd/sq0P3Vwaf/ZMR+7xQgI47reOPxp6sknBpkliLVS2/is/7cqscMOKoDRlhTyzjrXPagqhjzUt3rAx9+uf1PVF2kls0AZviG8S1tJpdwG0c5ryLw98LbX4xeNo7jV41m0XT5hK8LZxLIPur07VofETxYFj+zq3zyt5cad2Y9K9k+Fegr4c8M20Ei/6SwDysRyWNAG/caHEsMaRRCBI12RomNqqOgHFYWo6DcN8yFs9ttd7iOaPB6/SqUkXl55wPahk3PKb63v4mZTIyN/tVnJaXMjAzS7q9ZuNPhuOXQMfpWdN4dt2yVUA1I7nJafG33cEqBxVlrUswyCK6mx0eG3+8uRWnHptkzZdMigZxkOl+ZwqFyfSlutBljjLGJlxXodrbWVtzEgB75q401tJ8rIpH0oA8jhsW6/MDWlaxyRkY5ru5PDVhdSFwxQnsvFPj8K2XOJH/E0Ac/Y3Twlcmuss5hcQj1qn/wAIrax8+cwq1b21vp6584n60AWHtwMUzyCegzR/aiM2Bg1PHdr1xQAR2RbkjFWo1EOPlpy3CMABxUnDdTQBLHMp7/pTpFWRfvVAYwehpnlt2NACPC2TgZFRi365WpPLkH3Wo/er1bNAEbW444p6xhQcCl3P64oLP65oAYYTJ1+Wj7IG+82ady3ejaaAHLbxr25qVVXsMVAAVqVW3UAOYY6cVFImV4NSUbdwNArmZLAOTjNQrZ+eOE+7V+bKKSBmrenw7bcFhgtSGZflmMYK5qCZVkjKkV0Dwq38P6VVksx2WlcDmDpLbiYnx9aYdPue2G+hxXQyWftioGsyuNppAYMmnzsMGLP4g1n3WlzrgiJvwrrCk0eMULdSp1QD6igDh2EkZw0bD6ikyp4IrvPtET8SRq34YoW3s5G/1SfjQB53dSJHGzHjaKzLEkrvPVjXpWpaTZ3UfliJffbWU3gm2YfIdoqrCZzH2cTdDg0sfh7zm+eXYDXUr4NWNPkbJqvLps1n94ZHaiwjH/4QcsPlnyDUC+CZYpxulxk8dq6Sz1Dymw4H41qeekygqBuHPFOyKOVuPA92ibk+f8jWBf6Le2PMkTbfVQK9hs5FkhXPXpS3VskkTBlV19GxSsB4ishXkdfpWjbzGRcMOa6vVfClrcuxiXypOxFc3caHcaexyrMB/FQBEzNE3XipV/eJnNC/vISMc/SoLeTaxRuKYGxp4yuM1PKCrU3TVHUVZuIyxJ6/TrQBUZvlPasa+vvJUkkY/vZyPzqbWtQg02zlubueG3t41LPNM4WNR7k8V8UftAft5aZoD3Oi+AmXU9XXMbapIf8ARo/90cEn8MUAe8/Fz42+G/hPor3+vagsMjZENnEQZpj6Bff1NfFWr+NviD+2H4qOjaTEdI8Lxvlra3YGGJP78r5+ZvbJrkfhp8JfF/7RniN/EXiHULg2G/8A0jUrrILDPKRD/CvuTwH4J0zwjosGjaHa/YNLj4fcRvmPdnIHNMDS+B3wh0H4N+H0tNHiWe8wPtGouP3krd8c8L6V6bGxk2gZJz3xWZp8OxQAoHYAf/qretVWH5n4OOKQGrCot4QMc4qrd6gI1OWxis291kR7tz1yGseJwuQrdfQ0Abmpa6kectmuQ1XxNuyEbB+tYmoarJMxOWwfesrDuxJB/GgCxeX0t0+S2c+9VhGw5JNTR2/O7Oal8nPWgCoUJ9TTWj6VopZlvarMWmjOTz+FVYDG+zsRnFTRWJ4wuSa6COzA4Vc5q3DZpDy4yaLAUtP0tY9rSD5vStm2hNxMkaLgH0qvuLNtUcnoK2Y/L0XSZbuTHmbc4Pak3ZXDcpeK9Yj0PS/ssTjzXFebzMHTJOS3JNc34y8W3mpag8iOTHngVmWOvzEAO2a8StWU5WPRhRcdTreeM1KXCLk1jw6srIMtVu1AvHADfSsuZDcWSTXA/h5quqyzNgcit228P9271oRaWkPRf0qXLsOK7mFa6C0/LDFa9vo0MK8jNaUKgcbf0qVYg3QfpWdzRRRVitI4+i1NtUDjip2j2ioW596RTQw1FMu5QKlSPexGKmazG3NMixQjjw1W1jyvSkWE7ulWFXPA5p3EQbQOn8qVo1281b+zng4okhG0DrTAy3QNkCo1jC8EZP0rT+zqOg5qN7PPQc0rAULmzivrd4JoUmhcYZJFyD9a8J+I3wcbTbiS/wBKVhZt8zwjnyz6/SvoiO3VRyc4qOW3jmyGC46cjNbQqODIlFNWPkTQ7drG/iBAGWAzjFdL4t1R0sfIib95JwNprtfiV8Nxp9w2r6WjPAp3SRdce9eeW9r/AGxrdlCBlDICwH6ivUpzVRXOKceU9W8A6cui+H7G3GN8xDNxzk19S6RqDLoNlbY2tGFXbXzPbyeXqFnGg+QOPwx2r6c+G9q3iS6tZQmYI8bzjArsWxkavhTxUY4ltLtEmg7bhyK65vD9nqkfm2VwIWP8PUUUVihMwdS0XUNLy0kO9B/GmDn8BWP/AGoytnp7Nwfyooqrkly31QbgC6g+la9veblHpRRVDRcW6OBg1Dcak8anb1oooKKDapN1YnP1pBq0g6kj8aKKdgJF1x0I+dhVpddLqBk/jRRRYBra6I896qy+KtoIB20UUwMm88StJ1b5azZNc7A8UUUARvfLtLB+frXHeLvEaabZysz546cmiigDz34WeHbjx98QF1i/Vv7PsjmONiNpY8dK+vdNtVjtkBXjHHYfSiigm5b8tcYxTGtVb2oooYitNYlsbDg0sOlPLkM2BRRUjHS6SVyi/MazGVreQoTgiiigdyRZ9tKbgnoaKKBireSL3/Wnf2hIveiigBH1CRh941BJdu3BbP40UUAJHMR0NTLeSLjnNFFAFlNVMeMt+tXrfWPmALUUUgNiK6SRAc5qVZV5G6iilcB3HUNSqPeiii4Ay+9JtooouABadt9KKKoBRGOabtCnriiigTD8c0vY0UUhFaaMyYUDPNaKDaij0FFFK5Q6iiikBH5QOeKY0IXrRRQANbhhgCo/sfXjFFFAEUmmiTqcVQvNPNvG7B+RRRTQGQkkin7/ADVqOaTjLUUVQmTrO6/xcUNJ5o2uMiiihCRk3ulhsshrOhvpLKXa42r0ooqijotFvvOO3OR1rcZgVoopAULi2zluhqjJCNvzBT60UUgMu70OOYM0RCv6cCsD/hGLr7UXcEKO/FFFAG1CgtkUHBHSvLvjx8fvD/wR8Lzapqz+fO2VgsY3KyTMOwPYUUUmB+WHx2/as8bfHK+uIr++k0/RNxMGl2uFhCjpu5G411f7Of7Lt14+W38QeIwbXw+rBo7dB+8usfwr6Ciin0A+7dH8N2+m6bb29vbpaWUChYbWEbVQe49a6XSdP89gVjwF9qKKAOkjhjs1BJGfesXWPEq2+4BgT7GiigDjdQ1yW5Y8/rWXy2WzyaKKAIXjMmBipUtDxkHFFFOwFyOyVVzjk1Yh0ppSCFwKKKYGpFoZAXDc1fh8P7sF24oooAbcRx2uVVQfesyTfN9xWJ9hRRQBraRpJVvOnUqFGfmFcn8QvETXW6xhfavQ7aKKip8LKjujxPWLowXhiZc471QmuiqgqtFFfGyk+Zn1NNKUdStJrUy/dyK0tJ8YT2jDK5+tFFLmZbpxsdjpvxESRlEhGe9dhp/iW2vlGHRePeiitoyZwVIJbG1bSRyjKkNUnyr04ooraJl1GSsNvXNVQMt0oorQGT7RHg9M1MjBuOtFFFiGIyhe1CqM0UUySVm+UYqFmPbmiikwGMzUxZ9pPNFFSpMBGkLDpUGTnFFFUxrcrXUbTRsrDK9+K8w1DwWui+LPtqMv2SQFgo4KtRRXRhpPnsYVlodd8PfC19448WWtjZhsffllVfuIOpr7Z8I+HLXw/ZwWFqoCwryx/iP96iiveOA//9k=";
const MIGRATIONS = [m001, m002, m003, m004, m005, m006, m007, m008, m009, m010, m011, m012, m013, m014];
async function runMigrations(db2, hooks = {}) {
  db2.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  const applied = new Set(
    db2.prepare("SELECT version FROM schema_migrations").all().map((r) => r.version)
  );
  const pending = MIGRATIONS.filter((m) => !applied.has(m.version));
  if (pending.length > 0 && applied.size > 0 && typeof hooks.beforePendingMigrations === "function") {
    try {
      await hooks.beforePendingMigrations({
        fromVersion: Math.max(...applied),
        toVersion: Math.max(...pending.map((m) => m.version)),
        pendingVersions: pending.map((m) => m.version)
      });
    } catch (e) {
      logger.error("Pre-migration backup failed", e);
      throw new Error("فشل النسخ الاحتياطي قبل الترقية — تم إيقاف الترقية لحماية البيانات");
    }
  }
  for (const m of pending) {
    const tx = db2.transaction(() => {
      if (typeof m.upFn === "function") m.upFn(db2);
      else db2.exec(m.up);
      db2.prepare("INSERT INTO schema_migrations (version, name) VALUES (?, ?)").run(m.version, m.name);
    });
    tx();
    logger.info(`Migration applied: ${m.name} (v${m.version})`);
  }
  ensureSeedData(db2);
}
function ensureSeedData(db2) {
  try {
    const userCount = db2.prepare("SELECT COUNT(*) AS c FROM app_users").get()?.c || 0;
    if (userCount === 0) {
      const hash = hashPassword("admin123");
      db2.prepare(`
        INSERT INTO app_users (username, password_hash, full_name, role, permissions_json, avatar, is_active)
        VALUES ('admin', ?, 'مسؤول النظام', 'admin', ?, ?, 1)
      `).run(hash, JSON.stringify(ALL_PERMISSIONS), DEFAULT_ADMIN_AVATAR);
      logger.info("Default admin user created: username=admin, password=admin123");
    } else {
      try {
        db2.prepare(`
          UPDATE app_users 
          SET avatar = ? 
          WHERE role = 'admin' AND (avatar IS NULL OR avatar = '')
        `).run(DEFAULT_ADMIN_AVATAR);
      } catch {
      }
    }
  } catch (e) {
    logger.warn("Could not seed default admin user:", e.message);
  }
  let activeYear = db2.prepare("SELECT id FROM academic_years WHERE is_active = 1 LIMIT 1").get();
  if (!activeYear) {
    const hasYear = db2.prepare("SELECT id FROM academic_years LIMIT 1").get();
    if (!hasYear) {
      const yr = db2.prepare("INSERT INTO academic_years (label, is_active) VALUES (?, 1)").run(String((/* @__PURE__ */ new Date()).getFullYear()));
      activeYear = { id: yr.lastInsertRowid };
    } else {
      activeYear = hasYear;
    }
  }
  if (activeYear) {
    const periodCount = db2.prepare("SELECT COUNT(*) as c FROM evaluation_periods WHERE academic_year_id = ?").get(activeYear.id).c;
    if (periodCount === 0) {
      const insPeriod = db2.prepare("INSERT INTO evaluation_periods (academic_year_id, name, period_type, is_active) VALUES (?, ?, ?, 1)");
      insPeriod.run(activeYear.id, "التقييم النصف سنوي", "MIDYEAR");
      insPeriod.run(activeYear.id, "التقييم النهائي", "FINAL");
    }
    try {
      const defPeriod = db2.prepare(
        "SELECT id FROM evaluation_periods WHERE academic_year_id = ? ORDER BY CASE WHEN period_type = 'MIDYEAR' THEN 0 ELSE 1 END, id ASC LIMIT 1"
      ).get(activeYear.id);
      db2.prepare(`
        INSERT INTO app_settings (key, value, updated_at)
        VALUES ('active_year_id', ?, datetime('now', 'localtime'))
        ON CONFLICT(key) DO NOTHING
      `).run(String(activeYear.id));
      if (defPeriod) {
        db2.prepare(`
          INSERT INTO app_settings (key, value, updated_at)
          VALUES ('active_period_id', ?, datetime('now', 'localtime'))
          ON CONFLICT(key) DO NOTHING
        `).run(String(defPeriod.id));
      }
    } catch {
    }
  }
  let form = db2.prepare("SELECT id FROM evaluation_forms WHERE code = 'official'").get();
  if (!form) {
    const r = db2.prepare(
      "INSERT INTO evaluation_forms (code, name, description, is_official) VALUES (?, ?, ?, 1)"
    ).run(
      "official",
      "النموذج الرسمي لتقييم أداء مدير المدرسة",
      "نموذج تقييم الأداء الوظيفي الرسمي لمدراء المدارس — يتضمن 19 معيارًا تقييميًا معتمدًا بأوزان نسبية محددة"
    );
    form = { id: r.lastInsertRowid };
  }
  let version2 = db2.prepare("SELECT * FROM form_versions WHERE form_id = ? AND version_number = '1.0'").get(form.id);
  if (!version2) {
    const v = db2.prepare(
      "INSERT INTO form_versions (form_id, version_number, status, notes, source_reference) VALUES (?, ?, ?, ?, ?)"
    ).run(form.id, "1.0", "active", "النموذج الرسمي المعتمد لتقييم مدير المدرسة (19 عنصرًا تقييميًا)", "الدليل الإرشادي لتقييم أداء شاغلي الوظائف التعليمية");
    version2 = db2.prepare("SELECT * FROM form_versions WHERE id = ?").get(v.lastInsertRowid);
  }
  const levelCount = db2.prepare("SELECT COUNT(*) as c FROM performance_levels WHERE form_version_id = ?").get(version2.id).c;
  if (levelCount === 0) {
    const levels = [
      [5, "مثالي"],
      [4, "تخطى التوقعات"],
      [3, "وافق التوقعات"],
      [2, "بحاجة إلى تطوير"],
      [1, "غير مرضٍ"]
    ];
    const insLevel = db2.prepare(
      "INSERT INTO performance_levels (form_version_id, score_value, label) VALUES (?, ?, ?)"
    );
    for (const [s, l] of levels) insLevel.run(version2.id, s, l);
  }
  const elementsCount = db2.prepare("SELECT COUNT(*) as c FROM form_version_elements WHERE form_version_id = ?").get(version2.id).c;
  const evaluationsCount = db2.prepare("SELECT COUNT(*) as c FROM evaluations WHERE form_version_id = ?").get(version2.id).c;
  if (evaluationsCount === 0 && elementsCount !== 19) {
    db2.transaction(() => {
      db2.prepare("DELETE FROM form_version_elements WHERE form_version_id = ?").run(version2.id);
      const insEl = db2.prepare(`
        INSERT INTO form_version_elements (form_version_id, element_number, name, description, weight_bp, sort_order)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      for (const el of OFFICIAL_FORM_ELEMENTS) {
        insEl.run(version2.id, el.elementNumber, el.name, el.description, el.weightBp, el.elementNumber);
      }
      db2.prepare(`
        UPDATE form_versions SET status = 'active', activated_at = COALESCE(activated_at, datetime('now')) WHERE id = ?
      `).run(version2.id);
    })();
    logger.info("Official 19 evaluation elements populated and form version 1.0 activated.");
  }
  const defaultStages = [
    "ابتدائية",
    "متوسطة",
    "ثانوية",
    "ابتدائية ومتوسطة",
    "متوسطة وثانوية",
    "مجمع تعليمي",
    "ابتدائي",
    "متوسط",
    "ثانوي"
  ];
  try {
    const insStage = db2.prepare("INSERT INTO school_stages (name, sort_order) VALUES (?, ?) ON CONFLICT(name) DO NOTHING");
    defaultStages.forEach((st, idx) => {
      insStage.run(st, idx + 1);
    });
  } catch (e) {
    logger.warn("Could not seed default school stages:", e.message);
  }
  const defaultAdminName = "الإدارة العامة للتعليم بمنطقة جازان";
  try {
    db2.prepare("INSERT INTO education_administrations (name) VALUES (?) ON CONFLICT(name) DO NOTHING").run(defaultAdminName);
  } catch (e) {
    logger.warn("Could not seed default education administration:", e.message);
  }
}
function userError$a(message) {
  const e = new Error(message);
  e.userMessage = message;
  return e;
}
function ensureSchool(db2, { school_name, stage_name, administration_name }) {
  if (!school_name || !school_name.trim()) return null;
  let stage_id = null;
  if (stage_name && stage_name.trim()) {
    const s = db2.prepare("SELECT id FROM school_stages WHERE name = ?").get(stage_name.trim());
    stage_id = s ? s.id : db2.prepare("INSERT INTO school_stages (name) VALUES (?)").run(stage_name.trim()).lastInsertRowid;
  }
  let administration_id = null;
  if (administration_name && administration_name.trim()) {
    const a = db2.prepare("SELECT id FROM education_administrations WHERE name = ?").get(administration_name.trim());
    administration_id = a ? a.id : db2.prepare("INSERT INTO education_administrations (name) VALUES (?)").run(administration_name.trim()).lastInsertRowid;
  }
  const existing = db2.prepare(
    "SELECT id FROM schools WHERE name = ? AND (stage_id IS ?) AND (administration_id IS ?)"
  ).get(school_name.trim(), stage_id, administration_id);
  if (existing) return existing.id;
  return db2.prepare(
    "INSERT INTO schools (name, stage_id, administration_id) VALUES (?, ?, ?)"
  ).run(school_name.trim(), stage_id, administration_id).lastInsertRowid;
}
function rowToManager(row) {
  if (!row) return null;
  return {
    id: row.id,
    fullName: row.full_name,
    employeeNumber: row.employee_number || "",
    nationalId: row.national_id || "",
    notes: row.notes || "",
    status: row.status,
    isSample: !!row.is_sample,
    schoolId: row.school_id,
    schoolName: row.school_name || "",
    stageName: row.stage_name || "",
    administrationName: row.administration_name || "",
    hasMultipleSchools: !!row.has_multiple_schools,
    educationExperienceYears: Number(row.education_experience_years) || 0,
    administrationExperienceYears: Number(row.administration_experience_years) || 0,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
const SELECT_BASE$4 = `
  SELECT m.*, s.name AS school_name, st.name AS stage_name, ea.name AS administration_name
  FROM managers m
  LEFT JOIN schools s ON s.id = m.school_id
  LEFT JOIN school_stages st ON st.id = s.stage_id
  LEFT JOIN education_administrations ea ON ea.id = s.administration_id
`;
function listManagers(db2, { search = "", status = "active", schoolId = null, stageId = null, administrationId = null, page = 1, pageSize = 20 } = {}) {
  const where = [];
  const params = [];
  if (status === "active") {
    where.push("m.status = 'active'");
  } else if (status === "archived") {
    where.push("m.status = 'archived'");
  }
  if (search && search.trim()) {
    where.push("(m.full_name LIKE ? OR m.employee_number LIKE ?)");
    params.push(`%${search.trim()}%`, `%${search.trim()}%`);
  }
  if (schoolId) {
    where.push("m.school_id = ?");
    params.push(schoolId);
  }
  if (stageId) {
    where.push("s.stage_id = ?");
    params.push(stageId);
  }
  if (administrationId) {
    where.push("s.administration_id = ?");
    params.push(administrationId);
  }
  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const total = db2.prepare(`
    SELECT COUNT(*) AS c
    FROM managers m
    LEFT JOIN schools s ON s.id = m.school_id
    ${whereSql}
  `).get(...params).c;
  const safePage = Math.max(1, page | 0);
  const safeSize = Math.min(200, Math.max(1, pageSize | 0));
  const offset = (safePage - 1) * safeSize;
  const rows = db2.prepare(
    `${SELECT_BASE$4} ${whereSql} ORDER BY m.id DESC LIMIT ? OFFSET ?`
  ).all(...params, safeSize, offset);
  return { rows: rows.map(rowToManager), total, page: safePage, pageSize: safeSize };
}
function getManagerById(db2, id) {
  const row = db2.prepare(`${SELECT_BASE$4} WHERE m.id = ?`).get(id);
  return rowToManager(row);
}
function createManager(db2, input) {
  const fullName = (input.fullName || "").trim();
  if (!fullName) throw userError$a("اسم المدير مطلوب");
  const employeeNumber = (input.employeeNumber || "").trim() || null;
  if (employeeNumber) {
    const dup = db2.prepare("SELECT id FROM managers WHERE employee_number = ?").get(employeeNumber);
    if (dup) throw userError$a("الرقم الوظيفي مستخدم لمدير آخر");
  }
  const isSample = !!input.isSample;
  const tx = db2.transaction(() => {
    const school_id = ensureSchool(db2, {
      school_name: input.schoolName,
      stage_name: input.stageName,
      administration_name: input.administrationName
    });
    const r = db2.prepare(`
      INSERT INTO managers (
        full_name, school_id, employee_number, national_id, notes, is_sample,
        education_experience_years, administration_experience_years, has_multiple_schools
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      fullName,
      school_id,
      employeeNumber,
      (input.nationalId || "").trim() || null,
      (input.notes || "").trim() || null,
      isSample ? 1 : 0,
      Number(input.educationExperienceYears) || 0,
      Number(input.administrationExperienceYears) || 0,
      input.hasMultipleSchools ? 1 : 0
    );
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("manager.create", "manager", r.lastInsertRowid);
    return r.lastInsertRowid;
  });
  return getManagerById(db2, tx());
}
function updateManager(db2, id, input) {
  const current = db2.prepare("SELECT id FROM managers WHERE id = ?").get(id);
  if (!current) throw userError$a("المدير غير موجود");
  const fullName = (input.fullName || "").trim();
  if (!fullName) throw userError$a("اسم المدير مطلوب");
  const employeeNumber = (input.employeeNumber || "").trim() || null;
  if (employeeNumber) {
    const dup = db2.prepare("SELECT id FROM managers WHERE employee_number = ? AND id <> ?").get(employeeNumber, id);
    if (dup) throw userError$a("الرقم الوظيفي مستخدم لمدير آخر");
  }
  const tx = db2.transaction(() => {
    const school_id = ensureSchool(db2, {
      school_name: input.schoolName,
      stage_name: input.stageName,
      administration_name: input.administrationName
    });
    db2.prepare(`
      UPDATE managers
      SET full_name = ?, school_id = ?, employee_number = ?, national_id = ?, notes = ?,
          education_experience_years = ?, administration_experience_years = ?, has_multiple_schools = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).run(
      fullName,
      school_id,
      employeeNumber,
      (input.nationalId || "").trim() || null,
      (input.notes || "").trim() || null,
      Number(input.educationExperienceYears) || 0,
      Number(input.administrationExperienceYears) || 0,
      input.hasMultipleSchools ? 1 : 0,
      id
    );
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("manager.update", "manager", id);
  });
  tx();
  return getManagerById(db2, id);
}
function setManagerStatus(db2, id, status) {
  if (!["active", "archived"].includes(status)) throw userError$a("حالة غير صحيحة");
  const tx = db2.transaction(() => {
    db2.prepare("UPDATE managers SET status = ?, updated_at = datetime('now') WHERE id = ?").run(status, id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run(status === "archived" ? "manager.archive" : "manager.restore", "manager", id);
  });
  tx();
  return getManagerById(db2, id);
}
function deleteManager(db2, id) {
  const manager = db2.prepare("SELECT id, full_name FROM managers WHERE id = ?").get(id);
  if (!manager) throw userError$a("المدير غير موجود");
  const evalCount = db2.prepare("SELECT COUNT(*) AS c FROM evaluations WHERE manager_id = ?").get(id).c;
  if (evalCount > 0) {
    throw userError$a(`لا يمكن حذف المدير لوجود (${evalCount}) تقييم مرتبط به في السجل التاريخي. يمكنك أرشفة المدير لحفظ البيانات التاريخية.`);
  }
  const planCount = db2.prepare("SELECT COUNT(*) AS c FROM improvement_plans WHERE manager_id = ?").get(id).c;
  if (planCount > 0) {
    throw userError$a(`لا يمكن حذف المدير لوجود (${planCount}) خطة تحسين مرتبطة به. يرجى حذف الخطط أولًا أو أرشفة المدير.`);
  }
  const evidenceCount = db2.prepare("SELECT COUNT(*) AS c FROM evidences WHERE manager_id = ?").get(id).c;
  if (evidenceCount > 0) {
    throw userError$a(`لا يمكن حذف المدير لوجود (${evidenceCount}) شاهد/دليل مرتبط به. يرجى حذف الشواهد أولًا أو أرشفة المدير.`);
  }
  db2.transaction(() => {
    db2.prepare("DELETE FROM managers WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("manager.delete", "manager", id, JSON.stringify({ name: manager.full_name }));
  })();
  return true;
}
function deleteSampleManagers(db2) {
  const tx = db2.transaction(() => {
    db2.prepare("DELETE FROM managers WHERE is_sample = 1").run();
    db2.prepare("INSERT INTO audit_log (action, entity_type) VALUES (?, ?)").run("manager.deleteSamples", "manager");
  });
  tx();
}
function seedSampleManagers(db2) {
  const existing = db2.prepare("SELECT id FROM managers WHERE is_sample = 1 LIMIT 1").get();
  if (existing) throw userError$a("توجد بيانات تجريبية بالفعل");
  const samples = [
    { fullName: "[تجريبي] عبدالله المطيري", employeeNumber: "S-1001", schoolName: "مدرسة الأمل الابتدائية", stageName: "ابتدائي", administrationName: "إدارة تعليمية تجريبية" },
    { fullName: "[تجريبي] سارة القحطاني", employeeNumber: "S-1002", schoolName: "مدرسة النور المتوسطة", stageName: "متوسط", administrationName: "إدارة تعليمية تجريبية" },
    { fullName: "[تجريبي] محمد العنزي", employeeNumber: "S-1003", schoolName: "مدرسة الريادة الثانوية", stageName: "ثانوي", administrationName: "إدارة تعليمية تجريبية" }
  ];
  for (const s of samples) createManager(db2, { ...s, isSample: true });
}
function ensureTable(db2) {
  try {
    db2.exec(`
      CREATE TABLE IF NOT EXISTS app_notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'info',
        reference_id TEXT,
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
      );
    `);
  } catch (err) {
    console.error("ensureTable error:", err);
  }
}
let _backfillChecked = false;
function backfillIfEmpty(db2) {
  if (_backfillChecked) return;
  _backfillChecked = true;
  try {
    ensureTable(db2);
    try {
      const bfDone = db2.prepare("SELECT value FROM app_settings WHERE key = 'notifications_backfill_done'").get();
      if (bfDone) {
        return;
      }
    } catch {
    }
    const row = db2.prepare("SELECT COUNT(*) AS c FROM app_notifications").get();
    if (row && row.c === 0) {
      const portalEvidences = db2.prepare(`
        SELECT e.id, e.element_number, e.title, e.created_at, m.full_name, e.manager_id
        FROM evidences e
        JOIN managers m ON m.id = e.manager_id
        WHERE e.description LIKE '%البوابة%' OR e.file_name IN ('رابط خارجي', 'مستند إلكتروني')
        ORDER BY e.id DESC
        LIMIT 25
      `).all();
      for (const ev of portalEvidences) {
        db2.prepare(`
          INSERT INTO app_notifications (title, message, type, reference_id, manager_id, is_read, created_at)
          VALUES (?, ?, 'evidence', ?, ?, 0, COALESCE(?, datetime('now', 'localtime')))
        `).run(
          `شاهد وارد: ${ev.full_name || "مدير المدرسة"}`,
          `قام برفع شاهد في المعيار (${ev.element_number}): "${ev.title || "شاهد إلكتروني"}"`,
          String(ev.id),
          ev.manager_id,
          ev.created_at
        );
      }
      const portalPlans = db2.prepare(`
        SELECT p.id, p.manager_id, p.element_number, p.goal, p.created_at, m.full_name
        FROM improvement_plans p
        JOIN managers m ON m.id = p.manager_id
        WHERE p.notes LIKE '%البوابة%'
        ORDER BY p.id DESC
        LIMIT 25
      `).all();
      for (const pl of portalPlans) {
        const desc = pl.element_number ? `في المعيار (${pl.element_number})` : "خطة تطوير عامة";
        db2.prepare(`
          INSERT INTO app_notifications (title, message, type, reference_id, manager_id, is_read, created_at)
          VALUES (?, ?, 'plan', ?, ?, 0, COALESCE(?, datetime('now', 'localtime')))
        `).run(
          `خطة تحسين واردة: ${pl.full_name || "مدير المدرسة"}`,
          `قام بإضافة خطة تحسين ${desc}: "${pl.goal || "هدف جديد"}"`,
          String(pl.id),
          pl.manager_id,
          pl.created_at
        );
      }
    }
    _markBackfillDone(db2);
  } catch (err) {
    console.warn("backfillIfEmpty error:", err);
  }
}
function _markBackfillDone(db2) {
  try {
    db2.prepare("DELETE FROM app_settings WHERE key = 'notifications_backfill_done'").run();
    db2.prepare("INSERT INTO app_settings (key, value, updated_at) VALUES ('notifications_backfill_done', '1', datetime('now'))").run();
  } catch (e) {
    console.warn("_markBackfillDone error:", e);
  }
}
function listNotifications(db2, limit = 50) {
  try {
    ensureTable(db2);
    backfillIfEmpty(db2);
    return db2.prepare(`
      SELECT id, title, message, type, reference_id, manager_id, portal_id, is_read, created_at
      FROM app_notifications
      ORDER BY id DESC
      LIMIT ?
    `).all(limit);
  } catch (err) {
    console.error("listNotifications error:", err);
    return [];
  }
}
function countUnreadNotifications(db2) {
  try {
    ensureTable(db2);
    backfillIfEmpty(db2);
    const row = db2.prepare(`
      SELECT COUNT(*) AS count
      FROM app_notifications
      WHERE is_read = 0
    `).get();
    return row ? row.count : 0;
  } catch (err) {
    console.error("countUnreadNotifications error:", err);
    return 0;
  }
}
function markAllNotificationsRead(db2) {
  try {
    ensureTable(db2);
    db2.prepare(`UPDATE app_notifications SET is_read = 1 WHERE is_read = 0`).run();
    return true;
  } catch (err) {
    console.error("markAllNotificationsRead error:", err);
    return false;
  }
}
function markReadNotification(db2, id) {
  try {
    ensureTable(db2);
    db2.prepare(`UPDATE app_notifications SET is_read = 1 WHERE id = ?`).run(id);
    return true;
  } catch (err) {
    console.error("markReadNotification error:", err);
    return false;
  }
}
function deleteNotification(db2, id) {
  try {
    ensureTable(db2);
    db2.prepare(`DELETE FROM app_notifications WHERE id = ?`).run(id);
    return true;
  } catch (err) {
    console.error("deleteNotification error:", err);
    return false;
  }
}
function clearAllNotifications(db2) {
  try {
    ensureTable(db2);
    db2.prepare(`DELETE FROM app_notifications`).run();
    _backfillChecked = true;
    _markBackfillDone(db2);
    return true;
  } catch (err) {
    console.error("clearAllNotifications error:", err);
    return false;
  }
}
function addNotification(db2, { title, message, type = "info", reference_id = null }) {
  try {
    ensureTable(db2);
    const res = db2.prepare(`
      INSERT INTO app_notifications (title, message, type, reference_id, is_read, created_at)
      VALUES (?, ?, ?, ?, 0, datetime('now', 'localtime'))
    `).run(title, message, type, reference_id);
    return res.lastInsertRowid;
  } catch (err) {
    console.error("addNotification error:", err);
    return null;
  }
}
const ALLOWED_EXTS = [".pdf", ".jpg", ".jpeg", ".png", ".webp", ".doc", ".docx", ".xls", ".xlsx"];
const MIME_BY_EXT = {
  ".pdf": "application/pdf",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".doc": "application/msword",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".xls": "application/vnd.ms-excel",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
};
const DEFAULT_MAX_BYTES = 20 * 1024 * 1024;
function evidenceRoot$1() {
  return node_path.join(electron.app.getPath("userData"), "evidences");
}
function stagingRoot() {
  return node_path.join(evidenceRoot$1(), "_staging");
}
function finalRoot() {
  return node_path.join(evidenceRoot$1(), "files");
}
async function ensureDirs$1() {
  await node_fs.promises.mkdir(stagingRoot(), { recursive: true });
  await node_fs.promises.mkdir(finalRoot(), { recursive: true });
}
async function cleanStaging() {
  try {
    await node_fs.promises.rm(stagingRoot(), { recursive: true, force: true });
    await node_fs.promises.mkdir(stagingRoot(), { recursive: true });
  } catch {
  }
}
async function pickAndStageFile(parentWindow, opts = {}) {
  await ensureDirs$1();
  const maxBytes = Number(opts.maxSizeBytes) > 0 ? Number(opts.maxSizeBytes) : DEFAULT_MAX_BYTES;
  const result2 = await electron.dialog.showOpenDialog(parentWindow, {
    title: "اختر ملف الشاهد",
    properties: ["openFile"],
    filters: [
      { name: "المستندات والصور", extensions: ["pdf", "jpg", "jpeg", "png", "docx", "xlsx"] }
    ]
  });
  if (result2.canceled || !result2.filePaths.length) return { cancelled: true };
  const source = result2.filePaths[0];
  const ext = node_path.extname(source).toLowerCase();
  if (!ALLOWED_EXTS.includes(ext)) {
    throw Object.assign(new Error("bad ext"), {
      userMessage: "نوع الملف غير مسموح. المسموح: PDF, JPG, PNG, DOCX, XLSX"
    });
  }
  const stat = await node_fs.promises.stat(source);
  if (stat.size === 0) {
    throw Object.assign(new Error("empty"), { userMessage: "الملف فارغ" });
  }
  if (stat.size > maxBytes) {
    throw Object.assign(new Error("too big"), {
      userMessage: `حجم الملف يتجاوز الحد (${(maxBytes / 1024 / 1024).toFixed(0)} ميجابايت)`
    });
  }
  const stagingId = node_crypto.randomUUID();
  const targetPath = node_path.join(stagingRoot(), stagingId + ext);
  await node_fs.promises.copyFile(source, targetPath);
  const buffer = await node_fs.promises.readFile(targetPath);
  const sha256 = node_crypto.createHash("sha256").update(buffer).digest("hex");
  return {
    cancelled: false,
    stagingId,
    ext,
    fileName: node_path.basename(source),
    size: stat.size,
    mimeType: MIME_BY_EXT[ext] || "application/octet-stream",
    sha256
  };
}
async function pickAndStageFiles(parentWindow, opts = {}) {
  await ensureDirs$1();
  const maxBytes = Number(opts.maxSizeBytes) > 0 ? Number(opts.maxSizeBytes) : DEFAULT_MAX_BYTES;
  const result2 = await electron.dialog.showOpenDialog(parentWindow, {
    title: opts.title || "اختر الملفات المرفقة",
    properties: ["openFile", "multiSelections"],
    filters: [
      { name: "المستندات والصور", extensions: ["pdf", "jpg", "jpeg", "png", "webp", "doc", "docx", "xls", "xlsx"] }
    ]
  });
  if (result2.canceled || !result2.filePaths.length) return { cancelled: true, files: [] };
  const stagedFiles = [];
  for (const source of result2.filePaths) {
    const ext = node_path.extname(source).toLowerCase();
    if (!ALLOWED_EXTS.includes(ext)) {
      throw Object.assign(new Error("bad ext"), {
        userMessage: `نوع الملف (${node_path.basename(source)}) غير مسموح. المسموح: PDF, JPG, PNG, DOC, DOCX, XLS, XLSX`
      });
    }
    const stat = await node_fs.promises.stat(source);
    if (stat.size === 0) {
      throw Object.assign(new Error("empty"), { userMessage: `الملف (${node_path.basename(source)}) فارغ` });
    }
    if (stat.size > maxBytes) {
      throw Object.assign(new Error("too big"), {
        userMessage: `حجم الملف (${node_path.basename(source)}) يتجاوز الحد (${(maxBytes / 1024 / 1024).toFixed(0)} ميجابايت)`
      });
    }
    const stagingId = node_crypto.randomUUID();
    const targetPath = node_path.join(stagingRoot(), stagingId + ext);
    await node_fs.promises.copyFile(source, targetPath);
    const buffer = await node_fs.promises.readFile(targetPath);
    const sha256 = node_crypto.createHash("sha256").update(buffer).digest("hex");
    stagedFiles.push({
      stagingId,
      ext,
      fileName: node_path.basename(source),
      size: stat.size,
      mimeType: MIME_BY_EXT[ext] || "application/octet-stream",
      sha256
    });
  }
  return {
    cancelled: false,
    files: stagedFiles
  };
}
async function moveStagedToFinal(stagingId, ext) {
  await ensureDirs$1();
  const staged = node_path.join(stagingRoot(), stagingId + ext);
  await node_fs.promises.access(staged);
  const finalPath = node_path.join(finalRoot(), node_crypto.randomUUID() + ext);
  await node_fs.promises.rename(staged, finalPath);
  return finalPath;
}
async function discardStaged(stagingId, ext) {
  if (!stagingId || !ext) return;
  try {
    await node_fs.promises.unlink(node_path.join(stagingRoot(), stagingId + ext));
  } catch {
  }
}
function isInsideEvidenceRoot(p) {
  const root = node_path.resolve(evidenceRoot$1());
  const target = node_path.resolve(p);
  return target === root || target.startsWith(root + node_path.sep);
}
async function openEvidenceFile(p) {
  if (!p || !isInsideEvidenceRoot(p)) {
    throw Object.assign(new Error("invalid path"), { userMessage: "مسار الملف غير صالح" });
  }
  try {
    await node_fs.promises.access(p);
  } catch {
    throw Object.assign(new Error("missing"), { userMessage: "الملف غير موجود على القرص" });
  }
  const err = await electron.shell.openPath(p);
  if (err) throw Object.assign(new Error(err), { userMessage: "تعذر فتح الملف" });
  return true;
}
async function deleteFileIfExists(p) {
  if (!p || !isInsideEvidenceRoot(p)) return;
  try {
    await node_fs.promises.unlink(p);
  } catch {
  }
}
async function saveBufferOrDataUrl(dataUrlOrBase64, suggestedName = "evidence.pdf") {
  await ensureDirs$1();
  let buffer;
  const cleanSuggested = (suggestedName || "").trim();
  let ext = node_path.extname(cleanSuggested).toLowerCase();
  if (typeof dataUrlOrBase64 === "string" && dataUrlOrBase64.startsWith("data:")) {
    const match = dataUrlOrBase64.match(/^data:([^;]+);base64,([\s\S]*)$/);
    if (match) {
      const mime = match[1].toLowerCase();
      const base64Data = match[2];
      buffer = Buffer.from(base64Data, "base64");
      if (!ext) {
        if (mime === "application/pdf") ext = ".pdf";
        else if (mime === "image/jpeg" || mime === "image/jpg") ext = ".jpg";
        else if (mime === "image/png") ext = ".png";
        else if (mime === "image/webp") ext = ".webp";
        else if (mime.includes("openxmlformats") && mime.includes("word")) ext = ".docx";
        else if (mime.includes("msword")) ext = ".doc";
        else if (mime.includes("openxmlformats") && mime.includes("sheet")) ext = ".xlsx";
        else if (mime.includes("excel")) ext = ".xls";
      }
    } else {
      buffer = Buffer.from(dataUrlOrBase64, "utf-8");
    }
  } else if (typeof dataUrlOrBase64 === "string") {
    buffer = Buffer.from(dataUrlOrBase64, "base64");
  } else {
    buffer = Buffer.from(dataUrlOrBase64);
  }
  if (!ext) ext = ".pdf";
  const finalPath = node_path.join(finalRoot(), node_crypto.randomUUID() + ext);
  await node_fs.promises.writeFile(finalPath, buffer);
  let displayFileName = cleanSuggested || "مستند_" + node_path.basename(finalPath);
  if (!node_path.extname(displayFileName)) {
    displayFileName += ext;
  }
  return {
    filePath: finalPath,
    fileName: displayFileName,
    fileSize: buffer.length,
    mimeType: MIME_BY_EXT[ext] || "application/octet-stream"
  };
}
function userError$9(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function upsertSetting(db2, key, value) {
  db2.prepare(`
    INSERT INTO app_settings (key, value, updated_at)
    VALUES (?, ?, datetime('now', 'localtime'))
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
  `).run(key, String(value ?? ""));
}
function getActiveContext(db2) {
  const savedYearId = Number(
    db2.prepare("SELECT value FROM app_settings WHERE key = 'active_year_id'").get()?.value || 0
  );
  const savedPeriodId = Number(
    db2.prepare("SELECT value FROM app_settings WHERE key = 'active_period_id'").get()?.value || 0
  );
  let yearRow = null;
  if (savedYearId) {
    yearRow = db2.prepare("SELECT * FROM academic_years WHERE id = ? AND is_archived = 0").get(savedYearId);
  }
  if (!yearRow) {
    yearRow = db2.prepare("SELECT * FROM academic_years WHERE is_active = 1 AND is_archived = 0 ORDER BY id DESC LIMIT 1").get();
  }
  if (!yearRow) {
    yearRow = db2.prepare("SELECT * FROM academic_years WHERE is_archived = 0 ORDER BY label DESC, id DESC LIMIT 1").get();
  }
  if (!yearRow) {
    yearRow = db2.prepare("SELECT * FROM academic_years ORDER BY id DESC LIMIT 1").get();
  }
  if (!yearRow) {
    return {
      yearId: null,
      yearLabel: "",
      periodId: null,
      periodName: "",
      periodType: "MIDYEAR"
    };
  }
  let periodRow = null;
  if (savedPeriodId) {
    periodRow = db2.prepare(
      "SELECT * FROM evaluation_periods WHERE id = ? AND academic_year_id = ?"
    ).get(savedPeriodId, yearRow.id);
  }
  if (!periodRow) {
    periodRow = db2.prepare(`
      SELECT * FROM evaluation_periods
      WHERE academic_year_id = ? AND is_active = 1
      ORDER BY CASE WHEN period_type = 'MIDYEAR' THEN 0 WHEN period_type = 'FINAL' THEN 1 ELSE 2 END, id ASC
      LIMIT 1
    `).get(yearRow.id);
  }
  if (!periodRow) {
    periodRow = db2.prepare(
      "SELECT * FROM evaluation_periods WHERE academic_year_id = ? ORDER BY id ASC LIMIT 1"
    ).get(yearRow.id);
  }
  if (savedYearId !== yearRow.id) {
    upsertSetting(db2, "active_year_id", yearRow.id);
  }
  if (periodRow && savedPeriodId !== periodRow.id) {
    upsertSetting(db2, "active_period_id", periodRow.id);
  }
  const inferredType = periodRow ? periodRow.period_type === "FINAL" || String(periodRow.name || "").includes("نهائي") ? "FINAL" : "MIDYEAR" : "MIDYEAR";
  return {
    yearId: yearRow.id,
    yearLabel: yearRow.label,
    periodId: periodRow ? periodRow.id : null,
    periodName: periodRow ? periodRow.name : "",
    periodType: inferredType
  };
}
function setActiveContext(db2, { yearId, periodId } = {}) {
  const current = getActiveContext(db2);
  const targetYearId = yearId ? Number(yearId) : current.yearId;
  if (!targetYearId) throw userError$9("يرجى اختيار العام الدراسي");
  const yearRow = db2.prepare("SELECT * FROM academic_years WHERE id = ?").get(targetYearId);
  if (!yearRow) throw userError$9("العام الدراسي المحدد غير موجود");
  let periodRow = null;
  if (periodId) {
    periodRow = db2.prepare(
      "SELECT * FROM evaluation_periods WHERE id = ? AND academic_year_id = ?"
    ).get(Number(periodId), yearRow.id);
  }
  if (!periodRow) {
    periodRow = db2.prepare(`
      SELECT * FROM evaluation_periods
      WHERE academic_year_id = ? AND is_active = 1
      ORDER BY CASE WHEN period_type = 'MIDYEAR' THEN 0 WHEN period_type = 'FINAL' THEN 1 ELSE 2 END, id ASC
      LIMIT 1
    `).get(yearRow.id) || db2.prepare(
      "SELECT * FROM evaluation_periods WHERE academic_year_id = ? ORDER BY id ASC LIMIT 1"
    ).get(yearRow.id);
  }
  db2.transaction(() => {
    db2.prepare("UPDATE academic_years SET is_active = 0").run();
    db2.prepare("UPDATE academic_years SET is_active = 1, is_archived = 0 WHERE id = ?").run(yearRow.id);
    upsertSetting(db2, "active_year_id", yearRow.id);
    if (periodRow) {
      db2.prepare("UPDATE evaluation_periods SET is_active = 1 WHERE id = ?").run(periodRow.id);
      upsertSetting(db2, "active_period_id", periodRow.id);
    }
  })();
  return getActiveContext(db2);
}
function userError$8(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function ensureEvidenceColumns(db2) {
  try {
    db2.exec("ALTER TABLE evidences ADD COLUMN attachments_json TEXT;");
  } catch {
  }
  try {
    db2.exec("ALTER TABLE evidences ADD COLUMN academic_year_id INTEGER REFERENCES academic_years(id);");
  } catch {
  }
  try {
    db2.exec("ALTER TABLE evidences ADD COLUMN period_id INTEGER REFERENCES evaluation_periods(id);");
  } catch {
  }
  try {
    db2.exec("ALTER TABLE evidences ADD COLUMN portal_id INTEGER;");
  } catch {
  }
  try {
    db2.exec(`
      CREATE TABLE IF NOT EXISTS evidence_comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        evidence_id INTEGER NOT NULL REFERENCES evidences(id) ON DELETE CASCADE,
        comment TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
      );
    `);
  } catch {
  }
}
function extractRawEvidenceAttachments(r) {
  if (!r) return [];
  if (r.attachments_json) {
    try {
      const parsed = JSON.parse(r.attachments_json);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.filter((x) => x && x.filePath);
      }
    } catch {
    }
  }
  if (r.file_path) {
    return [{
      filePath: r.file_path,
      fileName: r.file_name || "ملف مرفق",
      fileSize: r.file_size || 0,
      mimeType: r.mime_type || "",
      sha256: r.sha256 || null
    }];
  }
  return [];
}
function rowToEvidence(r, comments = []) {
  if (!r) return null;
  const rawAtts = extractRawEvidenceAttachments(r);
  const attachments = rawAtts.map((a, index) => ({
    index,
    fileName: a.fileName || `ملف مرفق ${index + 1}`,
    fileSize: a.fileSize || 0,
    mimeType: a.mimeType || "",
    isLink: /^https?:\/\//i.test(a.filePath || "")
  }));
  const first = attachments[0] || null;
  return {
    id: r.id,
    managerId: r.manager_id,
    managerName: r.manager_name || "",
    evaluationId: r.evaluation_id,
    yearId: r.academic_year_id || r.eval_year_id || null,
    yearLabel: r.year_label || "",
    periodId: r.period_id || r.eval_period_id || null,
    periodName: r.period_name || "",
    periodType: r.period_type || "",
    portalId: r.portal_id || null,
    elementNumber: r.element_number,
    title: r.title,
    description: r.description || "",
    fileName: first ? first.fileName : r.file_name || "",
    fileSize: first ? first.fileSize : r.file_size || 0,
    mimeType: first ? first.mimeType : r.mime_type || "",
    hasFile: attachments.length > 0,
    attachmentCount: attachments.length,
    attachments,
    comments,
    commentCount: comments.length,
    isArchived: !!r.is_archived,
    createdAt: r.created_at,
    updatedAt: r.updated_at || r.created_at
  };
}
const SELECT_BASE$3 = `
  SELECT e.*,
         m.full_name AS manager_name,
         ev.academic_year_id AS eval_year_id,
         ev.period_id AS eval_period_id,
         ay.label AS year_label,
         ep.name AS period_name,
         ep.period_type AS period_type
  FROM evidences e
  JOIN managers m ON m.id = e.manager_id
  LEFT JOIN evaluations ev ON ev.id = e.evaluation_id
  LEFT JOIN academic_years ay ON ay.id = COALESCE(e.academic_year_id, ev.academic_year_id)
  LEFT JOIN evaluation_periods ep ON ep.id = COALESCE(e.period_id, ev.period_id)
`;
function listEvidences(db2, filters = {}) {
  ensureEvidenceColumns(db2);
  const where = [];
  const params = [];
  if (filters.includeArchived !== true) where.push("e.is_archived = 0");
  else if (filters.onlyArchived === true) where.push("e.is_archived = 1");
  if (filters.managerId) {
    where.push("e.manager_id = ?");
    params.push(Number(filters.managerId));
  }
  if (filters.evaluationId) {
    const evRow = db2.prepare("SELECT id, academic_year_id, period_id FROM evaluations WHERE id = ?").get(Number(filters.evaluationId));
    if (evRow) {
      where.push(`(
        e.evaluation_id = ?
        OR (COALESCE(e.academic_year_id, ev.academic_year_id) = ? AND COALESCE(e.period_id, ev.period_id) = ?)
      )`);
      params.push(evRow.id, evRow.academic_year_id, evRow.period_id);
    } else {
      where.push("e.evaluation_id = ?");
      params.push(Number(filters.evaluationId));
    }
  } else if (filters.allStages !== true) {
    const activeCtx = !filters.yearId || !filters.periodId ? getActiveContext(db2) : null;
    const effYearId = filters.yearId || activeCtx?.yearId;
    const effPeriodId = filters.periodId || activeCtx?.periodId;
    if (effYearId) {
      where.push("COALESCE(e.academic_year_id, ev.academic_year_id) = ?");
      params.push(Number(effYearId));
    }
    if (effPeriodId) {
      where.push("COALESCE(e.period_id, ev.period_id) = ?");
      params.push(Number(effPeriodId));
    }
  }
  if (filters.elementNumber) {
    where.push("e.element_number = ?");
    params.push(Number(filters.elementNumber));
  }
  if (filters.search && filters.search.trim()) {
    where.push("(e.title LIKE ? OR e.description LIKE ?)");
    params.push(`%${filters.search.trim()}%`, `%${filters.search.trim()}%`);
  }
  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const rows = db2.prepare(`${SELECT_BASE$3} ${whereSql} ORDER BY e.created_at DESC`).all(...params);
  const commentsByEv = {};
  if (rows.length > 0) {
    const ids = rows.map((r) => r.id);
    const placeholders = ids.map(() => "?").join(",");
    const cRows = db2.prepare(
      `SELECT id, evidence_id, comment, created_at FROM evidence_comments WHERE evidence_id IN (${placeholders}) ORDER BY id DESC`
    ).all(...ids);
    for (const c of cRows) {
      if (!commentsByEv[c.evidence_id]) commentsByEv[c.evidence_id] = [];
      commentsByEv[c.evidence_id].push({ id: c.id, comment: c.comment, createdAt: c.created_at });
    }
  }
  return rows.map((r) => rowToEvidence(r, commentsByEv[r.id] || []));
}
function getEvidence(db2, id) {
  ensureEvidenceColumns(db2);
  const r = db2.prepare(`${SELECT_BASE$3} WHERE e.id = ?`).get(id);
  if (!r) return null;
  const comments = db2.prepare(
    "SELECT id, comment, created_at FROM evidence_comments WHERE evidence_id = ? ORDER BY id DESC"
  ).all(id).map((c) => ({ id: c.id, comment: c.comment, createdAt: c.created_at }));
  return rowToEvidence(r, comments);
}
function getRaw(db2, id) {
  ensureEvidenceColumns(db2);
  return db2.prepare("SELECT * FROM evidences WHERE id = ?").get(id);
}
function normalizeStagedInput$1(staged) {
  if (!staged) return [];
  if (Array.isArray(staged)) return staged.filter((s) => s && s.stagingId);
  if (staged.stagingId) return [staged];
  return [];
}
async function createEvidence(db2, input, staged) {
  ensureEvidenceColumns(db2);
  const title = (input.title || "").trim();
  if (!title) throw userError$8("عنوان الشاهد مطلوب");
  const managerId = Number(input.managerId);
  if (!managerId) throw userError$8("المدير مطلوب");
  const manager = db2.prepare("SELECT id, status FROM managers WHERE id = ?").get(managerId);
  if (!manager) throw userError$8("المدير غير موجود");
  if (manager.status === "archived") throw userError$8("لا يمكن إضافة شاهد لمدير مؤرشف");
  const activeCtx = getActiveContext(db2);
  let yearId = input.yearId ? Number(input.yearId) : activeCtx.yearId;
  let periodId = input.periodId ? Number(input.periodId) : activeCtx.periodId;
  let evaluationId = input.evaluationId ? Number(input.evaluationId) : null;
  if (evaluationId) {
    const ev = db2.prepare("SELECT id, manager_id, academic_year_id, period_id FROM evaluations WHERE id = ?").get(evaluationId);
    if (!ev) throw userError$8("التقييم غير موجود");
    if (ev.manager_id !== managerId) throw userError$8("التقييم لا ينتمي للمدير المحدد");
    yearId = ev.academic_year_id;
    periodId = ev.period_id;
  }
  let elementNumber = null;
  if (input.elementNumber) {
    elementNumber = Number(input.elementNumber);
    if (evaluationId) {
      const elExists = db2.prepare(`
        SELECT 1 FROM evaluation_item_snapshots
        WHERE evaluation_id = ? AND element_number = ?
      `).get(evaluationId, elementNumber);
      if (!elExists) throw userError$8("العنصر غير موجود في التقييم المحدد");
    }
  }
  const stagedList = normalizeStagedInput$1(staged);
  const savedAttachments = [];
  try {
    for (const st of stagedList) {
      const finalPath = await moveStagedToFinal(st.stagingId, st.ext);
      savedAttachments.push({
        filePath: finalPath,
        fileName: st.fileName,
        fileSize: st.size,
        mimeType: st.mimeType,
        sha256: st.sha256 || null
      });
    }
  } catch {
    for (const st of stagedList) {
      await discardStaged(st.stagingId, st.ext).catch(() => {
      });
    }
    for (const sv of savedAttachments) {
      await deleteFileIfExists(sv.filePath);
    }
    throw userError$8("تعذر حفظ الملفات المرفقة على القرص");
  }
  const first = savedAttachments[0] || null;
  const attachmentsJson = savedAttachments.length > 0 ? JSON.stringify(savedAttachments) : null;
  try {
    const r = db2.prepare(`
      INSERT INTO evidences
        (manager_id, evaluation_id, academic_year_id, period_id, element_number, title, description,
         file_path, file_name, file_size, mime_type, sha256, attachments_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))
    `).run(
      managerId,
      evaluationId,
      yearId || null,
      periodId || null,
      elementNumber,
      title,
      (input.description || "").trim() || null,
      first ? first.filePath : null,
      first ? first.fileName : null,
      first ? first.fileSize : null,
      first ? first.mimeType : null,
      first ? first.sha256 : null,
      attachmentsJson
    );
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("evidence.create", "evidence", r.lastInsertRowid);
    return getEvidence(db2, r.lastInsertRowid);
  } catch (e) {
    for (const sv of savedAttachments) {
      await deleteFileIfExists(sv.filePath);
    }
    throw e;
  }
}
async function updateEvidence(db2, id, input, staged) {
  ensureEvidenceColumns(db2);
  const existing = getRaw(db2, id);
  if (!existing) throw userError$8("الشاهد غير موجود");
  if (existing.is_archived) throw userError$8("لا يمكن تعديل شاهد مؤرشف");
  const title = (input.title || "").trim();
  if (!title) throw userError$8("عنوان الشاهد مطلوب");
  const oldAttachments = extractRawEvidenceAttachments(existing);
  const stagedList = normalizeStagedInput$1(staged);
  const newlySaved = [];
  try {
    for (const st of stagedList) {
      const finalPath = await moveStagedToFinal(st.stagingId, st.ext);
      newlySaved.push({
        filePath: finalPath,
        fileName: st.fileName,
        fileSize: st.size,
        mimeType: st.mimeType,
        sha256: st.sha256 || null
      });
    }
  } catch {
    for (const st of stagedList) {
      await discardStaged(st.stagingId, st.ext).catch(() => {
      });
    }
    for (const sv of newlySaved) {
      await deleteFileIfExists(sv.filePath);
    }
    throw userError$8("تعذر حفظ الملفات المرفقة على القرص");
  }
  let keptOld = oldAttachments;
  let removedOld = [];
  if (Array.isArray(input.keepAttachmentIndexes)) {
    const keepSet = new Set(input.keepAttachmentIndexes.map(Number));
    keptOld = oldAttachments.filter((_, idx) => keepSet.has(idx));
    removedOld = oldAttachments.filter((_, idx) => !keepSet.has(idx));
  } else if (input.removeFile === true) {
    keptOld = [];
    removedOld = oldAttachments;
  } else if (newlySaved.length > 0 && !input.appendFiles) {
    keptOld = [];
    removedOld = oldAttachments;
  }
  const finalAttachments = [...keptOld, ...newlySaved];
  const first = finalAttachments[0] || null;
  const attachmentsJson = finalAttachments.length > 0 ? JSON.stringify(finalAttachments) : null;
  try {
    db2.prepare(`
      UPDATE evidences SET title = ?, description = ?,
        file_path = ?, file_name = ?, file_size = ?, mime_type = ?, sha256 = ?,
        attachments_json = ?,
        updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(
      title,
      (input.description || "").trim() || null,
      first ? first.filePath : null,
      first ? first.fileName : null,
      first ? first.fileSize : null,
      first ? first.mimeType : null,
      first ? first.sha256 : null,
      attachmentsJson,
      id
    );
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("evidence.update", "evidence", id);
  } catch (e) {
    for (const sv of newlySaved) {
      await deleteFileIfExists(sv.filePath);
    }
    throw e;
  }
  for (const rm of removedOld) {
    if (rm.filePath) await deleteFileIfExists(rm.filePath);
  }
  return getEvidence(db2, id);
}
async function archiveEvidence(db2, id, archived = true) {
  const existing = getRaw(db2, id);
  if (!existing) throw userError$8("الشاهد غير موجود");
  db2.prepare("UPDATE evidences SET is_archived = ?, updated_at = datetime('now', 'localtime') WHERE id = ?").run(archived ? 1 : 0, id);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run(archived ? "evidence.archive" : "evidence.restore", "evidence", id);
  return getEvidence(db2, id);
}
async function deleteEvidence(db2, id) {
  const existing = getRaw(db2, id);
  if (!existing) throw userError$8("الشاهد غير موجود");
  if (!existing.is_archived) throw userError$8("يجب أرشفة الشاهد أولًا قبل الحذف النهائي");
  const allAtts = extractRawEvidenceAttachments(existing);
  db2.transaction(() => {
    db2.prepare("DELETE FROM evidence_comments WHERE evidence_id = ?").run(id);
    db2.prepare("DELETE FROM evidences WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("evidence.delete", "evidence", id);
  })();
  for (const att of allAtts) {
    if (att.filePath) await deleteFileIfExists(att.filePath);
  }
  return { deleted: true, portalId: existing.portal_id || null };
}
async function openEvidence(db2, id, fileIndex = 0) {
  const existing = getRaw(db2, id);
  if (!existing) throw userError$8("الشاهد غير موجود");
  const allAtts = extractRawEvidenceAttachments(existing);
  if (!allAtts.length) throw userError$8("لا يوجد ملف مرتبط بهذا الشاهد");
  const idx = Number.isInteger(Number(fileIndex)) && Number(fileIndex) >= 0 ? Number(fileIndex) : 0;
  const target = allAtts[idx] || allAtts[0];
  if (!target || !target.filePath) throw userError$8("لا يوجد ملف مرتبط بهذا الشاهد");
  if (/^https?:\/\//i.test(target.filePath)) {
    const { shell } = await import("electron");
    await shell.openExternal(target.filePath);
    return true;
  }
  await openEvidenceFile(target.filePath);
  return true;
}
function addEvidenceComment(db2, evidenceId, comment) {
  ensureEvidenceColumns(db2);
  const text = String(comment || "").trim();
  if (!text) throw userError$8("يرجى كتابة نص التعليق");
  const ev = db2.prepare("SELECT id, is_archived FROM evidences WHERE id = ?").get(Number(evidenceId));
  if (!ev) throw userError$8("الشاهد غير موجود");
  if (ev.is_archived) throw userError$8("لا يمكن إضافة تعليق على شاهد مؤرشف");
  const r = db2.prepare(
    "INSERT INTO evidence_comments (evidence_id, comment, created_at) VALUES (?, ?, datetime('now', 'localtime'))"
  ).run(Number(evidenceId), text);
  db2.prepare("UPDATE evidences SET updated_at = datetime('now', 'localtime') WHERE id = ?").run(Number(evidenceId));
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("evidence.addComment", "evidence", Number(evidenceId));
  const created = db2.prepare("SELECT id, comment, created_at FROM evidence_comments WHERE id = ?").get(r.lastInsertRowid);
  return { id: created.id, comment: created.comment, createdAt: created.created_at };
}
function deleteEvidenceComment(db2, commentId) {
  ensureEvidenceColumns(db2);
  const row = db2.prepare("SELECT id, evidence_id FROM evidence_comments WHERE id = ?").get(Number(commentId));
  if (!row) throw userError$8("التعليق غير موجود");
  db2.prepare("DELETE FROM evidence_comments WHERE id = ?").run(Number(commentId));
  db2.prepare("UPDATE evidences SET updated_at = datetime('now', 'localtime') WHERE id = ?").run(row.evidence_id);
  return { deleted: true, evidenceId: row.evidence_id };
}
function countsByElement(db2, { managerId, evaluationId, yearId, periodId } = {}) {
  ensureEvidenceColumns(db2);
  if (!managerId) return {};
  const where = ["e.is_archived = 0", "e.element_number IS NOT NULL", "e.manager_id = ?"];
  const params = [Number(managerId)];
  if (evaluationId) {
    const evRow = db2.prepare("SELECT id, academic_year_id, period_id FROM evaluations WHERE id = ?").get(Number(evaluationId));
    if (evRow) {
      where.push(`(
        e.evaluation_id = ?
        OR (COALESCE(e.academic_year_id, ev.academic_year_id) = ? AND COALESCE(e.period_id, ev.period_id) = ?)
      )`);
      params.push(evRow.id, evRow.academic_year_id, evRow.period_id);
    } else {
      where.push("e.evaluation_id = ?");
      params.push(Number(evaluationId));
    }
  } else {
    if (yearId) {
      where.push("COALESCE(e.academic_year_id, ev.academic_year_id) = ?");
      params.push(Number(yearId));
    }
    if (periodId) {
      where.push("COALESCE(e.period_id, ev.period_id) = ?");
      params.push(Number(periodId));
    }
  }
  const rows = db2.prepare(`
    SELECT e.element_number, COUNT(*) AS c
    FROM evidences e
    LEFT JOIN evaluations ev ON ev.id = e.evaluation_id
    WHERE ${where.join(" AND ")}
    GROUP BY e.element_number
  `).all(...params);
  const out = {};
  for (const r of rows) out[r.element_number] = r.c;
  return out;
}
function userError$7(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
const VALID_STATUSES = ["not_started", "in_progress", "completed", "overdue"];
const STATUS_LABEL$1 = {
  not_started: "لم تبدأ",
  in_progress: "قيد التنفيذ",
  completed: "مكتملة",
  overdue: "متأخرة"
};
const SYSTEM_IMPORT_NOTES = /* @__PURE__ */ new Set([
  "هدف مسجل إلكترونياً من مدير المدرسة عبر البوابة",
  "خطة تطوير عامة للمدرسة مسجلة إلكترونياً عبر البوابة"
]);
function ensurePlanColumns(db2) {
  try {
    db2.exec("ALTER TABLE improvement_plans ADD COLUMN attachments_json TEXT;");
  } catch {
  }
  try {
    db2.exec("ALTER TABLE improvement_plans ADD COLUMN academic_year_id INTEGER REFERENCES academic_years(id);");
  } catch {
  }
  try {
    db2.exec("ALTER TABLE improvement_plans ADD COLUMN period_id INTEGER REFERENCES evaluation_periods(id);");
  } catch {
  }
  try {
    db2.exec("ALTER TABLE improvement_plans ADD COLUMN portal_id INTEGER;");
  } catch {
  }
}
function cleanPlanActionsText(raw) {
  if (!raw) return "";
  let text = String(raw);
  if (text.includes("<!--SUPERVISOR_NOTES-->")) {
    text = text.split("<!--SUPERVISOR_NOTES-->")[0];
  }
  text = text.replace(/<!--CTX_YEAR:[\s\S]*?-->/g, "").replace(/<!--CTX:[\s\S]*?-->/g, "").replace(/<!--PLAN_FILES_JSON:[\s\S]*?-->/g, "").replace(/<!--PLAN_FILES_META:[\s\S]*?-->/g, "").replace(/<!--PLAN_FILE:[\s\S]*?-->/g, "");
  return text.trim();
}
function cleanPlanNotesText(raw) {
  if (!raw) return "";
  const t = String(raw).trim();
  if (SYSTEM_IMPORT_NOTES.has(t)) return "";
  return t;
}
function extractRawPlanAttachments(r) {
  if (!r || !r.attachments_json) return [];
  try {
    const parsed = JSON.parse(r.attachments_json);
    if (Array.isArray(parsed)) {
      return parsed.filter((x) => x && x.filePath);
    }
  } catch {
  }
  return [];
}
function todayIso() {
  const d = /* @__PURE__ */ new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function normalizeDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  if (!s) return null;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) throw userError$7("صيغة التاريخ يجب أن تكون YYYY-MM-DD");
  return s;
}
function normalizeStatus(v) {
  if (!v) return "not_started";
  if (!VALID_STATUSES.includes(v)) throw userError$7("حالة الخطة غير صحيحة");
  return v;
}
function isOverdue(plan) {
  if (!plan.endsOn || plan.status === "completed") return false;
  return plan.endsOn < todayIso();
}
function rowToPlan(r, followUpCount = 0) {
  if (!r) return null;
  const rawAtts = extractRawPlanAttachments(r);
  const attachments = rawAtts.map((a, index) => ({
    index,
    fileName: a.fileName || `مرفق الخطة ${index + 1}`,
    fileSize: a.fileSize || 0,
    mimeType: a.mimeType || "",
    isLink: /^https?:\/\//i.test(a.filePath || "")
  }));
  const base = {
    id: r.id,
    managerId: r.manager_id,
    managerName: r.manager_name || "",
    evaluationId: r.evaluation_id,
    yearId: r.academic_year_id || r.eval_year_id || null,
    yearLabel: r.year_label || "",
    periodId: r.period_id || r.eval_period_id || null,
    periodName: r.period_name || "",
    portalId: r.portal_id || null,
    elementNumber: r.element_number,
    elementName: r.element_name || "",
    goal: r.goal,
    actions: cleanPlanActionsText(r.actions),
    startsOn: r.starts_on,
    endsOn: r.ends_on,
    status: r.status,
    statusLabel: STATUS_LABEL$1[r.status] || r.status,
    notes: cleanPlanNotesText(r.notes),
    attachments,
    attachmentCount: attachments.length,
    isArchived: !!r.is_archived,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    followUpCount
  };
  return { ...base, isOverdue: isOverdue(base) };
}
const SELECT_BASE$2 = `
  SELECT p.*,
    m.full_name AS manager_name,
    e.academic_year_id AS eval_year_id,
    e.period_id AS eval_period_id,
    ay.label AS year_label,
    ep.name AS period_name,
    s.name AS element_name
  FROM improvement_plans p
  JOIN managers m ON m.id = p.manager_id
  LEFT JOIN evaluations e ON e.id = p.evaluation_id
  LEFT JOIN academic_years ay ON ay.id = COALESCE(p.academic_year_id, e.academic_year_id)
  LEFT JOIN evaluation_periods ep ON ep.id = COALESCE(p.period_id, e.period_id)
  LEFT JOIN evaluation_item_snapshots s
    ON s.evaluation_id = p.evaluation_id AND s.element_number = p.element_number
`;
function listPlans(db2, filters = {}) {
  ensurePlanColumns(db2);
  const where = [];
  const params = [];
  if (filters.includeArchived !== true) where.push("p.is_archived = 0");
  else if (filters.onlyArchived === true) where.push("p.is_archived = 1");
  if (filters.managerId) {
    where.push("p.manager_id = ?");
    params.push(Number(filters.managerId));
  }
  if (filters.evaluationId) {
    const evRow = db2.prepare("SELECT id, academic_year_id, period_id FROM evaluations WHERE id = ?").get(Number(filters.evaluationId));
    if (evRow) {
      where.push(`(
        p.evaluation_id = ?
        OR (COALESCE(p.academic_year_id, e.academic_year_id) = ? AND COALESCE(p.period_id, e.period_id) = ?)
      )`);
      params.push(evRow.id, evRow.academic_year_id, evRow.period_id);
    } else {
      where.push("p.evaluation_id = ?");
      params.push(Number(filters.evaluationId));
    }
  } else if (filters.allStages !== true) {
    const activeCtx = !filters.yearId || !filters.periodId ? getActiveContext(db2) : null;
    const effYearId = filters.yearId || activeCtx?.yearId;
    const effPeriodId = filters.periodId || activeCtx?.periodId;
    if (effYearId) {
      where.push("COALESCE(p.academic_year_id, e.academic_year_id) = ?");
      params.push(Number(effYearId));
    }
    if (effPeriodId) {
      where.push("COALESCE(p.period_id, e.period_id) = ?");
      params.push(Number(effPeriodId));
    }
  }
  if (filters.status && VALID_STATUSES.includes(filters.status)) {
    where.push("p.status = ?");
    params.push(filters.status);
  }
  if (filters.search && filters.search.trim()) {
    where.push("(p.goal LIKE ? OR p.actions LIKE ?)");
    params.push(`%${filters.search.trim()}%`, `%${filters.search.trim()}%`);
  }
  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const rows = db2.prepare(`${SELECT_BASE$2} ${whereSql} ORDER BY p.created_at DESC`).all(...params);
  const ids = rows.map((r) => r.id);
  const counts = {};
  if (ids.length) {
    const placeholders = ids.map(() => "?").join(",");
    const cRows = db2.prepare(
      `SELECT plan_id, COUNT(*) AS c FROM plan_follow_ups WHERE plan_id IN (${placeholders}) GROUP BY plan_id`
    ).all(...ids);
    for (const r of cRows) counts[r.plan_id] = r.c;
  }
  return rows.map((r) => rowToPlan(r, counts[r.id] || 0));
}
function getPlan(db2, id) {
  ensurePlanColumns(db2);
  const r = db2.prepare(`${SELECT_BASE$2} WHERE p.id = ?`).get(id);
  if (!r) return null;
  const followUps = db2.prepare(
    "SELECT id, note, created_at FROM plan_follow_ups WHERE plan_id = ? ORDER BY created_at DESC"
  ).all(id).map((f) => ({ id: f.id, note: f.note, createdAt: f.created_at }));
  return { ...rowToPlan(r, followUps.length), followUps };
}
function normalizeStagedInput(staged) {
  if (!staged) return [];
  if (Array.isArray(staged)) return staged.filter((s) => s && s.stagingId);
  if (staged.stagingId) return [staged];
  return [];
}
async function createPlan(db2, input, staged) {
  ensurePlanColumns(db2);
  const managerId = Number(input.managerId);
  if (!managerId) throw userError$7("المدير مطلوب");
  const manager = db2.prepare("SELECT id, status FROM managers WHERE id = ?").get(managerId);
  if (!manager) throw userError$7("المدير غير موجود");
  if (manager.status === "archived") throw userError$7("لا يمكن ربط الخطة بمدير مؤرشف");
  const activeCtx = getActiveContext(db2);
  let yearId = input.yearId ? Number(input.yearId) : activeCtx.yearId;
  let periodId = input.periodId ? Number(input.periodId) : activeCtx.periodId;
  let evaluationId = input.evaluationId ? Number(input.evaluationId) : null;
  if (evaluationId) {
    const ev = db2.prepare(`
      SELECT e.id, e.manager_id, e.academic_year_id, e.period_id, ep.period_type, ep.name as period_name
      FROM evaluations e
      JOIN evaluation_periods ep ON ep.id = e.period_id
      WHERE e.id = ?
    `).get(evaluationId);
    if (!ev) throw userError$7("التقييم غير موجود");
    if (ev.manager_id !== managerId) throw userError$7("التقييم لا ينتمي للمدير المحدد");
    if (ev.period_type === "FINAL") {
      throw userError$7("خطط التحسين والتطوير متاحة للتقييم النصف سنوي فقط، ولا يمكن إضافتها للتقييم النهائي.");
    }
    yearId = ev.academic_year_id;
    periodId = ev.period_id;
  }
  let elementNumber = input.elementNumber ? Number(input.elementNumber) : null;
  if (elementNumber) {
    if (!evaluationId) throw userError$7("يجب ربط الخطة بتقييم لتحديد العنصر");
    const el = db2.prepare(
      "SELECT 1 FROM evaluation_item_snapshots WHERE evaluation_id = ? AND element_number = ?"
    ).get(evaluationId, elementNumber);
    if (!el) throw userError$7("العنصر غير موجود في التقييم المحدد");
  }
  const goal = (input.goal || "").trim();
  if (!goal) throw userError$7("هدف الخطة مطلوب");
  const startsOn = normalizeDate(input.startsOn);
  const endsOn = normalizeDate(input.endsOn);
  if (startsOn && endsOn && startsOn > endsOn)
    throw userError$7("تاريخ البداية يجب أن يسبق تاريخ النهاية");
  const status = normalizeStatus(input.status);
  const stagedList = normalizeStagedInput(staged);
  const savedAttachments = [];
  try {
    for (const st of stagedList) {
      const finalPath = await moveStagedToFinal(st.stagingId, st.ext);
      savedAttachments.push({
        filePath: finalPath,
        fileName: st.fileName,
        fileSize: st.size,
        mimeType: st.mimeType,
        sha256: st.sha256 || null
      });
    }
  } catch {
    for (const st of stagedList) await discardStaged(st.stagingId, st.ext).catch(() => {
    });
    for (const sv of savedAttachments) await deleteFileIfExists(sv.filePath);
    throw userError$7("تعذر حفظ مرفقات الخطة على القرص");
  }
  const attachmentsJson = savedAttachments.length > 0 ? JSON.stringify(savedAttachments) : null;
  try {
    const tx = db2.transaction(() => {
      const r = db2.prepare(`
        INSERT INTO improvement_plans
          (manager_id, evaluation_id, academic_year_id, period_id, element_number, goal, actions,
           starts_on, ends_on, status, notes, attachments_json, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))
      `).run(
        managerId,
        evaluationId,
        yearId || null,
        periodId || null,
        elementNumber,
        goal,
        cleanPlanActionsText(input.actions) || null,
        startsOn,
        endsOn,
        status,
        cleanPlanNotesText(input.notes) || null,
        attachmentsJson
      );
      db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("plan.create", "plan", r.lastInsertRowid);
      return r.lastInsertRowid;
    });
    return getPlan(db2, tx());
  } catch (e) {
    for (const sv of savedAttachments) await deleteFileIfExists(sv.filePath);
    throw e;
  }
}
async function updatePlan(db2, id, input, staged) {
  ensurePlanColumns(db2);
  const existing = db2.prepare("SELECT * FROM improvement_plans WHERE id = ?").get(id);
  if (!existing) throw userError$7("الخطة غير موجودة");
  if (existing.is_archived) throw userError$7("لا يمكن تعديل خطة مؤرشفة");
  const managerId = input.managerId !== void 0 ? Number(input.managerId) : existing.manager_id;
  const manager = db2.prepare("SELECT id, status FROM managers WHERE id = ?").get(managerId);
  if (!manager) throw userError$7("المدير غير موجود");
  if (manager.status === "archived") throw userError$7("لا يمكن ربط الخطة بمدير مؤرشف");
  let evaluationId = input.evaluationId !== void 0 ? input.evaluationId ? Number(input.evaluationId) : null : existing.evaluation_id;
  if (evaluationId) {
    const ev = db2.prepare("SELECT id, manager_id FROM evaluations WHERE id = ?").get(evaluationId);
    if (!ev) throw userError$7("التقييم غير موجود");
    if (ev.manager_id !== managerId) throw userError$7("التقييم لا ينتمي للمدير المحدد");
  }
  let elementNumber = input.elementNumber !== void 0 ? input.elementNumber ? Number(input.elementNumber) : null : existing.element_number;
  if (elementNumber) {
    if (!evaluationId) throw userError$7("يجب ربط الخطة بتقييم لتحديد العنصر");
    const el = db2.prepare(
      "SELECT 1 FROM evaluation_item_snapshots WHERE evaluation_id = ? AND element_number = ?"
    ).get(evaluationId, elementNumber);
    if (!el) throw userError$7("العنصر غير موجود في التقييم المحدد");
  }
  const goal = (input.goal !== void 0 ? input.goal : existing.goal || "").trim();
  if (!goal) throw userError$7("هدف الخطة مطلوب");
  const startsOn = input.startsOn !== void 0 ? normalizeDate(input.startsOn) : existing.starts_on;
  const endsOn = input.endsOn !== void 0 ? normalizeDate(input.endsOn) : existing.ends_on;
  if (startsOn && endsOn && startsOn > endsOn)
    throw userError$7("تاريخ البداية يجب أن يسبق تاريخ النهاية");
  const status = input.status !== void 0 ? normalizeStatus(input.status) : existing.status;
  const actions = input.actions !== void 0 ? cleanPlanActionsText(input.actions) || null : cleanPlanActionsText(existing.actions) || null;
  const notes = input.notes !== void 0 ? cleanPlanNotesText(input.notes) || null : cleanPlanNotesText(existing.notes) || null;
  const oldAttachments = extractRawPlanAttachments(existing);
  const stagedList = normalizeStagedInput(staged);
  const newlySaved = [];
  try {
    for (const st of stagedList) {
      const finalPath = await moveStagedToFinal(st.stagingId, st.ext);
      newlySaved.push({
        filePath: finalPath,
        fileName: st.fileName,
        fileSize: st.size,
        mimeType: st.mimeType,
        sha256: st.sha256 || null
      });
    }
  } catch {
    for (const st of stagedList) await discardStaged(st.stagingId, st.ext).catch(() => {
    });
    for (const sv of newlySaved) await deleteFileIfExists(sv.filePath);
    throw userError$7("تعذر حفظ مرفقات الخطة على القرص");
  }
  let keptOld = oldAttachments;
  let removedOld = [];
  if (Array.isArray(input.keepAttachmentIndexes)) {
    const keepSet = new Set(input.keepAttachmentIndexes.map(Number));
    keptOld = oldAttachments.filter((_, idx) => keepSet.has(idx));
    removedOld = oldAttachments.filter((_, idx) => !keepSet.has(idx));
  }
  const finalAttachments = [...keptOld, ...newlySaved];
  const attachmentsJson = finalAttachments.length > 0 ? JSON.stringify(finalAttachments) : null;
  try {
    db2.transaction(() => {
      db2.prepare(`
        UPDATE improvement_plans
        SET manager_id = ?, evaluation_id = ?, element_number = ?, goal = ?, actions = ?,
            starts_on = ?, ends_on = ?, status = ?, notes = ?, attachments_json = ?,
            updated_at = datetime('now', 'localtime')
        WHERE id = ?
      `).run(
        managerId,
        evaluationId,
        elementNumber,
        goal,
        actions,
        startsOn,
        endsOn,
        status,
        notes,
        attachmentsJson,
        id
      );
      db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("plan.update", "plan", id);
    })();
  } catch (e) {
    for (const sv of newlySaved) await deleteFileIfExists(sv.filePath);
    throw e;
  }
  for (const rm of removedOld) {
    if (rm.filePath) await deleteFileIfExists(rm.filePath);
  }
  return getPlan(db2, id);
}
function setPlanStatus(db2, id, status) {
  const existing = db2.prepare("SELECT id, is_archived FROM improvement_plans WHERE id = ?").get(id);
  if (!existing) throw userError$7("الخطة غير موجودة");
  if (existing.is_archived) throw userError$7("لا يمكن تعديل خطة مؤرشفة");
  const s = normalizeStatus(status);
  db2.prepare("UPDATE improvement_plans SET status = ?, updated_at = datetime('now', 'localtime') WHERE id = ?").run(s, id);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("plan.setStatus", "plan", id, JSON.stringify({ status: s }));
  return getPlan(db2, id);
}
function archivePlan(db2, id) {
  const existing = db2.prepare("SELECT id FROM improvement_plans WHERE id = ?").get(id);
  if (!existing) throw userError$7("الخطة غير موجودة");
  db2.prepare("UPDATE improvement_plans SET is_archived = 1, updated_at = datetime('now', 'localtime') WHERE id = ?").run(id);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("plan.archive", "plan", id);
  return getPlan(db2, id);
}
function restorePlan(db2, id) {
  const existing = db2.prepare("SELECT id FROM improvement_plans WHERE id = ?").get(id);
  if (!existing) throw userError$7("الخطة غير موجودة");
  db2.prepare("UPDATE improvement_plans SET is_archived = 0, updated_at = datetime('now', 'localtime') WHERE id = ?").run(id);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("plan.restore", "plan", id);
  return getPlan(db2, id);
}
async function deletePlan(db2, id) {
  ensurePlanColumns(db2);
  const existing = db2.prepare("SELECT * FROM improvement_plans WHERE id = ?").get(id);
  if (!existing) throw userError$7("الخطة غير موجودة");
  const allAtts = extractRawPlanAttachments(existing);
  db2.transaction(() => {
    db2.prepare("DELETE FROM plan_follow_ups WHERE plan_id = ?").run(id);
    db2.prepare("DELETE FROM improvement_plans WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("plan.delete", "plan", id, JSON.stringify({ goal: existing.goal }));
  })();
  for (const att of allAtts) {
    if (att.filePath) await deleteFileIfExists(att.filePath);
  }
  return { deleted: true, portalId: existing.portal_id || null };
}
async function openPlanAttachment(db2, id, fileIndex = 0) {
  ensurePlanColumns(db2);
  const existing = db2.prepare("SELECT * FROM improvement_plans WHERE id = ?").get(id);
  if (!existing) throw userError$7("الخطة غير موجودة");
  const allAtts = extractRawPlanAttachments(existing);
  if (!allAtts.length) throw userError$7("لا توجد ملفات مرفقة بهذه الخطة");
  const idx = Number.isInteger(Number(fileIndex)) && Number(fileIndex) >= 0 ? Number(fileIndex) : 0;
  const target = allAtts[idx] || allAtts[0];
  if (!target || !target.filePath) throw userError$7("الملف المطلوب غير موجود");
  if (/^https?:\/\//i.test(target.filePath)) {
    const { shell } = await import("electron");
    await shell.openExternal(target.filePath);
    return true;
  }
  await openEvidenceFile(target.filePath);
  return true;
}
function addFollowUp(db2, planId, note) {
  const t = (note || "").trim();
  if (!t) throw userError$7("نص الملاحظة مطلوب");
  const plan = db2.prepare("SELECT id, is_archived FROM improvement_plans WHERE id = ?").get(planId);
  if (!plan) throw userError$7("الخطة غير موجودة");
  if (plan.is_archived) throw userError$7("لا يمكن إضافة ملاحظة لخطة مؤرشفة");
  const r = db2.prepare(
    "INSERT INTO plan_follow_ups (plan_id, note) VALUES (?, ?)"
  ).run(planId, t);
  db2.prepare("UPDATE improvement_plans SET updated_at = datetime('now', 'localtime') WHERE id = ?").run(planId);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("plan.addFollowUp", "plan", planId);
  return { id: r.lastInsertRowid, note: t, createdAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function deleteFollowUp(db2, followUpId) {
  const f = db2.prepare("SELECT id, plan_id FROM plan_follow_ups WHERE id = ?").get(followUpId);
  if (!f) throw userError$7("الملاحظة غير موجودة");
  const plan = db2.prepare("SELECT is_archived FROM improvement_plans WHERE id = ?").get(f.plan_id);
  if (plan?.is_archived) throw userError$7("لا يمكن حذف ملاحظة من خطة مؤرشفة");
  db2.prepare("DELETE FROM plan_follow_ups WHERE id = ?").run(followUpId);
  db2.prepare("UPDATE improvement_plans SET updated_at = datetime('now', 'localtime') WHERE id = ?").run(f.plan_id);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("plan.deleteFollowUp", "plan", f.plan_id);
  return true;
}
function statsForDashboard(db2, { yearId, periodId } = {}) {
  ensurePlanColumns(db2);
  const extraWhere = [];
  const extraParams = [];
  if (yearId) {
    extraWhere.push("COALESCE(p.academic_year_id, e.academic_year_id) = ?");
    extraParams.push(Number(yearId));
  }
  if (periodId) {
    extraWhere.push("COALESCE(p.period_id, e.period_id) = ?");
    extraParams.push(Number(periodId));
  }
  const extraClause = extraWhere.length ? `AND ${extraWhere.join(" AND ")}` : "";
  const totalOpen = db2.prepare(`
    SELECT COUNT(*) c
    FROM improvement_plans p
    LEFT JOIN evaluations e ON e.id = p.evaluation_id
    WHERE p.is_archived = 0 AND p.status IN ('not_started','in_progress','overdue') ${extraClause}
  `).get(...extraParams).c;
  const completed = db2.prepare(`
    SELECT COUNT(*) c
    FROM improvement_plans p
    LEFT JOIN evaluations e ON e.id = p.evaluation_id
    WHERE p.is_archived = 0 AND p.status = 'completed' ${extraClause}
  `).get(...extraParams).c;
  const today = todayIso();
  const overdue = db2.prepare(`
    SELECT COUNT(*) c
    FROM improvement_plans p
    LEFT JOIN evaluations e ON e.id = p.evaluation_id
    WHERE p.is_archived = 0 AND p.status IN ('not_started','in_progress')
      AND p.ends_on IS NOT NULL AND p.ends_on < ? ${extraClause}
  `).get(today, ...extraParams).c;
  return { totalOpen, overdue, completed };
}
function userError$6(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function ensureAlertsTable(db2) {
  db2.exec(`
    CREATE TABLE IF NOT EXISTS supervisor_alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      manager_id INTEGER NOT NULL REFERENCES managers(id) ON DELETE CASCADE,
      academic_year_id INTEGER REFERENCES academic_years(id),
      period_id INTEGER REFERENCES evaluation_periods(id),
      title TEXT,
      message TEXT NOT NULL,
      portal_id INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
  `);
}
function rowToAlert(r) {
  if (!r) return null;
  return {
    id: r.id,
    managerId: r.manager_id,
    managerName: r.manager_name || "",
    yearId: r.academic_year_id,
    yearLabel: r.year_label || "",
    periodId: r.period_id,
    periodName: r.period_name || "",
    title: r.title || "تنبيه إشرافي عام",
    message: r.message,
    portalId: r.portal_id || null,
    createdAt: r.created_at
  };
}
function listManagerAlerts(db2, { managerId, yearId, periodId } = {}) {
  ensureAlertsTable(db2);
  const where = [];
  const params = [];
  if (managerId) {
    where.push("a.manager_id = ?");
    params.push(Number(managerId));
  }
  if (yearId) {
    where.push("a.academic_year_id = ?");
    params.push(Number(yearId));
  }
  if (periodId) {
    where.push("a.period_id = ?");
    params.push(Number(periodId));
  }
  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const rows = db2.prepare(`
    SELECT a.*,
           m.full_name AS manager_name,
           ay.label AS year_label,
           ep.name AS period_name
    FROM supervisor_alerts a
    JOIN managers m ON m.id = a.manager_id
    LEFT JOIN academic_years ay ON ay.id = a.academic_year_id
    LEFT JOIN evaluation_periods ep ON ep.id = a.period_id
    ${whereSql}
    ORDER BY a.id DESC
  `).all(...params);
  return rows.map(rowToAlert);
}
function createManagerAlert(db2, input = {}) {
  ensureAlertsTable(db2);
  const managerId = Number(input.managerId);
  if (!managerId) throw userError$6("يرجى تحديد المدير المرسل إليه");
  const mgr = db2.prepare("SELECT id, full_name FROM managers WHERE id = ?").get(managerId);
  if (!mgr) throw userError$6("المدير غير موجود");
  const message = String(input.message || "").trim();
  if (!message) throw userError$6("يرجى كتابة نص التنبيه أو التعليمات");
  const title = String(input.title || "").trim() || "تنبيه وتوجيه إشرافي";
  const ctx = getActiveContext(db2);
  const yearId = input.yearId ? Number(input.yearId) : ctx.yearId;
  const periodId = input.periodId ? Number(input.periodId) : ctx.periodId;
  const r = db2.prepare(`
    INSERT INTO supervisor_alerts (manager_id, academic_year_id, period_id, title, message, created_at)
    VALUES (?, ?, ?, ?, ?, datetime('now', 'localtime'))
  `).run(managerId, yearId || null, periodId || null, title, message);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("alert.create", "supervisor_alert", r.lastInsertRowid);
  const created = db2.prepare(`
    SELECT a.*,
           m.full_name AS manager_name,
           ay.label AS year_label,
           ep.name AS period_name
    FROM supervisor_alerts a
    JOIN managers m ON m.id = a.manager_id
    LEFT JOIN academic_years ay ON ay.id = a.academic_year_id
    LEFT JOIN evaluation_periods ep ON ep.id = a.period_id
    WHERE a.id = ?
  `).get(r.lastInsertRowid);
  return rowToAlert(created);
}
function deleteManagerAlert(db2, id) {
  ensureAlertsTable(db2);
  const existing = db2.prepare("SELECT * FROM supervisor_alerts WHERE id = ?").get(Number(id));
  if (!existing) throw userError$6("التنبيه غير موجود");
  db2.prepare("DELETE FROM supervisor_alerts WHERE id = ?").run(Number(id));
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("alert.delete", "supervisor_alert", Number(id));
  return { deleted: true, portalId: existing.portal_id || null, managerId: existing.manager_id };
}
const BACKUP_FORMAT = "principals-evaluation-backup";
const BACKUP_FORMAT_VERSION = 1;
function backupRoot() {
  return node_path.join(electron.app.getPath("userData"), "backups");
}
function autoBackupRoot() {
  return node_path.join(backupRoot(), "auto");
}
function evidenceRoot() {
  return node_path.join(electron.app.getPath("userData"), "evidences");
}
function evidenceFilesRoot() {
  return node_path.join(evidenceRoot(), "files");
}
async function ensureDirs() {
  await node_fs.promises.mkdir(backupRoot(), { recursive: true });
  await node_fs.promises.mkdir(autoBackupRoot(), { recursive: true });
  await node_fs.promises.mkdir(evidenceFilesRoot(), { recursive: true });
}
async function sha256OfFile(filePath) {
  const buf = await node_fs.promises.readFile(filePath);
  return node_crypto.createHash("sha256").update(buf).digest("hex");
}
async function pathExists(p) {
  try {
    await node_fs.promises.access(p);
    return true;
  } catch {
    return false;
  }
}
function timestampForFile() {
  const d = /* @__PURE__ */ new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function sanitizePath(p) {
  const norm = String(p).replace(/\\/g, "/").replace(/^\/+/, "");
  if (norm.includes("..")) return null;
  return norm;
}
function gatherStats(db2) {
  const safeCount = (table) => {
    try {
      return db2.prepare(`SELECT COUNT(*) c FROM ${table}`).get().c;
    } catch {
      return 0;
    }
  };
  return {
    managers: safeCount("managers"),
    evaluations: safeCount("evaluations"),
    evidences: safeCount("evidences"),
    plans: safeCount("improvement_plans"),
    academicYears: safeCount("academic_years"),
    formVersions: safeCount("form_versions")
  };
}
function currentSchemaVersion(db2) {
  try {
    return db2.prepare("SELECT MAX(version) v FROM schema_migrations").get()?.v || 0;
  } catch {
    return 0;
  }
}
async function snapshotDatabase(db2) {
  const tmpPath = node_path.join(node_os.tmpdir(), `pe-snapshot-${node_crypto.randomUUID()}.db`);
  const escaped = tmpPath.replace(/'/g, "''");
  db2.exec(`VACUUM INTO '${escaped}'`);
  return tmpPath;
}
async function collectEvidenceFiles() {
  const files = [];
  const root = evidenceFilesRoot();
  let entries;
  try {
    entries = await node_fs.promises.readdir(root);
  } catch {
    return files;
  }
  for (const name2 of entries) {
    const fullPath = node_path.join(root, name2);
    let stat;
    try {
      stat = await node_fs.promises.stat(fullPath);
    } catch {
      continue;
    }
    if (!stat.isFile()) continue;
    files.push({
      sourcePath: fullPath,
      zipPath: `evidences/${name2}`,
      size: stat.size
    });
  }
  return files;
}
async function createBackupToPath(db2, targetPath, { kind = "manual", reason = "" } = {}) {
  await ensureDirs();
  logger.info(`Creating ${kind} backup to ${targetPath}`);
  const dbSnapshot = await snapshotDatabase(db2);
  const evidenceFiles = await collectEvidenceFiles();
  try {
    const dbStat = await node_fs.promises.stat(dbSnapshot);
    const dbSha = await sha256OfFile(dbSnapshot);
    const evidenceManifest = [];
    for (const ef of evidenceFiles) {
      evidenceManifest.push({
        path: ef.zipPath,
        sha256: await sha256OfFile(ef.sourcePath),
        size: ef.size
      });
    }
    const manifest = {
      format: BACKUP_FORMAT,
      formatVersion: BACKUP_FORMAT_VERSION,
      appVersion: electron.app.getVersion(),
      schemaVersion: currentSchemaVersion(db2),
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      kind,
      reason,
      stats: gatherStats(db2),
      files: [
        { path: "app.db", sha256: dbSha, size: dbStat.size },
        ...evidenceManifest
      ]
    };
    await new Promise((resolvePromise, rejectPromise) => {
      const output = node_fs.createWriteStream(targetPath);
      const archive = archiver("zip", { zlib: { level: 9 } });
      output.on("close", resolvePromise);
      output.on("error", rejectPromise);
      archive.on("error", rejectPromise);
      archive.on("warning", (err) => {
        if (err.code === "ENOENT") logger.warn("Archive warning: " + err.message);
        else rejectPromise(err);
      });
      archive.pipe(output);
      archive.file(dbSnapshot, { name: "app.db" });
      for (const ef of evidenceFiles) {
        archive.file(ef.sourcePath, { name: ef.zipPath });
      }
      archive.append(JSON.stringify(manifest, null, 2), { name: "manifest.json" });
      archive.finalize();
    });
    logger.info(`Backup created: ${targetPath} (${evidenceFiles.length} evidence files)`);
    return { filePath: targetPath, manifest };
  } finally {
    try {
      await node_fs.promises.unlink(dbSnapshot);
    } catch {
    }
  }
}
async function createManualBackupWithDialog(db2) {
  await ensureDirs();
  const parent = electron.BrowserWindow.getFocusedWindow();
  const defaultName = `principals-evaluation-backup-${timestampForFile()}.zip`;
  const result2 = await electron.dialog.showSaveDialog(parent, {
    title: "حفظ النسخة الاحتياطية",
    defaultPath: node_path.join(backupRoot(), defaultName),
    filters: [{ name: "ZIP", extensions: ["zip"] }]
  });
  if (result2.canceled || !result2.filePath) return { cancelled: true };
  const { filePath, manifest } = await createBackupToPath(db2, result2.filePath, { kind: "manual" });
  try {
    db2.prepare(`
      INSERT INTO app_settings (key, value, updated_at) VALUES ('last_manual_backup_at', ?, datetime('now'))
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
    `).run(manifest.createdAt);
    db2.prepare(`
      INSERT INTO app_settings (key, value, updated_at) VALUES ('last_manual_backup_path', ?, datetime('now'))
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
    `).run(filePath);
  } catch {
  }
  return { cancelled: false, filePath, manifest };
}
async function createAutoBackup(db2, reason = "auto") {
  await ensureDirs();
  const fileName = `auto-${reason}-${timestampForFile()}.zip`;
  const targetPath = node_path.join(autoBackupRoot(), fileName);
  return createBackupToPath(db2, targetPath, { kind: "auto", reason });
}
async function listAutoBackups() {
  const root = autoBackupRoot();
  let entries = [];
  try {
    entries = await node_fs.promises.readdir(root);
  } catch {
    return [];
  }
  const out = [];
  for (const name2 of entries) {
    if (!name2.endsWith(".zip")) continue;
    const fullPath = node_path.join(root, name2);
    try {
      const stat = await node_fs.promises.stat(fullPath);
      if (!stat.isFile()) continue;
      out.push({ fileName: name2, filePath: fullPath, size: stat.size, createdAt: stat.mtime.toISOString() });
    } catch {
    }
  }
  out.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return out;
}
async function getLastBackupInfo(db2) {
  try {
    const rows = db2.prepare(
      "SELECT key, value FROM app_settings WHERE key IN ('last_manual_backup_at','last_manual_backup_path')"
    ).all();
    const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    const path = map.last_manual_backup_path || "";
    const at = map.last_manual_backup_at || "";
    const exists = path ? await pathExists(path) : false;
    return { path, at, exists, backupsRoot: backupRoot() };
  } catch {
    return { path: "", at: "", exists: false, backupsRoot: backupRoot() };
  }
}
async function inspectBackupZip(zipPath) {
  let stat;
  try {
    stat = await node_fs.promises.stat(zipPath);
  } catch {
    throw Object.assign(new Error("nf"), { userMessage: "ملف النسخة غير موجود" });
  }
  let zip;
  try {
    zip = new AdmZip(zipPath);
  } catch {
    throw Object.assign(new Error("bad zip"), { userMessage: "الملف ليس نسخة احتياطية صالحة" });
  }
  const manifestEntry = zip.getEntry("manifest.json");
  if (!manifestEntry) {
    throw Object.assign(new Error("no manifest"), { userMessage: "الملف لا يحتوي على بيان نسخة احتياطية" });
  }
  let manifest;
  try {
    manifest = JSON.parse(manifestEntry.getData().toString("utf8"));
  } catch {
    throw Object.assign(new Error("bad manifest"), { userMessage: "بيان النسخة تالف" });
  }
  if (manifest.format !== BACKUP_FORMAT) {
    throw Object.assign(new Error("wrong format"), {
      userMessage: "هذا الملف ليس نسخة احتياطية من نظام تقييم مدراء المدارس"
    });
  }
  return {
    filePath: zipPath,
    fileName: zipPath.split(/[\\/]/).pop(),
    fileSize: stat.size,
    manifest
  };
}
async function restoreBackup(zipPath, { safetyBackup = true, db: db2 } = {}) {
  await ensureDirs();
  const inspected = await inspectBackupZip(zipPath);
  const manifest = inspected.manifest;
  const expectedDbFile = manifest.files.find((f) => f.path === "app.db");
  if (!expectedDbFile) {
    throw Object.assign(new Error("no db"), { userMessage: "النسخة الاحتياطية لا تحتوي على قاعدة بيانات" });
  }
  const tempRoot = node_path.join(node_os.tmpdir(), `pe-restore-${node_crypto.randomUUID()}`);
  await node_fs.promises.mkdir(tempRoot, { recursive: true });
  const zip = new AdmZip(zipPath);
  const entries = zip.getEntries();
  const extractedPaths = /* @__PURE__ */ new Map();
  try {
    for (const entry of entries) {
      if (entry.isDirectory) continue;
      const safe = sanitizePath(entry.entryName);
      if (!safe) {
        throw Object.assign(new Error("zip slip"), {
          userMessage: `مسار غير آمن داخل الأرشيف: ${entry.entryName}`
        });
      }
      const target = node_path.join(tempRoot, safe);
      const resolved = node_path.resolve(target);
      const resolvedRoot = node_path.resolve(tempRoot);
      if (resolved !== resolvedRoot && !resolved.startsWith(resolvedRoot + node_path.sep)) {
        throw Object.assign(new Error("zip slip"), {
          userMessage: `مسار غير آمن داخل الأرشيف: ${entry.entryName}`
        });
      }
      await node_fs.promises.mkdir(node_path.dirname(target), { recursive: true });
      await node_fs.promises.writeFile(target, entry.getData());
      extractedPaths.set(safe, target);
    }
    for (const fileSpec of manifest.files) {
      const local = extractedPaths.get(fileSpec.path);
      if (!local) {
        throw Object.assign(new Error("missing"), {
          userMessage: `ملف مفقود داخل الأرشيف: ${fileSpec.path}`
        });
      }
      const actual = await sha256OfFile(local);
      if (actual !== fileSpec.sha256) {
        throw Object.assign(new Error("hash mismatch"), {
          userMessage: `تلف في الملف ${fileSpec.path} — تجزئة SHA-256 غير مطابقة`
        });
      }
    }
    let safetyPath = null;
    if (safetyBackup && db2) {
      try {
        const r = await createAutoBackup(db2, "pre-restore");
        safetyPath = r.filePath;
        logger.info(`Safety backup created: ${safetyPath}`);
      } catch (e) {
        logger.error("Safety backup failed", e);
        throw Object.assign(new Error("safety"), {
          userMessage: "تعذر إنشاء نسخة أمان قبل الاستعادة — تم الإلغاء"
        });
      }
    }
    closeDb();
    const dbTarget = node_path.join(electron.app.getPath("userData"), "data", "app.db");
    await node_fs.promises.mkdir(node_path.dirname(dbTarget), { recursive: true });
    const dbBackupPath = `${dbTarget}.before-restore-${Date.now()}`;
    let movedOriginalDb = false;
    try {
      if (await pathExists(dbTarget)) {
        await node_fs.promises.rename(dbTarget, dbBackupPath);
        movedOriginalDb = true;
      }
    } catch (e) {
      logger.warn("Could not move original DB: " + e.message);
    }
    try {
      await node_fs.promises.copyFile(extractedPaths.get("app.db"), dbTarget);
      for (const suffix of ["-wal", "-shm"]) {
        try {
          await node_fs.promises.unlink(dbTarget + suffix);
        } catch {
        }
      }
    } catch (e) {
      if (movedOriginalDb) {
        try {
          await node_fs.promises.rename(dbBackupPath, dbTarget);
        } catch {
        }
      }
      throw Object.assign(new Error("copy db"), { userMessage: "تعذر استبدال قاعدة البيانات" });
    }
    const evidenceTarget = evidenceFilesRoot();
    const evidenceOld = `${evidenceRoot()}/files.before-restore-${Date.now()}`;
    let movedEvidence = false;
    try {
      if (await pathExists(evidenceTarget)) {
        await node_fs.promises.rename(evidenceTarget, evidenceOld);
        movedEvidence = true;
      }
    } catch (e) {
      logger.warn("Could not move evidences dir: " + e.message);
    }
    try {
      await node_fs.promises.mkdir(evidenceTarget, { recursive: true });
      for (const [safePath, localPath] of extractedPaths) {
        if (!safePath.startsWith("evidences/")) continue;
        const rel = safePath.slice("evidences/".length);
        if (!rel || rel.includes("/")) continue;
        const targetFile = node_path.join(evidenceTarget, rel);
        await node_fs.promises.copyFile(localPath, targetFile);
      }
    } catch (e) {
      if (movedEvidence) {
        try {
          await node_fs.promises.rm(evidenceTarget, { recursive: true, force: true });
          await node_fs.promises.rename(evidenceOld, evidenceTarget);
        } catch {
        }
      }
      throw Object.assign(new Error("copy evidences"), { userMessage: "تعذر استبدال مجلد الشواهد" });
    }
    try {
      await node_fs.promises.unlink(dbBackupPath);
    } catch {
    }
    try {
      await node_fs.promises.rm(evidenceOld, { recursive: true, force: true });
    } catch {
    }
    logger.info(`Restore completed from ${zipPath}`);
    return { success: true, manifest, safetyBackupPath: safetyPath, restartRequired: true };
  } finally {
    try {
      await node_fs.promises.rm(tempRoot, { recursive: true, force: true });
    } catch {
    }
  }
}
async function openBackupsFolder() {
  await ensureDirs();
  const err = await electron.shell.openPath(backupRoot());
  if (err) throw Object.assign(new Error(err), { userMessage: "تعذر فتح مجلد النسخ" });
  return true;
}
async function pickBackupFileToRestore() {
  const parent = electron.BrowserWindow.getFocusedWindow();
  const result2 = await electron.dialog.showOpenDialog(parent, {
    title: "اختر ملف النسخة الاحتياطية",
    properties: ["openFile"],
    filters: [{ name: "ZIP", extensions: ["zip"] }]
  });
  if (result2.canceled || result2.filePaths.length === 0) return { cancelled: true };
  return { cancelled: false, filePath: result2.filePaths[0] };
}
const SUPABASE_URL = "https://yshmtcndshhbdejlzyfv.supabase.co";
const SUPABASE_KEY = "sb_publishable_0mJDcmOejQj8IFhN8YSOJQ_MjJjXXh8";
const HEADERS = {
  "apikey": SUPABASE_KEY,
  "Authorization": `Bearer ${SUPABASE_KEY}`,
  "Content-Type": "application/json"
};
const DEFAULT_EVIDENCE_DESC = "شاهد مرفوع إلكترونياً من مدير المدرسة عبر البوابة";
function ensureSyncColumns(db2) {
  ensureTable(db2);
  ensureEvidenceColumns(db2);
  ensurePlanColumns(db2);
  ensureAlertsTable(db2);
  try {
    db2.prepare("ALTER TABLE managers ADD COLUMN cloud_synced_at TEXT").run();
  } catch {
  }
  try {
    db2.prepare("ALTER TABLE evaluations ADD COLUMN cloud_synced_at TEXT").run();
  } catch {
  }
}
function buildPrincipalStatusToken(ctx) {
  const pType = ctx?.periodType === "FINAL" ? "FINAL" : "MIDYEAR";
  const yLabel = String(ctx?.yearLabel || "").replace(/\|/g, "/").trim();
  const pName = String(ctx?.periodName || "").replace(/\|/g, "/").trim();
  return `active|${pType}|${yLabel}|${pName}`;
}
function extractContextTag(rawStr) {
  const str = String(rawStr || "");
  const ctxMatch = str.match(/<!--CTX:(.*?)-->/);
  if (ctxMatch) {
    const [yearLabel = "", periodType = "", periodName = ""] = ctxMatch[1].split("|");
    const stripped = str.replace(/<!--CTX:[\s\S]*?-->\s*/g, "");
    return {
      yearLabel: yearLabel.trim(),
      periodType: periodType.trim(),
      periodName: periodName.trim(),
      stripped
    };
  }
  const yrMatch = str.match(/<!--CTX_YEAR:(.*?)-->/);
  if (yrMatch) {
    const stripped = str.replace(/<!--CTX_YEAR:[\s\S]*?-->\s*/g, "");
    return {
      yearLabel: yrMatch[1].trim(),
      periodType: "",
      periodName: "",
      stripped
    };
  }
  return { yearLabel: "", periodType: "", periodName: "", stripped: str };
}
function resolveLocalYearAndPeriod(db2, tagInfo, fallbackCtx) {
  let yearId = fallbackCtx?.yearId || null;
  let periodId = fallbackCtx?.periodId || null;
  if (tagInfo?.yearLabel) {
    const yr = db2.prepare("SELECT id FROM academic_years WHERE label = ? LIMIT 1").get(tagInfo.yearLabel);
    if (yr) {
      yearId = yr.id;
      if (tagInfo.periodType) {
        const pr = db2.prepare(
          "SELECT id FROM evaluation_periods WHERE academic_year_id = ? AND period_type = ? ORDER BY id ASC LIMIT 1"
        ).get(yr.id, tagInfo.periodType);
        if (pr) periodId = pr.id;
      }
      if (!periodId && tagInfo.periodName) {
        const pr2 = db2.prepare(
          "SELECT id FROM evaluation_periods WHERE academic_year_id = ? AND name = ? LIMIT 1"
        ).get(yr.id, tagInfo.periodName);
        if (pr2) periodId = pr2.id;
      }
      if (!periodId) {
        const prFallback = db2.prepare(
          "SELECT id FROM evaluation_periods WHERE academic_year_id = ? ORDER BY id ASC LIMIT 1"
        ).get(yr.id);
        if (prFallback) periodId = prFallback.id;
      }
    }
  } else if (yearId && tagInfo?.periodType) {
    const pr = db2.prepare(
      "SELECT id FROM evaluation_periods WHERE academic_year_id = ? AND period_type = ? ORDER BY id ASC LIMIT 1"
    ).get(yearId, tagInfo.periodType);
    if (pr) periodId = pr.id;
  }
  return { yearId, periodId };
}
async function extractFilesFromPlanActionsString(rawActions) {
  const { stripped } = extractContextTag(rawActions);
  let text = String(stripped || "");
  const extractedFiles = [];
  const multiRegex = /<!--PLAN_FILES_JSON:([\s\S]*?)-->/g;
  let mMatch;
  while ((mMatch = multiRegex.exec(text)) !== null) {
    try {
      const arr = JSON.parse(mMatch[1]);
      if (Array.isArray(arr)) {
        for (const item of arr) {
          if (item && item.data) {
            const saved = await saveBufferOrDataUrl(item.data, item.name || "ملف_خطة_التحسين.pdf");
            extractedFiles.push(saved);
          }
        }
      }
    } catch (e) {
      console.warn("[CloudSync] Failed to parse PLAN_FILES_JSON:", e);
    }
  }
  const singleRegex = /<!--PLAN_FILE:(.*?)\|\|([\s\S]*?)-->/g;
  let sMatch;
  while ((sMatch = singleRegex.exec(text)) !== null) {
    const fName = (sMatch[1] || "ملف_خطة_التحسين.pdf").trim();
    const fData = (sMatch[2] || "").trim();
    if (fData) {
      try {
        const saved = await saveBufferOrDataUrl(fData, fName);
        extractedFiles.push(saved);
      } catch (e) {
        console.warn("[CloudSync] Failed to save legacy PLAN_FILE:", e);
      }
    }
  }
  const cleanText = cleanPlanActionsText(text);
  return { cleanText, extractedFiles };
}
async function migrateLegacyEmbeddedPlanFiles(db2) {
  try {
    ensureSyncColumns(db2);
    db2.prepare(`
      UPDATE improvement_plans
      SET notes = NULL
      WHERE notes IN (
        'هدف مسجل إلكترونياً من مدير المدرسة عبر البوابة',
        'خطة تطوير عامة للمدرسة مسجلة إلكترونياً عبر البوابة'
      )
    `).run();
    const dirtyPlans = db2.prepare(`
      SELECT id, actions, attachments_json
      FROM improvement_plans
      WHERE actions LIKE '%<!--PLAN_FILE:%' OR actions LIKE '%<!--PLAN_FILES_JSON:%'
    `).all();
    for (const row of dirtyPlans) {
      const existingAtts = extractRawPlanAttachments(row);
      const { cleanText, extractedFiles } = await extractFilesFromPlanActionsString(row.actions);
      const merged = [...existingAtts, ...extractedFiles];
      db2.prepare(`
        UPDATE improvement_plans
        SET actions = ?, attachments_json = ?
        WHERE id = ?
      `).run(
        cleanText || null,
        merged.length > 0 ? JSON.stringify(merged) : null,
        row.id
      );
    }
    const dirtyEvidences = db2.prepare(`
      SELECT id, title, file_path, attachments_json
      FROM evidences
      WHERE file_path LIKE 'data:%'
    `).all();
    for (const ev of dirtyEvidences) {
      try {
        const saved = await saveBufferOrDataUrl(ev.file_path, ev.title || "شاهد_مرفق.pdf");
        const atts = [saved];
        db2.prepare(`
          UPDATE evidences
          SET file_path = ?, file_name = ?, file_size = ?, mime_type = ?, attachments_json = ?
          WHERE id = ?
        `).run(saved.filePath, saved.fileName, saved.fileSize, saved.mimeType, JSON.stringify(atts), ev.id);
      } catch (e) {
        console.warn("[CloudSync] Failed to migrate dirty evidence data URL:", e);
      }
    }
  } catch (err) {
    console.warn("[migrateLegacyEmbeddedPlanFiles] Warning:", err);
  }
}
async function parseIncomingEvidenceContent(ev) {
  const rawFull = typeof ev.content === "string" ? ev.content : "";
  const tagInfo = extractContextTag(rawFull);
  let raw = String(tagInfo.stripped || "").trim();
  if (raw.includes("<!--SUPERVISOR_COMMENTS-->")) {
    raw = raw.split("<!--SUPERVISOR_COMMENTS-->")[0].trim();
  }
  const savedAttachments = [];
  let description = DEFAULT_EVIDENCE_DESC;
  if (raw.startsWith("<!--MULTI_FILES_JSON-->")) {
    const jsonPart = raw.slice("<!--MULTI_FILES_JSON-->".length);
    try {
      const parsed = JSON.parse(jsonPart);
      const filesArr = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.files) ? parsed.files : [];
      if (parsed && typeof parsed.text === "string" && parsed.text.trim()) {
        description = parsed.text.trim();
      }
      for (let i = 0; i < filesArr.length; i++) {
        const f = filesArr[i];
        if (f && f.data) {
          const fallbackName = `${ev.title || "شاهد"}_${i + 1}.pdf`;
          const saved = await saveBufferOrDataUrl(f.data, f.name || fallbackName);
          savedAttachments.push(saved);
        }
      }
    } catch (e) {
      console.warn("[CloudSync] Failed to parse MULTI_FILES_JSON evidence:", e);
    }
  } else if (raw.startsWith("data:")) {
    try {
      const saved = await saveBufferOrDataUrl(raw, ev.title || "شاهد_مرفوع.pdf");
      savedAttachments.push(saved);
    } catch (e) {
      console.warn("[CloudSync] Failed to save single dataURL evidence:", e);
    }
  } else if (/^https?:\/\//i.test(raw)) {
    savedAttachments.push({
      filePath: raw,
      fileName: "رابط إلكتروني خارجي",
      fileSize: 0,
      mimeType: "text/uri-list"
    });
    description = raw;
  } else if (raw) {
    description = raw.replace(/<!--EVIDENCE_FILES_META:[\s\S]*?-->/g, "").trim() || DEFAULT_EVIDENCE_DESC;
  }
  return { savedAttachments, description, tagInfo };
}
async function resolveCloudManagerId(nationalId, fallbackLocalId) {
  try {
    if (nationalId) {
      const res = await fetch(
        `${SUPABASE_URL}/rest/v1/portal_principals?national_id=eq.${encodeURIComponent(nationalId)}&select=id&limit=1`,
        { headers: HEADERS }
      );
      if (res.ok) {
        const rows = await res.json();
        if (rows && rows.length > 0 && rows[0].id != null) return rows[0].id;
      }
    }
    if (fallbackLocalId != null) {
      const res2 = await fetch(
        `${SUPABASE_URL}/rest/v1/portal_principals?id=eq.${encodeURIComponent(fallbackLocalId)}&select=id&limit=1`,
        { headers: HEADERS }
      );
      if (res2.ok) {
        const rows2 = await res2.json();
        if (rows2 && rows2.length > 0 && rows2[0].id != null) return rows2[0].id;
      }
    }
  } catch {
  }
  return null;
}
function buildCloudEvidenceContent(evRow, commentsList, activeCtx) {
  const yLabel = evRow.year_label || activeCtx?.yearLabel || "";
  const pType = evRow.period_type === "FINAL" || String(evRow.period_name || "").includes("نهائي") ? "FINAL" : "MIDYEAR";
  const pName = evRow.period_name || activeCtx?.periodName || "";
  const parts = [`<!--CTX:${yLabel}|${pType}|${pName}-->`];
  const rawDesc = String(evRow.description || "").trim();
  if (rawDesc && rawDesc !== DEFAULT_EVIDENCE_DESC) {
    parts.push(rawDesc);
  }
  const rawAtts = extractRawEvidenceAttachments(evRow);
  const nonLinkAtts = rawAtts.filter((a) => !/^https?:\/\//i.test(a.filePath || ""));
  if (nonLinkAtts.length > 0) {
    const meta = nonLinkAtts.map((a) => ({
      name: a.fileName || "ملف مرفق",
      size: a.fileSize || 0,
      mime: a.mimeType || ""
    }));
    parts.push(`<!--EVIDENCE_FILES_META:${JSON.stringify(meta)}-->`);
  }
  if (commentsList.length > 0) {
    parts.push(`<!--SUPERVISOR_COMMENTS-->
${commentsList.join("\n---COMMENT_SEP---\n")}`);
  }
  return parts.join("\n");
}
async function pushSingleEvidenceComments(db2, evidenceId, { createIfMissing = true } = {}) {
  try {
    ensureSyncColumns(db2);
    const activeCtx = getActiveContext(db2);
    const evRow = db2.prepare(`
      SELECT e.*,
             m.national_id, m.employee_number,
             ay.label AS year_label,
             ep.name AS period_name,
             ep.period_type AS period_type
      FROM evidences e
      JOIN managers m ON m.id = e.manager_id
      LEFT JOIN evaluations ev ON ev.id = e.evaluation_id
      LEFT JOIN academic_years ay ON ay.id = COALESCE(e.academic_year_id, ev.academic_year_id)
      LEFT JOIN evaluation_periods ep ON ep.id = COALESCE(e.period_id, ev.period_id)
      WHERE e.id = ?
    `).get(Number(evidenceId));
    if (!evRow) return false;
    const comments = db2.prepare(
      "SELECT comment FROM evidence_comments WHERE evidence_id = ? ORDER BY id ASC"
    ).all(evRow.id).map((r) => String(r.comment || "").trim()).filter(Boolean);
    const nationalId = (evRow.national_id || "").trim() || String(evRow.employee_number || evRow.manager_id);
    const lightContent = buildCloudEvidenceContent(evRow, comments, activeCtx);
    const rawAtts = extractRawEvidenceAttachments(evRow);
    const evType = rawAtts.some((a) => /^https?:\/\//i.test(a.filePath || "")) ? "link" : rawAtts.length > 0 ? "file" : "text";
    let patched = false;
    if (evRow.portal_id) {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?id=eq.${evRow.portal_id}`, {
        method: "PATCH",
        headers: { ...HEADERS, "Prefer": "return=representation" },
        body: JSON.stringify({ content: lightContent, synced_to_desktop: true })
      });
      if (res.ok) {
        const rows = await res.json();
        if (rows && rows.length > 0) patched = true;
      }
    }
    if (!patched && nationalId) {
      const res2 = await fetch(
        `${SUPABASE_URL}/rest/v1/portal_evidences?national_id=eq.${encodeURIComponent(nationalId)}&title=eq.${encodeURIComponent(evRow.title)}`,
        {
          method: "PATCH",
          headers: { ...HEADERS, "Prefer": "return=representation" },
          body: JSON.stringify({ content: lightContent, synced_to_desktop: true })
        }
      );
      if (res2.ok) {
        const rows2 = await res2.json();
        if (rows2 && rows2.length > 0) {
          patched = true;
          if (rows2[0].id && !evRow.portal_id) {
            db2.prepare("UPDATE evidences SET portal_id = ? WHERE id = ?").run(rows2[0].id, evRow.id);
          }
        }
      }
    }
    if (!patched && createIfMissing) {
      const cloudManagerId = await resolveCloudManagerId(nationalId, evRow.manager_id);
      const payload = {
        manager_id: cloudManagerId,
        national_id: nationalId,
        element_number: evRow.element_number || 1,
        title: evRow.title,
        evidence_type: evType,
        content: lightContent,
        uploaded_by: "supervisor",
        synced_to_desktop: true
      };
      let postRes = await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences`, {
        method: "POST",
        headers: { ...HEADERS, "Prefer": "return=representation" },
        body: JSON.stringify(payload)
      });
      if (!postRes.ok && cloudManagerId !== null) {
        postRes = await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences`, {
          method: "POST",
          headers: { ...HEADERS, "Prefer": "return=representation" },
          body: JSON.stringify({ ...payload, manager_id: null })
        });
      }
      if (postRes.ok) {
        const created = await postRes.json();
        if (created && created[0]?.id) {
          db2.prepare("UPDATE evidences SET portal_id = ? WHERE id = ?").run(created[0].id, evRow.id);
        }
      }
    }
    return true;
  } catch (err) {
    console.warn("[pushSingleEvidenceComments] Warning:", err);
    return false;
  }
}
async function deleteCloudEvidence(portalId) {
  if (!portalId) return false;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?id=eq.${portalId}`, {
      method: "DELETE",
      headers: HEADERS
    });
    return true;
  } catch {
    return false;
  }
}
function buildCloudPlanActions(lp, notesList, activeCtx) {
  const yLabel = lp.year_label || activeCtx?.yearLabel || "";
  const pType = lp.period_type === "FINAL" || String(lp.period_name || "").includes("نهائي") ? "FINAL" : "MIDYEAR";
  const pName = lp.period_name || activeCtx?.periodName || "";
  const cleanActions = cleanPlanActionsText(lp.actions);
  const rawAtts = extractRawPlanAttachments(lp);
  const parts = [];
  if (yLabel) parts.push(`<!--CTX:${yLabel}|${pType}|${pName}-->`);
  if (cleanActions) parts.push(cleanActions);
  if (rawAtts.length > 0) {
    const meta = rawAtts.map((a) => ({
      name: a.fileName || "ملف مرفق",
      size: a.fileSize || 0,
      mime: a.mimeType || ""
    }));
    parts.push(`<!--PLAN_FILES_META:${JSON.stringify(meta)}-->`);
  }
  if (notesList.length > 0) {
    parts.push(`<!--SUPERVISOR_NOTES-->
${notesList.join("\n---NOTE_SEP---\n")}`);
  }
  return parts.join("\n");
}
async function syncPlanRecordToCloud(db2, lp, { createIfMissing = true } = {}) {
  const activeCtx = getActiveContext(db2);
  const followUps = db2.prepare(`
    SELECT note, created_at FROM plan_follow_ups WHERE plan_id = ? ORDER BY id ASC
  `).all(lp.id);
  const notesList = [];
  const cleanedGeneralNote = cleanPlanNotesText(lp.notes);
  if (cleanedGeneralNote) notesList.push(cleanedGeneralNote);
  for (const f of followUps) {
    if (f.note && f.note.trim() && !SYSTEM_IMPORT_NOTES.has(f.note.trim())) {
      notesList.push(f.note.trim());
    }
  }
  const nationalId = (lp.national_id || "").trim() || String(lp.employee_number || lp.manager_id);
  const combinedActions = buildCloudPlanActions(lp, notesList, activeCtx);
  let patchedRows = [];
  if (lp.portal_id) {
    const byIdRes = await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?id=eq.${lp.portal_id}`, {
      method: "PATCH",
      headers: { ...HEADERS, "Prefer": "return=representation" },
      body: JSON.stringify({ actions: combinedActions, synced_to_desktop: true })
    });
    if (byIdRes.ok) {
      patchedRows = await byIdRes.json();
    }
  }
  if ((!patchedRows || patchedRows.length === 0) && nationalId) {
    const patchRes = await fetch(
      `${SUPABASE_URL}/rest/v1/portal_plans?national_id=eq.${encodeURIComponent(nationalId)}&goal=eq.${encodeURIComponent(lp.goal)}&status=neq.supervisor_alert`,
      {
        method: "PATCH",
        headers: { ...HEADERS, "Prefer": "return=representation" },
        body: JSON.stringify({ actions: combinedActions, synced_to_desktop: true })
      }
    );
    if (patchRes.ok) {
      patchedRows = await patchRes.json();
    }
  }
  if (patchedRows && patchedRows.length > 0 && patchedRows[0].id && !lp.portal_id) {
    db2.prepare("UPDATE improvement_plans SET portal_id = ? WHERE id = ?").run(patchedRows[0].id, lp.id);
  }
  if ((!patchedRows || patchedRows.length === 0) && createIfMissing) {
    const cloudManagerId = await resolveCloudManagerId(nationalId, lp.manager_id);
    const postPayload = {
      manager_id: cloudManagerId,
      national_id: nationalId,
      element_number: lp.element_number || null,
      goal: lp.goal,
      actions: combinedActions,
      status: lp.status === "completed" ? "completed" : "active",
      uploaded_by: "supervisor",
      synced_to_desktop: true
    };
    let postRes = await fetch(`${SUPABASE_URL}/rest/v1/portal_plans`, {
      method: "POST",
      headers: { ...HEADERS, "Prefer": "return=representation" },
      body: JSON.stringify(postPayload)
    });
    if (!postRes.ok && cloudManagerId !== null) {
      postRes = await fetch(`${SUPABASE_URL}/rest/v1/portal_plans`, {
        method: "POST",
        headers: { ...HEADERS, "Prefer": "return=representation" },
        body: JSON.stringify({ ...postPayload, manager_id: null })
      });
    }
    if (postRes.ok) {
      const created = await postRes.json();
      if (created && created[0]?.id) {
        db2.prepare("UPDATE improvement_plans SET portal_id = ? WHERE id = ?").run(created[0].id, lp.id);
      }
    }
  }
  return true;
}
async function deleteCloudPlan(portalId) {
  if (!portalId) return false;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?id=eq.${portalId}`, {
      method: "DELETE",
      headers: HEADERS
    });
    return true;
  } catch {
    return false;
  }
}
async function pushManagerAlertToCloud(db2, alertId) {
  try {
    ensureSyncColumns(db2);
    const activeCtx = getActiveContext(db2);
    const row = db2.prepare(`
      SELECT a.*,
             m.national_id, m.employee_number,
             ay.label AS year_label,
             ep.name AS period_name,
             ep.period_type AS period_type
      FROM supervisor_alerts a
      JOIN managers m ON m.id = a.manager_id
      LEFT JOIN academic_years ay ON ay.id = a.academic_year_id
      LEFT JOIN evaluation_periods ep ON ep.id = a.period_id
      WHERE a.id = ?
    `).get(Number(alertId));
    if (!row) return false;
    if (row.portal_id) {
      return true;
    }
    const nationalId = (row.national_id || "").trim() || String(row.employee_number || row.manager_id);
    const yLabel = row.year_label || activeCtx.yearLabel || "";
    const pType = row.period_type === "FINAL" || String(row.period_name || "").includes("نهائي") ? "FINAL" : "MIDYEAR";
    const pName = row.period_name || activeCtx.periodName || "";
    const cloudManagerId = await resolveCloudManagerId(nationalId, row.manager_id);
    const payload = {
      manager_id: cloudManagerId,
      national_id: nationalId,
      element_number: null,
      goal: row.title || "تنبيه وتوجيه إشرافي",
      actions: `<!--CTX:${yLabel}|${pType}|${pName}-->
${row.message}`,
      status: "supervisor_alert",
      uploaded_by: "supervisor",
      synced_to_desktop: true
    };
    let res = await fetch(`${SUPABASE_URL}/rest/v1/portal_plans`, {
      method: "POST",
      headers: { ...HEADERS, "Prefer": "return=representation" },
      body: JSON.stringify(payload)
    });
    if (!res.ok && cloudManagerId !== null) {
      res = await fetch(`${SUPABASE_URL}/rest/v1/portal_plans`, {
        method: "POST",
        headers: { ...HEADERS, "Prefer": "return=representation" },
        body: JSON.stringify({ ...payload, manager_id: null })
      });
    }
    if (res.ok) {
      const created = await res.json();
      if (created && created[0]?.id) {
        db2.prepare("UPDATE supervisor_alerts SET portal_id = ? WHERE id = ?").run(created[0].id, row.id);
      }
      return true;
    }
    return false;
  } catch (err) {
    console.warn("[pushManagerAlertToCloud] Warning:", err);
    return false;
  }
}
async function deleteManagerAlertFromCloud(portalId) {
  if (!portalId) return false;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?id=eq.${portalId}`, {
      method: "DELETE",
      headers: HEADERS
    });
    return true;
  } catch {
    return false;
  }
}
async function deleteManagerFromCloud({ id, nationalId } = {}) {
  try {
    const cleanNat = nationalId ? String(nationalId).trim() : null;
    if (cleanNat) {
      await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?national_id=eq.${encodeURIComponent(cleanNat)}`, {
        method: "DELETE",
        headers: HEADERS
      }).catch(() => {
      });
      await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?national_id=eq.${encodeURIComponent(cleanNat)}`, { method: "DELETE", headers: HEADERS }).catch(() => {
      });
      await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?national_id=eq.${encodeURIComponent(cleanNat)}`, { method: "DELETE", headers: HEADERS }).catch(() => {
      });
      await fetch(`${SUPABASE_URL}/rest/v1/portal_evaluations?national_id=eq.${encodeURIComponent(cleanNat)}`, { method: "DELETE", headers: HEADERS }).catch(() => {
      });
    }
    if (id != null) {
      await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?id=eq.${id}`, {
        method: "DELETE",
        headers: HEADERS
      }).catch(() => {
      });
      await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?manager_id=eq.${id}`, { method: "DELETE", headers: HEADERS }).catch(() => {
      });
      await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?manager_id=eq.${id}`, { method: "DELETE", headers: HEADERS }).catch(() => {
      });
      await fetch(`${SUPABASE_URL}/rest/v1/portal_evaluations?manager_id=eq.${id}`, { method: "DELETE", headers: HEADERS }).catch(() => {
      });
    }
    return true;
  } catch {
    return false;
  }
}
async function purgeAllCloudData() {
  try {
    const pEv = fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?id=gt.0`, {
      method: "DELETE",
      headers: HEADERS
    }).catch(() => {
    });
    const pPl = fetch(`${SUPABASE_URL}/rest/v1/portal_plans?id=gt.0`, {
      method: "DELETE",
      headers: HEADERS
    }).catch(() => {
    });
    const pEvl = fetch(`${SUPABASE_URL}/rest/v1/portal_evaluations?id=gt.0`, {
      method: "DELETE",
      headers: HEADERS
    }).catch(() => {
    });
    const pPr = fetch(`${SUPABASE_URL}/rest/v1/portal_principals?national_id=neq.admin&national_id=neq.system_app_settings&national_id=neq.system_app_version`, {
      method: "DELETE",
      headers: HEADERS
    }).catch(() => {
    });
    await Promise.all([pEv, pPl, pEvl, pPr]);
    return { success: true };
  } catch (err) {
    console.error("[purgeAllCloudData] Error:", err);
    return { success: false, error: err.message };
  }
}
async function pushAppSettingsToCloud(db2) {
  try {
    const rows = db2.prepare("SELECT key, value FROM app_settings").all();
    const allowedKeys = /* @__PURE__ */ new Set([
      "app_title",
      "prepared_by",
      "supervisor_name",
      "supervisor_title",
      "org_name",
      "org_subtitle",
      "active_year_id",
      "active_period_id"
    ]);
    const settingsObj = {};
    for (const r of rows) {
      if (allowedKeys.has(r.key)) {
        settingsObj[r.key] = r.value;
      }
    }
    const activeCtx = getActiveContext(db2);
    const sysToken = activeCtx ? `system_settings|${activeCtx.periodType || "MIDYEAR"}|${activeCtx.yearLabel || ""}|${activeCtx.periodName || ""}` : "system_settings";
    const payload = {
      id: 999999999,
      national_id: "system_app_settings",
      full_name: JSON.stringify(settingsObj),
      school_name: "إعدادات النظام المشتركة",
      password: "system_settings_lock",
      status: sysToken
    };
    await fetch(`${SUPABASE_URL}/rest/v1/portal_principals`, {
      method: "POST",
      headers: { ...HEADERS, "Prefer": "resolution=merge-duplicates" },
      body: JSON.stringify([payload])
    });
  } catch (err) {
    console.warn("[pushAppSettingsToCloud] error:", err);
  }
}
async function pullAppSettingsFromCloud(db2) {
  try {
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?national_id=eq.system_app_settings`, { headers: HEADERS });
    if (!resp.ok) return;
    const rows = await resp.json();
    if (rows && rows.length > 0 && rows[0].full_name) {
      try {
        const parsed = JSON.parse(rows[0].full_name);
        for (const [k, v] of Object.entries(parsed)) {
          db2.prepare(`
            INSERT INTO app_settings (key, value, updated_at)
            VALUES (?, ?, datetime('now', 'localtime'))
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
          `).run(k, String(v ?? ""));
        }
      } catch {
      }
    }
  } catch (err) {
    console.warn("[pullAppSettingsFromCloud] error:", err);
  }
}
async function pushActiveContextToCloud(db2) {
  try {
    ensureSyncColumns(db2);
    const activeCtx = getActiveContext(db2);
    const statusToken = buildPrincipalStatusToken(activeCtx);
    await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?id=gt.0&school_name=not.ilike.*إشراف*&school_name=not.ilike.*مشرف*&school_name=not.ilike.*إعدادات*&national_id=neq.admin&national_id=neq.system_app_version&national_id=neq.system_app_settings&status=not.ilike.*system*`, {
      method: "PATCH",
      headers: HEADERS,
      body: JSON.stringify({ status: statusToken })
    }).catch(() => {
    });
    const sysToken = activeCtx ? `system_settings|${activeCtx.periodType || "MIDYEAR"}|${activeCtx.yearLabel || ""}|${activeCtx.periodName || ""}` : "system_settings";
    await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?national_id=eq.system_app_settings`, {
      method: "PATCH",
      headers: HEADERS,
      body: JSON.stringify({ status: sysToken })
    }).catch(() => {
    });
    const managers = db2.prepare(`
      SELECT m.id, m.full_name, m.national_id, m.employee_number, s.name AS school_name
      FROM managers m
      LEFT JOIN schools s ON s.id = m.school_id
      WHERE m.status = 'active'
    `).all();
    if (managers.length > 0) {
      const payload = managers.map((m) => ({
        id: m.id,
        national_id: (m.national_id || "").trim() || String(m.employee_number || m.id),
        full_name: m.full_name,
        school_name: m.school_name || "المدرسة المسجلة",
        password: (m.national_id || "").trim() || "123456",
        status: statusToken
      }));
      await fetch(`${SUPABASE_URL}/rest/v1/portal_principals`, {
        method: "POST",
        headers: { ...HEADERS, "Prefer": "resolution=merge-duplicates" },
        body: JSON.stringify(payload)
      }).catch(() => {
      });
    }
    return true;
  } catch (err) {
    console.warn("[pushActiveContextToCloud] Warning:", err);
    return false;
  }
}
let isSyncActive = false;
async function syncWithCloud(db2, options = {}) {
  if (isSyncActive) {
    return { success: true, skipped: true };
  }
  try {
    const syncSetting = db2.prepare("SELECT value FROM app_settings WHERE key = 'cloud_sync_enabled'").get();
    if (syncSetting && syncSetting.value === "false" && !options?.forceFull) {
      return { success: true, skipped: true, disabled: true };
    }
  } catch {
  }
  isSyncActive = true;
  try {
    const forceFull = options?.forceFull === true;
    ensureSyncColumns(db2);
    await migrateLegacyEmbeddedPlanFiles(db2);
    const result2 = {
      pushedPrincipals: 0,
      pushedEvaluations: 0,
      pulledEvidences: 0,
      pulledPlans: 0,
      errors: []
    };
    const activeCtx = getActiveContext(db2);
    const statusToken = buildPrincipalStatusToken(activeCtx);
    await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?id=gt.0&status=not.ilike.*deleted*&status=not.ilike.*system*&school_name=not.ilike.*إشراف*&school_name=not.ilike.*مشرف*&school_name=not.ilike.*إعدادات*&national_id=neq.admin&national_id=neq.system_app_version&national_id=neq.system_app_settings`, {
      method: "PATCH",
      headers: HEADERS,
      body: JSON.stringify({ status: statusToken })
    }).catch(() => {
    });
    try {
      await pullPrincipalsFromCloud(db2);
    } catch (pullPrincipalsErr) {
      console.warn("[syncWithCloud] pullPrincipalsFromCloud warning:", pullPrincipalsErr);
    }
    try {
      await pullAppSettingsFromCloud(db2);
    } catch (pullSettingsErr) {
      console.warn("[syncWithCloud] pullAppSettingsFromCloud warning:", pullSettingsErr);
    }
    try {
      await pullEvaluationsFromCloud(db2);
    } catch (pullEvalsErr) {
      console.warn("[syncWithCloud] pullEvaluationsFromCloud warning:", pullEvalsErr);
    }
    const managerWhere = [
      "(m.status = 'active' OR m.id IN (SELECT manager_id FROM evaluations WHERE status = 'approved'))"
    ];
    if (!forceFull) {
      managerWhere.push("(m.cloud_synced_at IS NULL OR m.updated_at > m.cloud_synced_at)");
    }
    const managers = db2.prepare(`
      SELECT m.id, m.full_name, m.national_id, m.employee_number, s.name AS school_name
      FROM managers m
      LEFT JOIN schools s ON s.id = m.school_id
      WHERE ${managerWhere.join(" AND ")}
    `).all();
    if (managers.length > 0) {
      const principalsPayload = managers.map((m) => ({
        id: m.id,
        national_id: (m.national_id || "").trim() || String(m.employee_number || m.id),
        full_name: m.full_name,
        school_name: m.school_name || "المدرسة المسجلة",
        password: (m.national_id || "").trim() || "123456",
        status: statusToken
      }));
      const resp = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals`, {
        method: "POST",
        headers: { ...HEADERS, "Prefer": "resolution=merge-duplicates" },
        body: JSON.stringify(principalsPayload)
      });
      if (resp.ok) {
        result2.pushedPrincipals = principalsPayload.length;
        const managerIds = managers.map((m) => m.id);
        db2.prepare(`
          UPDATE managers
          SET cloud_synced_at = datetime('now', 'localtime')
          WHERE id IN (${managerIds.map(() => "?").join(",")})
        `).run(...managerIds);
      } else {
        const errText = await resp.text();
        result2.errors.push(`فشل رفع المدراء: ${errText}`);
      }
    }
    await pushAppSettingsToCloud(db2).catch(() => {
    });
    const evalWhere = ["e.status = 'approved'"];
    if (!forceFull) {
      evalWhere.push("(e.cloud_synced_at IS NULL OR e.updated_at > e.cloud_synced_at)");
    }
    const approvedEvals = db2.prepare(`
      SELECT e.id, e.manager_id, m.national_id, m.employee_number,
             ay.label AS year_label, ep.name AS period_name, ep.period_type,
             e.status, e.final_score, e.general_rating, e.notes, e.approved_at
      FROM evaluations e
      JOIN managers m ON m.id = e.manager_id
      JOIN academic_years ay ON ay.id = e.academic_year_id
      JOIN evaluation_periods ep ON ep.id = e.period_id
      WHERE ${evalWhere.join(" AND ")}
    `).all();
    if (approvedEvals.length > 0) {
      const evalsPayload = [];
      for (const ev of approvedEvals) {
        const items = db2.prepare(`
          SELECT element_number, name, weight_bp, score_value, level_label, notes
          FROM evaluation_item_snapshots
          WHERE evaluation_id = ?
          ORDER BY element_number
        `).all(ev.id).map((it) => ({
          num: it.element_number,
          name: it.name,
          weight: it.weight_bp ? it.weight_bp / 100 : 5.26,
          score: it.score_value || 0,
          levelLabel: it.level_label || "",
          notes: (it.notes || "").trim()
        }));
        const natId = (ev.national_id || "").trim() || String(ev.employee_number || ev.manager_id);
        const cloudMgrId = await resolveCloudManagerId(natId, ev.manager_id);
        evalsPayload.push({
          id: ev.id,
          manager_id: cloudMgrId ?? ev.manager_id,
          national_id: natId,
          year_label: ev.year_label,
          period_name: ev.period_name,
          period_type: ev.period_type || "MIDYEAR",
          status: "approved",
          final_score: ev.final_score,
          general_rating: ev.general_rating || "",
          notes: ev.notes || "",
          items,
          approved_at: ev.approved_at || (/* @__PURE__ */ new Date()).toISOString(),
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      const evalResp = await fetch(`${SUPABASE_URL}/rest/v1/portal_evaluations`, {
        method: "POST",
        headers: { ...HEADERS, "Prefer": "resolution=merge-duplicates" },
        body: JSON.stringify(evalsPayload)
      });
      if (evalResp.ok) {
        result2.pushedEvaluations = evalsPayload.length;
        const evalIds = approvedEvals.map((e) => e.id);
        db2.prepare(`
          UPDATE evaluations
          SET cloud_synced_at = datetime('now', 'localtime')
          WHERE id IN (${evalIds.map(() => "?").join(",")})
        `).run(...evalIds);
      } else {
        const errText = await evalResp.text();
        result2.errors.push(`فشل رفع التقييمات: ${errText}`);
      }
    }
    const evResp = await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?uploaded_by=eq.principal&order=created_at.desc&limit=500`, {
      method: "GET",
      headers: HEADERS
    });
    if (evResp.ok) {
      const incomingEvidences = await evResp.json();
      for (const ev of incomingEvidences) {
        const mgr = db2.prepare("SELECT id, full_name FROM managers WHERE national_id = ? OR id = ?").get(ev.national_id, ev.manager_id);
        if (mgr) {
          const existingNotif = db2.prepare("SELECT id FROM app_notifications WHERE portal_id = ? AND type = ?").get(String(ev.id), "evidence");
          let insertedEvId = null;
          if (!existingNotif) {
            const { savedAttachments, description, tagInfo } = await parseIncomingEvidenceContent(ev);
            const { yearId, periodId } = resolveLocalYearAndPeriod(db2, tagInfo, activeCtx);
            const matchedEval = yearId && periodId ? db2.prepare(`
                  SELECT id FROM evaluations
                  WHERE manager_id = ? AND academic_year_id = ? AND period_id = ?
                    AND status IN ('draft', 'completed', 'approved')
                  ORDER BY updated_at DESC LIMIT 1
                `).get(mgr.id, yearId, periodId) : null;
            const evalId = matchedEval ? matchedEval.id : null;
            const firstFile = savedAttachments[0] || null;
            const attachmentsJson = savedAttachments.length > 0 ? JSON.stringify(savedAttachments) : null;
            const insRes = db2.prepare(`
              INSERT INTO evidences
                (manager_id, evaluation_id, academic_year_id, period_id, portal_id, element_number, title, description,
                 file_path, file_name, file_size, mime_type, attachments_json, updated_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))
            `).run(
              mgr.id,
              evalId,
              yearId || null,
              periodId || null,
              ev.id,
              ev.element_number,
              ev.title,
              description,
              firstFile ? firstFile.filePath : null,
              firstFile ? firstFile.fileName : null,
              firstFile ? firstFile.fileSize : 0,
              firstFile ? firstFile.mimeType : null,
              attachmentsJson
            );
            insertedEvId = insRes.lastInsertRowid;
            try {
              const filesBadge = savedAttachments.length > 1 ? ` (${savedAttachments.length} ملفات مرفقة)` : "";
              db2.prepare(`
                INSERT OR IGNORE INTO app_notifications (title, message, type, reference_id, manager_id, portal_id, is_read, created_at)
                VALUES (?, ?, 'evidence', ?, ?, ?, 0, datetime('now', 'localtime'))
              `).run(
                `شاهد جديد: ${mgr.full_name || "مدير المدرسة"}`,
                `قام المدير برفع شاهد في المعيار (${ev.element_number}): "${ev.title || "شاهد إلكتروني"}"${filesBadge}`,
                String(mgr.id),
                mgr.id,
                String(ev.id)
              );
            } catch (notifErr) {
              console.warn("[CloudSync] Notification insert failed:", notifErr);
            }
            result2.pulledEvidences++;
          }
          if (insertedEvId) {
            await pushSingleEvidenceComments(db2, insertedEvId);
          } else {
            await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?id=eq.${ev.id}`, {
              method: "PATCH",
              headers: HEADERS,
              body: JSON.stringify({ synced_to_desktop: true })
            }).catch(() => {
            });
          }
        }
      }
    }
    const plResp = await fetch(
      `${SUPABASE_URL}/rest/v1/portal_plans?uploaded_by=eq.principal&status=neq.supervisor_alert&order=created_at.desc&limit=500`,
      { method: "GET", headers: HEADERS }
    );
    if (plResp.ok) {
      const incomingPlans = await plResp.json();
      for (const pl of incomingPlans) {
        const mgr = db2.prepare("SELECT id, full_name FROM managers WHERE national_id = ? OR id = ?").get(pl.national_id, pl.manager_id);
        if (mgr) {
          const existingNotif = db2.prepare("SELECT id FROM app_notifications WHERE portal_id = ? AND type = ?").get(String(pl.id), "plan");
          let insertedPlanId = null;
          if (!existingNotif) {
            const tagInfo = extractContextTag(pl.actions);
            const { yearId, periodId } = resolveLocalYearAndPeriod(db2, tagInfo, activeCtx);
            const matchedEval = yearId ? db2.prepare(`
                  SELECT id FROM evaluations
                  WHERE manager_id = ? AND academic_year_id = ?
                    AND status IN ('draft', 'completed', 'approved')
                  ORDER BY updated_at DESC LIMIT 1
                `).get(mgr.id, yearId) : null;
            const evalId = matchedEval ? matchedEval.id : null;
            const elNum = pl.element_number ? Number(pl.element_number) : null;
            const parsedPlan = await extractFilesFromPlanActionsString(pl.actions);
            const cleanActions = parsedPlan.cleanText;
            const extractedFiles = parsedPlan.extractedFiles;
            const attachmentsJson = extractedFiles.length > 0 ? JSON.stringify(extractedFiles) : null;
            const insRes = db2.prepare(`
              INSERT INTO improvement_plans
                (manager_id, evaluation_id, academic_year_id, period_id, portal_id, element_number, goal, actions, status, notes, attachments_json, updated_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'not_started', NULL, ?, datetime('now', 'localtime'))
            `).run(
              mgr.id,
              evalId,
              yearId || null,
              periodId || null,
              pl.id,
              elNum,
              pl.goal,
              cleanActions || null,
              attachmentsJson
            );
            insertedPlanId = insRes.lastInsertRowid;
            try {
              const planTypeDesc = elNum ? `في المعيار (${elNum})` : "خطة تطوير عامة للمدرسة";
              const filesInfo = extractedFiles.length > 0 ? ` (${extractedFiles.length} ${extractedFiles.length === 1 ? "ملف مرفق" : "ملفات مرفقة"})` : "";
              db2.prepare(`
                INSERT OR IGNORE INTO app_notifications (title, message, type, reference_id, manager_id, portal_id, is_read, created_at)
                VALUES (?, ?, 'plan', ?, ?, ?, 0, datetime('now', 'localtime'))
              `).run(
                `خطة تحسين جديدة: ${mgr.full_name || "مدير المدرسة"}`,
                `قام المدير بإضافة خطة تحسين ${planTypeDesc}: "${pl.goal || "هدف جديد"}"${filesInfo}`,
                String(mgr.id),
                mgr.id,
                String(pl.id)
              );
            } catch (notifErr) {
              console.warn("[CloudSync] Notification insert failed:", notifErr);
            }
            result2.pulledPlans++;
          }
          if (insertedPlanId) {
            await pushSinglePlanFollowUps(db2, insertedPlanId);
          } else {
            await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?id=eq.${pl.id}`, {
              method: "PATCH",
              headers: HEADERS,
              body: JSON.stringify({ synced_to_desktop: true })
            }).catch(() => {
            });
          }
        }
      }
    }
    const localPlans = db2.prepare(`
      SELECT p.id, p.manager_id, p.portal_id, p.element_number, p.goal, p.actions, p.notes, p.status,
             p.attachments_json, m.national_id, m.employee_number,
             ay.label AS year_label,
             ep.name AS period_name,
             ep.period_type AS period_type
      FROM improvement_plans p
      JOIN managers m ON m.id = p.manager_id
      LEFT JOIN evaluations e ON e.id = p.evaluation_id
      LEFT JOIN academic_years ay ON ay.id = COALESCE(p.academic_year_id, e.academic_year_id)
      LEFT JOIN evaluation_periods ep ON ep.id = COALESCE(p.period_id, e.period_id)
      WHERE p.is_archived = 0
    `).all();
    for (const lp of localPlans) {
      const followUpCount = db2.prepare("SELECT COUNT(*) AS c FROM plan_follow_ups WHERE plan_id = ?").get(lp.id)?.c || 0;
      const hasNotes = followUpCount > 0 || Boolean(cleanPlanNotesText(lp.notes));
      try {
        await syncPlanRecordToCloud(db2, lp, { createIfMissing: hasNotes });
      } catch (e) {
        console.warn("[CloudSync] Failed to sync plan follow-ups:", lp.goal, e);
      }
    }
    const evidencesToSync = db2.prepare(`
      SELECT e.id AS evidence_id,
             (SELECT COUNT(*) FROM evidence_comments ec WHERE ec.evidence_id = e.id) AS c_cnt
      FROM evidences e
      WHERE e.is_archived = 0
    `).all();
    for (const ce of evidencesToSync) {
      await pushSingleEvidenceComments(db2, ce.evidence_id, { createIfMissing: ce.c_cnt > 0 }).catch(() => {
      });
    }
    const unsyncedAlerts = db2.prepare(`
      SELECT id FROM supervisor_alerts WHERE portal_id IS NULL
    `).all();
    for (const ua of unsyncedAlerts) {
      await pushManagerAlertToCloud(db2, ua.id).catch(() => {
      });
    }
    try {
      const alertResp = await fetch(
        `${SUPABASE_URL}/rest/v1/portal_plans?uploaded_by=eq.supervisor&status=eq.supervisor_alert&synced_to_desktop=eq.false&limit=100`,
        { method: "GET", headers: HEADERS }
      );
      if (alertResp && alertResp.ok) {
        const incomingAlerts = await alertResp.json();
        for (const sa of incomingAlerts) {
          const mgr = db2.prepare("SELECT id FROM managers WHERE national_id = ? OR id = ?").get(sa.national_id, sa.manager_id);
          if (mgr) {
            const existing = db2.prepare("SELECT id FROM supervisor_alerts WHERE portal_id = ?").get(sa.id);
            if (!existing) {
              const cleanMsg = (sa.actions || "").replace(/<!--CTX:[\s\S]*?-->\s*/g, "").trim();
              db2.prepare(`
                INSERT INTO supervisor_alerts (manager_id, portal_id, title, message, created_at)
                VALUES (?, ?, ?, ?, ?)
              `).run(mgr.id, sa.id, sa.goal || "تنبيه وتوجيه إشرافي", cleanMsg || sa.goal, sa.created_at || (/* @__PURE__ */ new Date()).toISOString());
            }
            await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?id=eq.${sa.id}`, {
              method: "PATCH",
              headers: HEADERS,
              body: JSON.stringify({ synced_to_desktop: true })
            }).catch(() => {
            });
          }
        }
      }
    } catch (eAlert) {
      console.warn("[CloudSync] Pull alerts warning:", eAlert);
    }
    result2.success = true;
    try {
      electron.BrowserWindow.getAllWindows().forEach((win) => {
        if (!win.isDestroyed()) {
          win.webContents.send("data:changed", result2);
        }
      });
    } catch {
    }
    return result2;
  } catch (err) {
    console.error("[CloudSync Error]", err);
    result.success = false;
    result.errors.push(err.message);
    return result;
  } finally {
    isSyncActive = false;
  }
}
async function pushSinglePlanFollowUps(db2, planId) {
  try {
    ensureSyncColumns(db2);
    await migrateLegacyEmbeddedPlanFiles(db2);
    const lp = db2.prepare(`
      SELECT p.id, p.manager_id, p.portal_id, p.element_number, p.goal, p.actions, p.notes, p.status,
             p.attachments_json, m.national_id, m.employee_number,
             ay.label AS year_label,
             ep.name AS period_name,
             ep.period_type AS period_type
      FROM improvement_plans p
      JOIN managers m ON m.id = p.manager_id
      LEFT JOIN evaluations e ON e.id = p.evaluation_id
      LEFT JOIN academic_years ay ON ay.id = COALESCE(p.academic_year_id, e.academic_year_id)
      LEFT JOIN evaluation_periods ep ON ep.id = COALESCE(p.period_id, e.period_id)
      WHERE p.id = ?
    `).get(planId);
    if (!lp) return false;
    await syncPlanRecordToCloud(db2, lp, { createIfMissing: true });
    return true;
  } catch (err) {
    console.warn("[pushSinglePlanFollowUps] Warning:", err);
    return false;
  }
}
async function pullPrincipalsFromCloud(db2) {
  let pulled = 0;
  try {
    const syncSetting = db2.prepare("SELECT value FROM app_settings WHERE key = 'cloud_sync_enabled'").get();
    if (syncSetting && syncSetting.value === "false") {
      return 0;
    }
  } catch {
  }
  try {
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?order=id.asc`, { headers: HEADERS });
    if (!resp.ok) return 0;
    const cloudPrincipals = await resp.json();
    const activeCloudNatIds = /* @__PURE__ */ new Set();
    for (const p of cloudPrincipals) {
      try {
        if (!p) continue;
        if (p.status && (p.status.includes("supervisor") || p.status.includes("deleted"))) continue;
        if (p.school_name && (p.school_name.includes("إشراف") || p.school_name.includes("مشرف"))) continue;
        if (p.national_id === "admin" || p.national_id === "system_app_version" || p.national_id === "system_app_settings") continue;
        const cleanNatId = (p.national_id || "").trim();
        if (!cleanNatId) continue;
        activeCloudNatIds.add(cleanNatId);
        let schoolId = null;
        if (p.school_name && p.school_name !== "المدرسة المسجلة") {
          const sRow = db2.prepare("SELECT id FROM schools WHERE name = ?").get(p.school_name);
          if (sRow) {
            schoolId = sRow.id;
          } else {
            const insS = db2.prepare(`
              INSERT INTO schools (name)
              VALUES (?)
            `).run(p.school_name);
            schoolId = insS.lastInsertRowid;
          }
        }
        let localMgr = db2.prepare("SELECT id, full_name, school_id FROM managers WHERE national_id = ?").get(cleanNatId);
        if (!localMgr) {
          const idTaken = p.id ? db2.prepare("SELECT id FROM managers WHERE id = ?").get(p.id) : null;
          if (idTaken) {
            db2.prepare(`
              INSERT INTO managers (full_name, national_id, employee_number, school_id, status, cloud_synced_at, created_at, updated_at)
              VALUES (?, ?, NULL, ?, 'active', datetime('now', 'localtime'), datetime('now', 'localtime'), datetime('now', 'localtime'))
            `).run(p.full_name, cleanNatId, schoolId);
          } else {
            db2.prepare(`
              INSERT INTO managers (id, full_name, national_id, employee_number, school_id, status, cloud_synced_at, created_at, updated_at)
              VALUES (?, ?, ?, NULL, ?, 'active', datetime('now', 'localtime'), datetime('now', 'localtime'), datetime('now', 'localtime'))
            `).run(p.id, p.full_name, cleanNatId, schoolId);
          }
          pulled++;
        } else {
          db2.prepare(`
            UPDATE managers
            SET full_name = COALESCE(?, full_name),
                school_id = COALESCE(?, school_id),
                status = 'active',
                cloud_synced_at = datetime('now', 'localtime'),
                updated_at = datetime('now', 'localtime')
            WHERE id = ?
          `).run(p.full_name || null, schoolId || null, localMgr.id);
        }
      } catch (rowErr) {
        console.warn(`[pullPrincipalsFromCloud] error processing principal ${p?.id}:`, rowErr);
      }
    }
    const syncedLocalManagers = db2.prepare(`
      SELECT id, national_id
      FROM managers
      WHERE cloud_synced_at IS NOT NULL
    `).all();
    for (const lm of syncedLocalManagers) {
      const cleanLocalNat = (lm.national_id || "").trim();
      if (cleanLocalNat && !activeCloudNatIds.has(cleanLocalNat)) {
        try {
          db2.prepare("DELETE FROM plan_follow_ups WHERE plan_id IN (SELECT id FROM improvement_plans WHERE manager_id = ?)").run(lm.id);
          db2.prepare("DELETE FROM improvement_plans WHERE manager_id = ?").run(lm.id);
          db2.prepare("DELETE FROM evidence_comments WHERE evidence_id IN (SELECT id FROM evidences WHERE manager_id = ?)").run(lm.id);
          db2.prepare("DELETE FROM evidences WHERE manager_id = ?").run(lm.id);
          db2.prepare("DELETE FROM evaluation_item_snapshots WHERE evaluation_id IN (SELECT id FROM evaluations WHERE manager_id = ?)").run(lm.id);
          db2.prepare("DELETE FROM evaluations WHERE manager_id = ?").run(lm.id);
          db2.prepare("DELETE FROM supervisor_alerts WHERE manager_id = ?").run(lm.id);
          db2.prepare("DELETE FROM managers WHERE id = ?").run(lm.id);
        } catch (delErr) {
          console.warn("[pullPrincipalsFromCloud] error deleting local removed manager:", delErr);
        }
      }
    }
  } catch (err) {
    console.warn("[pullPrincipalsFromCloud] error:", err);
  }
  return pulled;
}
async function pullEvaluationsFromCloud(db2) {
  let pulled = 0;
  try {
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/portal_evaluations?status=eq.approved`, { headers: HEADERS });
    if (!resp.ok) return 0;
    const cloudEvals = await resp.json();
    const activeCtx = getActiveContext(db2);
    for (const cev of cloudEvals) {
      try {
        const cleanNatId = (cev.national_id || "").trim();
        if (!cleanNatId) continue;
        const mgr = db2.prepare("SELECT id FROM managers WHERE national_id = ? OR id = ?").get(cleanNatId, cev.manager_id);
        if (!mgr) continue;
        const yrRow = cev.year_label ? db2.prepare("SELECT id FROM academic_years WHERE label = ?").get(cev.year_label) : null;
        const yearId = yrRow ? yrRow.id : activeCtx?.yearId || null;
        let periodId = null;
        if (yearId && cev.period_type) {
          const pr = db2.prepare("SELECT id FROM evaluation_periods WHERE academic_year_id = ? AND period_type = ? LIMIT 1").get(yearId, cev.period_type);
          if (pr) periodId = pr.id;
        }
        if (!periodId && yearId && cev.period_name) {
          const pr2 = db2.prepare("SELECT id FROM evaluation_periods WHERE academic_year_id = ? AND name = ? LIMIT 1").get(yearId, cev.period_name);
          if (pr2) periodId = pr2.id;
        }
        if (!periodId) periodId = activeCtx?.periodId || null;
        const existingEval = db2.prepare("SELECT id FROM evaluations WHERE id = ? OR (manager_id = ? AND academic_year_id = ? AND period_id = ?)").get(cev.id, mgr.id, yearId, periodId);
        if (!existingEval) {
          const insEval = db2.prepare(`
            INSERT INTO evaluations (id, manager_id, academic_year_id, period_id, status, final_score, general_rating, notes, approved_at, cloud_synced_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'approved', ?, ?, ?, ?, datetime('now', 'localtime'), datetime('now', 'localtime'), datetime('now', 'localtime'))
          `).run(cev.id, mgr.id, yearId, periodId, cev.final_score, cev.general_rating, cev.notes, cev.approved_at);
          const evalId = insEval.lastInsertRowid || cev.id;
          if (Array.isArray(cev.items)) {
            for (const it of cev.items) {
              db2.prepare(`
                INSERT OR REPLACE INTO evaluation_item_snapshots
                  (evaluation_id, element_number, name, weight_bp, score_value, level_label, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
              `).run(
                evalId,
                it.num || it.element_number,
                it.name || `معيار ${it.num || it.element_number}`,
                Math.round((it.weight || 5) * 100),
                it.score || 0,
                it.levelLabel || "",
                it.notes || ""
              );
            }
          }
          pulled++;
        }
      } catch (evRowErr) {
        console.warn(`[pullEvaluationsFromCloud] error processing evaluation ${cev?.id}:`, evRowErr);
      }
    }
  } catch (err) {
    console.warn("[pullEvaluationsFromCloud] error:", err);
  }
  return pulled;
}
async function purgeCloudAttachments(db2) {
  ensureSyncColumns(db2);
  const backupRes = await createAutoBackup(db2, "pre-cloud-purge");
  let purgedEvidences = 0;
  let purgedPlans = 0;
  try {
    const evResp = await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?content=like.*MULTI_FILES_JSON*&select=id,content`, { headers: HEADERS });
    if (evResp.ok) {
      const rows = await evResp.json();
      for (const row of rows) {
        const raw = row.content || "";
        const ctxMatch = raw.match(/<!--CTX:[\s\S]*?-->\s*/);
        const ctxPart = ctxMatch ? ctxMatch[0] : "";
        let commentsPart = "";
        if (raw.includes("<!--SUPERVISOR_COMMENTS-->")) {
          commentsPart = "<!--SUPERVISOR_COMMENTS-->" + raw.split("<!--SUPERVISOR_COMMENTS-->")[1];
        }
        let metaNotice = "<!--PURGED-->\n[تم تنزيل الشاهد ومرفقاته إلى أرشيف البرنامج المكتبي وحفظه محلياً على الجهاز]";
        try {
          const jsonMatch = raw.match(/<!--MULTI_FILES_JSON-->([\s\S]*?)(?:<!--SUPERVISOR_COMMENTS-->|$)/);
          if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[1].trim());
            const fileNames = (parsed.files || []).map((f) => f.name).filter(Boolean);
            if (fileNames.length > 0) {
              metaNotice += `
المرفقات المؤرشفة: ${fileNames.join(" ، ")}`;
            }
          }
        } catch (_) {
        }
        const cleanContent = `${ctxPart}${metaNotice}
${commentsPart}`.trim();
        await fetch(`${SUPABASE_URL}/rest/v1/portal_evidences?id=eq.${row.id}`, {
          method: "PATCH",
          headers: HEADERS,
          body: JSON.stringify({ content: cleanContent, evidence_type: "archived_file" })
        });
        purgedEvidences++;
      }
    }
    const plResp = await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?actions=like.*PLAN_FILES_JSON*&select=id,actions`, { headers: HEADERS });
    if (plResp.ok) {
      const rows = await plResp.json();
      for (const row of rows) {
        let acts = row.actions || "";
        acts = acts.replace(/<!--PLAN_FILES_JSON:[\s\S]*?-->/g, "<!--PLAN_FILES_ARCHIVED-->\n[تمت أرشفة ملفات الخطة محلياً]");
        await fetch(`${SUPABASE_URL}/rest/v1/portal_plans?id=eq.${row.id}`, {
          method: "PATCH",
          headers: HEADERS,
          body: JSON.stringify({ actions: acts })
        });
        purgedPlans++;
      }
    }
  } catch (err) {
    console.error("[purgeCloudAttachments] error:", err);
    throw new Error("فشل تفريغ بعض الملفات السحابية: " + err.message);
  }
  return {
    success: true,
    backupPath: backupRes.filePath,
    purgedEvidences,
    purgedPlans
  };
}
async function listWebSupervisors() {
  const resp = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?or=(status.like.*supervisor*,school_name.ilike.*إشراف*,school_name.ilike.*مشرف*,national_id.eq.admin)&order=created_at.desc`, { headers: HEADERS });
  if (!resp.ok) return [];
  const rows = await resp.json();
  return rows.map((r) => ({
    id: r.id,
    username: r.national_id,
    fullName: r.full_name,
    schoolName: r.school_name,
    password: r.password,
    canComment: !r.status.includes("can_comment:false"),
    createdAt: r.created_at
  }));
}
async function addWebSupervisor({ username, password, fullName, canComment = true }) {
  const u = (username || "").trim();
  const p = (password || "").trim();
  const n = (fullName || "").trim();
  if (!u || !p || !n) throw new Error("يرجى ملء جميع الحقول المطلوبة للمشرف");
  const check = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?national_id=eq.${encodeURIComponent(u)}`, { headers: HEADERS });
  if (check.ok) {
    const existing = await check.json();
    if (existing && existing.length > 0) throw new Error("اسم المستخدم هذا مستخدم مسبقاً، يرجى اختيار اسم مستخدم آخر");
  }
  const payload = {
    id: Date.now(),
    national_id: u,
    full_name: n,
    school_name: "إشراف عام / إدارة التعليم",
    password: p,
    status: `role:supervisor|can_comment:${canComment ? "true" : "false"}`
  };
  const res = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals`, {
    method: "POST",
    headers: { ...HEADERS, "Prefer": "return=representation" },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error("تعذر حفظ حساب المشرف في السحابة");
  return true;
}
async function updateWebSupervisor(id, { username, password, fullName, canComment = true }) {
  const payload = {};
  if (username) payload.national_id = username.trim();
  if (fullName) payload.full_name = fullName.trim();
  if (password) payload.password = password.trim();
  payload.status = `role:supervisor|can_comment:${canComment ? "true" : "false"}`;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?id=eq.${id}`, {
    method: "PATCH",
    headers: HEADERS,
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error("تعذر تحديث بيانات المشرف");
  return true;
}
async function deleteWebSupervisor(id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?id=eq.${id}`, {
    method: "DELETE",
    headers: HEADERS
  });
  return res.ok;
}
function extractVersionFromFilename(filename) {
  if (!filename) return null;
  const m = String(filename).match(/[vV]?(\d+\.\d+(?:\.\d+)?)/);
  return m ? m[1] : null;
}
function parseSemver(v) {
  if (!v) return [0, 0, 0];
  const clean = String(v).replace(/^[vV]/, "").trim();
  const parts = clean.split(".").map((p) => parseInt(p, 10) || 0);
  while (parts.length < 3) parts.push(0);
  return parts;
}
function isNewerVersion(newer, current) {
  if (!newer) return false;
  if (!current) return true;
  const [n1, n2, n3] = parseSemver(newer);
  const [c1, c2, c3] = parseSemver(current);
  if (n1 !== c1) return n1 > c1;
  if (n2 !== c2) return n2 > c2;
  return n3 > c3;
}
async function syncUpdateToSupabase(updateData) {
  try {
    const payload = {
      national_id: "system_app_version",
      password: String(updateData.latestVersion || ""),
      full_name: String(updateData.notes || "تحديث النظام"),
      status: String(updateData.downloadUrl || ""),
      school_name: String(updateData.fileName || "ملف التحديث")
    };
    await fetch(`${SUPABASE_URL}/rest/v1/portal_principals`, {
      method: "POST",
      headers: { ...HEADERS, "Prefer": "resolution=merge-duplicates" },
      body: JSON.stringify(payload)
    });
  } catch (_) {
  }
}
async function checkSystemUpdate(currentVersion) {
  const GITHUB_REPO = "hg5g/Repository-name";
  const GITHUB_BRANCH = "main";
  try {
    const ghUrl = `https://api.github.com/repos/${GITHUB_REPO}/contents/updates?ref=${GITHUB_BRANCH}`;
    const ghResp = await fetch(ghUrl, {
      headers: {
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "PrincipalsEvaluationApp"
      }
    });
    if (ghResp.ok) {
      const items = await ghResp.json();
      if (Array.isArray(items)) {
        const updateFiles = items.filter(
          (f) => f.type === "file" && f.name !== ".gitkeep" && f.name !== "README.md" && (f.name.endsWith(".exe") || f.name.endsWith(".zip") || f.name.endsWith(".msi") || f.name.endsWith(".pkg"))
        );
        if (updateFiles.length > 0) {
          const scored = updateFiles.map((f) => {
            const ver = extractVersionFromFilename(f.name);
            return {
              file: f,
              version: ver,
              isNewer: ver ? isNewerVersion(ver, currentVersion) : true
            };
          }).filter((x) => x.isNewer);
          if (scored.length > 0) {
            scored.sort((a, b) => {
              if (!a.version && !b.version) return 0;
              if (!a.version) return 1;
              if (!b.version) return -1;
              return isNewerVersion(a.version, b.version) ? -1 : 1;
            });
            const best = scored[0];
            const downloadUrl = best.file.download_url || `https://github.com/${GITHUB_REPO}/raw/${GITHUB_BRANCH}/updates/${encodeURIComponent(best.file.name)}`;
            const result2 = {
              hasUpdate: true,
              latestVersion: best.version || "إصدار جديد",
              currentVersion,
              fileName: best.file.name,
              fileSize: best.file.size || 0,
              notes: `ملف تحديث جديد متاح (${best.file.name}) تم رصده في مجلد updates على GitHub`,
              downloadUrl,
              source: "github_updates_folder"
            };
            syncUpdateToSupabase(result2).catch(() => {
            });
            return result2;
          } else {
            return {
              hasUpdate: false,
              latestVersion: currentVersion,
              currentVersion,
              notes: "أنت تعمل بالفعل على أحدث إصدار"
            };
          }
        } else {
          return {
            hasUpdate: false,
            latestVersion: currentVersion,
            currentVersion,
            notes: "لا توجد أي ملفات تحديث في مجلد التحديثات"
          };
        }
      }
    }
  } catch (err) {
    console.warn("GitHub updates folder check failed, trying fallback:", err);
  }
  try {
    const relUrl = `https://api.github.com/repos/${GITHUB_REPO}/releases/latest`;
    const relResp = await fetch(relUrl, {
      headers: { "Accept": "application/vnd.github.v3+json", "User-Agent": "PrincipalsEvaluationApp" }
    });
    if (relResp.ok) {
      const rel = await relResp.json();
      const tagVer = (rel.tag_name || "").replace(/^[vV]/, "").trim();
      if (tagVer && isNewerVersion(tagVer, currentVersion)) {
        const asset = (rel.assets || []).find((a) => a.name.endsWith(".exe") || a.name.endsWith(".zip"));
        const downloadUrl = asset ? asset.browser_download_url : rel.html_url;
        const res = {
          hasUpdate: true,
          latestVersion: tagVer,
          currentVersion,
          fileName: asset ? asset.name : "تحديث النظام",
          fileSize: asset ? asset.size : 0,
          notes: rel.body || "تحديث جديد من إصدارات GitHub",
          downloadUrl,
          source: "github_releases"
        };
        syncUpdateToSupabase(res).catch(() => {
        });
        return res;
      }
    }
  } catch (_) {
  }
  try {
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/portal_principals?national_id=eq.system_app_version`, { headers: HEADERS });
    if (resp.ok) {
      const rows = await resp.json();
      if (rows && rows.length > 0) {
        const latestVer = rows[0].password || rows[0].school_name;
        const notes = rows[0].full_name || "";
        const downloadUrl = rows[0].status || "";
        if (latestVer && isNewerVersion(latestVer, currentVersion)) {
          return {
            hasUpdate: true,
            latestVersion: latestVer,
            currentVersion,
            notes,
            downloadUrl,
            source: "supabase"
          };
        }
      }
    }
  } catch (_) {
  }
  return { hasUpdate: false, currentVersion };
}
function wrap$i(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerManagersIpc(ipc, db2) {
  ipc.handle("managers:list", wrap$i(async (_e, filters) => {
    try {
      await pullPrincipalsFromCloud(db2);
    } catch (pullErr) {
      logger.warn("[managers:list] pullPrincipalsFromCloud warning:", pullErr);
    }
    return listManagers(db2, filters || {});
  }));
  ipc.handle("managers:get", wrap$i((_e, id) => {
    const m = getManagerById(db2, id);
    if (!m) throw Object.assign(new Error("not found"), { userMessage: "المدير غير موجود" });
    return m;
  }));
  ipc.handle("managers:create", wrap$i(async (_e, data) => {
    const res = createManager(db2, data || {});
    try {
      await syncWithCloud(db2, { forceFull: true });
    } catch (syncErr) {
      logger.warn("[managers:create] syncWithCloud warning:", syncErr);
    }
    return res;
  }));
  ipc.handle("managers:update", wrap$i(async (_e, id, data) => {
    const res = updateManager(db2, id, data || {});
    try {
      await syncWithCloud(db2, { forceFull: true });
    } catch (syncErr) {
      logger.warn("[managers:update] syncWithCloud warning:", syncErr);
    }
    return res;
  }));
  ipc.handle("managers:archive", wrap$i(async (_e, id) => {
    const res = setManagerStatus(db2, id, "archived");
    try {
      await syncWithCloud(db2, { forceFull: true });
    } catch (syncErr) {
      logger.warn("[managers:archive] syncWithCloud warning:", syncErr);
    }
    return res;
  }));
  ipc.handle("managers:restore", wrap$i(async (_e, id) => {
    const res = setManagerStatus(db2, id, "active");
    try {
      await syncWithCloud(db2, { forceFull: true });
    } catch (syncErr) {
      logger.warn("[managers:restore] syncWithCloud warning:", syncErr);
    }
    return res;
  }));
  ipc.handle("managers:delete", wrap$i(async (_e, id) => {
    let natId = null;
    try {
      const mgr = db2.prepare("SELECT national_id FROM managers WHERE id = ?").get(id);
      natId = mgr?.national_id;
    } catch {
    }
    const res = deleteManager(db2, id);
    try {
      await deleteManagerFromCloud({ id, nationalId: natId });
    } catch (delErr) {
      logger.warn("[managers:delete] deleteManagerFromCloud warning:", delErr);
    }
    try {
      await syncWithCloud(db2, { forceFull: false });
    } catch (syncErr) {
      logger.warn("[managers:delete] syncWithCloud warning:", syncErr);
    }
    return res;
  }));
  ipc.handle("managers:seedSamples", wrap$i(async () => {
    seedSampleManagers(db2);
    try {
      await syncWithCloud(db2, { forceFull: true });
    } catch {
    }
    return true;
  }));
  ipc.handle("managers:deleteSamples", wrap$i(async () => {
    deleteSampleManagers(db2);
    try {
      await syncWithCloud(db2, { forceFull: true });
    } catch {
    }
    return true;
  }));
}
function wrap$h(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerSettingsIpc(ipc, db2) {
  ipc.handle("settings:getAll", wrap$h(() => {
    const rows = db2.prepare("SELECT key, value FROM app_settings").all();
    const out = {
      app_title: "تقييم أداء مدراء المدارس وفق الدليل الإرشادي لإدارة الأداء الوظيفي لشاغلي الوظائف التعليمية",
      prepared_by: "إعداد وتنسيق : أخصائي الإدارة المدرسية / الحسين إبراهيم شويع",
      org_name: "الإصدار الثاني",
      org_subtitle: ""
    };
    for (const r of rows) out[r.key] = r.value;
    return out;
  }));
  ipc.handle("settings:set", wrap$h((_e, key, value) => {
    db2.prepare(`
      INSERT INTO app_settings (key, value, updated_at)
      VALUES (?, ?, datetime('now', 'localtime'))
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
    `).run(key, String(value ?? ""));
    pushAppSettingsToCloud(db2).catch(() => {
    });
    return true;
  }));
  ipc.handle("settings:dbInfo", wrap$h(() => {
    const row = db2.prepare("PRAGMA database_list").get();
    const size = db2.prepare("SELECT page_count * page_size AS size FROM pragma_page_count(), pragma_page_size()").get();
    return { path: row?.file || "", sizeBytes: size?.size || 0 };
  }));
  ipc.handle("settings:pickFolder", wrap$h(async () => {
    const res = await electron.dialog.showOpenDialog({
      properties: ["openDirectory", "createDirectory"],
      title: "اختر مجلد حفظ البيانات (الشواهد، خطط التحسين، والتقارير)"
    });
    if (res.canceled || !res.filePaths.length) return null;
    return res.filePaths[0];
  }));
  ipc.handle("settings:clearAllManagersData", wrap$h(async () => {
    try {
      await purgeAllCloudData();
    } catch (cloudErr) {
      logger.warn("Failed to purge cloud on clearAllManagersData:", cloudErr);
    }
    db2.pragma("foreign_keys = OFF");
    try {
      const tx = db2.transaction(() => {
        try {
          db2.prepare("DELETE FROM plan_follow_ups").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM improvement_plans").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evidence_comments").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evidences").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM supervisor_alerts").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evaluation_item_snapshots").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evaluations").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM sync_queue").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM managers").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM app_notifications WHERE type IN ('evidence','plan','eval')").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("INSERT INTO audit_log (action, entity_type) VALUES (?, ?)").run("settings.clearAllManagersData", "all_managers");
        } catch (e) {
          logger.warn(e.message);
        }
      });
      tx();
    } finally {
      db2.pragma("foreign_keys = ON");
    }
    return true;
  }));
  ipc.handle("settings:factoryReset", wrap$h(async () => {
    try {
      await purgeAllCloudData();
    } catch (cloudErr) {
      logger.warn("Failed to purge cloud on factoryReset:", cloudErr);
    }
    db2.pragma("foreign_keys = OFF");
    try {
      const tx = db2.transaction(() => {
        try {
          db2.prepare("DELETE FROM plan_follow_ups").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM improvement_plans").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evidence_comments").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evidences").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM supervisor_alerts").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evaluation_item_snapshots").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evaluations").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM sync_queue").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM managers").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM schools").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM school_stages").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM education_administrations").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evaluation_periods").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM academic_years").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM form_version_elements").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM performance_levels").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM form_versions").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM evaluation_forms").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM app_notifications").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM app_settings").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM app_users").run();
        } catch (e) {
          logger.warn(e.message);
        }
        try {
          db2.prepare("DELETE FROM audit_log").run();
        } catch (e) {
          logger.warn(e.message);
        }
      });
      tx();
      try {
        ensureSeedData(db2);
      } catch (e) {
        logger.error("Failed to re-seed defaults after factory reset:", e);
      }
    } finally {
      db2.pragma("foreign_keys = ON");
    }
    return true;
  }));
}
function wrap$g(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerDashboardIpc(ipc, db2) {
  ipc.handle("dashboard:stats", wrap$g(async (_e, filters = {}) => {
    pullPrincipalsFromCloud(db2).catch(() => {
    });
    pullEvaluationsFromCloud(db2).catch(() => {
    });
    const totalManagers = db2.prepare("SELECT COUNT(*) c FROM managers WHERE status='active'").get().c;
    const archivedManagers = db2.prepare("SELECT COUNT(*) c FROM managers WHERE status='archived'").get().c;
    const sampleManagers = db2.prepare("SELECT COUNT(*) c FROM managers WHERE is_sample=1").get().c;
    const whereEval = [];
    const paramsEval = [];
    if (filters.yearId) {
      whereEval.push("e.academic_year_id = ?");
      paramsEval.push(Number(filters.yearId));
    }
    if (filters.periodId) {
      whereEval.push("e.period_id = ?");
      paramsEval.push(Number(filters.periodId));
    }
    const whereSql = whereEval.length ? `WHERE ${whereEval.join(" AND ")}` : "";
    const totalEvaluations = db2.prepare(`SELECT COUNT(*) c FROM evaluations e ${whereSql}`).get(...paramsEval).c;
    const approvedWhereSql = whereEval.length ? `WHERE ${whereEval.join(" AND ")} AND e.status='approved'` : "WHERE e.status='approved'";
    const approvedEvaluations = db2.prepare(`SELECT COUNT(*) c FROM evaluations e ${approvedWhereSql}`).get(...paramsEval).c;
    const draftWhereSql = whereEval.length ? `WHERE ${whereEval.join(" AND ")} AND e.status IN ('draft','completed')` : "WHERE e.status IN ('draft','completed')";
    const draftEvaluations = db2.prepare(`SELECT COUNT(*) c FROM evaluations e ${draftWhereSql}`).get(...paramsEval).c;
    const avgRow = db2.prepare(`SELECT AVG(CAST(e.final_score AS REAL)) AS avgScore FROM evaluations e ${approvedWhereSql}`).get(...paramsEval);
    const averageApprovedScore = avgRow?.avgScore != null ? Number(avgRow.avgScore).toFixed(2) : null;
    const plans = statsForDashboard(db2, { yearId: filters.yearId, periodId: filters.periodId });
    const whereEvid = ["e.is_archived = 0"];
    const paramsEvid = [];
    if (filters.yearId) {
      whereEvid.push("COALESCE(e.academic_year_id, ev.academic_year_id) = ?");
      paramsEvid.push(Number(filters.yearId));
    }
    if (filters.periodId) {
      whereEvid.push("COALESCE(e.period_id, ev.period_id) = ?");
      paramsEvid.push(Number(filters.periodId));
    }
    const totalEvidences = db2.prepare(`
      SELECT COUNT(*) c
      FROM evidences e
      LEFT JOIN evaluations ev ON ev.id = e.evaluation_id
      WHERE ${whereEvid.join(" AND ")}
    `).get(...paramsEvid).c;
    const activeFormVersion = db2.prepare(`
      SELECT fv.version_number, fv.status, fv.activated_at,
             (SELECT COUNT(*) FROM form_version_elements WHERE form_version_id = fv.id) AS elements_count
      FROM form_versions fv
      JOIN evaluation_forms ef ON ef.id = fv.form_id
      WHERE ef.code = 'official' AND fv.status = 'active'
      LIMIT 1
    `).get();
    const latest = db2.prepare(`
      SELECT e.id, e.status, e.final_score, e.general_rating, e.updated_at,
             m.id AS manager_id,
             m.full_name AS manager_name, s.name AS school_name,
             ay.label AS year_label, ep.name AS period_name
      FROM evaluations e
      JOIN managers m ON m.id = e.manager_id
      LEFT JOIN schools s ON s.id = m.school_id
      JOIN academic_years ay ON ay.id = e.academic_year_id
      JOIN evaluation_periods ep ON ep.id = e.period_id
      ${whereSql}
      ORDER BY e.updated_at DESC LIMIT 5
    `).all(...paramsEval);
    const statuses = { draft: 0, completed: 0, approved: 0, superseded: 0 };
    const statusRows = db2.prepare(`SELECT e.status, COUNT(*) AS c FROM evaluations e ${whereSql} GROUP BY e.status`).all(...paramsEval);
    statusRows.forEach((r) => {
      if (statuses[r.status] !== void 0) statuses[r.status] = r.c;
    });
    const scoreRanges = [
      { range: "20 - 40", count: 0 },
      { range: "41 - 60", count: 0 },
      { range: "61 - 75", count: 0 },
      { range: "76 - 89", count: 0 },
      { range: "90 - 100", count: 0 }
    ];
    const approvedScores = db2.prepare(`SELECT CAST(e.final_score AS REAL) AS sc FROM evaluations e ${approvedWhereSql}`).all(...paramsEval);
    approvedScores.forEach((r) => {
      const s = r.sc;
      if (s < 41) scoreRanges[0].count++;
      else if (s < 61) scoreRanges[1].count++;
      else if (s < 76) scoreRanges[2].count++;
      else if (s < 90) scoreRanges[3].count++;
      else scoreRanges[4].count++;
    });
    const elementAverages = db2.prepare(`
      SELECT s.element_number,
             COALESCE(MAX(s.name), 'معيار تقييمي') AS element_name,
             AVG(s.score_value) AS avg_score,
             COUNT(s.score_value) AS filled_count
      FROM evaluation_item_snapshots s
      JOIN evaluations e ON e.id = s.evaluation_id
      ${approvedWhereSql} AND s.score_value IS NOT NULL
      GROUP BY s.element_number
      ORDER BY s.element_number
    `).all(...paramsEval).map((r) => ({
      elementNumber: r.element_number,
      name: r.element_name,
      elementName: r.element_name,
      avgScore: r.avg_score != null ? Number(r.avg_score.toFixed(2)) : null,
      filledCount: r.filled_count
    }));
    const schoolsDist = db2.prepare(`
      SELECT COALESCE(s.name, 'غير محدد') AS school_name, COUNT(m.id) AS manager_count
      FROM managers m
      LEFT JOIN schools s ON s.id = m.school_id
      WHERE m.status = 'active'
      GROUP BY m.school_id
      ORDER BY manager_count DESC
      LIMIT 6
    `).all();
    let periodComparison = [];
    if (filters.yearId) {
      periodComparison = db2.prepare(`
        SELECT ep.name AS period_name, ep.period_type, AVG(CAST(e.final_score AS REAL)) AS avg_score, COUNT(e.id) AS count
        FROM evaluation_periods ep
        LEFT JOIN evaluations e ON e.period_id = ep.id AND e.status = 'approved'
        WHERE ep.academic_year_id = ?
        GROUP BY ep.id
        ORDER BY ep.id
      `).all(Number(filters.yearId)).map((r) => ({
        periodName: r.period_name,
        periodType: r.period_type,
        avgScore: r.avg_score != null ? Number(r.avg_score.toFixed(2)) : 0,
        count: r.count
      }));
    }
    return {
      totalManagers,
      archivedManagers,
      sampleManagers,
      totalEvaluations,
      approvedEvaluations,
      draftEvaluations,
      averageApprovedScore,
      totalEvidences,
      openPlans: plans.totalOpen,
      overduePlans: plans.overdue,
      completedPlans: plans.completed,
      charts: {
        statuses,
        scoreRanges,
        elementAverages,
        schoolsDist,
        periodComparison
      },
      activeFormVersion: activeFormVersion ? {
        versionNumber: activeFormVersion.version_number,
        status: activeFormVersion.status,
        elementsCount: activeFormVersion.elements_count,
        activatedAt: activeFormVersion.activated_at
      } : null,
      latestEvaluations: latest
    };
  }));
}
function userError$5(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function normalizeDigits(str) {
  if (!str) return "";
  return String(str).replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d)).replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)).trim();
}
function rowToYear(r) {
  return {
    id: r.id,
    label: r.label,
    isActive: !!r.is_active,
    isArchived: !!r.is_archived,
    createdAt: r.created_at
  };
}
function listYears(db2) {
  return db2.prepare("SELECT * FROM academic_years ORDER BY label DESC, id DESC").all().map(rowToYear);
}
function createYear(db2, label) {
  const normalized = normalizeDigits(label);
  if (!/^\d{4}$/.test(normalized)) {
    throw userError$5("يرجى إدخال السنة الدراسية من 4 أرقام فقط (مثال: 2027)");
  }
  const existing = db2.prepare("SELECT id FROM academic_years WHERE label = ?").get(normalized);
  if (existing) throw userError$5("هذه السنة موجودة بالفعل");
  let createdYearId = null;
  db2.transaction(() => {
    const r = db2.prepare("INSERT INTO academic_years (label) VALUES (?)").run(normalized);
    createdYearId = r.lastInsertRowid;
    const insPeriod = db2.prepare(
      "INSERT INTO evaluation_periods (academic_year_id, name, period_type, is_active) VALUES (?, ?, ?, 1)"
    );
    insPeriod.run(createdYearId, "التقييم النصف سنوي", "MIDYEAR");
    insPeriod.run(createdYearId, "التقييم النهائي", "FINAL");
  })();
  return { id: createdYearId, label: normalized, isActive: false, isArchived: false };
}
function activateYear(db2, id) {
  const exists = db2.prepare("SELECT id FROM academic_years WHERE id = ?").get(id);
  if (!exists) throw userError$5("السنة غير موجودة");
  db2.transaction(() => {
    db2.prepare("UPDATE academic_years SET is_active = 0").run();
    db2.prepare("UPDATE academic_years SET is_active = 1, is_archived = 0 WHERE id = ?").run(id);
    db2.prepare(`
      INSERT INTO app_settings (key, value, updated_at)
      VALUES ('active_year_id', ?, datetime('now', 'localtime'))
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
    `).run(String(id));
    const defPeriod = db2.prepare(`
      SELECT id FROM evaluation_periods
      WHERE academic_year_id = ? AND is_active = 1
      ORDER BY CASE WHEN period_type = 'MIDYEAR' THEN 0 ELSE 1 END, id ASC
      LIMIT 1
    `).get(id) || db2.prepare("SELECT id FROM evaluation_periods WHERE academic_year_id = ? ORDER BY id ASC LIMIT 1").get(id);
    if (defPeriod) {
      db2.prepare(`
        INSERT INTO app_settings (key, value, updated_at)
        VALUES ('active_period_id', ?, datetime('now', 'localtime'))
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
      `).run(String(defPeriod.id));
    }
  })();
  return true;
}
function archiveYear(db2, id) {
  const exists = db2.prepare("SELECT id FROM academic_years WHERE id = ? AND is_active = 0").get(id);
  if (!exists) throw userError$5("لا يمكن أرشفة السنة المفعّلة. فعّل سنة أخرى أولًا.");
  db2.prepare("UPDATE academic_years SET is_archived = 1 WHERE id = ?").run(id);
  return true;
}
function restoreYear(db2, id) {
  db2.prepare("UPDATE academic_years SET is_archived = 0 WHERE id = ?").run(id);
  return true;
}
function deleteYear(db2, id) {
  const year = db2.prepare("SELECT id, label, is_active FROM academic_years WHERE id = ?").get(id);
  if (!year) throw userError$5("السنة غير موجودة");
  if (year.is_active) throw userError$5("لا يمكن حذف السنة المفعّلة حالياً. فعّل سنة أخرى أولاً قبل حذفها.");
  const periodIds = db2.prepare("SELECT id FROM evaluation_periods WHERE academic_year_id = ?").all(id).map((r) => r.id);
  const evalCount = periodIds.length > 0 ? db2.prepare(`SELECT COUNT(*) AS c FROM evaluations WHERE period_id IN (${periodIds.map(() => "?").join(",")})`).get(...periodIds).c : 0;
  db2.transaction(() => {
    try {
      db2.prepare("DELETE FROM supervisor_alerts WHERE academic_year_id = ?").run(id);
    } catch {
    }
    try {
      const evIds = db2.prepare("SELECT id FROM evidences WHERE academic_year_id = ?").all(id).map((r) => r.id);
      for (const evid of evIds) {
        try {
          db2.prepare("DELETE FROM evidence_comments WHERE evidence_id = ?").run(evid);
        } catch {
        }
      }
      db2.prepare("DELETE FROM evidences WHERE academic_year_id = ?").run(id);
    } catch {
    }
    try {
      const plIds = db2.prepare("SELECT id FROM improvement_plans WHERE academic_year_id = ?").all(id).map((r) => r.id);
      for (const plid of plIds) {
        db2.prepare("DELETE FROM plan_follow_ups WHERE plan_id = ?").run(plid);
      }
      db2.prepare("DELETE FROM improvement_plans WHERE academic_year_id = ?").run(id);
    } catch {
    }
    if (periodIds.length > 0) {
      if (evalCount > 0) {
        const evalIds = db2.prepare(`SELECT id FROM evaluations WHERE period_id IN (${periodIds.map(() => "?").join(",")})`).all(...periodIds).map((r) => r.id);
        for (const eid of evalIds) {
          db2.prepare("DELETE FROM evaluation_item_snapshots WHERE evaluation_id = ?").run(eid);
        }
        db2.prepare(`DELETE FROM evaluations WHERE period_id IN (${periodIds.map(() => "?").join(",")})`).run(...periodIds);
      }
      db2.prepare("DELETE FROM evaluation_periods WHERE academic_year_id = ?").run(id);
    }
    db2.prepare("DELETE FROM academic_years WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("year.delete", "year", id, JSON.stringify({ label: year.label, periodCount: periodIds.length, evalCount }));
  })();
  return { deleted: true, periodCount: periodIds.length, evalCount };
}
function wrap$f(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerYearsIpc(ipc, db2) {
  ipc.handle("years:list", wrap$f(() => listYears(db2)));
  ipc.handle("years:create", wrap$f((_e, label) => createYear(db2, label)));
  ipc.handle("years:activate", wrap$f((_e, id) => {
    const res = activateYear(db2, id);
    pushActiveContextToCloud(db2).catch(() => {
    });
    return res;
  }));
  ipc.handle("years:archive", wrap$f((_e, id) => archiveYear(db2, id)));
  ipc.handle("years:restore", wrap$f((_e, id) => restoreYear(db2, id)));
  ipc.handle("years:delete", wrap$f((_e, id) => deleteYear(db2, id)));
}
function userError$4(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function rowToPeriod(r) {
  return {
    id: r.id,
    academicYearId: r.academic_year_id,
    name: r.name,
    periodType: r.period_type || "OTHER",
    isActive: !!r.is_active,
    createdAt: r.created_at
  };
}
function listPeriods(db2, { yearId } = {}) {
  if (yearId) {
    return db2.prepare("SELECT * FROM evaluation_periods WHERE academic_year_id = ? ORDER BY id").all(yearId).map(rowToPeriod);
  }
  return db2.prepare("SELECT * FROM evaluation_periods ORDER BY academic_year_id DESC, id").all().map(rowToPeriod);
}
function createPeriod(db2, { academicYearId, name: name2, periodType }) {
  const trimmed = (name2 || "").trim();
  if (!trimmed) throw userError$4("اسم الفترة مطلوب");
  const year = db2.prepare("SELECT id FROM academic_years WHERE id = ?").get(academicYearId);
  if (!year) throw userError$4("السنة الدراسية غير موجودة");
  const normType = ["MIDYEAR", "FINAL"].includes(periodType) ? periodType : "OTHER";
  const dup = db2.prepare("SELECT id FROM evaluation_periods WHERE academic_year_id = ? AND name = ?").get(academicYearId, trimmed);
  if (dup) throw userError$4("توجد فترة بنفس الاسم في هذه السنة");
  const sameTypeCount = normType !== "OTHER" ? db2.prepare("SELECT COUNT(*) AS c FROM evaluation_periods WHERE academic_year_id = ? AND period_type = ?").get(academicYearId, normType).c : 0;
  const r = db2.prepare("INSERT INTO evaluation_periods (academic_year_id, name, period_type) VALUES (?, ?, ?)").run(academicYearId, trimmed, normType);
  return {
    id: r.lastInsertRowid,
    academicYearId,
    name: trimmed,
    periodType: normType,
    isActive: true,
    warning: sameTypeCount > 0 ? "توجد بالفعل فترة أخرى من نفس النوع في هذه السنة الدراسية" : null
  };
}
function updatePeriod(db2, id, { name: name2, periodType }) {
  const trimmed = (name2 || "").trim();
  if (!trimmed) throw userError$4("اسم الفترة مطلوب");
  const p = db2.prepare("SELECT id, academic_year_id, period_type FROM evaluation_periods WHERE id = ?").get(id);
  if (!p) throw userError$4("الفترة غير موجودة");
  const dup = db2.prepare(
    "SELECT id FROM evaluation_periods WHERE academic_year_id = ? AND name = ? AND id <> ?"
  ).get(p.academic_year_id, trimmed, id);
  if (dup) throw userError$4("توجد فترة بنفس الاسم في هذه السنة");
  const normType = periodType ? ["MIDYEAR", "FINAL"].includes(periodType) ? periodType : "OTHER" : p.period_type;
  db2.prepare("UPDATE evaluation_periods SET name = ?, period_type = ? WHERE id = ?").run(trimmed, normType, id);
  return true;
}
function deletePeriod(db2, id) {
  const period = db2.prepare("SELECT id, name, academic_year_id FROM evaluation_periods WHERE id = ?").get(id);
  if (!period) throw userError$4("الفترة غير موجودة");
  const evalCount = db2.prepare("SELECT COUNT(*) AS c FROM evaluations WHERE period_id = ?").get(id).c;
  db2.transaction(() => {
    if (evalCount > 0) {
      const evalIds = db2.prepare("SELECT id FROM evaluations WHERE period_id = ?").all(id).map((r) => r.id);
      for (const eid of evalIds) {
        db2.prepare("DELETE FROM evaluation_item_snapshots WHERE evaluation_id = ?").run(eid);
      }
      db2.prepare("DELETE FROM evaluations WHERE period_id = ?").run(id);
    }
    db2.prepare("DELETE FROM evaluation_periods WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("period.delete", "period", id, JSON.stringify({ name: period.name, evalCount }));
  })();
  return { deleted: true, evalCount };
}
function togglePeriodActive(db2, id, isActive) {
  db2.prepare("UPDATE evaluation_periods SET is_active = ? WHERE id = ?").run(isActive ? 1 : 0, id);
  return true;
}
function wrap$e(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerPeriodsIpc(ipc, db2) {
  ipc.handle("periods:list", wrap$e((_e, opts) => listPeriods(db2, opts || {})));
  ipc.handle("periods:create", wrap$e((_e, data) => createPeriod(db2, data || {})));
  ipc.handle("periods:update", wrap$e((_e, id, data) => updatePeriod(db2, id, data || {})));
  ipc.handle("periods:delete", wrap$e((_e, id) => deletePeriod(db2, id)));
  ipc.handle("periods:toggleActive", wrap$e((_e, id, isActive) => togglePeriodActive(db2, id, isActive)));
}
function userError$3(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function listAdministrations(db2) {
  return db2.prepare("SELECT * FROM education_administrations ORDER BY is_archived, name").all().map((r) => ({ id: r.id, name: r.name, isArchived: !!r.is_archived }));
}
function createAdministration(db2, name2) {
  const t = (name2 || "").trim();
  if (!t) throw userError$3("اسم الإدارة مطلوب");
  const dup = db2.prepare("SELECT id FROM education_administrations WHERE name = ?").get(t);
  if (dup) throw userError$3("الإدارة موجودة بالفعل");
  const r = db2.prepare("INSERT INTO education_administrations (name) VALUES (?)").run(t);
  return { id: r.lastInsertRowid, name: t, isArchived: false };
}
function updateAdministration(db2, id, name2) {
  const t = (name2 || "").trim();
  if (!t) throw userError$3("اسم الإدارة مطلوب");
  const dup = db2.prepare("SELECT id FROM education_administrations WHERE name = ? AND id <> ?").get(t, id);
  if (dup) throw userError$3("الإدارة موجودة بالفعل");
  db2.prepare("UPDATE education_administrations SET name = ? WHERE id = ?").run(t, id);
  return true;
}
function archiveAdministration(db2, id, archived = true) {
  db2.prepare("UPDATE education_administrations SET is_archived = ? WHERE id = ?").run(archived ? 1 : 0, id);
  return true;
}
function deleteAdministration(db2, id) {
  const admin = db2.prepare("SELECT id, name FROM education_administrations WHERE id = ?").get(id);
  if (!admin) throw userError$3("الإدارة التعليمية غير موجودة");
  const count = db2.prepare("SELECT COUNT(*) AS c FROM schools WHERE administration_id = ?").get(id).c;
  if (count > 0) {
    throw userError$3(`لا يمكن حذف الإدارة لأنها مرتبطة بـ (${count}) من المدارس المسجلة. يمكنك أرشفتها بدلاً من ذلك.`);
  }
  db2.transaction(() => {
    db2.prepare("DELETE FROM education_administrations WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("administration.delete", "administration", id, JSON.stringify({ name: admin.name }));
  })();
  return true;
}
function listStages(db2) {
  return db2.prepare("SELECT * FROM school_stages ORDER BY is_archived, sort_order, name").all().map((r) => ({ id: r.id, name: r.name, sortOrder: r.sort_order, isArchived: !!r.is_archived }));
}
function createStage(db2, name2) {
  const t = (name2 || "").trim();
  if (!t) throw userError$3("اسم المرحلة مطلوب");
  const dup = db2.prepare("SELECT id FROM school_stages WHERE name = ?").get(t);
  if (dup) throw userError$3("المرحلة موجودة بالفعل");
  const r = db2.prepare("INSERT INTO school_stages (name) VALUES (?)").run(t);
  return { id: r.lastInsertRowid, name: t, isArchived: false };
}
function updateStage(db2, id, name2) {
  const t = (name2 || "").trim();
  if (!t) throw userError$3("اسم المرحلة مطلوب");
  const dup = db2.prepare("SELECT id FROM school_stages WHERE name = ? AND id <> ?").get(t, id);
  if (dup) throw userError$3("المرحلة موجودة بالفعل");
  db2.prepare("UPDATE school_stages SET name = ? WHERE id = ?").run(t, id);
  return true;
}
function archiveStage(db2, id, archived = true) {
  db2.prepare("UPDATE school_stages SET is_archived = ? WHERE id = ?").run(archived ? 1 : 0, id);
  return true;
}
function deleteStage(db2, id) {
  const stage = db2.prepare("SELECT id, name FROM school_stages WHERE id = ?").get(id);
  if (!stage) throw userError$3("المرحلة الدراسية غير موجودة");
  const count = db2.prepare("SELECT COUNT(*) AS c FROM schools WHERE stage_id = ?").get(id).c;
  if (count > 0) {
    throw userError$3(`لا يمكن حذف المرحلة لأنها مرتبطة بـ (${count}) من المدارس المسجلة. يمكنك أرشفتها بدلاً من ذلك.`);
  }
  db2.transaction(() => {
    db2.prepare("DELETE FROM school_stages WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("stage.delete", "stage", id, JSON.stringify({ name: stage.name }));
  })();
  return true;
}
const SELECT_BASE$1 = `
  SELECT s.*, st.name AS stage_name, ea.name AS administration_name
  FROM schools s
  LEFT JOIN school_stages st ON st.id = s.stage_id
  LEFT JOIN education_administrations ea ON ea.id = s.administration_id
`;
function rowToSchool(r) {
  return {
    id: r.id,
    name: r.name,
    stageId: r.stage_id,
    stageName: r.stage_name || "",
    administrationId: r.administration_id,
    administrationName: r.administration_name || "",
    isArchived: !!r.is_archived,
    createdAt: r.created_at
  };
}
function listSchools(db2, { search = "", includeArchived = false, administrationId, stageId } = {}) {
  const where = [];
  const params = [];
  if (!includeArchived) where.push("s.is_archived = 0");
  if (administrationId) {
    where.push("s.administration_id = ?");
    params.push(administrationId);
  }
  if (stageId) {
    where.push("s.stage_id = ?");
    params.push(stageId);
  }
  if (search && search.trim()) {
    where.push("s.name LIKE ?");
    params.push(`%${search.trim()}%`);
  }
  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  return db2.prepare(`${SELECT_BASE$1} ${whereSql} ORDER BY s.name`).all(...params).map(rowToSchool);
}
function createSchool(db2, { name: name2, stageId, administrationId }) {
  const t = (name2 || "").trim();
  if (!t) throw userError$3("اسم المدرسة مطلوب");
  const dup = db2.prepare(
    "SELECT id FROM schools WHERE name = ? AND (stage_id IS ?) AND (administration_id IS ?) AND is_archived = 0"
  ).get(t, stageId || null, administrationId || null);
  if (dup) throw userError$3("توجد مدرسة بنفس الاسم والمرحلة والإدارة");
  const r = db2.prepare(
    "INSERT INTO schools (name, stage_id, administration_id) VALUES (?, ?, ?)"
  ).run(t, stageId || null, administrationId || null);
  return { id: r.lastInsertRowid };
}
function updateSchool(db2, id, { name: name2, stageId, administrationId }) {
  const t = (name2 || "").trim();
  if (!t) throw userError$3("اسم المدرسة مطلوب");
  db2.prepare(
    "UPDATE schools SET name = ?, stage_id = ?, administration_id = ? WHERE id = ?"
  ).run(t, stageId || null, administrationId || null, id);
  return true;
}
function archiveSchool(db2, id, archived = true) {
  db2.prepare("UPDATE schools SET is_archived = ? WHERE id = ?").run(archived ? 1 : 0, id);
  return true;
}
function deleteSchool(db2, id) {
  const school = db2.prepare("SELECT id, name FROM schools WHERE id = ?").get(id);
  if (!school) throw userError$3("المدرسة غير موجودة");
  const managerCount = db2.prepare("SELECT COUNT(*) AS c FROM managers WHERE school_id = ?").get(id).c;
  if (managerCount > 0) {
    throw userError$3(`لا يمكن حذف المدرسة لأنها مرتبطة بـ (${managerCount}) من المدراء المسجلين. يمكنك نقل المدراء لمدرسة أخرى أولاً أو أرشفة المدرسة بدلاً من حذفها.`);
  }
  db2.transaction(() => {
    db2.prepare("DELETE FROM schools WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("school.delete", "school", id, JSON.stringify({ name: school.name }));
  })();
  return true;
}
function wrap$d(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerSchoolsIpc(ipc, db2) {
  ipc.handle("schools:listAdministrations", wrap$d(() => listAdministrations(db2)));
  ipc.handle("schools:createAdministration", wrap$d((_e, name2) => createAdministration(db2, name2)));
  ipc.handle("schools:updateAdministration", wrap$d((_e, id, name2) => updateAdministration(db2, id, name2)));
  ipc.handle("schools:archiveAdministration", wrap$d((_e, id, archived) => archiveAdministration(db2, id, archived)));
  ipc.handle("schools:deleteAdministration", wrap$d((_e, id) => deleteAdministration(db2, id)));
  ipc.handle("schools:listStages", wrap$d(() => listStages(db2)));
  ipc.handle("schools:createStage", wrap$d((_e, name2) => createStage(db2, name2)));
  ipc.handle("schools:updateStage", wrap$d((_e, id, name2) => updateStage(db2, id, name2)));
  ipc.handle("schools:archiveStage", wrap$d((_e, id, archived) => archiveStage(db2, id, archived)));
  ipc.handle("schools:deleteStage", wrap$d((_e, id) => deleteStage(db2, id)));
  ipc.handle("schools:list", wrap$d((_e, opts) => listSchools(db2, opts || {})));
  ipc.handle("schools:create", wrap$d((_e, data) => createSchool(db2, data || {})));
  ipc.handle("schools:update", wrap$d((_e, id, data) => updateSchool(db2, id, data || {})));
  ipc.handle("schools:archive", wrap$d((_e, id, archived) => archiveSchool(db2, id, archived)));
  ipc.handle("schools:delete", wrap$d((_e, id) => deleteSchool(db2, id)));
}
function validateVersionForActivation({ elements, levels, roundingPlaces, isOfficial = true }) {
  const errors = [];
  if (!elements || elements.length === 0) {
    errors.push("يجب إضافة عناصر للنموذج قبل التفعيل");
  } else {
    const missingNames = elements.filter((e) => !(e.name || "").trim());
    if (missingNames.length) {
      errors.push(`يوجد ${missingNames.length} عنصر بدون اسم`);
    }
    const invalidWeights = elements.filter((e) => {
      const bp = e.weight_bp !== void 0 ? e.weight_bp : e.weightBp;
      return !Number.isInteger(bp) || bp <= 0;
    });
    if (invalidWeights.length) {
      errors.push(`يوجد ${invalidWeights.length} عنصر بوزن نسبي غير صالح`);
    }
    const sumBp = elements.reduce((acc, e) => {
      const bp = e.weight_bp !== void 0 ? e.weight_bp : e.weightBp;
      return acc + (bp | 0);
    }, 0);
    if (sumBp !== 1e4) {
      errors.push(`مجموع الأوزان = ${(sumBp / 100).toFixed(2)}% ويجب أن يساوي 100.00% بالضبط`);
    }
    const nums = elements.map((e) => e.element_number !== void 0 ? e.element_number : e.elementNumber);
    if (new Set(nums).size !== nums.length) {
      errors.push("توجد أرقام عناصر مكررة");
    }
    if (isOfficial) {
      if (elements.length !== 19) {
        errors.push(`النموذج الرسمي يتطلب 19 عنصرًا بالضبط (العناصر المتوفرة: ${elements.length})`);
      }
      for (const el of elements) {
        const num = el.element_number !== void 0 ? el.element_number : el.elementNumber;
        const bp = el.weight_bp !== void 0 ? el.weight_bp : el.weightBp;
        if (num === 13 && bp !== 1e3) {
          errors.push(`العنصر رقم 13 (التحصيل الدراسي واختبارات نافس) يجب أن يكون وزنه 10% (1000 نقطة أساس)؛ وزنه الحالي ${(bp / 100).toFixed(2)}%`);
        }
      }
    }
  }
  if (!levels || levels.length !== 5) {
    errors.push("يجب تعريف 5 مستويات أداء بالضبط (من 1 إلى 5)");
  } else {
    const scores = new Set(levels.map((l) => l.score_value !== void 0 ? l.score_value : l.scoreValue));
    for (let i = 1; i <= 5; i++) {
      if (!scores.has(i)) errors.push(`المستوى ${i} مفقود`);
    }
    const missingLabels = levels.filter((l) => !(l.label || "").trim());
    if (missingLabels.length) {
      errors.push("توجد مستويات أداء بدون مسمى");
    }
  }
  if (!Number.isInteger(roundingPlaces) || roundingPlaces < 0 || roundingPlaces > 4) {
    errors.push("عدد الخانات العشرية للتقريب يجب أن يكون بين 0 و 4");
  }
  return { valid: errors.length === 0, errors };
}
function userError$2(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function rowToForm(r) {
  return { id: r.id, code: r.code, name: r.name, description: r.description, isOfficial: !!r.is_official, createdAt: r.created_at };
}
function rowToVersion(r) {
  return {
    id: r.id,
    formId: r.form_id,
    versionNumber: r.version_number,
    status: r.status,
    roundingPlaces: r.rounding_places,
    roundingMode: r.rounding_mode,
    sourceReference: r.source_reference,
    notes: r.notes,
    activatedAt: r.activated_at,
    createdAt: r.created_at,
    formName: r.form_name,
    elementCount: r.element_count,
    weightSumBp: r.weight_sum_bp
  };
}
function rowToElement(r) {
  return {
    id: r.id,
    formVersionId: r.form_version_id,
    elementNumber: r.element_number,
    name: r.name,
    description: r.description,
    weightBp: r.weight_bp,
    sortOrder: r.sort_order
  };
}
function createForm(db2, { name: name2, code, description }) {
  const n = (name2 || "").trim();
  if (!n) throw userError$2("اسم النموذج مطلوب");
  const c = (code || "").trim() || `form_${Date.now()}`;
  const dup = db2.prepare("SELECT id FROM evaluation_forms WHERE code = ? OR name = ?").get(c, n);
  if (dup) throw userError$2("يوجد نموذج آخر بنفس الاسم أو الرمز");
  const r = db2.prepare(`
    INSERT INTO evaluation_forms (code, name, description, is_official)
    VALUES (?, ?, ?, 0)
  `).run(c, n, (description || "").trim() || null);
  const formId = r.lastInsertRowid;
  const v = db2.prepare(`
    INSERT INTO form_versions (form_id, version_number, status, notes)
    VALUES (?, '1.0', 'draft', 'الإصدار الأولي للنموذج')
  `).run(formId);
  const levels = [[5, "مثالي"], [4, "تخطى التوقعات"], [3, "وافق التوقعات"], [2, "بحاجة إلى تطوير"], [1, "غير مرضٍ"]];
  const ins = db2.prepare("INSERT INTO performance_levels (form_version_id, score_value, label) VALUES (?, ?, ?)");
  for (const [s, l] of levels) ins.run(v.lastInsertRowid, s, l);
  return { id: formId, initialVersionId: v.lastInsertRowid };
}
function deleteForm(db2, formId) {
  const form = db2.prepare("SELECT * FROM evaluation_forms WHERE id = ?").get(formId);
  if (!form) throw userError$2("النموذج غير موجود");
  if (form.is_official) {
    throw userError$2("لا يمكن حذف النموذج الرسمي الأساسي للنظام. يمكنك إنشاء نماذج مخصصة أخرى.");
  }
  const versions = db2.prepare("SELECT id FROM form_versions WHERE form_id = ?").all(formId);
  const versionIds = versions.map((v) => v.id);
  if (versionIds.length > 0) {
    const placeholders = versionIds.map(() => "?").join(",");
    const evalCount = db2.prepare(`
      SELECT COUNT(*) AS c FROM evaluations WHERE form_version_id IN (${placeholders})
    `).get(...versionIds).c;
    if (evalCount > 0) {
      throw userError$2(`لا يمكن حذف هذا النموذج لوجود (${evalCount}) تقييم مرتبط بإصداراته. تم الحفاظ على بيانات التقييمات التاريخية.`);
    }
  }
  db2.transaction(() => {
    for (const vid of versionIds) {
      db2.prepare("DELETE FROM form_version_elements WHERE form_version_id = ?").run(vid);
      db2.prepare("DELETE FROM performance_levels WHERE form_version_id = ?").run(vid);
      db2.prepare("DELETE FROM form_versions WHERE id = ?").run(vid);
    }
    db2.prepare("DELETE FROM evaluation_forms WHERE id = ?").run(formId);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("form.delete", "form", formId, JSON.stringify({ name: form.name, code: form.code }));
  })();
  return true;
}
function listForms(db2) {
  const forms = db2.prepare(`
    SELECT f.*, 
      (SELECT COUNT(*) FROM form_versions WHERE form_id = f.id) AS version_count
    FROM evaluation_forms f ORDER BY f.is_official DESC, f.created_at
  `).all();
  return forms.map((f) => ({
    ...rowToForm(f),
    versionCount: f.version_count
  }));
}
function listVersionsByForm(db2, formId) {
  return db2.prepare(`
    SELECT fv.*, f.name AS form_name,
      (SELECT COUNT(*) FROM form_version_elements WHERE form_version_id = fv.id) AS element_count,
      (SELECT COALESCE(SUM(weight_bp),0) FROM form_version_elements WHERE form_version_id = fv.id) AS weight_sum_bp
    FROM form_versions fv
    JOIN evaluation_forms f ON f.id = fv.form_id
    WHERE fv.form_id = ?
    ORDER BY fv.created_at DESC
  `).all(formId).map(rowToVersion);
}
function getVersion(db2, versionId) {
  const v = db2.prepare(`
    SELECT fv.*, f.name AS form_name,
      (SELECT COUNT(*) FROM form_version_elements WHERE form_version_id = fv.id) AS element_count,
      (SELECT COALESCE(SUM(weight_bp),0) FROM form_version_elements WHERE form_version_id = fv.id) AS weight_sum_bp
    FROM form_versions fv
    JOIN evaluation_forms f ON f.id = fv.form_id
    WHERE fv.id = ?
  `).get(versionId);
  return v ? rowToVersion(v) : null;
}
function createVersion(db2, { formId, versionNumber, notes, sourceReference }) {
  const t = (versionNumber || "").trim();
  if (!t) throw userError$2("رقم الإصدار مطلوب");
  const form = db2.prepare("SELECT id FROM evaluation_forms WHERE id = ?").get(formId);
  if (!form) throw userError$2("النموذج غير موجود");
  const dup = db2.prepare("SELECT id FROM form_versions WHERE form_id = ? AND version_number = ?").get(formId, t);
  if (dup) throw userError$2("رقم الإصدار مستخدم بالفعل لهذا النموذج");
  const r = db2.prepare(`
    INSERT INTO form_versions (form_id, version_number, status, notes, source_reference)
    VALUES (?, ?, 'draft', ?, ?)
  `).run(formId, t, (notes || "").trim() || null, (sourceReference || "").trim() || null);
  const levels = [[5, "مثالي"], [4, "تخطى التوقعات"], [3, "وافق التوقعات"], [2, "بحاجة إلى تطوير"], [1, "غير مرضٍ"]];
  const ins = db2.prepare("INSERT INTO performance_levels (form_version_id, score_value, label) VALUES (?, ?, ?)");
  for (const [s, l] of levels) ins.run(r.lastInsertRowid, s, l);
  return { id: r.lastInsertRowid };
}
function deleteVersion(db2, versionId) {
  const v = db2.prepare("SELECT * FROM form_versions WHERE id = ?").get(versionId);
  if (!v) throw userError$2("إصدار النموذج غير موجود");
  if (v.status === "active") {
    throw userError$2("لا يمكن حذف إصدار مفعّل حالياً. قم بأرشفته أو تفعيل إصدار آخر أولاً.");
  }
  const evalCount = db2.prepare("SELECT COUNT(*) AS c FROM evaluations WHERE form_version_id = ?").get(versionId).c;
  if (evalCount > 0) {
    throw userError$2(`لا يمكن حذف هذا الإصدار لوجود (${evalCount}) تقييم مرتبط به. تم الحفاظ على بيانات التقييمات التاريخية.`);
  }
  db2.transaction(() => {
    db2.prepare("DELETE FROM form_version_elements WHERE form_version_id = ?").run(versionId);
    db2.prepare("DELETE FROM performance_levels WHERE form_version_id = ?").run(versionId);
    db2.prepare("DELETE FROM form_versions WHERE id = ?").run(versionId);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("form_version.delete", "form_version", versionId, JSON.stringify({ formId: v.form_id, versionNumber: v.version_number }));
  })();
  return true;
}
function updateVersionSettings(db2, versionId, { roundingPlaces, roundingMode, notes, sourceReference }) {
  const v = db2.prepare("SELECT id, status FROM form_versions WHERE id = ?").get(versionId);
  if (!v) throw userError$2("الإصدار غير موجود");
  if (v.status === "active")
    throw userError$2("لا يمكن تعديل الإعدادات بعد التفعيل. أنشئ إصدارًا جديدًا بدلًا من ذلك.");
  const rp = Number.isInteger(roundingPlaces) ? roundingPlaces : 2;
  const rm = ["HALF_UP", "HALF_EVEN", "DOWN"].includes(roundingMode) ? roundingMode : "HALF_UP";
  db2.prepare(`
    UPDATE form_versions SET rounding_places = ?, rounding_mode = ?, notes = ?, source_reference = ?
    WHERE id = ?
  `).run(rp, rm, (notes || "").trim() || null, (sourceReference || "").trim() || null, versionId);
  return true;
}
function activateVersion(db2, versionId) {
  const v = getVersion(db2, versionId);
  if (!v) throw userError$2("الإصدار غير موجود");
  if (v.status === "active") return true;
  const elements = listElements(db2, versionId);
  const levels = listLevels(db2, versionId);
  const form = db2.prepare("SELECT is_official FROM evaluation_forms WHERE id = ?").get(v.formId);
  const isOfficial = !!form?.is_official;
  const check = validateVersionForActivation({
    elements,
    levels,
    roundingPlaces: v.roundingPlaces,
    isOfficial
  });
  if (!check.valid) throw userError$2(check.errors[0]);
  db2.transaction(() => {
    db2.prepare(`
      UPDATE form_versions SET status = 'archived'
      WHERE form_id = ? AND status = 'active' AND id <> ?
    `).run(v.formId, versionId);
    db2.prepare(`
      UPDATE form_versions SET status = 'active', activated_at = datetime('now')
      WHERE id = ?
    `).run(versionId);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("form_version.activate", "form_version", versionId);
  })();
  return true;
}
function archiveVersion(db2, versionId) {
  const v = db2.prepare("SELECT id, status FROM form_versions WHERE id = ?").get(versionId);
  if (!v) throw userError$2("الإصدار غير موجود");
  if (v.status !== "active") throw userError$2("الإصدار غير مفعّل");
  db2.prepare("UPDATE form_versions SET status = 'archived' WHERE id = ?").run(versionId);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("form_version.archive", "form_version", versionId);
  return true;
}
function unarchiveVersion(db2, versionId, targetStatus = "active") {
  const v = db2.prepare("SELECT id, form_id, status FROM form_versions WHERE id = ?").get(versionId);
  if (!v) throw userError$2("الإصدار غير موجود");
  if (targetStatus === "active") {
    return activateVersion(db2, versionId);
  }
  db2.prepare("UPDATE form_versions SET status = 'draft' WHERE id = ?").run(versionId);
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("form_version.unarchive_draft", "form_version", versionId);
  return true;
}
function checkVersionReadiness(db2, versionId) {
  const v = getVersion(db2, versionId);
  if (!v) throw userError$2("الإصدار غير موجود");
  const elements = listElements(db2, versionId);
  const levels = listLevels(db2, versionId);
  const form = db2.prepare("SELECT is_official FROM evaluation_forms WHERE id = ?").get(v.formId);
  const isOfficial = !!form?.is_official;
  return validateVersionForActivation({ elements, levels, roundingPlaces: v.roundingPlaces, isOfficial });
}
function listElements(db2, versionId) {
  return db2.prepare(`
    SELECT * FROM form_version_elements WHERE form_version_id = ?
    ORDER BY element_number
  `).all(versionId).map(rowToElement);
}
function addElement(db2, versionId, { elementNumber, name: name2, weightBp, description }) {
  const v = db2.prepare("SELECT id, status FROM form_versions WHERE id = ?").get(versionId);
  if (!v) throw userError$2("الإصدار غير موجود");
  if (v.status === "active") throw userError$2("لا يمكن تعديل عناصر إصدار مفعّل. أنشئ إصدارًا جديدًا.");
  const n = (name2 || "").trim();
  if (!n) throw userError$2("اسم العنصر مطلوب");
  if (!Number.isInteger(weightBp) || weightBp <= 0 || weightBp > 1e4)
    throw userError$2("الوزن يجب أن يكون بين 0.01% و100%");
  const num = Number.isInteger(elementNumber) && elementNumber > 0 ? elementNumber : db2.prepare("SELECT COALESCE(MAX(element_number),0) + 1 AS n FROM form_version_elements WHERE form_version_id = ?").get(versionId).n;
  const dup = db2.prepare(
    "SELECT id FROM form_version_elements WHERE form_version_id = ? AND element_number = ?"
  ).get(versionId, num);
  if (dup) throw userError$2(`رقم العنصر ${num} مستخدم بالفعل`);
  const r = db2.prepare(`
    INSERT INTO form_version_elements (form_version_id, element_number, name, description, weight_bp, sort_order)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(versionId, num, n, (description || "").trim() || null, weightBp, num);
  return { id: r.lastInsertRowid };
}
function updateElement(db2, elementId, { name: name2, weightBp, description }) {
  const e = db2.prepare(`
    SELECT e.*, v.status FROM form_version_elements e
    JOIN form_versions v ON v.id = e.form_version_id
    WHERE e.id = ?
  `).get(elementId);
  if (!e) throw userError$2("العنصر غير موجود");
  if (e.status === "active") throw userError$2("لا يمكن تعديل عناصر إصدار مفعّل");
  const n = (name2 || "").trim();
  if (!n) throw userError$2("اسم العنصر مطلوب");
  if (!Number.isInteger(weightBp) || weightBp <= 0 || weightBp > 1e4)
    throw userError$2("الوزن يجب أن يكون بين 0.01% و100%");
  db2.prepare(`
    UPDATE form_version_elements SET name = ?, description = ?, weight_bp = ? WHERE id = ?
  `).run(n, (description || "").trim() || null, weightBp, elementId);
  return true;
}
function deleteElement(db2, elementId) {
  const e = db2.prepare(`
    SELECT e.*, v.status FROM form_version_elements e
    JOIN form_versions v ON v.id = e.form_version_id
    WHERE e.id = ?
  `).get(elementId);
  if (!e) throw userError$2("العنصر غير موجود");
  if (e.status === "active") throw userError$2("لا يمكن حذف عناصر إصدار مفعّل");
  db2.prepare("DELETE FROM form_version_elements WHERE id = ?").run(elementId);
  return true;
}
function replaceAllElements(db2, versionId, elements) {
  const v = db2.prepare("SELECT id, status FROM form_versions WHERE id = ?").get(versionId);
  if (!v) throw userError$2("الإصدار غير موجود");
  if (v.status === "active") throw userError$2("لا يمكن استبدال عناصر إصدار مفعّل");
  if (!Array.isArray(elements) || elements.length === 0)
    throw userError$2("لا توجد عناصر للاستيراد");
  const prepared = [];
  const seen = /* @__PURE__ */ new Set();
  for (let i = 0; i < elements.length; i++) {
    const raw = elements[i];
    const n = (raw.name || "").trim();
    if (!n) throw userError$2(`العنصر رقم ${i + 1}: الاسم مفقود`);
    const num = Number.isInteger(raw.elementNumber) && raw.elementNumber > 0 ? raw.elementNumber : i + 1;
    if (seen.has(num)) throw userError$2(`رقم العنصر ${num} مكرر`);
    seen.add(num);
    const wBp = Number.isInteger(raw.weightBp) ? raw.weightBp : Math.round((Number(raw.weightPercent) || 0) * 100);
    if (!wBp || wBp <= 0 || wBp > 1e4) throw userError$2(`العنصر "${n}": وزن غير صالح`);
    prepared.push({ num, name: n, weightBp: wBp, description: (raw.description || "").trim() || null });
  }
  db2.transaction(() => {
    db2.prepare("DELETE FROM form_version_elements WHERE form_version_id = ?").run(versionId);
    const ins = db2.prepare(`
      INSERT INTO form_version_elements (form_version_id, element_number, name, description, weight_bp, sort_order)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    for (const p of prepared) ins.run(versionId, p.num, p.name, p.description, p.weightBp, p.num);
  })();
  return { imported: prepared.length };
}
function listLevels(db2, versionId) {
  return db2.prepare(`
    SELECT * FROM performance_levels WHERE form_version_id = ? ORDER BY score_value DESC
  `).all(versionId).map((r) => ({
    id: r.id,
    scoreValue: r.score_value,
    label: r.label,
    description: r.description
  }));
}
function updateLevel(db2, levelId, { label, description }) {
  const l = db2.prepare(`
    SELECT l.*, v.status FROM performance_levels l
    JOIN form_versions v ON v.id = l.form_version_id
    WHERE l.id = ?
  `).get(levelId);
  if (!l) throw userError$2("المستوى غير موجود");
  if (l.status === "active") throw userError$2("لا يمكن تعديل مستويات إصدار مفعّل");
  const t = (label || "").trim();
  if (!t) throw userError$2("اسم المستوى مطلوب");
  db2.prepare("UPDATE performance_levels SET label = ?, description = ? WHERE id = ?").run(t, (description || "").trim() || null, levelId);
  return true;
}
function cellValue(cell) {
  const v = cell.value;
  if (v && typeof v === "object") {
    if ("result" in v) return v.result;
    if ("text" in v) return v.text;
    if ("richText" in v) return v.richText.map((r) => r.text).join("");
  }
  return v;
}
async function pickAndParseElementsFile(parentWindow) {
  const result2 = await electron.dialog.showOpenDialog(parentWindow, {
    title: "اختر ملف عناصر التقييم الرسمية",
    properties: ["openFile"],
    filters: [{ name: "Excel", extensions: ["xlsx"] }]
  });
  if (result2.canceled || result2.filePaths.length === 0) {
    return { cancelled: true };
  }
  const filePath = result2.filePaths[0];
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(filePath);
  const ws = wb.worksheets[0];
  if (!ws) throw Object.assign(new Error("no sheet"), { userMessage: "الملف لا يحتوي على أوراق عمل" });
  const rows = [];
  const errors = [];
  const warnings = [];
  const seenNumbers = /* @__PURE__ */ new Set();
  const seenNames = /* @__PURE__ */ new Set();
  ws.eachRow({ includeEmpty: false }, (row, rowNum) => {
    if (rowNum === 1) return;
    const numVal = cellValue(row.getCell(1));
    const nameVal = cellValue(row.getCell(2));
    const weightVal = cellValue(row.getCell(3));
    const descVal = cellValue(row.getCell(4));
    const nameStr = nameVal == null ? "" : String(nameVal).trim();
    const numStr = numVal == null ? "" : String(numVal).trim();
    const weightStr = weightVal == null ? "" : String(weightVal).trim();
    if (nameStr.includes("ملاحظة") || nameStr.includes("الإجمالي") || nameStr.includes("المجموع") || numStr.includes("الإجمالي") || numStr.includes("المجموع")) {
      return;
    }
    if (!nameStr && !numStr && !weightStr) {
      return;
    }
    if (!nameStr) {
      errors.push(`الصف ${rowNum}: اسم عنصر التقييم مفقود`);
      return;
    }
    let weightNum = null;
    if (typeof weightVal === "number") {
      weightNum = weightVal;
    } else if (weightStr) {
      const parsed = parseFloat(weightStr.replace("%", "").replace(",", ".").trim());
      if (Number.isFinite(parsed)) weightNum = parsed;
    }
    if (weightNum === null || !Number.isFinite(weightNum) || weightNum <= 0 || weightNum > 100) {
      errors.push(`الصف ${rowNum} (${nameStr}): الوزن غير صالح أو غير رقمي («${weightStr}»). يجب أن يكون رقمًا موجبًا.`);
      return;
    }
    const parsedNum = parseInt(numStr, 10);
    const elementNumber = Number.isFinite(parsedNum) && parsedNum > 0 ? parsedNum : rows.length + 1;
    if (seenNumbers.has(elementNumber)) {
      errors.push(`الصف ${rowNum}: رقم العنصر ${elementNumber} مكرر في الملف`);
    }
    seenNumbers.add(elementNumber);
    if (seenNames.has(nameStr)) {
      warnings.push(`الصف ${rowNum}: اسم العنصر «${nameStr}» تكرر في الملف`);
    }
    seenNames.add(nameStr);
    rows.push({
      elementNumber,
      name: nameStr,
      weightPercent: weightNum,
      weightBp: Math.round(weightNum * 100),
      description: descVal == null ? "" : String(descVal).trim()
    });
  });
  if (rows.length !== 19) {
    errors.push(`نموذج تقييم مدير المدرسة يجب أن يحتوي على 19 عنصرًا بالضبط (تم العثور على ${rows.length} عنصرًا بالملف)`);
  }
  const sumPercent = rows.reduce((a, r) => a + r.weightPercent, 0);
  const sumPercentRounded = Math.round(sumPercent * 100) / 100;
  if (Math.round(sumPercent * 100) !== 1e4) {
    errors.push(`مجموع الأوزان بالملف = ${sumPercentRounded.toFixed(2)}% ويجب أن يساوي 100.00% بالضبط`);
  }
  const el13 = rows.find((r) => r.elementNumber === 13);
  if (el13) {
    if (Math.round(el13.weightPercent * 100) !== 1e3) {
      errors.push(`العنصر رقم 13 («${el13.name}») يجب أن يكون وزنه 10% (الوزن الحالي بالملف: ${el13.weightPercent}%)`);
    }
  }
  for (const r of rows) {
    if (r.elementNumber !== 13 && Math.round(r.weightPercent * 100) !== 500) {
      warnings.push(`العنصر رقم ${r.elementNumber} («${r.name}») وزنه ${r.weightPercent}% والوزن المعتمد هو 5%`);
    }
  }
  return {
    cancelled: false,
    fileName: filePath.split(/[\\/]/).pop(),
    rows,
    errors,
    warnings,
    sumPercent: sumPercentRounded,
    isValid: errors.length === 0
  };
}
async function saveTemplateFile(parentWindow) {
  const result2 = await electron.dialog.showSaveDialog(parentWindow, {
    title: "حفظ قالب عناصر تقييم أداء مدير المدرسة المعتمد",
    defaultPath: "نموذج-تقييم-مدير-المدرسة-19-عنصر.xlsx",
    filters: [{ name: "Excel", extensions: ["xlsx"] }]
  });
  if (result2.canceled || !result2.filePath) return { cancelled: true };
  const wb = new ExcelJS.Workbook();
  wb.creator = "نظام تقييم الأداء الوظيفي لمدراء المدارس";
  wb.created = /* @__PURE__ */ new Date();
  const ws = wb.addWorksheet("عناصر التقييم الرسمية", { views: [{ rightToLeft: true }] });
  ws.columns = [
    { header: "م", key: "num", width: 8 },
    { header: "عنصر التقييم", key: "name", width: 65 },
    { header: "الوزن النسبي %", key: "weight", width: 16 },
    { header: "الوصف / مؤشرات الأداء", key: "desc", width: 60 }
  ];
  const headerRow = ws.getRow(1);
  headerRow.font = { name: "Cairo", bold: true, size: 12, color: { argb: "FF065F46" } };
  headerRow.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFD1FAE5" } };
  headerRow.alignment = { horizontal: "center", vertical: "middle" };
  headerRow.height = 30;
  const border = {
    top: { style: "thin", color: { argb: "FFCBD5E1" } },
    bottom: { style: "thin", color: { argb: "FFCBD5E1" } },
    left: { style: "thin", color: { argb: "FFCBD5E1" } },
    right: { style: "thin", color: { argb: "FFCBD5E1" } }
  };
  headerRow.eachCell((c) => {
    c.border = border;
  });
  OFFICIAL_FORM_ELEMENTS.forEach((el) => {
    const r = ws.addRow({
      num: el.elementNumber,
      name: el.name,
      weight: el.weightPercent,
      desc: el.description
    });
    r.font = { name: "Cairo", size: 11 };
    r.alignment = { vertical: "middle", readingOrder: "rtl" };
    r.getCell("num").alignment = { horizontal: "center", vertical: "middle" };
    r.getCell("weight").alignment = { horizontal: "center", vertical: "middle" };
    r.getCell("weight").numFmt = '0"%"';
    r.height = 24;
    if (el.elementNumber === 13) {
      r.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFFEF3C7" } };
      r.font = { name: "Cairo", bold: true, size: 11, color: { argb: "FF92400E" } };
    }
    r.eachCell((c) => {
      c.border = border;
    });
  });
  const totalRow = ws.addRow({
    num: "",
    name: "المجموع الإجمالي (18 عنصرًا بوزن 5% + عنصر واحد بوزن 10%)",
    weight: 100,
    desc: "مجموع الأوزان النسبية يساوي 100% تمامًا"
  });
  totalRow.font = { name: "Cairo", bold: true, size: 11, color: { argb: "FF065F46" } };
  totalRow.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFECFDF5" } };
  totalRow.height = 26;
  totalRow.getCell("weight").alignment = { horizontal: "center", vertical: "middle" };
  totalRow.getCell("weight").numFmt = '0"%"';
  totalRow.eachCell((c) => {
    c.border = border;
  });
  await wb.xlsx.writeFile(result2.filePath);
  return { cancelled: false, filePath: result2.filePath };
}
function wrap$c(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerFormsIpc(ipc, db2) {
  ipc.handle("forms:list", wrap$c(() => listForms(db2)));
  ipc.handle("forms:create", wrap$c((_e, data) => createForm(db2, data || {})));
  ipc.handle("forms:delete", wrap$c((_e, id) => deleteForm(db2, id)));
  ipc.handle("forms:listVersions", wrap$c((_e, formId) => listVersionsByForm(db2, formId)));
  ipc.handle("forms:getVersion", wrap$c((_e, id) => getVersion(db2, id)));
  ipc.handle("forms:createVersion", wrap$c((_e, data) => createVersion(db2, data || {})));
  ipc.handle("forms:deleteVersion", wrap$c((_e, id) => deleteVersion(db2, id)));
  ipc.handle("forms:updateVersionSettings", wrap$c((_e, id, data) => updateVersionSettings(db2, id, data || {})));
  ipc.handle("forms:activateVersion", wrap$c((_e, id) => activateVersion(db2, id)));
  ipc.handle("forms:archiveVersion", wrap$c((_e, id) => archiveVersion(db2, id)));
  ipc.handle("forms:unarchiveVersion", wrap$c((_e, id, targetStatus) => unarchiveVersion(db2, id, targetStatus)));
  ipc.handle("forms:checkReadiness", wrap$c((_e, id) => checkVersionReadiness(db2, id)));
  ipc.handle("formElements:list", wrap$c((_e, versionId) => listElements(db2, versionId)));
  ipc.handle("formElements:add", wrap$c((_e, versionId, data) => addElement(db2, versionId, data || {})));
  ipc.handle("formElements:update", wrap$c((_e, id, data) => updateElement(db2, id, data || {})));
  ipc.handle("formElements:delete", wrap$c((_e, id) => deleteElement(db2, id)));
  ipc.handle("formElements:replaceAll", wrap$c((_e, versionId, elements) => replaceAllElements(db2, versionId, elements)));
  ipc.handle("formLevels:list", wrap$c((_e, versionId) => listLevels(db2, versionId)));
  ipc.handle("formLevels:update", wrap$c((_e, id, data) => updateLevel(db2, id, data || {})));
  ipc.handle("formElements:pickAndParse", wrap$c(() => {
    const win = electron.BrowserWindow.getFocusedWindow();
    return pickAndParseElementsFile(win);
  }));
  ipc.handle("formElements:saveTemplate", wrap$c(() => {
    const win = electron.BrowserWindow.getFocusedWindow();
    return saveTemplateFile(win);
  }));
}
const ROUND_MODES = {
  HALF_UP: decimal_js.Decimal.ROUND_HALF_UP,
  HALF_EVEN: decimal_js.Decimal.ROUND_HALF_EVEN,
  DOWN: decimal_js.Decimal.ROUND_DOWN
};
function computeElementContribution(scoreValue, weightBp, options = {}) {
  if (scoreValue == null) return null;
  if (!Number.isInteger(scoreValue) || scoreValue < 1 || scoreValue > 5) return null;
  if (!Number.isInteger(weightBp) || weightBp <= 0) return null;
  const rp = normalizeRoundingPlaces(options.roundingPlaces);
  const rm = normalizeRoundingMode(options.roundingMode);
  const val = new decimal_js.Decimal(scoreValue).times(weightBp).div(500);
  return val.toDecimalPlaces(rp, ROUND_MODES[rm]).toFixed(rp);
}
function computeFinalScore(items, options = {}) {
  const errors = [];
  const missingIndexes = [];
  if (!Array.isArray(items) || items.length === 0) {
    return {
      complete: false,
      rawScore: "0",
      finalScore: "0",
      missingIndexes: [],
      errors: ["لا توجد عناصر للتقييم"],
      isNumericComplete: false,
      items: []
    };
  }
  let sumBp = 0;
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    if (!Number.isInteger(it.weightBp) || it.weightBp <= 0) {
      errors.push(`العنصر رقم ${it.elementNumber || i + 1}: وزن غير صالح (يجب أن يكون عددًا صحيحًا موجبًا بنقاط الأساس)`);
    } else {
      sumBp += it.weightBp;
    }
  }
  if (sumBp !== 1e4) {
    errors.push(`مجموع الأوزان = ${(sumBp / 100).toFixed(2)}% ويجب أن يساوي 100.00% بالضبط`);
  }
  for (let i = 0; i < items.length; i++) {
    const sv = items[i].scoreValue;
    if (sv === null || sv === void 0) {
      missingIndexes.push(i);
      continue;
    }
    if (!Number.isInteger(sv) || sv < 1 || sv > 5) {
      errors.push(`العنصر رقم ${items[i].elementNumber || i + 1}: درجة غير صالحة (${sv})`);
    }
  }
  let numerator = new decimal_js.Decimal(0);
  for (const it of items) {
    if (it.scoreValue == null) continue;
    numerator = numerator.plus(new decimal_js.Decimal(it.scoreValue).times(it.weightBp));
  }
  const rawScore = numerator.div(500);
  const rp = normalizeRoundingPlaces(options.roundingPlaces);
  const rm = normalizeRoundingMode(options.roundingMode);
  const finalScore = rawScore.toDecimalPlaces(rp, ROUND_MODES[rm]);
  const calculatedItems = items.map((it, idx) => ({
    elementNumber: it.elementNumber ?? idx + 1,
    name: it.name || "",
    scoreValue: it.scoreValue,
    weightBp: it.weightBp,
    contribution: computeElementContribution(it.scoreValue, it.weightBp, { roundingPlaces: rp, roundingMode: rm })
  }));
  return {
    complete: missingIndexes.length === 0 && errors.length === 0,
    isNumericComplete: missingIndexes.length === 0 && errors.length === 0,
    rawScore: rawScore.toFixed(rp),
    finalScore: finalScore.toFixed(rp),
    missingIndexes,
    errors,
    items: calculatedItems
  };
}
function normalizeRoundingPlaces(rp) {
  if (!Number.isInteger(rp) || rp < 0 || rp > 4) return 2;
  return rp;
}
function normalizeRoundingMode(rm) {
  return ROUND_MODES[rm] ? rm : "HALF_UP";
}
function userError$1(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function rowToEval(r) {
  if (!r) return null;
  return {
    id: r.id,
    managerId: r.manager_id,
    yearId: r.academic_year_id,
    periodId: r.period_id,
    formVersionId: r.form_version_id,
    status: r.status,
    finalScore: r.final_score,
    generalRating: r.general_rating || "",
    notes: r.notes,
    previousEvaluationId: r.previous_evaluation_id,
    correctionReason: r.correction_reason,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    approvedAt: r.approved_at,
    managerName: r.manager_name,
    yearLabel: r.year_label,
    periodName: r.period_name,
    periodType: r.period_type || "OTHER",
    formVersionNumber: r.form_version_number
  };
}
const SELECT_BASE = `
  SELECT e.*, m.full_name AS manager_name, ay.label AS year_label,
         ep.name AS period_name, ep.period_type AS period_type, fv.version_number AS form_version_number
  FROM evaluations e
  JOIN managers m ON m.id = e.manager_id
  JOIN academic_years ay ON ay.id = e.academic_year_id
  JOIN evaluation_periods ep ON ep.id = e.period_id
  JOIN form_versions fv ON fv.id = e.form_version_id
`;
function listByManager(db2, managerId) {
  return db2.prepare(`${SELECT_BASE} WHERE e.manager_id = ? ORDER BY e.updated_at DESC`).all(managerId).map(rowToEval);
}
function getEvaluation(db2, evaluationId) {
  const e = db2.prepare(`${SELECT_BASE} WHERE e.id = ?`).get(evaluationId);
  if (!e) return null;
  const version2 = db2.prepare("SELECT rounding_places, rounding_mode FROM form_versions WHERE id = ?").get(e.form_version_id);
  const rp = version2?.rounding_places ?? 2;
  const rm = version2?.rounding_mode ?? "HALF_UP";
  const items = db2.prepare(`
    SELECT * FROM evaluation_item_snapshots WHERE evaluation_id = ? ORDER BY element_number
  `).all(evaluationId).map((r) => ({
    id: r.id,
    elementNumber: r.element_number,
    name: r.name,
    weightBp: r.weight_bp,
    scoreValue: r.score_value,
    levelLabel: r.level_label,
    notes: r.notes || "",
    contribution: computeElementContribution(r.score_value, r.weight_bp, { roundingPlaces: rp, roundingMode: rm })
  }));
  return { ...rowToEval(e), items };
}
function findForContext(db2, { managerId, yearId, periodId, formVersionId }) {
  const e = db2.prepare(`${SELECT_BASE}
    WHERE e.manager_id = ? AND e.academic_year_id = ? AND e.period_id = ? AND e.form_version_id = ?
      AND e.status IN ('draft','completed','approved')
    ORDER BY e.updated_at DESC LIMIT 1
  `).get(managerId, yearId, periodId, formVersionId);
  return e ? getEvaluation(db2, e.id) : null;
}
function createDraft(db2, { managerId, yearId, periodId, formVersionId }) {
  const version2 = db2.prepare("SELECT * FROM form_versions WHERE id = ?").get(formVersionId);
  if (!version2) throw userError$1("إصدار النموذج غير موجود");
  if (version2.status !== "active")
    throw userError$1("لا يمكن إنشاء تقييم إلا بإصدار نموذج مفعّل");
  const manager = db2.prepare("SELECT id, status FROM managers WHERE id = ?").get(managerId);
  if (!manager) throw userError$1("المدير غير موجود");
  if (manager.status === "archived") throw userError$1("لا يمكن تقييم مدير مؤرشف");
  const year = db2.prepare("SELECT id FROM academic_years WHERE id = ?").get(yearId);
  if (!year) throw userError$1("السنة الدراسية غير موجودة");
  const period = db2.prepare("SELECT id, period_type FROM evaluation_periods WHERE id = ? AND academic_year_id = ?").get(periodId, yearId);
  if (!period) throw userError$1("الفترة لا تنتمي للسنة المحددة");
  if (period.period_type === "FINAL") {
    const midyearPeriod = db2.prepare(`
      SELECT id FROM evaluation_periods
      WHERE academic_year_id = ? AND period_type = 'MIDYEAR'
      LIMIT 1
    `).get(yearId);
    if (midyearPeriod) {
      const midApproved = db2.prepare(`
        SELECT id FROM evaluations
        WHERE manager_id = ? AND academic_year_id = ? AND period_id = ? AND status = 'approved'
        LIMIT 1
      `).get(managerId, yearId, midyearPeriod.id);
      if (!midApproved) {
        throw userError$1("لا يمكن بدء التقييم النهائي إلا بعد اعتماد التقييم النصف سنوي لهذا المدير في نفس السنة الدراسية.");
      }
    }
  }
  const existing = findForContext(db2, { managerId, yearId, periodId, formVersionId });
  if (existing) return existing;
  const elements = db2.prepare(
    "SELECT * FROM form_version_elements WHERE form_version_id = ? ORDER BY element_number"
  ).all(formVersionId);
  if (elements.length === 0) throw userError$1("الإصدار لا يحتوي عناصر");
  let newId;
  db2.transaction(() => {
    const r = db2.prepare(`
      INSERT INTO evaluations (manager_id, academic_year_id, period_id, form_version_id, status)
      VALUES (?, ?, ?, ?, 'draft')
    `).run(managerId, yearId, periodId, formVersionId);
    newId = r.lastInsertRowid;
    const ins = db2.prepare(`
      INSERT INTO evaluation_item_snapshots
        (evaluation_id, source_element_id, element_number, name, weight_bp, score_value, level_label, notes)
      VALUES (?, ?, ?, ?, ?, NULL, NULL, NULL)
    `);
    for (const el of elements) {
      ins.run(newId, el.id, el.element_number, el.name, el.weight_bp);
    }
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("evaluation.create", "evaluation", newId);
  })();
  return getEvaluation(db2, newId);
}
function saveScores(db2, evaluationId, itemScores, options = {}) {
  const ev = getEvaluation(db2, evaluationId);
  if (!ev) throw userError$1("التقييم غير موجود");
  if (ev.status === "approved")
    throw userError$1('لا يمكن تعديل تقييم معتمد. استخدم "طلب تصحيح".');
  if (ev.status === "superseded")
    throw userError$1("لا يمكن تعديل تقييم مُستبدل.");
  const levels = db2.prepare(
    "SELECT score_value, label FROM performance_levels WHERE form_version_id = ?"
  ).all(ev.formVersionId);
  const levelMap = new Map(levels.map((l) => [l.score_value, l.label]));
  const byElementNumber = new Map(ev.items.map((it) => [it.elementNumber, it]));
  db2.transaction(() => {
    const upd = db2.prepare(`
      UPDATE evaluation_item_snapshots
      SET score_value = ?, level_label = ?, notes = ?
      WHERE id = ?
    `);
    for (const s of itemScores || []) {
      const target = byElementNumber.get(s.elementNumber);
      if (!target) continue;
      const scoreValue = s.scoreValue;
      let levelLabel = null;
      if (scoreValue != null) {
        if (!Number.isInteger(scoreValue) || scoreValue < 1 || scoreValue > 5)
          throw userError$1(`العنصر ${s.elementNumber}: درجة غير صالحة`);
        levelLabel = levelMap.get(scoreValue) || null;
      }
      upd.run(scoreValue ?? null, levelLabel, (s.notes || "").trim() || null, target.id);
    }
    const generalRating = options.generalRating !== void 0 ? (options.generalRating || "").trim() || null : void 0;
    const evalNotes = options.notes !== void 0 ? (options.notes || "").trim() || null : void 0;
    if (generalRating !== void 0 || evalNotes !== void 0) {
      db2.prepare(`
        UPDATE evaluations
        SET general_rating = CASE WHEN ? = 1 THEN ? ELSE general_rating END,
            notes = CASE WHEN ? = 1 THEN ? ELSE notes END
        WHERE id = ?
      `).run(
        generalRating !== void 0 ? 1 : 0,
        generalRating ?? null,
        evalNotes !== void 0 ? 1 : 0,
        evalNotes ?? null,
        evaluationId
      );
    }
    const fresh = getEvaluation(db2, evaluationId);
    const allFilled = fresh.items.every((it) => it.scoreValue != null);
    const nextStatus = allFilled ? "completed" : "draft";
    db2.prepare(`
      UPDATE evaluations SET status = ?, updated_at = datetime('now', 'localtime') WHERE id = ?
    `).run(nextStatus, evaluationId);
  })();
  return getEvaluation(db2, evaluationId);
}
function previewEvaluation(db2, evaluationId) {
  const ev = getEvaluation(db2, evaluationId);
  if (!ev) throw userError$1("التقييم غير موجود");
  const version2 = db2.prepare("SELECT rounding_places, rounding_mode FROM form_versions WHERE id = ?").get(ev.formVersionId);
  const result2 = computeFinalScore(
    ev.items.map((it) => ({
      elementNumber: it.elementNumber,
      name: it.name,
      weightBp: it.weightBp,
      scoreValue: it.scoreValue
    })),
    { roundingPlaces: version2.rounding_places, roundingMode: version2.rounding_mode }
  );
  return { evaluation: ev, result: result2 };
}
function approveEvaluation(db2, evaluationId, { notes, generalRating } = {}) {
  const ev = getEvaluation(db2, evaluationId);
  if (!ev) throw userError$1("التقييم غير موجود");
  if (ev.status === "approved") throw userError$1("التقييم معتمد بالفعل");
  if (ev.status === "superseded") throw userError$1("لا يمكن اعتماد تقييم مُستبدل");
  const version2 = db2.prepare("SELECT rounding_places, rounding_mode FROM form_versions WHERE id = ?").get(ev.formVersionId);
  const preview = computeFinalScore(
    ev.items.map((it) => ({ weightBp: it.weightBp, scoreValue: it.scoreValue })),
    { roundingPlaces: version2.rounding_places, roundingMode: version2.rounding_mode }
  );
  if (!preview.complete)
    throw userError$1(`التقييم غير مكتمل: ${preview.errors[0] || `${preview.missingIndexes.length} عنصر بلا درجة`}`);
  db2.transaction(() => {
    db2.prepare(`
      UPDATE evaluations
      SET status = 'approved',
          final_score = ?,
          notes = COALESCE(?, notes),
          general_rating = COALESCE(?, general_rating),
          approved_at = datetime('now', 'localtime'),
          updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(
      preview.finalScore,
      (notes || "").trim() || null,
      (generalRating || "").trim() || null,
      evaluationId
    );
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("evaluation.approve", "evaluation", evaluationId);
  })();
  return getEvaluation(db2, evaluationId);
}
function correctApproved(db2, originalId, { reason } = {}) {
  const orig = getEvaluation(db2, originalId);
  if (!orig) throw userError$1("التقييم غير موجود");
  if (orig.status !== "approved") throw userError$1("يمكن تصحيح التقييمات المعتمدة فقط");
  const trimmed = (reason || "").trim();
  if (!trimmed) throw userError$1("سبب التصحيح مطلوب");
  let newId;
  db2.transaction(() => {
    db2.prepare("UPDATE evaluations SET status = 'superseded' WHERE id = ?").run(originalId);
    const r = db2.prepare(`
      INSERT INTO evaluations
        (manager_id, academic_year_id, period_id, form_version_id, status,
         previous_evaluation_id, correction_reason, general_rating)
      VALUES (?, ?, ?, ?, 'draft', ?, ?, ?)
    `).run(
      orig.managerId,
      orig.yearId,
      orig.periodId,
      orig.formVersionId,
      originalId,
      trimmed,
      orig.generalRating || null
    );
    newId = r.lastInsertRowid;
    const ins = db2.prepare(`
      INSERT INTO evaluation_item_snapshots
        (evaluation_id, source_element_id, element_number, name, weight_bp, score_value, level_label, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const it of orig.items) {
      ins.run(
        newId,
        null,
        it.elementNumber,
        it.name,
        it.weightBp,
        it.scoreValue ?? null,
        it.levelLabel ?? null,
        it.notes || null
      );
    }
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("evaluation.correct", "evaluation", newId, JSON.stringify({ originalId, reason: trimmed }));
  })();
  return getEvaluation(db2, newId);
}
function deleteDraft(db2, evaluationId) {
  const ev = getEvaluation(db2, evaluationId);
  if (!ev) throw userError$1("التقييم غير موجود");
  if (!["draft", "completed"].includes(ev.status))
    throw userError$1("يمكن حذف المسودات فقط");
  db2.transaction(() => {
    db2.prepare("DELETE FROM evaluation_item_snapshots WHERE evaluation_id = ?").run(evaluationId);
    db2.prepare("DELETE FROM evaluations WHERE id = ?").run(evaluationId);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id) VALUES (?, ?, ?)").run("evaluation.deleteDraft", "evaluation", evaluationId);
  })();
  return true;
}
function deleteApprovedEvaluation(db2, evaluationId, { reason, user } = {}) {
  const ev = getEvaluation(db2, evaluationId);
  if (!ev) throw userError$1("التقييم غير موجود");
  const trimmed = (reason || "").trim();
  if (!trimmed) throw userError$1("سبب الحذف إلزامي لحذف تقييم معتمد");
  const username = user?.username || "مستخدم";
  db2.transaction(() => {
    db2.prepare("DELETE FROM evaluation_item_snapshots WHERE evaluation_id = ?").run(evaluationId);
    db2.prepare("DELETE FROM evaluations WHERE id = ?").run(evaluationId);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("evaluation.delete_approved", "evaluation", evaluationId, JSON.stringify({
      managerName: ev.managerName,
      yearLabel: ev.yearLabel,
      periodName: ev.periodName,
      finalScore: ev.finalScore,
      reason: trimmed,
      deletedBy: username
    }));
  })();
  return true;
}
function wrap$b(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerEvaluationsIpc(ipc, db2) {
  ipc.handle("evaluations:listByManager", wrap$b((_e, managerId) => listByManager(db2, managerId)));
  ipc.handle("evaluations:get", wrap$b((_e, id) => getEvaluation(db2, id)));
  ipc.handle("evaluations:findForContext", wrap$b((_e, ctx) => findForContext(db2, ctx || {})));
  ipc.handle("evaluations:createDraft", wrap$b((_e, data) => createDraft(db2, data || {})));
  ipc.handle("evaluations:saveScores", wrap$b((_e, id, scores, opts) => saveScores(db2, id, scores || [], opts || {})));
  ipc.handle("evaluations:preview", wrap$b((_e, id) => previewEvaluation(db2, id)));
  ipc.handle("evaluations:approve", wrap$b((_e, id, opts) => {
    const res = approveEvaluation(db2, id, opts || {});
    syncWithCloud(db2).catch(() => {
    });
    return res;
  }));
  ipc.handle("evaluations:correct", wrap$b((_e, id, data) => {
    const res = correctApproved(db2, id, data || {});
    syncWithCloud(db2).catch(() => {
    });
    return res;
  }));
  ipc.handle("evaluations:deleteDraft", wrap$b((_e, id) => deleteDraft(db2, id)));
  ipc.handle("evaluations:deleteApproved", wrap$b((_e, id, data) => {
    const res = deleteApprovedEvaluation(db2, id, data || {});
    syncWithCloud(db2).catch(() => {
    });
    return res;
  }));
  ipc.handle("evaluations:listAll", wrap$b((_e, filters) => {
    const where = [];
    const params = [];
    if (filters?.managerId) {
      where.push("e.manager_id = ?");
      params.push(filters.managerId);
    }
    if (filters?.yearId) {
      where.push("e.academic_year_id = ?");
      params.push(filters.yearId);
    }
    if (filters?.periodId) {
      where.push("e.period_id = ?");
      params.push(filters.periodId);
    }
    if (filters?.status && ["draft", "completed", "approved", "superseded"].includes(filters.status)) {
      where.push("e.status = ?");
      params.push(filters.status);
    }
    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
    return db2.prepare(`
      SELECT e.id, e.status, e.final_score,
             m.full_name AS managerName,
             ay.label AS yearLabel, ep.name AS periodName,
             e.updated_at AS updatedAt
      FROM evaluations e
      JOIN managers m ON m.id = e.manager_id
      JOIN academic_years ay ON ay.id = e.academic_year_id
      JOIN evaluation_periods ep ON ep.id = e.period_id
      ${whereSql}
      ORDER BY ay.label DESC, ep.name, m.full_name
    `).all(...params);
  }));
}
function wrap$a(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerEvidencesIpc(ipc, db2) {
  ipc.handle("evidences:list", wrap$a((_e, filters) => listEvidences(db2, filters || {})));
  ipc.handle("evidences:get", wrap$a((_e, id) => getEvidence(db2, id)));
  ipc.handle("evidences:pickAndStage", wrap$a(() => {
    const win = electron.BrowserWindow.getFocusedWindow();
    return pickAndStageFile(win);
  }));
  ipc.handle("evidences:pickAndStageMulti", wrap$a(() => {
    const win = electron.BrowserWindow.getFocusedWindow();
    return pickAndStageFiles(win, { title: "اختر ملفات الشاهد" });
  }));
  ipc.handle("evidences:discardStaged", wrap$a(async (_e, stagingId, ext) => {
    await discardStaged(stagingId, ext);
    return true;
  }));
  ipc.handle("evidences:create", wrap$a(async (_e, input, staged) => {
    const created = await createEvidence(db2, input || {}, staged);
    if (created?.id) {
      pushSingleEvidenceComments(db2, created.id).catch(() => {
      });
    }
    return created;
  }));
  ipc.handle("evidences:update", wrap$a(async (_e, id, input, staged) => {
    const updated = await updateEvidence(db2, id, input || {}, staged);
    pushSingleEvidenceComments(db2, id).catch(() => {
    });
    return updated;
  }));
  ipc.handle("evidences:archive", wrap$a((_e, id) => archiveEvidence(db2, id, true)));
  ipc.handle("evidences:restore", wrap$a((_e, id) => archiveEvidence(db2, id, false)));
  ipc.handle("evidences:delete", wrap$a(async (_e, id) => {
    const res = await deleteEvidence(db2, id);
    if (res?.portalId) {
      await deleteCloudEvidence(res.portalId).catch(() => {
      });
    }
    return true;
  }));
  ipc.handle("evidences:open", wrap$a((_e, id, fileIndex = 0) => openEvidence(db2, id, fileIndex)));
  ipc.handle("evidences:countsByElement", wrap$a((_e, ctx) => countsByElement(db2, ctx || {})));
  ipc.handle("evidences:addComment", wrap$a(async (_e, evidenceId, comment) => {
    const created = addEvidenceComment(db2, evidenceId, comment);
    await pushSingleEvidenceComments(db2, evidenceId).catch(() => {
    });
    return created;
  }));
  ipc.handle("evidences:deleteComment", wrap$a(async (_e, commentId) => {
    const res = deleteEvidenceComment(db2, commentId);
    if (res?.evidenceId) {
      await pushSingleEvidenceComments(db2, res.evidenceId).catch(() => {
      });
    }
    return true;
  }));
}
function wrap$9(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerPlansIpc(ipc, db2) {
  ipc.handle("plans:list", wrap$9((_e, filters) => listPlans(db2, filters || {})));
  ipc.handle("plans:get", wrap$9((_e, id) => getPlan(db2, id)));
  ipc.handle("plans:pickAndStageMulti", wrap$9(() => {
    const win = electron.BrowserWindow.getFocusedWindow();
    return pickAndStageFiles(win, { title: "اختر ملفات خطة التحسين" });
  }));
  ipc.handle("plans:discardStaged", wrap$9(async (_e, stagingId, ext) => {
    await discardStaged(stagingId, ext);
    return true;
  }));
  ipc.handle("plans:create", wrap$9(async (_e, input, staged) => {
    const res = await createPlan(db2, input || {}, staged);
    if (res && res.id) {
      await pushSinglePlanFollowUps(db2, res.id).catch(() => {
      });
    }
    return res;
  }));
  ipc.handle("plans:update", wrap$9(async (_e, id, input, staged) => {
    const res = await updatePlan(db2, id, input || {}, staged);
    await pushSinglePlanFollowUps(db2, id).catch(() => {
    });
    return res;
  }));
  ipc.handle("plans:setStatus", wrap$9((_e, id, status) => setPlanStatus(db2, id, status)));
  ipc.handle("plans:archive", wrap$9((_e, id) => archivePlan(db2, id)));
  ipc.handle("plans:restore", wrap$9((_e, id) => restorePlan(db2, id)));
  ipc.handle("plans:delete", wrap$9(async (_e, id) => {
    const res = deletePlan(db2, id);
    if (res?.portalId) {
      await deleteCloudPlan(res.portalId).catch(() => {
      });
    }
    return true;
  }));
  ipc.handle("plans:openAttachment", wrap$9((_e, id, fileIndex = 0) => openPlanAttachment(db2, id, fileIndex)));
  ipc.handle("plans:addFollowUp", wrap$9(async (_e, planId, note) => {
    const res = await addFollowUp(db2, planId, note);
    await pushSinglePlanFollowUps(db2, planId).catch(() => {
    });
    return res;
  }));
  ipc.handle("plans:deleteFollowUp", wrap$9(async (_e, followUpId) => {
    const row = db2.prepare("SELECT plan_id FROM plan_follow_ups WHERE id = ?").get(followUpId);
    const res = await deleteFollowUp(db2, followUpId);
    if (row && row.plan_id) {
      await pushSinglePlanFollowUps(db2, row.plan_id).catch(() => {
      });
    }
    return res;
  }));
}
const STATUS_LABEL = {
  draft: "مسودة",
  completed: "مكتمل (بانتظار الاعتماد)",
  approved: "معتمد رسميًا",
  superseded: "مُستبدل بتصحيح"
};
const SHORT_STATUS_LABEL = {
  draft: "مسودة",
  completed: "مكتمل",
  approved: "معتمد",
  superseded: "مُستبدل"
};
const PLAN_STATUS_LABEL = {
  not_started: "لم تبدأ",
  in_progress: "قيد التنفيذ",
  completed: "مكتملة",
  overdue: "متأخرة"
};
function getRatingByScore(score) {
  if (score === null || score === void 0 || score === "" || Number.isNaN(Number(score))) return "";
  const s = Number(score);
  if (s >= 90) return "متميز";
  if (s >= 76) return "فوق التوقعات";
  if (s >= 61) return "وافق التوقعات";
  if (s >= 41) return "بحاجة إلى تطوير";
  return "غير مرضٍ";
}
function getRatingMeta(ratingText, fallbackScore = null) {
  const r = (ratingText || getRatingByScore(fallbackScore) || "").trim();
  if (r.includes("متميز") || r.includes("ممتاز")) {
    return { label: r || "متميز", badge: "rating-excellent", bar: "#10b981", text: "#065f46", bg: "#ecfdf5", border: "#6ee7b7" };
  }
  if (r.includes("فوق التوقعات") || r.includes("جيد جدا") || r.includes("جيد جدًا")) {
    return { label: r || "فوق التوقعات", badge: "rating-verygood", bar: "#0284c7", text: "#075985", bg: "#f0f9ff", border: "#7dd3fc" };
  }
  if (r.includes("وافق التوقعات") || r.includes("جيد")) {
    return { label: r || "وافق التوقعات", badge: "rating-good", bar: "#d97706", text: "#92400e", bg: "#fffbeb", border: "#fcd34d" };
  }
  if (r.includes("بحاجة") || r.includes("تطوير")) {
    return { label: r || "بحاجة إلى تطوير", badge: "rating-needsdev", bar: "#ea580c", text: "#9a3412", bg: "#fff7ed", border: "#fdba74" };
  }
  if (r.includes("غير مرض")) {
    return { label: r || "غير مرضٍ", badge: "rating-unsat", bar: "#e11d48", text: "#9f1239", bg: "#fff1f2", border: "#fda4af" };
  }
  return { label: r || "—", badge: "badge-neutral", bar: "#64748b", text: "#334155", bg: "#f8fafc", border: "#cbd5e1" };
}
function getScorePillClass(score) {
  const n = Number(score);
  if (n === 5) return "score-5";
  if (n === 4) return "score-4";
  if (n === 3) return "score-3";
  if (n === 2) return "score-2";
  if (n === 1) return "score-1";
  return "score-none";
}
function esc(v) {
  if (v === null || v === void 0) return "";
  return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function fmtDate(iso) {
  if (!iso) return "—";
  const str = String(iso).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(str)) {
    return str.slice(0, 10).replace(/-/g, "/");
  }
  try {
    const d = new Date(iso);
    if (!Number.isNaN(d.getTime())) {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, "0");
      const day = String(d.getDate()).padStart(2, "0");
      return `${y}/${m}/${day}`;
    }
  } catch {
  }
  return String(iso).slice(0, 10);
}
function fmtNowDateTime() {
  const d = /* @__PURE__ */ new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  let hours = d.getHours();
  const minutes = String(d.getMinutes()).padStart(2, "0");
  const period = hours >= 12 ? "مساءً" : "صباحًا";
  hours = hours % 12;
  if (hours === 0) hours = 12;
  return `${y}/${m}/${day} — ${String(hours).padStart(2, "0")}:${minutes} ${period}`;
}
function fmtTodaySlash() {
  const d = /* @__PURE__ */ new Date();
  return `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}`;
}
function buildFontFaces(assets = {}) {
  const {
    fontRegular,
    fontBold,
    fontArabic400,
    fontLatin400,
    fontArabic600,
    fontLatin600,
    fontArabic700,
    fontLatin700
  } = assets;
  const rules = [];
  const arRange = "U+0600-06FF, U+0750-077F, U+08A0-08FF, U+FB50-FDFF, U+FE70-FEFF";
  const latRange = "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD";
  if (fontArabic400 || fontLatin400) {
    if (fontArabic400) {
      rules.push(`@font-face { font-family: 'Cairo'; src: url('${fontArabic400}') format('woff2'); font-weight: 400; font-style: normal; unicode-range: ${arRange}; font-display: block; }`);
    }
    if (fontLatin400) {
      rules.push(`@font-face { font-family: 'Cairo'; src: url('${fontLatin400}') format('woff2'); font-weight: 400; font-style: normal; unicode-range: ${latRange}; font-display: block; }`);
    }
  } else if (fontRegular && String(fontRegular).startsWith("data:")) {
    rules.push(`@font-face { font-family: 'Cairo'; src: url('${fontRegular}') format('woff2'); font-weight: 400; font-display: block; }`);
  }
  if (fontArabic600 || fontLatin600) {
    if (fontArabic600) {
      rules.push(`@font-face { font-family: 'Cairo'; src: url('${fontArabic600}') format('woff2'); font-weight: 600; font-style: normal; unicode-range: ${arRange}; font-display: block; }`);
    }
    if (fontLatin600) {
      rules.push(`@font-face { font-family: 'Cairo'; src: url('${fontLatin600}') format('woff2'); font-weight: 600; font-style: normal; unicode-range: ${latRange}; font-display: block; }`);
    }
  }
  if (fontArabic700 || fontLatin700) {
    if (fontArabic700) {
      rules.push(`@font-face { font-family: 'Cairo'; src: url('${fontArabic700}') format('woff2'); font-weight: 700; font-style: normal; unicode-range: ${arRange}; font-display: block; }`);
    }
    if (fontLatin700) {
      rules.push(`@font-face { font-family: 'Cairo'; src: url('${fontLatin700}') format('woff2'); font-weight: 700; font-style: normal; unicode-range: ${latRange}; font-display: block; }`);
    }
  } else if (fontBold && String(fontBold).startsWith("data:")) {
    rules.push(`@font-face { font-family: 'Cairo'; src: url('${fontBold}') format('woff2'); font-weight: 700; font-display: block; }`);
  }
  return rules.join("\n");
}
function baseStyles(assets = {}, landscape = false) {
  return `
    ${buildFontFaces(assets)}
    * { box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    body {
      font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
      margin: 0;
      padding: 0;
      color: #0f172a;
      background: #ffffff;
      font-size: 11px;
      line-height: 1.55;
    }
    .page {
      padding: 2mm 2mm;
    }
    .top-ribbon {
      height: 5px;
      border-radius: 6px 6px 0 0;
      background: linear-gradient(90deg, #064e3b 0%, #059669 45%, #0d9488 78%, #d97706 100%);
      margin-bottom: 0;
    }
    header.report-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);
      border: 1px solid #cbd5e1;
      border-top: none;
      border-bottom: 2.5px solid #059669;
      border-radius: 0 0 10px 10px;
      padding: 10px 14px;
      margin-bottom: 12px;
    }
    .hdr-right { flex: 1.35; min-width: 0; }
    .hdr-kicker { font-size: 9.5px; font-weight: 700; color: #047857; letter-spacing: 0.2px; }
    .hdr-org { font-size: 15px; font-weight: 700; color: #064e3b; line-height: 1.25; margin-top: 1px; }
    .hdr-app { font-size: 9.8px; font-weight: 600; color: #0f766e; margin-top: 2px; line-height: 1.4; }
    .hdr-sub { font-size: 9px; color: #475569; margin-top: 2px; }
    .hdr-center {
      flex: 0 0 auto;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 4px 10px;
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
    }
    .hdr-center img {
      height: 52px;
      width: auto;
      max-width: 110px;
      object-fit: contain;
      display: block;
    }
    .hdr-left {
      flex: 1;
      text-align: end;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 3px;
    }
    .doc-pill {
      display: inline-block;
      background: #ecfdf5;
      color: #065f46;
      border: 1px solid #a7f3d0;
      padding: 3px 10px;
      border-radius: 999px;
      font-size: 10.5px;
      font-weight: 700;
    }
    .hdr-meta { font-size: 9.5px; color: #334155; font-weight: 600; }
    .hdr-date { font-size: 8.8px; color: #64748b; }

    .hero-card {
      display: flex;
      align-items: stretch;
      justify-content: space-between;
      gap: 12px;
      background: linear-gradient(135deg, #f8fafc 0%, #f0fdf4 100%);
      border: 1px solid #bbf7d0;
      border-radius: 10px;
      padding: 11px 14px;
      margin-bottom: 10px;
      page-break-inside: avoid;
    }
    .hero-main { flex: 1; min-width: 0; }
    .hero-title { font-size: 16.5px; font-weight: 700; color: #064e3b; margin: 0 0 3px; line-height: 1.3; }
    .hero-sub { font-size: 10.5px; color: #334155; font-weight: 600; margin-bottom: 6px; }
    .hero-tags { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }

    .hero-score-card {
      min-width: 175px;
      background: #ffffff;
      border: 2px solid #059669;
      border-radius: 10px;
      padding: 8px 14px;
      text-align: center;
      display: flex;
      flex-direction: column;
      justify-content: center;
      box-shadow: 0 1px 3px rgba(6, 78, 59, 0.06);
    }
    .hero-score-card .sc-lbl { font-size: 9.5px; font-weight: 700; color: #047857; }
    .hero-score-card .sc-val { font-size: 26px; font-weight: 700; color: #064e3b; line-height: 1.1; margin: 2px 0; }
    .hero-score-card .sc-val span { font-size: 11px; font-weight: 600; color: #64748b; }

    h2.sec-title {
      font-size: 12.5px;
      font-weight: 700;
      margin: 12px 0 6px;
      color: #064e3b;
      display: flex;
      align-items: center;
      gap: 6px;
      border-right: 4px solid #059669;
      padding-right: 8px;
      background: linear-gradient(90deg, transparent, #f0fdf4);
      padding-top: 3px;
      padding-bottom: 3px;
      border-radius: 0 4px 4px 0;
      page-break-after: avoid;
    }

    .info-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 6px;
      margin-bottom: 10px;
      page-break-inside: avoid;
    }
    .info-grid-3 {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 6px;
      margin-bottom: 10px;
      page-break-inside: avoid;
    }
    .info-item {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      padding: 5px 8px;
      border-radius: 7px;
    }
    .info-label { font-size: 9px; color: #64748b; font-weight: 600; }
    .info-value { font-size: 11px; font-weight: 700; color: #0f172a; margin-top: 1px; }

    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(6, 1fr);
      gap: 6px;
      margin-bottom: 11px;
      page-break-inside: avoid;
    }
    .kpi-grid-5 {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 6px;
      margin-bottom: 11px;
      page-break-inside: avoid;
    }
    .kpi-card {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-top: 3px solid #059669;
      border-radius: 8px;
      padding: 6px 8px;
      text-align: center;
    }
    .kpi-card.kpi-blue { border-top-color: #0284c7; }
    .kpi-card.kpi-amber { border-top-color: #d97706; }
    .kpi-card.kpi-rose { border-top-color: #e11d48; }
    .kpi-card.kpi-teal { border-top-color: #0d9488; }
    .kpi-card.kpi-slate { border-top-color: #475569; }
    .kpi-num { font-size: 15px; font-weight: 700; color: #0f172a; line-height: 1.2; }
    .kpi-lbl { font-size: 8.8px; font-weight: 600; color: #64748b; margin-top: 2px; }
    .kpi-sub { font-size: 8px; color: #059669; font-weight: 700; margin-top: 1px; }

    .levels-strip {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 5px;
      margin-bottom: 10px;
      page-break-inside: avoid;
    }
    .lvl-chip {
      border: 1px solid #e2e8f0;
      border-radius: 7px;
      padding: 4px 6px;
      text-align: center;
      font-size: 9.5px;
      background: #f8fafc;
    }
    .lvl-chip strong { font-size: 12px; display: inline-block; margin-inline-start: 3px; }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 10px;
      margin-bottom: 10px;
      page-break-inside: auto;
    }
    tr { page-break-inside: avoid; page-break-after: auto; }
    thead { display: table-header-group; }
    tfoot { display: table-footer-group; }
    th {
      background: #065f46;
      color: #ffffff;
      font-weight: 700;
      padding: 6px 6px;
      text-align: start;
      border: 1px solid #047857;
      font-size: 9.8px;
    }
    td {
      padding: 5px 6px;
      border: 1px solid #cbd5e1;
      vertical-align: middle;
    }
    tbody tr:nth-child(even) { background: #f8fafc; }
    tr.element-highlight { background: #fffbeb !important; }
    tr.element-highlight td { border-color: #fcd34d; }
    .center { text-align: center; }
    .num { font-variant-numeric: tabular-nums; }

    .badge {
      display: inline-block;
      padding: 1.5px 7px;
      border-radius: 999px;
      font-size: 8.8px;
      font-weight: 700;
      vertical-align: middle;
      white-space: nowrap;
    }
    .badge-success { background: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; }
    .badge-info { background: #e0f2fe; color: #075985; border: 1px solid #7dd3fc; }
    .badge-warning { background: #fef3c7; color: #92400e; border: 1px solid #fcd34d; }
    .badge-neutral { background: #f1f5f9; color: #475569; border: 1px solid #cbd5e1; }
    .badge-danger { background: #ffe4e6; color: #9f1239; border: 1px solid #fda4af; }

    .rating-excellent { background: #ecfdf5; color: #065f46; border: 1px solid #6ee7b7; }
    .rating-verygood { background: #f0f9ff; color: #075985; border: 1px solid #7dd3fc; }
    .rating-good { background: #fffbeb; color: #92400e; border: 1px solid #fcd34d; }
    .rating-needsdev { background: #fff7ed; color: #9a3412; border: 1px solid #fdba74; }
    .rating-unsat { background: #fff1f2; color: #9f1239; border: 1px solid #fda4af; }

    .score-pill {
      display: inline-block;
      min-width: 22px;
      height: 20px;
      line-height: 18px;
      border-radius: 6px;
      font-weight: 700;
      font-size: 10.5px;
      text-align: center;
      padding: 0 5px;
    }
    .score-5 { background: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; }
    .score-4 { background: #e0f2fe; color: #075985; border: 1px solid #7dd3fc; }
    .score-3 { background: #fef3c7; color: #92400e; border: 1px solid #fcd34d; }
    .score-2 { background: #ffedd5; color: #9a3412; border: 1px solid #fdba74; }
    .score-1 { background: #ffe4e6; color: #9f1239; border: 1px solid #fda4af; }
    .score-none { background: #f1f5f9; color: #64748b; border: 1px solid #cbd5e1; }

    .mini-bar-wrap {
      width: 100%;
      height: 5px;
      background: #e2e8f0;
      border-radius: 999px;
      overflow: hidden;
      margin-top: 3px;
    }
    .mini-bar-fill {
      height: 100%;
      border-radius: 999px;
    }

    .insights-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin: 8px 0 10px;
      page-break-inside: avoid;
    }
    .insight-box {
      border-radius: 8px;
      padding: 8px 10px;
      border: 1px solid #cbd5e1;
      font-size: 9.8px;
    }
    .insight-strength { background: #f0fdf4; border-color: #86efac; }
    .insight-improve { background: #fffbeb; border-color: #fde68a; }
    .insight-title { font-weight: 700; font-size: 10.5px; margin-bottom: 4px; }
    .insight-list { margin: 0; padding-right: 16px; }
    .insight-list li { margin-bottom: 2px; }

    .dist-grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 6px;
      margin-bottom: 10px;
      page-break-inside: avoid;
    }
    .dist-card {
      border-radius: 8px;
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      background: #ffffff;
    }
    .dist-top { display: flex; justify-content: space-between; align-items: baseline; font-weight: 700; font-size: 9.5px; }
    .dist-count { font-size: 14px; font-weight: 700; margin-top: 2px; }

    .note-box {
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      border-right: 4px solid #0284c7;
      padding: 7px 10px;
      border-radius: 6px;
      font-size: 9.8px;
      color: #1e293b;
      margin: 8px 0;
      page-break-inside: avoid;
    }
    .warn-box {
      background: #fffbeb;
      border: 1px solid #fcd34d;
      border-right: 4px solid #d97706;
      padding: 7px 10px;
      border-radius: 6px;
      font-size: 9.8px;
      color: #78350f;
      margin: 8px 0;
      page-break-inside: avoid;
    }

    .signature-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 10px;
      margin-top: 16px;
      page-break-inside: avoid;
    }
    .sig-card {
      border: 1px solid #cbd5e1;
      background: #f8fafc;
      border-radius: 8px;
      padding: 8px 10px;
      text-align: center;
    }
    .sig-role { font-size: 10px; font-weight: 700; color: #064e3b; margin-bottom: 4px; }
    .sig-sub { font-size: 8.8px; color: #64748b; }
    .sig-line {
      border-top: 1px dashed #64748b;
      margin-top: 26px;
      padding-top: 4px;
      font-size: 8.8px;
      color: #475569;
    }

    .footer {
      margin-top: 14px;
      padding-top: 6px;
      border-top: 1px solid #cbd5e1;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 8.5px;
      color: #64748b;
    }
    .empty {
      text-align: center;
      padding: 16px;
      color: #64748b;
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 8px;
      font-size: 10px;
      margin-bottom: 10px;
    }
    @page {
      size: ${landscape ? "A4 landscape" : "A4 portrait"};
      margin: 9mm 9mm;
    }
    @media print {
      .page { padding: 0; }
    }
  `;
}
function pageHeader({ orgName, orgSubtitle, docTitle, meta, appTitle, preparedBy, logoDataUri }) {
  const displayAppTitle = appTitle || "تقييم أداء مدراء المدارس وفق الدليل الإرشادي لإدارة الأداء الوظيفي لشاغلي الوظائف التعليمية (الإصدار الثاني)";
  const displayPreparedBy = preparedBy || "إعداد وتنسيق : أخصائي الإدارة المدرسية / الحسين إبراهيم شويع";
  return `
    <div class="top-ribbon"></div>
    <header class="report-header">
      <div class="hdr-right">
        <div class="hdr-kicker">المملكة العربية السعودية</div>
        <div class="hdr-org">${esc(orgName || "وزارة التعليم")}</div>
        <div class="hdr-app">${esc(displayAppTitle)}</div>
        <div class="hdr-sub">${esc(displayPreparedBy)}${orgSubtitle ? ` — ${esc(orgSubtitle)}` : ""}</div>
      </div>
      ${logoDataUri ? `
        <div class="hdr-center">
          <img src="${logoDataUri}" alt="شعار وزارة التعليم" />
        </div>
      ` : ""}
      <div class="hdr-left">
        <div class="doc-pill">${esc(docTitle)}</div>
        ${meta ? `<div class="hdr-meta">${esc(meta)}</div>` : ""}
        <div class="hdr-date">تاريخ الإصدار: ${esc(fmtTodaySlash())}</div>
      </div>
    </header>
  `;
}
function pageFooter(orgName) {
  return `
    <div class="footer">
      <div>${esc(orgName || "وزارة التعليم")} — نظام تقييم الأداء الوظيفي لمدراء المدارس (الإصدار الثاني)</div>
      <div>تاريخ ووقت استخراج الوثيقة: ${esc(fmtNowDateTime())}</div>
    </div>
  `;
}
function wrap$8(html, assets = {}, landscape = false) {
  return `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <title>تقرير رسمي</title>
  <style>${baseStyles(assets, landscape)}</style>
</head>
<body>
  <div class="page">
    ${html}
  </div>
</body>
</html>`;
}
function renderEvaluationReport(params) {
  const {
    evaluation,
    orgName,
    orgSubtitle,
    appTitle,
    preparedBy,
    logoDataUri
  } = params;
  const ev = evaluation || {};
  const items = ev.items || [];
  const evidences = ev.evidences || [];
  const plans = ev.plans || [];
  const evCountMap = ev.evidenceCountsByElement || {};
  const totalWeightBp = items.reduce((a, it) => a + (it.weightBp || 0), 0);
  const filledItems = items.filter((it) => it.scoreValue != null);
  const filledCount = filledItems.length;
  const isApproved = ev.status === "approved";
  const statusLabel = STATUS_LABEL[ev.status] || ev.status || "—";
  const statusBadgeClass = ev.status === "approved" ? "badge-success" : ev.status === "completed" ? "badge-info" : ev.status === "draft" ? "badge-warning" : "badge-neutral";
  const rawPreviewScore = filledItems.length > 0 ? filledItems.reduce((acc, it) => acc + Number(it.scoreValue) * Number(it.weightBp || 0) / 500, 0).toFixed(2) : null;
  const effectiveScore = isApproved && ev.finalScore != null ? Number(ev.finalScore).toFixed(2) : null;
  const effectiveRatingMeta = getRatingMeta(ev.generalRating || ev.general_rating, effectiveScore ?? rawPreviewScore);
  const levelCounts = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  for (const it of filledItems) {
    if (levelCounts[it.scoreValue] !== void 0) levelCounts[it.scoreValue]++;
  }
  const strengths = [...filledItems].filter((it) => Number(it.scoreValue) >= 4).sort((a, b) => Number(b.scoreValue) - Number(a.scoreValue) || Number(b.weightBp) - Number(a.weightBp)).slice(0, 4);
  const improvements = [...filledItems].filter((it) => Number(it.scoreValue) <= 3).sort((a, b) => Number(a.scoreValue) - Number(b.scoreValue) || Number(b.weightBp) - Number(a.weightBp)).slice(0, 4);
  const rows = items.map((it) => {
    const maxPts = (Number(it.weightBp || 0) / 100).toFixed(2);
    const contribution = it.contribution != null ? Number(it.contribution).toFixed(2) : it.scoreValue != null ? (Number(it.scoreValue) * Number(it.weightBp) / 500).toFixed(2) : null;
    const pct = it.scoreValue != null ? Math.round(Number(it.scoreValue) / 5 * 100) : 0;
    const barColor = Number(it.scoreValue) >= 5 ? "#10b981" : Number(it.scoreValue) === 4 ? "#0284c7" : Number(it.scoreValue) === 3 ? "#d97706" : Number(it.scoreValue) === 2 ? "#ea580c" : "#e11d48";
    const isEl13 = it.elementNumber === 13;
    const elEvCount = evCountMap[it.elementNumber] || 0;
    return `
      <tr class="${isEl13 ? "element-highlight" : ""}">
        <td class="center num" style="font-weight:700;">${esc(it.elementNumber)}</td>
        <td>
          <div style="font-weight:${isEl13 ? "700" : "600"};color:#0f172a;">
            ${esc(it.name)}
            ${isEl13 ? ' <span class="badge badge-warning">وزن مضاعف 10%</span>' : ""}
          </div>
        </td>
        <td class="center num">${maxPts}%</td>
        <td class="center num">
          <span class="score-pill ${getScorePillClass(it.scoreValue)}">${it.scoreValue != null ? esc(it.scoreValue) : "—"}</span>
        </td>
        <td class="center" style="font-size:9.3px;font-weight:600;">${it.levelLabel ? esc(it.levelLabel) : "—"}</td>
        <td class="center num">
          ${contribution != null ? `
            <div style="font-weight:700;color:#064e3b;">${esc(contribution)} <span style="font-size:8.2px;color:#64748b;font-weight:400;">/ ${maxPts}</span></div>
            <div class="mini-bar-wrap"><div class="mini-bar-fill" style="width:${pct}%;background:${barColor};"></div></div>
          ` : "—"}
        </td>
        <td class="center num">${elEvCount > 0 ? `<span class="badge badge-info">${elEvCount}</span>` : '<span style="color:#94a3b8;">0</span>'}</td>
        <td style="font-size:9.2px;color:#334155;">${it.notes ? esc(it.notes) : '<span style="color:#cbd5e1;">—</span>'}</td>
      </tr>
    `;
  }).join("");
  const totalEvidencesLinked = evidences.length;
  const totalRow = `
    <tr style="background:#ecfdf5;font-weight:700;color:#064e3b;">
      <td colspan="2" class="center">المجموع الكلي (19 معيارًا رسميًا)</td>
      <td class="center num">${(totalWeightBp / 100).toFixed(2)}%</td>
      <td class="center num" colspan="2">${filledCount} / ${items.length} معيارًا مقيَّمًا</td>
      <td class="center num" style="font-size:11.5px;">${effectiveScore != null ? `${esc(effectiveScore)} / 100` : rawPreviewScore ? `${esc(rawPreviewScore)}*` : "—"}</td>
      <td class="center num">${totalEvidencesLinked}</td>
      <td></td>
    </tr>
  `;
  const scoreHeroBox = isApproved && effectiveScore != null ? `
      <div class="hero-score-card" style="border-color:${effectiveRatingMeta.bar};background:${effectiveRatingMeta.bg};">
        <div class="sc-lbl" style="color:${effectiveRatingMeta.text};">النتيجة النهائية المعتمدة</div>
        <div class="sc-val" style="color:${effectiveRatingMeta.text};">${esc(effectiveScore)} <span>/ 100</span></div>
        <div style="margin-top:3px;">
          <span class="badge ${effectiveRatingMeta.badge}" style="font-size:10px;padding:2px 10px;">التقدير العام: ${esc(effectiveRatingMeta.label)}</span>
        </div>
      </div>
    ` : `
      <div class="hero-score-card" style="border-color:#d97706;background:#fffbeb;">
        <div class="sc-lbl" style="color:#92400e;">حالة الوثيقة: ${esc(SHORT_STATUS_LABEL[ev.status] || ev.status)}</div>
        <div class="sc-val" style="color:#92400e;font-size:18px;">${rawPreviewScore ? `${esc(rawPreviewScore)} <span style="font-size:10px;">(مبدئي)</span>` : "قيد الرصد"}</div>
        <div style="font-size:8.5px;color:#78350f;margin-top:2px;">تُعتمد النتيجة رسميًا بعد الاعتماد النهائي</div>
      </div>
    `;
  const insightsHtml = filledCount > 0 ? `
    <div class="insights-grid">
      <div class="insight-box insight-strength">
        <div class="insight-title" style="color:#065f46;">أبرز نقاط القوة والتميز المهني</div>
        ${strengths.length > 0 ? `
          <ul class="insight-list">
            ${strengths.map((s) => `<li><strong>ع${esc(s.elementNumber)}:</strong> ${esc(s.name)} <span style="color:#047857;font-weight:700;">(الدرجة: ${esc(s.scoreValue)}/5)</span></li>`).join("")}
          </ul>
        ` : '<div style="color:#64748b;">لم تُسجل معايير في المستوى المتقدم (4 أو 5) بعد.</div>'}
      </div>
      <div class="insight-box insight-improve">
        <div class="insight-title" style="color:#92400e;">أبرز فرص التحسين والأولويات التطويرية</div>
        ${improvements.length > 0 ? `
          <ul class="insight-list">
            ${improvements.map((s) => `<li><strong>ع${esc(s.elementNumber)}:</strong> ${esc(s.name)} <span style="color:#b45309;font-weight:700;">(الدرجة: ${esc(s.scoreValue)}/5)</span></li>`).join("")}
          </ul>
        ` : '<div style="color:#065f46;font-weight:600;">جميع المعايير المرصودة حققت مستوى فوق التوقعات أو متميز (4 فأعلى).</div>'}
      </div>
    </div>
  ` : "";
  const stageAttachmentsSummary = evidences.length > 0 || plans.length > 0 ? `
    <h2 class="sec-title">ملخص الشواهد المهنية وخطط التحسين المرتبطة بالمرحلة</h2>
    <div class="insights-grid">
      <div class="info-item">
        <div class="info-label">الشواهد المرفوعة لهذه المرحلة (${evidences.length})</div>
        ${evidences.length > 0 ? `
          <div style="margin-top:4px;font-size:9.2px;color:#334155;">
            ${evidences.slice(0, 5).map((e) => `• <strong>${e.elementNumber ? `[ع${esc(e.elementNumber)}] ` : ""}</strong>${esc(e.title)} (${e.attachmentCount || 0} مرفق)`).join("<br/>")}
            ${evidences.length > 5 ? `<div style="color:#059669;font-weight:600;margin-top:2px;">+ ${evidences.length - 5} شواهد إضافية موثقة بالنظام</div>` : ""}
          </div>
        ` : '<div style="font-size:9.2px;color:#94a3b8;margin-top:3px;">لا توجد شواهد مرفوعة لهذه المرحلة.</div>'}
      </div>
      <div class="info-item">
        <div class="info-label">خطط التحسين المرتبطة بهذه المرحلة (${plans.length})</div>
        ${plans.length > 0 ? `
          <div style="margin-top:4px;font-size:9.2px;color:#334155;">
            ${plans.slice(0, 5).map((p) => `• <strong>${p.elementNumber ? `[ع${esc(p.elementNumber)}] ` : ""}</strong>${esc(p.goal)} — <span style="font-weight:700;">${esc(PLAN_STATUS_LABEL[p.status] || p.status)}</span>`).join("<br/>")}
            ${plans.length > 5 ? `<div style="color:#059669;font-weight:600;margin-top:2px;">+ ${plans.length - 5} خطط إضافية مسجلة بالنظام</div>` : ""}
          </div>
        ` : '<div style="font-size:9.2px;color:#94a3b8;margin-top:3px;">لا توجد خطط تحسين مسجلة لهذه المرحلة.</div>'}
      </div>
    </div>
  ` : "";
  const content = `
    ${pageHeader({
    orgName,
    orgSubtitle,
    appTitle,
    preparedBy,
    logoDataUri,
    docTitle: "بطاقة تقييم الأداء الوظيفي لمدير مدرسة",
    meta: `العام الدراسي: ${ev.yearLabel || "—"} · ${ev.periodName || "—"}`
  })}

    <div class="hero-card">
      <div class="hero-main">
        <h1 class="hero-title">${esc(ev.managerName || "—")}</h1>
        <div class="hero-sub">
          ${esc(ev.schoolName || "مدرسة غير محددة")}
          ${ev.stageName ? ` · المرحلة: ${esc(ev.stageName)}` : ""}
          ${ev.administrationName ? ` · ${esc(ev.administrationName)}` : ""}
        </div>
        <div class="hero-tags">
          <span class="badge ${statusBadgeClass}">${esc(statusLabel)}</span>
          ${ev.approvedAt ? `<span class="badge badge-neutral">تاريخ الاعتماد: ${esc(fmtDate(ev.approvedAt))}</span>` : `<span class="badge badge-neutral">آخر تحديث: ${esc(fmtDate(ev.updatedAt))}</span>`}
          <span class="badge badge-neutral">إصدار النموذج: ${esc(ev.formVersionNumber || "1")}</span>
        </div>
      </div>
      ${scoreHeroBox}
    </div>

    ${!isApproved ? `<div class="warn-box"><strong>تنبيه إداري:</strong> هذه الوثيقة تمثل تقييمًا بحالة «${esc(statusLabel)}» ولم يُعتمد نهائيًا بعد؛ لا تُعد الدرجة نهائية إلا بعد الاعتماد الرسمي.</div>` : ""}
    ${ev.correctionReason ? `<div class="warn-box"><strong>ملاحظة تصحيح رسمي:</strong> تم إنشاء هذا التقييم كنسخة تصحيحية. سبب التصحيح: ${esc(ev.correctionReason)}</div>` : ""}

    <div class="info-grid">
      <div class="info-item"><div class="info-label">الرقم الوظيفي</div><div class="info-value num">${esc(ev.employeeNumber || "—")}</div></div>
      <div class="info-item"><div class="info-label">رقم الهوية / السجل المدني</div><div class="info-value num">${esc(ev.nationalId || "—")}</div></div>
      <div class="info-item"><div class="info-label">نطاق التكليف الإداري</div><div class="info-value">${ev.hasMultipleSchools ? "مكلف بعدة مدارس" : "مدرسة واحدة"}</div></div>
      <div class="info-item"><div class="info-label">خبرة التعليم / الإدارة</div><div class="info-value num">${ev.educationExperienceYears || 0} سنة تعليم · ${ev.administrationExperienceYears || 0} سنة إدارة</div></div>
      <div class="info-item"><div class="info-label">المدرسة المكلف بها</div><div class="info-value">${esc(ev.schoolName || "—")}</div></div>
      <div class="info-item"><div class="info-label">المرحلة الدراسية</div><div class="info-value">${esc(ev.stageName || "—")}</div></div>
      <div class="info-item"><div class="info-label">الإدارة التعليمية</div><div class="info-value">${esc(ev.administrationName || "—")}</div></div>
      <div class="info-item"><div class="info-label">توثيق المرحلة</div><div class="info-value num">${evidences.length} شاهد · ${plans.length} خطة تحسين</div></div>
    </div>

    <div class="levels-strip">
      <div class="lvl-chip" style="background:#ecfdf5;border-color:#a7f3d0;color:#065f46;">المستوى (5) متميز: <strong>${levelCounts[5]}</strong></div>
      <div class="lvl-chip" style="background:#f0f9ff;border-color:#bae6fd;color:#075985;">المستوى (4) فوق التوقعات: <strong>${levelCounts[4]}</strong></div>
      <div class="lvl-chip" style="background:#fffbeb;border-color:#fde68a;color:#92400e;">المستوى (3) وافق التوقعات: <strong>${levelCounts[3]}</strong></div>
      <div class="lvl-chip" style="background:#fff7ed;border-color:#fed7aa;color:#9a3412;">المستوى (2) بحاجة لتطوير: <strong>${levelCounts[2]}</strong></div>
      <div class="lvl-chip" style="background:#fff1f2;border-color:#fecdd3;color:#9f1239;">المستوى (1) غير مرضٍ: <strong>${levelCounts[1]}</strong></div>
    </div>

    <h2 class="sec-title">تفصيل عناصر ومعايير التقييم الرسمية (19 معيارًا)</h2>
    <table>
      <thead>
        <tr>
          <th style="width:24px;" class="center">#</th>
          <th>عنصر / معيار التقييم الرسمي</th>
          <th style="width:52px;" class="center">الوزن</th>
          <th style="width:48px;" class="center">الدرجة</th>
          <th style="width:88px;" class="center">مستوى الأداء</th>
          <th style="width:82px;" class="center">النقاط الموزونة</th>
          <th style="width:44px;" class="center">الشواهد</th>
          <th style="width:140px;">ملاحظات المُقيِّم</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
      <tfoot>${totalRow}</tfoot>
    </table>

    ${insightsHtml}

    ${ev.notes ? `<div class="note-box"><strong>التوصيات والملاحظات الإشرافية العامة:</strong><br/>${esc(ev.notes)}</div>` : ""}

    ${stageAttachmentsSummary}

    <div class="signature-grid">
      <div class="sig-card">
        <div class="sig-role">المشرف التربوي / المُقيِّم المعتمد</div>
        <div class="sig-sub">الاسم والتوقيع</div>
        <div class="sig-line">التوقيع: ........................................</div>
      </div>
      <div class="sig-card">
        <div class="sig-role">مدير المدرسة (بالعلم والاطلاع)</div>
        <div class="sig-sub">${esc(ev.managerName || "—")}</div>
        <div class="sig-line">التوقيع: ........................................</div>
      </div>
      <div class="sig-card">
        <div class="sig-role">اعتماد الجهة الإشرافية</div>
        <div class="sig-sub">الختم الرسمي والتاريخ</div>
        <div class="sig-line">الاعتماد: ........................................</div>
      </div>
    </div>

    ${pageFooter(orgName)}
  `;
  return wrap$8(content, params);
}
function renderManagerReport(params) {
  const {
    manager = {},
    evaluations = [],
    latestApprovedEvaluation = null,
    plans = [],
    evidences = [],
    orgName,
    orgSubtitle,
    appTitle,
    preparedBy,
    logoDataUri
  } = params;
  const approvedEvals = evaluations.filter((e) => e.status === "approved" && e.finalScore != null);
  const scores = approvedEvals.map((e) => Number(e.finalScore)).filter((n) => !Number.isNaN(n));
  const avgScore = scores.length ? (scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(2) : "—";
  const maxScore = scores.length ? Math.max(...scores).toFixed(2) : "—";
  const completedPlansCount = plans.filter((p) => p.status === "completed").length;
  const overduePlansCount = plans.filter((p) => (p.isOverdue || p.status === "overdue") && p.status !== "completed").length;
  const totalFiles = evidences.reduce((acc, e) => acc + (e.attachmentCount || 0), 0);
  const chronologicalApproved = [...approvedEvals].reverse();
  const deltaByEvalId = {};
  for (let i = 1; i < chronologicalApproved.length; i++) {
    const prev = Number(chronologicalApproved[i - 1].finalScore);
    const curr = Number(chronologicalApproved[i].finalScore);
    if (!Number.isNaN(prev) && !Number.isNaN(curr)) {
      deltaByEvalId[chronologicalApproved[i].id] = Number((curr - prev).toFixed(2));
    }
  }
  const evalRows = evaluations.map((ev, idx) => {
    const st = SHORT_STATUS_LABEL[ev.status] || ev.status;
    const stClass = ev.status === "approved" ? "badge-success" : ev.status === "completed" ? "badge-info" : ev.status === "draft" ? "badge-warning" : "badge-neutral";
    const scoreVal = ev.finalScore != null ? Number(ev.finalScore).toFixed(2) : null;
    const ratingMeta = getRatingMeta(ev.generalRating || ev.general_rating, scoreVal);
    const delta = deltaByEvalId[ev.id];
    const deltaHtml = delta === void 0 ? '<span style="color:#94a3b8;">—</span>' : delta > 0 ? `<span style="color:#059669;font-weight:700;">+${delta.toFixed(2)} ▲</span>` : delta < 0 ? `<span style="color:#e11d48;font-weight:700;">${delta.toFixed(2)} ▼</span>` : '<span style="color:#64748b;">0.00 ▬</span>';
    return `
      <tr>
        <td class="center num">${idx + 1}</td>
        <td style="font-weight:700;">${esc(ev.yearLabel || "—")}</td>
        <td>${esc(ev.periodName || "—")}</td>
        <td class="center num" style="font-weight:700;color:#064e3b;">${scoreVal != null ? `${esc(scoreVal)} / 100` : "—"}</td>
        <td class="center">${scoreVal != null || ev.generalRating ? `<span class="badge ${ratingMeta.badge}">${esc(ratingMeta.label)}</span>` : "—"}</td>
        <td class="center num">${deltaHtml}</td>
        <td class="center"><span class="badge ${stClass}">${esc(st)}</span></td>
        <td class="center num">${esc(fmtDate(ev.approvedAt || ev.updatedAt))}</td>
        <td style="font-size:9px;color:#475569;">${ev.notes ? esc(ev.notes) : "—"}</td>
      </tr>
    `;
  }).join("");
  const latestItemsHtml = latestApprovedEvaluation && Array.isArray(latestApprovedEvaluation.items) && latestApprovedEvaluation.items.length > 0 ? `
      <h2 class="sec-title">تفصيل أحدث تقييم معتمد (${esc(latestApprovedEvaluation.yearLabel || "")} — ${esc(latestApprovedEvaluation.periodName || "")} · النتيجة: ${esc(Number(latestApprovedEvaluation.finalScore).toFixed(2))})</h2>
      <table>
        <thead>
          <tr>
            <th style="width:24px;" class="center">#</th>
            <th>المعيار الرسمي</th>
            <th style="width:52px;" class="center">الوزن</th>
            <th style="width:48px;" class="center">الدرجة</th>
            <th style="width:92px;" class="center">مستوى الأداء</th>
            <th style="width:65px;" class="center">المساهمة</th>
            <th style="width:150px;">ملاحظة المعيار</th>
          </tr>
        </thead>
        <tbody>
          ${latestApprovedEvaluation.items.map((it) => `
            <tr class="${it.elementNumber === 13 ? "element-highlight" : ""}">
              <td class="center num">${esc(it.elementNumber)}</td>
              <td>${esc(it.name)}${it.elementNumber === 13 ? ' <span class="badge badge-warning">10%</span>' : ""}</td>
              <td class="center num">${(Number(it.weightBp || 0) / 100).toFixed(2)}%</td>
              <td class="center num"><span class="score-pill ${getScorePillClass(it.scoreValue)}">${it.scoreValue ?? "—"}</span></td>
              <td class="center" style="font-size:9px;">${esc(it.levelLabel || "—")}</td>
              <td class="center num" style="font-weight:700;">${it.contribution != null ? esc(it.contribution) : "—"}</td>
              <td style="font-size:9px;">${esc(it.notes || "—")}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    ` : "";
  const planRows = plans.map((p, idx) => {
    const isLate = (p.isOverdue || p.status === "overdue") && p.status !== "completed";
    const st = isLate ? "متأخرة" : PLAN_STATUS_LABEL[p.status] || p.status;
    const stClass = p.status === "completed" ? "badge-success" : isLate ? "badge-danger" : p.status === "in_progress" ? "badge-info" : "badge-neutral";
    const stageStr = [p.yearLabel, p.periodName].filter(Boolean).join(" / ") || "—";
    return `
      <tr>
        <td class="center num">${idx + 1}</td>
        <td>
          <div style="font-weight:700;color:#0f172a;">${esc(p.goal)}</div>
          ${p.actions ? `<div style="font-size:8.8px;color:#475569;margin-top:2px;">الإجراءات: ${esc(p.actions)}</div>` : ""}
          ${p.latestFollowUp ? `<div style="font-size:8.8px;color:#0369a1;margin-top:2px;">متابعة المشرف: ${esc(p.latestFollowUp)}</div>` : ""}
        </td>
        <td class="center">${p.elementNumber ? `<span class="badge badge-neutral">ع${esc(p.elementNumber)}</span>` : "عامة"}</td>
        <td class="center" style="font-size:9px;">${esc(stageStr)}</td>
        <td class="center num" style="font-size:9px;">${esc(fmtDate(p.startsOn))} ← ${esc(fmtDate(p.endsOn))}</td>
        <td class="center num">${p.attachmentCount || 0} مرفق · ${p.followUpCount || 0} متابعة</td>
        <td class="center"><span class="badge ${stClass}">${esc(st)}</span></td>
      </tr>
    `;
  }).join("");
  const evidenceRows = evidences.map((e, idx) => {
    const stageStr = [e.yearLabel, e.periodName].filter(Boolean).join(" / ") || "—";
    const latestComment = e.comments && e.comments.length > 0 ? e.comments[0].comment : "";
    return `
      <tr>
        <td class="center num">${idx + 1}</td>
        <td>
          <div style="font-weight:700;">${esc(e.title)}</div>
          ${e.description ? `<div style="font-size:8.8px;color:#475569;">${esc(e.description)}</div>` : ""}
        </td>
        <td class="center">${e.elementNumber ? `<span class="badge badge-info">ع${esc(e.elementNumber)}</span>` : "عام"}</td>
        <td class="center" style="font-size:9px;">${esc(stageStr)}</td>
        <td class="center num">${e.attachmentCount || 0} ملف</td>
        <td style="font-size:9px;color:#0369a1;">${latestComment ? esc(latestComment) : '<span style="color:#94a3b8;">—</span>'}</td>
        <td class="center num">${esc(fmtDate(e.createdAt))}</td>
      </tr>
    `;
  }).join("");
  const avgRatingMeta = getRatingMeta("", avgScore !== "—" ? Number(avgScore) : null);
  const content = `
    ${pageHeader({
    orgName,
    orgSubtitle,
    appTitle,
    preparedBy,
    logoDataUri,
    docTitle: "الملف التقييمي والإشرافي الشامل لمدير المدرسة",
    meta: `سجل مهني متكامل — ${manager.status === "active" ? "مدير نشط" : "سجل مؤرشف"}`
  })}

    <div class="hero-card">
      <div class="hero-main">
        <h1 class="hero-title">${esc(manager.fullName || "—")}</h1>
        <div class="hero-sub">
          ${esc(manager.schoolName || "بدون مدرسة مسجلة")}
          ${manager.stageName ? ` · المرحلة: ${esc(manager.stageName)}` : ""}
          ${manager.administrationName ? ` · ${esc(manager.administrationName)}` : ""}
        </div>
        <div class="hero-tags">
          <span class="badge ${manager.status === "active" ? "badge-success" : "badge-neutral"}">${manager.status === "active" ? "على رأس العمل (نشط)" : "مؤرشف"}</span>
          <span class="badge badge-neutral">الرقم الوظيفي: ${esc(manager.employeeNumber || "—")}</span>
          <span class="badge badge-neutral">الهوية الوطنية: ${esc(manager.nationalId || "—")}</span>
          <span class="badge badge-neutral">${manager.hasMultipleSchools ? "مكلف بعدة مدارس" : "مدرسة واحدة"}</span>
          <span class="badge badge-neutral">الخدمة: ${manager.educationExperienceYears || 0}س تعليم / ${manager.administrationExperienceYears || 0}س إدارة</span>
        </div>
      </div>
      <div class="hero-score-card" style="border-color:${avgRatingMeta.bar};background:${avgRatingMeta.bg};">
        <div class="sc-lbl" style="color:${avgRatingMeta.text};">متوسط التقييمات المعتمدة</div>
        <div class="sc-val" style="color:${avgRatingMeta.text};">${esc(avgScore)} ${avgScore !== "—" ? "<span>/ 100</span>" : ""}</div>
        ${avgScore !== "—" ? `<div style="margin-top:2px;"><span class="badge ${avgRatingMeta.badge}">${esc(avgRatingMeta.label)}</span></div>` : '<div style="font-size:8.5px;color:#64748b;">لا يوجد تقييم معتمد بعد</div>'}
      </div>
    </div>

    <div class="kpi-grid">
      <div class="kpi-card"><div class="kpi-num num">${evaluations.length}</div><div class="kpi-lbl">إجمالي التقييمات</div></div>
      <div class="kpi-card kpi-teal"><div class="kpi-num num">${approvedEvals.length}</div><div class="kpi-lbl">التقييمات المعتمدة</div></div>
      <div class="kpi-card kpi-blue"><div class="kpi-num num">${esc(maxScore)}</div><div class="kpi-lbl">أعلى درجة محققة</div></div>
      <div class="kpi-card kpi-amber"><div class="kpi-num num">${evidences.length}</div><div class="kpi-lbl">الشواهد المرفوعة</div><div class="kpi-sub">${totalFiles} ملف مرفق</div></div>
      <div class="kpi-card"><div class="kpi-num num">${completedPlansCount} / ${plans.length}</div><div class="kpi-lbl">خطط التحسين المنجزة</div></div>
      <div class="kpi-card kpi-rose"><div class="kpi-num num">${overduePlansCount}</div><div class="kpi-lbl">خطط متأخرة</div></div>
    </div>

    <h2 class="sec-title">أولاً: سجل التقييمات عبر الأعوام والفترات (${evaluations.length})</h2>
    ${evalRows ? `
      <table>
        <thead><tr>
          <th style="width:24px;" class="center">#</th>
          <th style="width:65px;">العام</th>
          <th style="width:95px;">الفترة</th>
          <th style="width:80px;" class="center">النتيجة</th>
          <th style="width:95px;" class="center">التقدير العام</th>
          <th style="width:68px;" class="center">مؤشر التغير</th>
          <th style="width:65px;" class="center">الحالة</th>
          <th style="width:75px;" class="center">التاريخ</th>
          <th>ملاحظات عامة</th>
        </tr></thead>
        <tbody>${evalRows}</tbody>
      </table>
    ` : '<div class="empty">لا توجد تقييمات مسجلة لهذا المدير حتى الآن.</div>'}

    ${latestItemsHtml}

    <h2 class="sec-title">ثانيًا: خطط التحسين والتطوير المهني (${plans.length})</h2>
    ${planRows ? `
      <table>
        <thead><tr>
          <th style="width:24px;" class="center">#</th>
          <th>الهدف التطويري والإجراءات ومتابعة المشرف</th>
          <th style="width:52px;" class="center">المعيار</th>
          <th style="width:95px;" class="center">العام / الفترة</th>
          <th style="width:110px;" class="center">الفترة الزمنية</th>
          <th style="width:90px;" class="center">التوثيق</th>
          <th style="width:68px;" class="center">الحالة</th>
        </tr></thead>
        <tbody>${planRows}</tbody>
      </table>
    ` : '<div class="empty">لا توجد خطط تحسين مسجلة لهذا المدير.</div>'}

    <h2 class="sec-title">ثالثًا: سجل الشواهد المهنية الموثقة (${evidences.length})</h2>
    ${evidenceRows ? `
      <table>
        <thead><tr>
          <th style="width:24px;" class="center">#</th>
          <th>عنوان الشاهد ووصفه</th>
          <th style="width:52px;" class="center">المعيار</th>
          <th style="width:95px;" class="center">العام / الفترة</th>
          <th style="width:58px;" class="center">المرفقات</th>
          <th style="width:150px;">تعليق المشرف التربوي</th>
          <th style="width:72px;" class="center">تاريخ الرفع</th>
        </tr></thead>
        <tbody>${evidenceRows}</tbody>
      </table>
    ` : '<div class="empty">لا توجد شواهد مهنية مرفوعة لهذا المدير.</div>'}

    <div class="signature-grid">
      <div class="sig-card">
        <div class="sig-role">المشرف التربوي المختص</div>
        <div class="sig-line">التوقيع: ........................................</div>
      </div>
      <div class="sig-card">
        <div class="sig-role">مدير المدرسة</div>
        <div class="sig-line">التوقيع: ........................................</div>
      </div>
      <div class="sig-card">
        <div class="sig-role">اعتماد الإدارة / القسم</div>
        <div class="sig-line">الختم والتوقيع: .................................</div>
      </div>
    </div>

    ${pageFooter(orgName)}
  `;
  return wrap$8(content, params);
}
function renderAllManagersReport(params) {
  const {
    evaluations = [],
    criteriaStats = [],
    filters = {},
    orgName,
    orgSubtitle,
    appTitle,
    preparedBy,
    logoDataUri
  } = params;
  const approved = evaluations.filter((e) => e.status === "approved" && e.finalScore != null);
  const inProgress = evaluations.filter((e) => e.status === "draft" || e.status === "completed");
  const scores = approved.map((e) => Number(e.finalScore)).filter((n) => !Number.isNaN(n));
  const avg = scores.length ? (scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(2) : "—";
  const max = scores.length ? Math.max(...scores).toFixed(2) : "—";
  const min = scores.length ? Math.min(...scores).toFixed(2) : "—";
  const approvalRate = evaluations.length ? Math.round(approved.length / evaluations.length * 100) : 0;
  const tiers = [
    { key: "exc", label: "متميز", range: "90 – 100", count: 0, color: "#10b981", bg: "#ecfdf5", text: "#065f46" },
    { key: "vg", label: "فوق التوقعات", range: "76 – 89", count: 0, color: "#0284c7", bg: "#f0f9ff", text: "#075985" },
    { key: "gd", label: "وافق التوقعات", range: "61 – 75", count: 0, color: "#d97706", bg: "#fffbeb", text: "#92400e" },
    { key: "nd", label: "بحاجة إلى تطوير", range: "41 – 60", count: 0, color: "#ea580c", bg: "#fff7ed", text: "#9a3412" },
    { key: "un", label: "غير مرضٍ", range: "أقل من 41", count: 0, color: "#e11d48", bg: "#fff1f2", text: "#9f1239" }
  ];
  for (const s of scores) {
    if (s >= 90) tiers[0].count++;
    else if (s >= 76) tiers[1].count++;
    else if (s >= 61) tiers[2].count++;
    else if (s >= 41) tiers[3].count++;
    else tiers[4].count++;
  }
  const sortedEvaluations = [...evaluations].sort((a, b) => {
    const rank = { approved: 1, completed: 2, draft: 3, superseded: 4 };
    const ra = rank[a.status] || 9;
    const rb = rank[b.status] || 9;
    if (ra !== rb) return ra - rb;
    if (a.finalScore != null && b.finalScore != null) return Number(b.finalScore) - Number(a.finalScore);
    return String(a.managerName || "").localeCompare(String(b.managerName || ""), "ar");
  });
  const rows = sortedEvaluations.map((ev, i) => {
    const st = SHORT_STATUS_LABEL[ev.status] || ev.status;
    const stClass = ev.status === "approved" ? "badge-success" : ev.status === "completed" ? "badge-info" : ev.status === "draft" ? "badge-warning" : "badge-neutral";
    const scoreVal = ev.finalScore != null ? Number(ev.finalScore).toFixed(2) : null;
    const rMeta = getRatingMeta(ev.generalRating || ev.general_rating, scoreVal);
    return `
      <tr>
        <td class="center num" style="font-weight:700;">${i + 1}</td>
        <td>
          <div style="font-weight:700;color:#0f172a;">${esc(ev.managerName || "—")}</div>
          ${ev.employeeNumber ? `<div style="font-size:8.5px;color:#64748b;">الرقم الوظيفي: ${esc(ev.employeeNumber)}</div>` : ""}
        </td>
        <td>
          <div>${esc(ev.schoolName || "—")}</div>
          ${ev.stageName ? `<div style="font-size:8.5px;color:#64748b;">${esc(ev.stageName)}</div>` : ""}
        </td>
        <td class="center">${esc(ev.yearLabel || "—")} / ${esc(ev.periodName || "—")}</td>
        <td class="center num" style="font-size:9px;">${ev.evidencesCount ?? 0} شاهد · ${ev.plansCount ?? 0} خطة</td>
        <td class="center num" style="font-weight:700;font-size:11px;color:#064e3b;">${scoreVal != null ? esc(scoreVal) : "—"}</td>
        <td class="center">${scoreVal != null || ev.generalRating ? `<span class="badge ${rMeta.badge}">${esc(rMeta.label)}</span>` : "—"}</td>
        <td class="center"><span class="badge ${stClass}">${esc(st)}</span></td>
        <td class="center num">${esc(fmtDate(ev.approvedAt || ev.updatedAt))}</td>
      </tr>
    `;
  }).join("");
  const filterLine = filters?.label || [
    filters?.yearLabel ? `السنة: ${filters.yearLabel}` : "",
    filters?.periodName ? `الفترة: ${filters.periodName}` : "",
    filters?.status ? `الحالة: ${SHORT_STATUS_LABEL[filters.status] || filters.status}` : ""
  ].filter(Boolean).join(" · ") || "جميع الأعوام والفترات";
  const distHtml = scores.length > 0 ? `
    <h2 class="sec-title">توزيع التقديرات العامة للأداء (للتقييمات المعتمدة: ${scores.length})</h2>
    <div class="dist-grid">
      ${tiers.map((t) => {
    const pct = scores.length ? Math.round(t.count / scores.length * 100) : 0;
    return `
          <div class="dist-card" style="background:${t.bg};border-color:${t.color}55;">
            <div class="dist-top" style="color:${t.text};">
              <span>${esc(t.label)}</span>
              <span style="font-size:8px;opacity:0.85;">(${esc(t.range)})</span>
            </div>
            <div class="dist-count num" style="color:${t.text};">${t.count} <span style="font-size:9.5px;font-weight:600;">(${pct}%)</span></div>
            <div class="mini-bar-wrap"><div class="mini-bar-fill" style="width:${pct}%;background:${t.color};"></div></div>
          </div>
        `;
  }).join("")}
    </div>
  ` : "";
  const validCriteria = (criteriaStats || []).filter((c) => c.evaluatedCount > 0);
  const criteriaHtml = validCriteria.length > 0 ? `
    <h2 class="sec-title">التحليل الإحصائي لأداء المعايير الرسمية الـ 19 (عبر التقييمات المعتمدة)</h2>
    <table>
      <thead>
        <tr>
          <th style="width:24px;" class="center">#</th>
          <th>اسم المعيار الرسمي</th>
          <th style="width:52px;" class="center">الوزن</th>
          <th style="width:65px;" class="center">متوسط الدرجة</th>
          <th style="width:95px;" class="center">نسبة التحقق</th>
          <th style="width:68px;" class="center">أعلى / أدنى</th>
          <th style="width:95px;" class="center">مؤشر الأداء الجماعي</th>
        </tr>
      </thead>
      <tbody>
        ${criteriaStats.map((c) => {
    const avg5 = c.avgScore != null ? Number(c.avgScore).toFixed(2) : "—";
    const pct = c.avgScore != null ? Math.round(Number(c.avgScore) / 5 * 100) : 0;
    const badge = c.avgScore == null ? '<span class="badge badge-neutral">غير مقيم</span>' : c.avgScore >= 4.2 ? '<span class="badge badge-success">نقطة قوة متميزة</span>' : c.avgScore >= 3.4 ? '<span class="badge badge-info">أداء مستقر جيد</span>' : '<span class="badge badge-warning">أولوية تطوير</span>';
    const barColor = c.avgScore >= 4.2 ? "#10b981" : c.avgScore >= 3.4 ? "#0284c7" : "#d97706";
    return `
            <tr class="${c.elementNumber === 13 ? "element-highlight" : ""}">
              <td class="center num">${esc(c.elementNumber)}</td>
              <td>${esc(c.name)}${c.elementNumber === 13 ? ' <span class="badge badge-warning">10%</span>' : ""}</td>
              <td class="center num">${(Number(c.weightBp || 0) / 100).toFixed(2)}%</td>
              <td class="center num" style="font-weight:700;">${avg5 !== "—" ? `${avg5} / 5` : "—"}</td>
              <td class="center num">
                ${c.avgScore != null ? `
                  <div style="font-weight:700;font-size:9.5px;">${pct}%</div>
                  <div class="mini-bar-wrap"><div class="mini-bar-fill" style="width:${pct}%;background:${barColor};"></div></div>
                ` : "—"}
              </td>
              <td class="center num">${c.maxScore ?? "—"} / ${c.minScore ?? "—"}</td>
              <td class="center">${badge}</td>
            </tr>
          `;
  }).join("")}
      </tbody>
    </table>
  ` : "";
  const content = `
    ${pageHeader({
    orgName,
    orgSubtitle,
    appTitle,
    preparedBy,
    logoDataUri,
    docTitle: "التقرير الإحصائي الشامل لنتائج تقييم مدراء المدارس",
    meta: filterLine
  })}

    <div class="kpi-grid">
      <div class="kpi-card"><div class="kpi-num num">${evaluations.length}</div><div class="kpi-lbl">إجمالي السجلات</div></div>
      <div class="kpi-card kpi-teal"><div class="kpi-num num">${approved.length}</div><div class="kpi-lbl">التقييمات المعتمدة</div><div class="kpi-sub">نسبة الاعتماد ${approvalRate}%</div></div>
      <div class="kpi-card kpi-amber"><div class="kpi-num num">${inProgress.length}</div><div class="kpi-lbl">قيد الإجراء / مكتمل</div></div>
      <div class="kpi-card kpi-blue"><div class="kpi-num num">${esc(avg)}</div><div class="kpi-lbl">المتوسط العام للمعتمد</div></div>
      <div class="kpi-card"><div class="kpi-num num">${esc(max)}</div><div class="kpi-lbl">أعلى نتيجة معتمدة</div></div>
      <div class="kpi-card kpi-slate"><div class="kpi-num num">${esc(min)}</div><div class="kpi-lbl">أدنى نتيجة معتمدة</div></div>
    </div>

    ${distHtml}

    <h2 class="sec-title">بيان نتائج مدراء المدارس مرتبًا حسب الأداء (${evaluations.length})</h2>
    ${rows ? `
      <table>
        <thead><tr>
          <th style="width:24px;" class="center">#</th>
          <th>مدير المدرسة</th>
          <th>المدرسة والمرحلة</th>
          <th style="width:110px;" class="center">العام / الفترة</th>
          <th style="width:88px;" class="center">التوثيق</th>
          <th style="width:58px;" class="center">النتيجة</th>
          <th style="width:92px;" class="center">التقدير العام</th>
          <th style="width:62px;" class="center">الحالة</th>
          <th style="width:72px;" class="center">التاريخ</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
    ` : '<div class="empty">لا توجد سجلات تقييم مطابقة للفلاتر المحددة.</div>'}

    ${criteriaHtml}

    <div class="note-box"><strong>إيضاح منهجي:</strong> تُحتسب المتوسطات ونسب التقديرات حصريًا من التقييمات المعتمدة رسميًا. السجلات التي ما زالت في مرحلة المسودة أو بانتظار الاعتماد تظهر في الجدول لمتابعة الإنجاز دون التأثير على المتوسط الإحصائي.</div>

    ${pageFooter(orgName)}
  `;
  return wrap$8(content, params);
}
function getLocalDateStr() {
  const d = /* @__PURE__ */ new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function fmtSlashDate(iso) {
  if (!iso) return "—";
  const s = String(iso).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10).replace(/-/g, "/");
  return s.slice(0, 10);
}
function colToLetter(colNumber) {
  let n = Number(colNumber);
  let letter = "";
  while (n > 0) {
    const mod = (n - 1) % 26;
    letter = String.fromCharCode(65 + mod) + letter;
    n = Math.floor((n - 1) / 26);
  }
  return letter || "A";
}
const FILLS = {
  bannerMain: { type: "pattern", pattern: "solid", fgColor: { argb: "FF064E3B" } },
  bannerSub: { type: "pattern", pattern: "solid", fgColor: { argb: "FFECFDF5" } },
  bannerMeta: { type: "pattern", pattern: "solid", fgColor: { argb: "FFF8FAFC" } },
  tableHeader: { type: "pattern", pattern: "solid", fgColor: { argb: "FF065F46" } },
  zebraEven: { type: "pattern", pattern: "solid", fgColor: { argb: "FFF8FAFC" } },
  zebraOdd: { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFFFFF" } },
  totalRow: { type: "pattern", pattern: "solid", fgColor: { argb: "FFD1FAE5" } },
  kpiLabel: { type: "pattern", pattern: "solid", fgColor: { argb: "FFF1F5F9" } },
  kpiValue: { type: "pattern", pattern: "solid", fgColor: { argb: "FFECFDF5" } },
  el13Highlight: { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFFBEB" } },
  // التقديرات والحالات
  emeraldSoft: { type: "pattern", pattern: "solid", fgColor: { argb: "FFD1FAE5" } },
  skySoft: { type: "pattern", pattern: "solid", fgColor: { argb: "FFE0F2FE" } },
  amberSoft: { type: "pattern", pattern: "solid", fgColor: { argb: "FFFEF3C7" } },
  orangeSoft: { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFEDD5" } },
  roseSoft: { type: "pattern", pattern: "solid", fgColor: { argb: "FFFFE4E6" } },
  slateSoft: { type: "pattern", pattern: "solid", fgColor: { argb: "FFF1F5F9" } }
};
const FONTS = {
  bannerTitle: { name: "Cairo", bold: true, size: 14, color: { argb: "FFFFFFFF" } },
  bannerSub: { name: "Cairo", bold: true, size: 10.5, color: { argb: "FF065F46" } },
  bannerMeta: { name: "Cairo", bold: false, size: 9.5, color: { argb: "FF475569" } },
  tableHeader: { name: "Cairo", bold: true, size: 11, color: { argb: "FFFFFFFF" } },
  body: { name: "Cairo", bold: false, size: 10.5, color: { argb: "FF0F172A" } },
  bodyBold: { name: "Cairo", bold: true, size: 10.5, color: { argb: "FF0F172A" } },
  total: { name: "Cairo", bold: true, size: 11, color: { argb: "FF064E3B" } },
  emeraldBold: { name: "Cairo", bold: true, size: 10.5, color: { argb: "FF065F46" } },
  skyBold: { name: "Cairo", bold: true, size: 10.5, color: { argb: "FF075985" } },
  amberBold: { name: "Cairo", bold: true, size: 10.5, color: { argb: "FF92400E" } },
  orangeBold: { name: "Cairo", bold: true, size: 10.5, color: { argb: "FF9A3412" } },
  roseBold: { name: "Cairo", bold: true, size: 10.5, color: { argb: "FF9F1239" } },
  slateBold: { name: "Cairo", bold: true, size: 10, color: { argb: "FF475569" } }
};
const THIN_BORDER = {
  top: { style: "thin", color: { argb: "FFCBD5E1" } },
  bottom: { style: "thin", color: { argb: "FFCBD5E1" } },
  left: { style: "thin", color: { argb: "FFCBD5E1" } },
  right: { style: "thin", color: { argb: "FFCBD5E1" } }
};
const HEADER_BORDER = {
  top: { style: "medium", color: { argb: "FF064E3B" } },
  bottom: { style: "medium", color: { argb: "FF047857" } },
  left: { style: "thin", color: { argb: "FF047857" } },
  right: { style: "thin", color: { argb: "FF047857" } }
};
function styleRatingCell(cell, ratingText, scoreFallback = null) {
  const r = String(ratingText || getRatingByScore(scoreFallback) || "").trim();
  cell.alignment = { horizontal: "center", vertical: "middle", readingOrder: "rtl" };
  if (!r || r === "—") {
    cell.font = FONTS.slateBold;
    return;
  }
  if (r.includes("متميز") || r.includes("ممتاز")) {
    cell.fill = FILLS.emeraldSoft;
    cell.font = FONTS.emeraldBold;
  } else if (r.includes("فوق التوقعات") || r.includes("جيد جدا") || r.includes("جيد جدًا")) {
    cell.fill = FILLS.skySoft;
    cell.font = FONTS.skyBold;
  } else if (r.includes("وافق التوقعات") || r.includes("جيد")) {
    cell.fill = FILLS.amberSoft;
    cell.font = FONTS.amberBold;
  } else if (r.includes("بحاجة") || r.includes("تطوير")) {
    cell.fill = FILLS.orangeSoft;
    cell.font = FONTS.orangeBold;
  } else if (r.includes("غير مرض")) {
    cell.fill = FILLS.roseSoft;
    cell.font = FONTS.roseBold;
  } else {
    cell.fill = FILLS.slateSoft;
    cell.font = FONTS.slateBold;
  }
}
function styleStatusCell(cell, statusText) {
  const s = String(statusText || "").trim();
  cell.alignment = { horizontal: "center", vertical: "middle", readingOrder: "rtl" };
  if (s === "معتمد" || s === "مكتملة" || s === "نشط") {
    cell.fill = FILLS.emeraldSoft;
    cell.font = FONTS.emeraldBold;
  } else if (s === "مكتمل" || s === "قيد التنفيذ") {
    cell.fill = FILLS.skySoft;
    cell.font = FONTS.skyBold;
  } else if (s === "مسودة") {
    cell.fill = FILLS.amberSoft;
    cell.font = FONTS.amberBold;
  } else if (s === "متأخرة" || s === "نعم") {
    cell.fill = FILLS.roseSoft;
    cell.font = FONTS.roseBold;
  } else {
    cell.fill = FILLS.slateSoft;
    cell.font = FONTS.slateBold;
  }
}
function styleScoreCell(cell, val) {
  cell.alignment = { horizontal: "center", vertical: "middle" };
  const n = Number(val);
  if (!Number.isInteger(n) || n < 1 || n > 5) {
    cell.font = FONTS.slateBold;
    return;
  }
  if (n === 5) {
    cell.fill = FILLS.emeraldSoft;
    cell.font = FONTS.emeraldBold;
  } else if (n === 4) {
    cell.fill = FILLS.skySoft;
    cell.font = FONTS.skyBold;
  } else if (n === 3) {
    cell.fill = FILLS.amberSoft;
    cell.font = FONTS.amberBold;
  } else if (n === 2) {
    cell.fill = FILLS.orangeSoft;
    cell.font = FONTS.orangeBold;
  } else if (n === 1) {
    cell.fill = FILLS.roseSoft;
    cell.font = FONTS.roseBold;
  }
}
function newWorkbook() {
  const wb = new ExcelJS.Workbook();
  wb.creator = "نظام تقييم الأداء الوظيفي لمدراء المدارس";
  wb.created = /* @__PURE__ */ new Date();
  wb.modified = /* @__PURE__ */ new Date();
  return wb;
}
function newSheet(wb, name2, orientation = "landscape") {
  return wb.addWorksheet(name2, {
    views: [{ rightToLeft: true }],
    pageSetup: {
      paperSize: 9,
      // A4
      orientation,
      fitToPage: true,
      fitToWidth: 1,
      fitToHeight: 0,
      horizontalCentered: true,
      margins: { left: 0.3, right: 0.3, top: 0.4, bottom: 0.4, header: 0.2, footer: 0.2 }
    }
  });
}
function addOfficialBanner(ws, {
  colCount,
  title,
  filterLabel: filterLabel2,
  orgName = "وزارة التعليم",
  appTitle = "تقييم أداء مدراء المدارس وفق الدليل الإرشادي لإدارة الأداء الوظيفي لشاغلي الوظائف التعليمية (الإصدار الثاني)",
  preparedBy = "إعداد وتنسيق : أخصائي الإدارة المدرسية / الحسين إبراهيم شويع",
  orgSubtitle = ""
}) {
  const lastCol = colToLetter(Math.max(colCount, 2));
  const r1 = ws.addRow([`المملكة العربية السعودية — ${orgName}  |  ${title}`]);
  ws.mergeCells(`A${r1.number}:${lastCol}${r1.number}`);
  r1.height = 32;
  r1.getCell(1).fill = FILLS.bannerMain;
  r1.getCell(1).font = FONTS.bannerTitle;
  r1.getCell(1).alignment = { horizontal: "center", vertical: "middle", readingOrder: "rtl" };
  const r2Text = `${appTitle}${filterLabel2 ? `   •   النطاق: ${filterLabel2}` : ""}`;
  const r2 = ws.addRow([r2Text]);
  ws.mergeCells(`A${r2.number}:${lastCol}${r2.number}`);
  r2.height = 24;
  r2.getCell(1).fill = FILLS.bannerSub;
  r2.getCell(1).font = FONTS.bannerSub;
  r2.getCell(1).alignment = { horizontal: "center", vertical: "middle", readingOrder: "rtl" };
  r2.getCell(1).border = THIN_BORDER;
  const r3Text = `${preparedBy}${orgSubtitle ? ` — ${orgSubtitle}` : ""}   |   تاريخ استخراج التقرير: ${getLocalDateStr()}`;
  const r3 = ws.addRow([r3Text]);
  ws.mergeCells(`A${r3.number}:${lastCol}${r3.number}`);
  r3.height = 21;
  r3.getCell(1).fill = FILLS.bannerMeta;
  r3.getCell(1).font = FONTS.bannerMeta;
  r3.getCell(1).alignment = { horizontal: "center", vertical: "middle", readingOrder: "rtl" };
  r3.getCell(1).border = THIN_BORDER;
}
function addKpiSummaryStrip(ws, kpis, colCount) {
  if (!kpis || kpis.length === 0) return;
  ws.addRow([]);
  const labelRowVals = new Array(Math.max(colCount, kpis.length)).fill("");
  const valRowVals = new Array(Math.max(colCount, kpis.length)).fill("");
  kpis.forEach((k, idx) => {
    if (idx < labelRowVals.length) {
      labelRowVals[idx] = k.label;
      valRowVals[idx] = k.value;
    }
  });
  const rLbl = ws.addRow(labelRowVals.slice(0, Math.max(colCount, kpis.length)));
  const rVal = ws.addRow(valRowVals.slice(0, Math.max(colCount, kpis.length)));
  rLbl.height = 20;
  rVal.height = 25;
  const limit = Math.min(kpis.length, colCount);
  for (let c = 1; c <= limit; c++) {
    const cL = rLbl.getCell(c);
    const cV = rVal.getCell(c);
    cL.fill = FILLS.kpiLabel;
    cL.font = FONTS.slateBold;
    cL.alignment = { horizontal: "center", vertical: "middle", readingOrder: "rtl", wrapText: true };
    cL.border = THIN_BORDER;
    cV.fill = FILLS.kpiValue;
    cV.font = FONTS.total;
    cV.alignment = { horizontal: "center", vertical: "middle", readingOrder: "rtl" };
    cV.border = THIN_BORDER;
  }
  ws.addRow([]);
}
function addTableHeader(ws, cols, freeze = true) {
  const headerRow = ws.addRow(cols.map((c) => c.header));
  const rowIdx = headerRow.number;
  headerRow.height = 30;
  for (let c = 1; c <= cols.length; c++) {
    const cell = headerRow.getCell(c);
    cell.fill = FILLS.tableHeader;
    cell.font = FONTS.tableHeader;
    cell.alignment = { horizontal: "center", vertical: "middle", readingOrder: "rtl", wrapText: true };
    cell.border = HEADER_BORDER;
  }
  if (freeze) {
    ws.views = [{ rightToLeft: true, state: "frozen", ySplit: rowIdx }];
  }
  ws.autoFilter = {
    from: { row: rowIdx, column: 1 },
    to: { row: rowIdx, column: cols.length }
  };
  return rowIdx;
}
function styleDataRow(row, idx, cols) {
  const isEven = idx % 2 === 1;
  const baseFill = isEven ? FILLS.zebraEven : FILLS.zebraOdd;
  row.height = 24;
  for (let c = 1; c <= cols.length; c++) {
    const cell = row.getCell(c);
    const colDef = cols[c - 1];
    cell.fill = baseFill;
    cell.font = colDef.bold ? FONTS.bodyBold : FONTS.body;
    cell.border = THIN_BORDER;
    cell.alignment = {
      horizontal: colDef.align || "start",
      vertical: "middle",
      readingOrder: "rtl",
      wrapText: true
    };
    if (colDef.numFmt) {
      cell.numFmt = colDef.numFmt;
    }
  }
}
async function saveWithDialog(workbook, defaultFileName) {
  const parent = electron.BrowserWindow.getFocusedWindow();
  const result2 = await electron.dialog.showSaveDialog(parent, {
    title: "حفظ التقرير بصيغة Excel",
    defaultPath: defaultFileName || `report-${Date.now()}.xlsx`,
    filters: [{ name: "ملف Excel", extensions: ["xlsx"] }]
  });
  if (result2.canceled || !result2.filePath) return { cancelled: true };
  try {
    await workbook.xlsx.writeFile(result2.filePath);
    return { cancelled: false, filePath: result2.filePath };
  } catch (e) {
    logger.error("Excel save failed", e);
    throw Object.assign(new Error("xlsx"), { userMessage: "تعذر إنشاء ملف Excel" });
  }
}
async function exportManagersExcel(input, extra = {}) {
  const managers = Array.isArray(input) ? input : input?.managers || [];
  const org = Array.isArray(input) ? extra : input;
  const wb = newWorkbook();
  const ws = newSheet(wb, "سجل مدراء المدارس", "landscape");
  const cols = [
    { header: "#", key: "n", width: 6, align: "center", bold: true },
    { header: "اسم مدير المدرسة", key: "name", width: 30, bold: true },
    { header: "الرقم الوظيفي", key: "emp", width: 15, align: "center" },
    { header: "رقم الهوية الوطنية", key: "nat", width: 16, align: "center" },
    { header: "المدرسة المكلف بها", key: "school", width: 28 },
    { header: "نطاق الإدارة", key: "scope", width: 15, align: "center" },
    { header: "المرحلة الدراسية", key: "stage", width: 18, align: "center" },
    { header: "الإدارة التعليمية", key: "admin", width: 22 },
    { header: "خدمة التعليم (سنة)", key: "edu_exp", width: 16, align: "center" },
    { header: "خدمة الإدارة (سنة)", key: "adm_exp", width: 16, align: "center" },
    { header: "التقييمات المعتمدة", key: "approved_cnt", width: 16, align: "center" },
    { header: "آخر نتيجة معتمدة", key: "last_score", width: 16, align: "center", numFmt: "0.00", bold: true },
    { header: "آخر تقدير عام", key: "last_rating", width: 18, align: "center" },
    { header: "الشواهد المرفوعة", key: "ev_cnt", width: 14, align: "center" },
    { header: "خطط التحسين", key: "pl_cnt", width: 14, align: "center" },
    { header: "الحالة", key: "status", width: 12, align: "center" },
    { header: "ملاحظات", key: "notes", width: 28 }
  ];
  ws.columns = cols.map((c) => ({ key: c.key, width: c.width }));
  const activeCount = managers.filter((m) => m.status === "active").length;
  const archivedCount = managers.length - activeCount;
  const multiSchoolCount = managers.filter((m) => m.hasMultipleSchools).length;
  const avgEduExp = managers.length ? (managers.reduce((a, m) => a + (Number(m.educationExperienceYears) || 0), 0) / managers.length).toFixed(1) : "0";
  const avgAdmExp = managers.length ? (managers.reduce((a, m) => a + (Number(m.administrationExperienceYears) || 0), 0) / managers.length).toFixed(1) : "0";
  addOfficialBanner(ws, {
    colCount: cols.length,
    title: "السجل الرسمي الشامل لقاعدة بيانات مدراء المدارس",
    filterLabel: "جميع السجلات (النشطة والمؤرشفة)",
    ...org
  });
  addKpiSummaryStrip(ws, [
    { label: "إجمالي المدراء", value: managers.length },
    { label: "المدراء النشطون", value: activeCount },
    { label: "السجلات المؤرشفة", value: archivedCount },
    { label: "مكلفون بعدة مدارس", value: multiSchoolCount },
    { label: "متوسط خدمة التعليم", value: `${avgEduExp} سنة` },
    { label: "متوسط خدمة الإدارة", value: `${avgAdmExp} سنة` }
  ], cols.length);
  addTableHeader(ws, cols);
  managers.forEach((m, i) => {
    const statusText = m.status === "active" ? "نشط" : "مؤرشف";
    const lastScoreNum = m.latestApprovedScore != null ? Number(m.latestApprovedScore) : null;
    const lastRating = m.latestGeneralRating || (lastScoreNum != null ? getRatingByScore(lastScoreNum) : "—");
    const r = ws.addRow({
      n: i + 1,
      name: m.fullName || "—",
      emp: m.employeeNumber || "—",
      nat: m.nationalId || "—",
      school: m.schoolName || "—",
      scope: m.hasMultipleSchools ? "عدة مدارس" : "مدرسة واحدة",
      stage: m.stageName || "—",
      admin: m.administrationName || "—",
      edu_exp: m.educationExperienceYears ?? 0,
      adm_exp: m.administrationExperienceYears ?? 0,
      approved_cnt: m.approvedEvaluationsCount ?? 0,
      last_score: lastScoreNum != null ? lastScoreNum : "—",
      last_rating: lastRating || "—",
      ev_cnt: m.evidencesCount ?? 0,
      pl_cnt: m.plansCount ?? 0,
      status: statusText,
      notes: m.notes || ""
    });
    styleDataRow(r, i, cols);
    styleRatingCell(r.getCell(13), lastRating, lastScoreNum);
    styleStatusCell(r.getCell(16), statusText);
  });
  const wsStats = newSheet(wb, "إحصائيات التوزيع", "portrait");
  const statCols = [
    { header: "فئة التصنيف", key: "cat", width: 22, bold: true },
    { header: "البيان / الجهة", key: "name", width: 34, bold: true },
    { header: "عدد المدراء", key: "cnt", width: 16, align: "center" },
    { header: "النسبة المئوية", key: "pct", width: 16, align: "center", numFmt: '0.0"%"' }
  ];
  wsStats.columns = statCols.map((c) => ({ key: c.key, width: c.width }));
  addOfficialBanner(wsStats, {
    colCount: statCols.length,
    title: "إحصائيات توزيع مدراء المدارس حسب المرحلة والإدارة التعليمية",
    filterLabel: `إجمالي المدراء: ${managers.length}`,
    ...org
  });
  wsStats.addRow([]);
  addTableHeader(wsStats, statCols);
  const byStage = {};
  const byAdmin = {};
  for (const m of managers) {
    const st = m.stageName || "غير محدد";
    const ad = m.administrationName || "غير محدد";
    byStage[st] = (byStage[st] || 0) + 1;
    byAdmin[ad] = (byAdmin[ad] || 0) + 1;
  }
  let sIdx = 0;
  Object.entries(byStage).sort((a, b) => b[1] - a[1]).forEach(([name2, cnt]) => {
    const r = wsStats.addRow({
      cat: "المرحلة الدراسية",
      name: name2,
      cnt,
      pct: managers.length ? Number((cnt / managers.length * 100).toFixed(1)) : 0
    });
    styleDataRow(r, sIdx++, statCols);
  });
  Object.entries(byAdmin).sort((a, b) => b[1] - a[1]).forEach(([name2, cnt]) => {
    const r = wsStats.addRow({
      cat: "الإدارة التعليمية",
      name: name2,
      cnt,
      pct: managers.length ? Number((cnt / managers.length * 100).toFixed(1)) : 0
    });
    styleDataRow(r, sIdx++, statCols);
  });
  return saveWithDialog(wb, `قاعدة-بيانات-مدراء-المدارس-${getLocalDateStr()}.xlsx`);
}
async function exportEvaluationsExcel({
  evaluations = [],
  filterLabel: filterLabel2 = "شامل",
  db: db2,
  orgName,
  orgSubtitle,
  appTitle,
  preparedBy
}) {
  const wb = newWorkbook();
  const org = { orgName, orgSubtitle, appTitle, preparedBy };
  const sortedEvals = [...evaluations].sort((a, b) => {
    const rank = { approved: 1, completed: 2, draft: 3, superseded: 4 };
    const ra = rank[a.status] || 9;
    const rb = rank[b.status] || 9;
    if (ra !== rb) return ra - rb;
    if (a.finalScore != null && b.finalScore != null) return Number(b.finalScore) - Number(a.finalScore);
    return String(a.managerName || "").localeCompare(String(b.managerName || ""), "ar");
  });
  const approvedEvals = sortedEvals.filter((e) => e.status === "approved" && e.finalScore != null);
  const approvedScores = approvedEvals.map((e) => Number(e.finalScore)).filter((n) => !Number.isNaN(n));
  const avgScore = approvedScores.length ? (approvedScores.reduce((a, b) => a + b, 0) / approvedScores.length).toFixed(2) : "—";
  const maxScore = approvedScores.length ? Math.max(...approvedScores).toFixed(2) : "—";
  const minScore = approvedScores.length ? Math.min(...approvedScores).toFixed(2) : "—";
  const approvalPct = sortedEvals.length ? `${Math.round(approvedEvals.length / sortedEvals.length * 100)}%` : "0%";
  const ws = newSheet(wb, "ملخص النتائج الشامل", "landscape");
  const summaryCols = [
    { header: "#", key: "n", width: 6, align: "center", bold: true },
    { header: "اسم مدير المدرسة", key: "mgr", width: 28, bold: true },
    { header: "الرقم الوظيفي", key: "emp", width: 14, align: "center" },
    { header: "المدرسة", key: "school", width: 26 },
    { header: "المرحلة", key: "stage", width: 15, align: "center" },
    { header: "العام الدراسي", key: "year", width: 12, align: "center", bold: true },
    { header: "فترة التقييم", key: "period", width: 18, align: "center" },
    { header: "حالة التقييم", key: "status", width: 13, align: "center" }
  ];
  for (let el = 1; el <= 19; el++) {
    summaryCols.push({
      header: el === 13 ? "ع13 (10%)" : `ع${el}`,
      key: `el_${el}`,
      width: el === 13 ? 10 : 7,
      align: "center"
    });
  }
  summaryCols.push(
    { header: "الشواهد", key: "ev_cnt", width: 10, align: "center" },
    { header: "الخطط", key: "pl_cnt", width: 10, align: "center" },
    { header: "المجموع من 100", key: "score", width: 15, align: "center", numFmt: "0.00", bold: true },
    { header: "التقدير العام للأداء", key: "rating", width: 19, align: "center" },
    { header: "تاريخ الاعتماد / التحديث", key: "date", width: 16, align: "center" },
    { header: "ملاحظات عامة", key: "notes", width: 28 }
  );
  ws.columns = summaryCols.map((c) => ({ key: c.key, width: c.width }));
  addOfficialBanner(ws, {
    colCount: summaryCols.length,
    title: "سجل نتائج تقييم مدراء المدارس وتفصيل المعايير الـ 19",
    filterLabel: filterLabel2,
    ...org
  });
  addKpiSummaryStrip(ws, [
    { label: "إجمالي السجلات", value: sortedEvals.length },
    { label: "التقييمات المعتمدة", value: approvedEvals.length },
    { label: "نسبة الاعتماد", value: approvalPct },
    { label: "المتوسط العام للمعتمد", value: avgScore },
    { label: "أعلى درجة محققة", value: maxScore },
    { label: "أدنى درجة معتمدة", value: minScore }
  ], summaryCols.length);
  addTableHeader(ws, summaryCols);
  const allEvaluationItems = [];
  const criteriaAgg = {};
  sortedEvals.forEach((ev, i) => {
    const statusText = { draft: "مسودة", completed: "مكتمل", approved: "معتمد", superseded: "مُستبدل" }[ev.status] || ev.status;
    const itemScoresMap = {};
    if (db2 && ev.id) {
      try {
        const rows = db2.prepare(`
          SELECT element_number, score_value, level_label, weight_bp, notes, name
          FROM evaluation_item_snapshots
          WHERE evaluation_id = ?
          ORDER BY element_number
        `).all(ev.id);
        rows.forEach((r2) => {
          itemScoresMap[r2.element_number] = r2;
          if (!criteriaAgg[r2.element_number]) {
            criteriaAgg[r2.element_number] = {
              elementNumber: r2.element_number,
              name: r2.name || `معيار ${r2.element_number}`,
              weightBp: r2.weight_bp || 500,
              scores: []
            };
          }
          if (ev.status === "approved" && r2.score_value != null) {
            criteriaAgg[r2.element_number].scores.push(Number(r2.score_value));
          }
          allEvaluationItems.push({
            mgr: ev.managerName || "—",
            school: ev.schoolName || "—",
            year: ev.yearLabel || "—",
            period: ev.periodName || "—",
            status: statusText,
            elementNum: r2.element_number,
            elementName: r2.name || `معيار ${r2.element_number}`,
            weightPct: Number(((r2.weight_bp || 0) / 100).toFixed(2)),
            scoreValue: r2.score_value != null ? r2.score_value : "—",
            levelLabel: r2.level_label || "—",
            points: r2.score_value != null ? Number((r2.score_value * r2.weight_bp / 500).toFixed(2)) : "—",
            notes: r2.notes || ""
          });
        });
      } catch (e) {
        logger.error("Error fetching items for eval " + ev.id, e);
      }
    }
    const scoreNum = ev.finalScore != null ? Number(ev.finalScore) : null;
    const ratingVal = ev.generalRating || ev.general_rating || (ev.status === "approved" && scoreNum != null ? getRatingByScore(scoreNum) : "");
    const rowData = {
      n: i + 1,
      mgr: ev.managerName || "—",
      emp: ev.employeeNumber || "—",
      school: ev.schoolName || "—",
      stage: ev.stageName || "—",
      year: ev.yearLabel || "—",
      period: ev.periodName || "—",
      status: statusText,
      ev_cnt: ev.evidencesCount ?? 0,
      pl_cnt: ev.plansCount ?? 0,
      score: scoreNum != null ? scoreNum : "—",
      rating: ratingVal || "—",
      date: fmtSlashDate(ev.approvedAt || ev.updatedAt),
      notes: ev.notes || ""
    };
    for (let el = 1; el <= 19; el++) {
      const it = itemScoresMap[el];
      rowData[`el_${el}`] = it && it.score_value != null ? it.score_value : "—";
    }
    const r = ws.addRow(rowData);
    styleDataRow(r, i, summaryCols);
    styleStatusCell(r.getCell(8), statusText);
    for (let el = 1; el <= 19; el++) {
      styleScoreCell(r.getCell(8 + el), rowData[`el_${el}`]);
    }
    styleRatingCell(r.getCell(31), ratingVal, scoreNum);
  });
  if (approvedScores.length > 0) {
    const avgRowObj = {
      n: "",
      mgr: `متوسط التقييمات المعتمدة (${approvedScores.length} مديرًا)`,
      emp: "",
      school: "",
      stage: "",
      year: "",
      period: "",
      status: "متوسط معتمد",
      ev_cnt: sortedEvals.reduce((a, e) => a + (e.evidencesCount || 0), 0),
      pl_cnt: sortedEvals.reduce((a, e) => a + (e.plansCount || 0), 0),
      score: Number(avgScore),
      rating: getRatingByScore(Number(avgScore)),
      date: "",
      notes: ""
    };
    for (let el = 1; el <= 19; el++) {
      const scArr = criteriaAgg[el]?.scores || [];
      avgRowObj[`el_${el}`] = scArr.length ? Number((scArr.reduce((a, b) => a + b, 0) / scArr.length).toFixed(2)) : "—";
    }
    const totalRow = ws.addRow(avgRowObj);
    totalRow.height = 28;
    for (let c = 1; c <= summaryCols.length; c++) {
      const cell = totalRow.getCell(c);
      cell.fill = FILLS.totalRow;
      cell.font = FONTS.total;
      cell.border = HEADER_BORDER;
      cell.alignment = { horizontal: c === 2 ? "start" : "center", vertical: "middle", readingOrder: "rtl" };
    }
    totalRow.getCell(30).numFmt = "0.00";
  }
  const criteriaList = Object.values(criteriaAgg).sort((a, b) => a.elementNumber - b.elementNumber);
  if (criteriaList.length > 0) {
    const wsCrit = newSheet(wb, "تحليل المعايير الـ 19", "landscape");
    const critCols = [
      { header: "#", key: "num", width: 7, align: "center", bold: true },
      { header: "اسم المعيار الرسمي", key: "name", width: 52, bold: true },
      { header: "الوزن النسبي %", key: "weight", width: 14, align: "center", numFmt: '0.00"%"' },
      { header: "عدد التقييمات المعتمدة", key: "cnt", width: 18, align: "center" },
      { header: "متوسط الدرجة (من 5)", key: "avg5", width: 18, align: "center", numFmt: "0.00", bold: true },
      { header: "نسبة التحقق %", key: "pct", width: 16, align: "center", numFmt: '0.0"%"', bold: true },
      { header: "أعلى درجة", key: "max", width: 12, align: "center" },
      { header: "أدنى درجة", key: "min", width: 12, align: "center" },
      { header: "متوسط النقاط الموزونة", key: "avgPts", width: 18, align: "center", numFmt: "0.00" },
      { header: "تصنيف مستوى الأداء الجماعي", key: "tier", width: 22, align: "center" }
    ];
    wsCrit.columns = critCols.map((c) => ({ key: c.key, width: c.width }));
    addOfficialBanner(wsCrit, {
      colCount: critCols.length,
      title: "التحليل الإحصائي لأداء المعايير الرسمية الـ 19 عبر المدارس",
      filterLabel: filterLabel2,
      ...org
    });
    wsCrit.addRow([]);
    addTableHeader(wsCrit, critCols);
    criteriaList.forEach((c, idx) => {
      const cnt = c.scores.length;
      const avg5 = cnt ? Number((c.scores.reduce((a, b) => a + b, 0) / cnt).toFixed(2)) : null;
      const pct = avg5 != null ? Number((avg5 / 5 * 100).toFixed(1)) : null;
      const max = cnt ? Math.max(...c.scores) : "—";
      const min = cnt ? Math.min(...c.scores) : "—";
      const avgPts = avg5 != null ? Number((avg5 * c.weightBp / 500).toFixed(2)) : "—";
      const tier = avg5 == null ? "غير مقيم" : avg5 >= 4.2 ? "نقطة قوة متميزة" : avg5 >= 3.4 ? "أداء مستقر جيد" : "أولوية تطوير وتحسين";
      const r = wsCrit.addRow({
        num: c.elementNumber,
        name: c.name,
        weight: Number((c.weightBp / 100).toFixed(2)),
        cnt,
        avg5: avg5 ?? "—",
        pct: pct ?? "—",
        max,
        min,
        avgPts,
        tier
      });
      styleDataRow(r, idx, critCols);
      if (c.elementNumber === 13) {
        for (let col = 1; col <= critCols.length; col++) r.getCell(col).fill = FILLS.el13Highlight;
      }
      const tierCell = r.getCell(10);
      if (tier === "نقطة قوة متميزة") {
        tierCell.fill = FILLS.emeraldSoft;
        tierCell.font = FONTS.emeraldBold;
      } else if (tier === "أداء مستقر جيد") {
        tierCell.fill = FILLS.skySoft;
        tierCell.font = FONTS.skyBold;
      } else if (tier === "أولوية تطوير وتحسين") {
        tierCell.fill = FILLS.amberSoft;
        tierCell.font = FONTS.amberBold;
      }
    });
  }
  if (allEvaluationItems.length > 0) {
    const wsDetail = newSheet(wb, "تفصيل الدرجات والملاحظات", "landscape");
    const detCols = [
      { header: "#", key: "n", width: 7, align: "center", bold: true },
      { header: "اسم المدير", key: "mgr", width: 26, bold: true },
      { header: "المدرسة", key: "school", width: 24 },
      { header: "العام الدراسي", key: "year", width: 12, align: "center" },
      { header: "فترة التقييم", key: "period", width: 18, align: "center" },
      { header: "حالة التقييم", key: "status", width: 13, align: "center" },
      { header: "رقم المعيار", key: "elementNum", width: 11, align: "center", bold: true },
      { header: "اسم المعيار الرسمي", key: "elementName", width: 46 },
      { header: "الوزن %", key: "weightPct", width: 12, align: "center", numFmt: '0.00"%"' },
      { header: "الدرجة (1-5)", key: "scoreValue", width: 13, align: "center" },
      { header: "مستوى الأداء", key: "levelLabel", width: 18, align: "center" },
      { header: "النقاط الموزونة", key: "points", width: 15, align: "center", numFmt: "0.00", bold: true },
      { header: "ملاحظات المُقيِّم", key: "notes", width: 34 }
    ];
    wsDetail.columns = detCols.map((c) => ({ key: c.key, width: c.width }));
    addOfficialBanner(wsDetail, {
      colCount: detCols.length,
      title: "السجل التفصيلي لدرجات وملاحظات المعايير لكل مدير مدرسة",
      filterLabel: filterLabel2,
      ...org
    });
    wsDetail.addRow([]);
    addTableHeader(wsDetail, detCols);
    allEvaluationItems.forEach((it, idx) => {
      const r = wsDetail.addRow({ n: idx + 1, ...it });
      styleDataRow(r, idx, detCols);
      if (it.elementNum === 13) {
        for (let col = 1; col <= detCols.length; col++) r.getCell(col).fill = FILLS.el13Highlight;
      }
      styleStatusCell(r.getCell(6), it.status);
      styleScoreCell(r.getCell(10), it.scoreValue);
    });
  }
  const wsDist = newSheet(wb, "توزيع التقديرات ومعلومات التقرير", "portrait");
  const distCols = [
    { header: "التقدير العام الرسمي", key: "tier", width: 26, bold: true },
    { header: "المدى الرقمي للدرجات", key: "range", width: 22, align: "center" },
    { header: "عدد المدراء المعتمدين", key: "cnt", width: 22, align: "center", bold: true },
    { header: "النسبة من إجمالي المعتمد", key: "pct", width: 22, align: "center", numFmt: '0.0"%"' }
  ];
  wsDist.columns = distCols.map((c) => ({ key: c.key, width: c.width }));
  addOfficialBanner(wsDist, {
    colCount: distCols.length,
    title: "توزيع التقديرات الرسمية للأداء الوظيفي ومعلومات الوثيقة",
    filterLabel: filterLabel2,
    ...org
  });
  wsDist.addRow([]);
  addTableHeader(wsDist, distCols);
  const buckets = [
    { tier: "متميز", range: "90 – 100", cnt: approvedScores.filter((s) => s >= 90).length },
    { tier: "فوق التوقعات", range: "76 – 89", cnt: approvedScores.filter((s) => s >= 76 && s < 90).length },
    { tier: "وافق التوقعات", range: "61 – 75", cnt: approvedScores.filter((s) => s >= 61 && s < 76).length },
    { tier: "بحاجة إلى تطوير", range: "41 – 60", cnt: approvedScores.filter((s) => s >= 41 && s < 61).length },
    { tier: "غير مرضٍ", range: "أقل من 41", cnt: approvedScores.filter((s) => s < 41).length }
  ];
  buckets.forEach((b, idx) => {
    const r = wsDist.addRow({
      tier: b.tier,
      range: b.range,
      cnt: b.cnt,
      pct: approvedScores.length ? Number((b.cnt / approvedScores.length * 100).toFixed(1)) : 0
    });
    styleDataRow(r, idx, distCols);
    styleRatingCell(r.getCell(1), b.tier);
  });
  return saveWithDialog(wb, `سجل-نتائج-التقييمات-الشامل-${getLocalDateStr()}.xlsx`);
}
async function exportEvaluationDetailsExcel({
  evaluation,
  orgName,
  orgSubtitle,
  appTitle,
  preparedBy
}) {
  const wb = newWorkbook();
  const ws = newSheet(wb, "بطاقة التقييم التفصيلية", "portrait");
  const ev = evaluation || {};
  const items = ev.items || [];
  const evidences = ev.evidences || [];
  const plans = ev.plans || [];
  const evCountMap = ev.evidenceCountsByElement || {};
  const cols = [
    { header: "#", key: "num", width: 6, align: "center", bold: true },
    { header: "عنصر / معيار التقييم الرسمي", key: "name", width: 48, bold: true },
    { header: "الوزن النسبي %", key: "weight", width: 13, align: "center", numFmt: '0.00"%"' },
    { header: "الدرجة (1-5)", key: "score", width: 12, align: "center" },
    { header: "مستوى الأداء", key: "level", width: 18, align: "center" },
    { header: "النقاط الموزونة", key: "contrib", width: 15, align: "center", numFmt: "0.00", bold: true },
    { header: "الشواهد", key: "evCnt", width: 10, align: "center" },
    { header: "ملاحظات المُقيِّم", key: "notes", width: 30 }
  ];
  ws.columns = cols.map((c) => ({ key: c.key, width: c.width }));
  const statusText = { draft: "مسودة", completed: "مكتمل", approved: "معتمد", superseded: "مُستبدل" }[ev.status] || ev.status;
  const effectiveRating = ev.generalRating || ev.general_rating || (ev.finalScore != null ? getRatingByScore(ev.finalScore) : "—");
  addOfficialBanner(ws, {
    colCount: cols.length,
    title: `بطاقة تقييم الأداء الوظيفي لمدير مدرسة — ${ev.managerName || ""}`,
    filterLabel: `${ev.yearLabel || "—"} / ${ev.periodName || "—"}`,
    orgName,
    orgSubtitle,
    appTitle,
    preparedBy
  });
  ws.addRow([]);
  const metaPairs = [
    ["اسم مدير المدرسة", ev.managerName || "—", "المدرسة المكلف بها", ev.schoolName || "—"],
    ["الرقم الوظيفي", ev.employeeNumber || "—", "رقم الهوية الوطنية", ev.nationalId || "—"],
    ["المرحلة الدراسية", ev.stageName || "—", "الإدارة التعليمية", ev.administrationName || "—"],
    ["العام الدراسي", ev.yearLabel || "—", "فترة التقييم", ev.periodName || "—"],
    ["خبرة التعليم / الإدارة", `${ev.educationExperienceYears || 0}س تعليم / ${ev.administrationExperienceYears || 0}س إدارة`, "حالة التقييم وتاريخه", `${statusText} (${fmtSlashDate(ev.approvedAt || ev.updatedAt)})`],
    ["النتيجة النهائية المعتمدة", ev.finalScore != null ? `${Number(ev.finalScore).toFixed(2)} من 100` : "غير معتمدة بعد", "التقدير العام للأداء", effectiveRating]
  ];
  metaPairs.forEach((pair, idx) => {
    const r = ws.addRow([pair[0], pair[1], "", pair[2], pair[3], "", "", ""]);
    ws.mergeCells(`B${r.number}:C${r.number}`);
    ws.mergeCells(`E${r.number}:H${r.number}`);
    r.height = 23;
    for (const cIdx of [1, 4]) {
      const c = r.getCell(cIdx);
      c.fill = FILLS.kpiLabel;
      c.font = FONTS.slateBold;
      c.alignment = { horizontal: "start", vertical: "middle", readingOrder: "rtl" };
      c.border = THIN_BORDER;
    }
    for (const cIdx of [2, 3, 5, 6, 7, 8]) {
      const c = r.getCell(cIdx);
      c.fill = idx === 5 ? FILLS.kpiValue : FILLS.zebraOdd;
      c.font = idx === 5 ? FONTS.total : FONTS.bodyBold;
      c.alignment = { horizontal: "start", vertical: "middle", readingOrder: "rtl" };
      c.border = THIN_BORDER;
    }
    if (idx === 5) {
      styleRatingCell(r.getCell(5), effectiveRating, ev.finalScore);
    }
  });
  ws.addRow([]);
  addTableHeader(ws, cols, false);
  let totalWeightBp = 0;
  items.forEach((it, idx) => {
    totalWeightBp += it.weightBp || 0;
    const contribution = it.contribution != null ? Number(it.contribution) : it.scoreValue != null ? Number((it.scoreValue * it.weightBp / 500).toFixed(2)) : "—";
    const r = ws.addRow({
      num: it.elementNumber,
      name: it.elementNumber === 13 ? `${it.name} (وزن مضاعف 10%)` : it.name,
      weight: Number(((it.weightBp || 0) / 100).toFixed(2)),
      score: it.scoreValue != null ? it.scoreValue : "—",
      level: it.levelLabel || "—",
      contrib: contribution,
      evCnt: evCountMap[it.elementNumber] || 0,
      notes: it.notes || ""
    });
    styleDataRow(r, idx, cols);
    if (it.elementNumber === 13) {
      for (let col = 1; col <= cols.length; col++) r.getCell(col).fill = FILLS.el13Highlight;
    }
    styleScoreCell(r.getCell(4), it.scoreValue);
  });
  const totalRow = ws.addRow({
    num: "",
    name: "الإجمالي العام (19 معيارًا رسميًا)",
    weight: Number((totalWeightBp / 100).toFixed(2)),
    score: `${items.filter((x) => x.scoreValue != null).length} / ${items.length}`,
    level: effectiveRating,
    contrib: ev.finalScore != null ? Number(ev.finalScore) : "—",
    evCnt: evidences.length,
    notes: ev.notes || ""
  });
  totalRow.height = 28;
  for (let c = 1; c <= cols.length; c++) {
    const cell = totalRow.getCell(c);
    cell.fill = FILLS.totalRow;
    cell.font = FONTS.total;
    cell.border = HEADER_BORDER;
    cell.alignment = { horizontal: c === 2 || c === 8 ? "start" : "center", vertical: "middle", readingOrder: "rtl", wrapText: true };
  }
  totalRow.getCell(3).numFmt = '0.00"%"';
  if (ev.finalScore != null) totalRow.getCell(6).numFmt = "0.00";
  if (evidences.length > 0 || plans.length > 0) {
    const wsAtt = newSheet(wb, "الشواهد وخطط التحسين", "landscape");
    const attCols = [
      { header: "#", key: "n", width: 6, align: "center", bold: true },
      { header: "النوع", key: "type", width: 15, align: "center", bold: true },
      { header: "المعيار المرتبط", key: "el", width: 14, align: "center" },
      { header: "العنوان / الهدف التطويري", key: "title", width: 38, bold: true },
      { header: "الوصف / الإجراءات التنفيذية", key: "desc", width: 42 },
      { header: "الحالة / المرفقات", key: "meta", width: 20, align: "center" },
      { header: "تعليق / متابعة المشرف", key: "comment", width: 34 }
    ];
    wsAtt.columns = attCols.map((c) => ({ key: c.key, width: c.width }));
    addOfficialBanner(wsAtt, {
      colCount: attCols.length,
      title: `سجل الشواهد المهنية وخطط التحسين المرتبطة — ${ev.managerName || ""}`,
      filterLabel: `${ev.yearLabel || "—"} / ${ev.periodName || "—"}`,
      orgName,
      orgSubtitle,
      appTitle,
      preparedBy
    });
    wsAtt.addRow([]);
    addTableHeader(wsAtt, attCols);
    let rowCounter = 0;
    evidences.forEach((e) => {
      const r = wsAtt.addRow({
        n: ++rowCounter,
        type: "شاهد مهني",
        el: e.elementNumber ? `ع${e.elementNumber}` : "عام",
        title: e.title || "—",
        desc: e.description || "—",
        meta: `${e.attachmentCount || 0} مرفق`,
        comment: e.comments?.[0]?.comment || "—"
      });
      styleDataRow(r, rowCounter - 1, attCols);
    });
    plans.forEach((p) => {
      const stText = { not_started: "لم تبدأ", in_progress: "قيد التنفيذ", completed: "مكتملة", overdue: "متأخرة" }[p.status] || p.status;
      const r = wsAtt.addRow({
        n: ++rowCounter,
        type: "خطة تحسين",
        el: p.elementNumber ? `ع${p.elementNumber}` : "عامة",
        title: p.goal || "—",
        desc: p.actions || "—",
        meta: stText,
        comment: p.latestFollowUp || p.notes || "—"
      });
      styleDataRow(r, rowCounter - 1, attCols);
      styleStatusCell(r.getCell(6), stText);
    });
  }
  const safeName = (ev.managerName || "manager").replace(/[\\/:*?"<>|]/g, "_");
  return saveWithDialog(wb, `بطاقة-تقييم-${safeName}-${ev.yearLabel || ""}.xlsx`.replace(/\s+/g, "-"));
}
async function exportPlansExcel({
  plans = [],
  filterLabel: filterLabel2 = "جميع السجلات",
  orgName,
  orgSubtitle,
  appTitle,
  preparedBy
}) {
  const wb = newWorkbook();
  const org = { orgName, orgSubtitle, appTitle, preparedBy };
  const ws = newSheet(wb, "خطط التحسين والتطوير", "landscape");
  const cols = [
    { header: "#", key: "n", width: 6, align: "center", bold: true },
    { header: "اسم مدير المدرسة", key: "mgr", width: 26, bold: true },
    { header: "المدرسة", key: "school", width: 24 },
    { header: "العام الدراسي", key: "year", width: 12, align: "center" },
    { header: "فترة التقييم", key: "period", width: 17, align: "center" },
    { header: "رقم المعيار", key: "element", width: 11, align: "center", bold: true },
    { header: "اسم المعيار المرتبط", key: "elName", width: 32 },
    { header: "الهدف التطويري", key: "goal", width: 36, bold: true },
    { header: "الإجراءات التنفيذية", key: "actions", width: 38 },
    { header: "تاريخ البداية", key: "start", width: 13, align: "center" },
    { header: "تاريخ النهاية", key: "end", width: 13, align: "center" },
    { header: "متأخرة؟", key: "overdue", width: 10, align: "center" },
    { header: "حالة الخطة", key: "status", width: 14, align: "center" },
    { header: "المرفقات", key: "atts", width: 10, align: "center" },
    { header: "متابعات المشرف", key: "fups", width: 13, align: "center" },
    { header: "آخر متابعة / تعليق للمشرف", key: "lastFollowUp", width: 34 },
    { header: "ملاحظات إضافية", key: "notes", width: 28 }
  ];
  ws.columns = cols.map((c) => ({ key: c.key, width: c.width }));
  const completed = plans.filter((p) => p.status === "completed").length;
  const inProgress = plans.filter((p) => p.status === "in_progress" && !p.isOverdue).length;
  const overdue = plans.filter((p) => (p.isOverdue || p.status === "overdue") && p.status !== "completed").length;
  const pct = plans.length ? `${Math.round(completed / plans.length * 100)}%` : "0%";
  addOfficialBanner(ws, {
    colCount: cols.length,
    title: "سجل متابعة خطط التحسين والتطوير المهني لمدراء المدارس",
    filterLabel: filterLabel2,
    ...org
  });
  addKpiSummaryStrip(ws, [
    { label: "إجمالي الخطط", value: plans.length },
    { label: "الخطط المكتملة", value: completed },
    { label: "نسبة الإنجاز", value: pct },
    { label: "قيد التنفيذ", value: inProgress },
    { label: "خطط متأخرة", value: overdue },
    { label: "متابعات المشرف", value: plans.reduce((a, p) => a + (p.followUpCount || 0), 0) }
  ], cols.length);
  addTableHeader(ws, cols);
  const byManager = {};
  plans.forEach((p, i) => {
    const isLate = (p.isOverdue || p.status === "overdue") && p.status !== "completed";
    const statusText = isLate ? "متأخرة" : { not_started: "لم تبدأ", in_progress: "قيد التنفيذ", completed: "مكتملة", overdue: "متأخرة" }[p.status] || p.status;
    const lateText = isLate ? "نعم" : "لا";
    const r = ws.addRow({
      n: i + 1,
      mgr: p.managerName || "—",
      school: p.schoolName || "—",
      year: p.yearLabel || "—",
      period: p.periodName || "—",
      element: p.elementNumber ? `ع${p.elementNumber}` : "عامة",
      elName: p.elementName || "—",
      goal: p.goal || "—",
      actions: p.actions || "—",
      start: fmtSlashDate(p.startsOn),
      end: fmtSlashDate(p.endsOn),
      overdue: lateText,
      status: statusText,
      atts: p.attachmentCount || 0,
      fups: p.followUpCount || 0,
      lastFollowUp: p.latestFollowUp || "—",
      notes: p.notes || ""
    });
    styleDataRow(r, i, cols);
    if (lateText === "نعم") styleStatusCell(r.getCell(12), "نعم");
    styleStatusCell(r.getCell(13), statusText);
    const mKey = p.managerId || p.managerName || "unknown";
    if (!byManager[mKey]) {
      byManager[mKey] = {
        name: p.managerName || "—",
        school: p.schoolName || "—",
        total: 0,
        completed: 0,
        inProgress: 0,
        overdue: 0
      };
    }
    byManager[mKey].total++;
    if (p.status === "completed") byManager[mKey].completed++;
    else if (isLate) byManager[mKey].overdue++;
    else if (p.status === "in_progress") byManager[mKey].inProgress++;
  });
  const mgrSummaryRows = Object.values(byManager).sort((a, b) => b.total - a.total);
  if (mgrSummaryRows.length > 0) {
    const wsMgr = newSheet(wb, "ملخص الإنجاز حسب المدير", "portrait");
    const mCols = [
      { header: "#", key: "n", width: 6, align: "center", bold: true },
      { header: "اسم المدير", key: "name", width: 28, bold: true },
      { header: "المدرسة", key: "school", width: 26 },
      { header: "إجمالي الخطط", key: "total", width: 14, align: "center", bold: true },
      { header: "مكتملة", key: "completed", width: 12, align: "center" },
      { header: "قيد التنفيذ", key: "inProgress", width: 13, align: "center" },
      { header: "متأخرة", key: "overdue", width: 12, align: "center" },
      { header: "نسبة الإنجاز %", key: "pct", width: 16, align: "center", numFmt: '0.0"%"', bold: true }
    ];
    wsMgr.columns = mCols.map((c) => ({ key: c.key, width: c.width }));
    addOfficialBanner(wsMgr, {
      colCount: mCols.length,
      title: "ملخص نسب إنجاز خطط التحسين حسب مدراء المدارس",
      filterLabel: filterLabel2,
      ...org
    });
    wsMgr.addRow([]);
    addTableHeader(wsMgr, mCols);
    mgrSummaryRows.forEach((m, idx) => {
      const r = wsMgr.addRow({
        n: idx + 1,
        name: m.name,
        school: m.school,
        total: m.total,
        completed: m.completed,
        inProgress: m.inProgress,
        overdue: m.overdue,
        pct: m.total ? Number((m.completed / m.total * 100).toFixed(1)) : 0
      });
      styleDataRow(r, idx, mCols);
      if (m.overdue > 0) styleStatusCell(r.getCell(7), "متأخرة");
    });
  }
  return saveWithDialog(wb, `سجل-خطط-التحسين-${getLocalDateStr()}.xlsx`);
}
let cachedPdfAssets = null;
async function findFontDataUri(candidates) {
  const appPath = electron.app.getAppPath();
  const resPath = process.resourcesPath || "";
  const bases = [
    node_path.join(appPath, "node_modules/@fontsource/cairo/files"),
    node_path.join(resPath, "app.asar.unpacked/node_modules/@fontsource/cairo/files"),
    node_path.join(resPath, "app.asar/node_modules/@fontsource/cairo/files"),
    node_path.join(resPath, "app/node_modules/@fontsource/cairo/files")
  ];
  for (const base of bases) {
    for (const name2 of candidates) {
      try {
        const p = node_path.join(base, name2);
        const buf = await node_fs.promises.readFile(p);
        return `data:font/woff2;base64,${buf.toString("base64")}`;
      } catch {
      }
    }
  }
  return null;
}
async function findLogoDataUri() {
  const appPath = electron.app.getAppPath();
  const resPath = process.resourcesPath || "";
  const svgCandidates = [
    node_path.join(appPath, "src/assets/ministry-logo.svg"),
    node_path.join(resPath, "assets/ministry-logo.svg"),
    node_path.join(appPath, "../website/assets/ministry-logo.svg")
  ];
  for (const p of svgCandidates) {
    try {
      const buf = await node_fs.promises.readFile(p);
      return `data:image/svg+xml;base64,${buf.toString("base64")}`;
    } catch {
    }
  }
  const pngCandidates = [
    node_path.join(appPath, "src/assets/ministry-logo.png"),
    node_path.join(resPath, "assets/ministry-logo.png")
  ];
  for (const p of pngCandidates) {
    try {
      const buf = await node_fs.promises.readFile(p);
      return `data:image/png;base64,${buf.toString("base64")}`;
    } catch {
    }
  }
  return null;
}
async function getFontDataUris() {
  if (cachedPdfAssets) return cachedPdfAssets;
  const [
    fontArabic400,
    fontLatin400,
    fontArabic600,
    fontLatin600,
    fontArabic700,
    fontLatin700,
    logoDataUri
  ] = await Promise.all([
    findFontDataUri(["cairo-arabic-400-normal.woff2", "cairo-400.woff2"]),
    findFontDataUri(["cairo-latin-400-normal.woff2"]),
    findFontDataUri(["cairo-arabic-600-normal.woff2"]),
    findFontDataUri(["cairo-latin-600-normal.woff2"]),
    findFontDataUri(["cairo-arabic-700-normal.woff2", "cairo-700.woff2"]),
    findFontDataUri(["cairo-latin-700-normal.woff2"]),
    findLogoDataUri()
  ]);
  cachedPdfAssets = {
    fontRegular: fontArabic400 || fontLatin400 || "",
    fontBold: fontArabic700 || fontLatin700 || "",
    fontArabic400,
    fontLatin400,
    fontArabic600,
    fontLatin600,
    fontArabic700,
    fontLatin700,
    logoDataUri
  };
  return cachedPdfAssets;
}
async function createHiddenWindow(landscape = false) {
  const win = new electron.BrowserWindow({
    show: false,
    width: landscape ? 1280 : 960,
    height: landscape ? 900 : 1280,
    webPreferences: {
      sandbox: false,
      contextIsolation: true,
      nodeIntegration: false,
      offscreen: true
    }
  });
  return win;
}
async function loadHtml(win, html) {
  const tmpDir = electron.app.getPath("temp");
  const tmpFile = node_path.join(tmpDir, `report-${Date.now()}-${Math.random().toString(36).slice(2)}.html`);
  await node_fs.promises.writeFile(tmpFile, html, "utf8");
  await win.loadFile(tmpFile);
  await win.webContents.executeJavaScript(`
    Promise.all([
      document.fonts ? document.fonts.ready : Promise.resolve(),
      ...Array.from(document.images || []).map(img =>
        img.complete ? Promise.resolve() : new Promise(r => { img.onload = r; img.onerror = r; })
      )
    ]).then(() => new Promise(r => setTimeout(r, 60)))
  `);
  return tmpFile;
}
async function renderPdf(html, options = {}) {
  const landscape = !!options.landscape;
  const win = await createHiddenWindow(landscape);
  let tmpFile = null;
  try {
    tmpFile = await loadHtml(win, html);
    const pdfData = await win.webContents.printToPDF({
      pageSize: "A4",
      landscape,
      printBackground: true,
      preferCSSPageSize: true,
      margins: { marginType: "custom", top: 0.32, bottom: 0.35, left: 0.32, right: 0.32 }
    });
    return pdfData;
  } finally {
    try {
      win.destroy();
    } catch {
    }
    if (tmpFile) node_fs.promises.unlink(tmpFile).catch(() => {
    });
  }
}
async function printHtml(html, options = {}) {
  const landscape = !!options.landscape;
  const win = await createHiddenWindow(landscape);
  let tmpFile = null;
  try {
    tmpFile = await loadHtml(win, html);
    return await new Promise((resolve, reject) => {
      win.webContents.print(
        {
          silent: false,
          landscape,
          printBackground: true,
          margins: { marginType: "custom", top: 0.32, bottom: 0.35, left: 0.32, right: 0.32 }
        },
        (success, failureReason) => {
          if (success) resolve(true);
          else reject(new Error(failureReason || "تعذرت الطباعة"));
        }
      );
    });
  } finally {
    try {
      win.destroy();
    } catch {
    }
    if (tmpFile) node_fs.promises.unlink(tmpFile).catch(() => {
    });
  }
}
async function savePdfWithDialog(html, defaultFileName, options = {}) {
  const parent = electron.BrowserWindow.getFocusedWindow();
  const result2 = await electron.dialog.showSaveDialog(parent, {
    title: "حفظ التقرير الرسمي بصيغة PDF",
    defaultPath: defaultFileName || `report-${Date.now()}.pdf`,
    filters: [{ name: "ملف PDF", extensions: ["pdf"] }]
  });
  if (result2.canceled || !result2.filePath) return { cancelled: true };
  try {
    const pdfData = await renderPdf(html, options);
    await node_fs.promises.writeFile(result2.filePath, pdfData);
    return { cancelled: false, filePath: result2.filePath };
  } catch (e) {
    logger.error("PDF save failed", e);
    throw Object.assign(new Error("pdf"), { userMessage: "تعذر إنشاء ملف PDF" });
  }
}
async function printHtmlWithDialog(html, options = {}) {
  try {
    await printHtml(html, options);
    return { success: true };
  } catch (e) {
    logger.error("Print failed", e);
    throw Object.assign(new Error("print"), { userMessage: "تعذرت الطباعة" });
  }
}
function wrap$7(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function getOrgSettings(db2) {
  const rows = db2.prepare("SELECT key, value FROM app_settings WHERE key IN ('org_name','org_subtitle','app_title','prepared_by','supervisor_name')").all();
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return {
    orgName: map.org_name || "وزارة التعليم",
    orgSubtitle: map.org_subtitle || "",
    appTitle: map.app_title || "تقييم أداء مدراء المدارس وفق الدليل الإرشادي لإدارة الأداء الوظيفي لشاغلي الوظائف التعليمية (الإصدار الثاني)",
    preparedBy: map.prepared_by || map.supervisor_name || "إعداد وتنسيق : أخصائي الإدارة المدرسية / الحسين إبراهيم شويع"
  };
}
function buildEvaluationReportContext(db2, evaluationId) {
  const ev = getEvaluation(db2, evaluationId);
  if (!ev) throw Object.assign(new Error("not found"), { userMessage: "التقييم غير موجود" });
  const mgr = getManagerById(db2, ev.managerId);
  const enriched = {
    ...ev,
    managerName: mgr?.fullName || ev.managerName,
    schoolName: mgr?.schoolName || "",
    employeeNumber: mgr?.employeeNumber || "",
    nationalId: mgr?.nationalId || "",
    stageName: mgr?.stageName || "",
    administrationName: mgr?.administrationName || "",
    educationExperienceYears: mgr?.educationExperienceYears ?? 0,
    administrationExperienceYears: mgr?.administrationExperienceYears ?? 0,
    hasMultipleSchools: mgr?.hasMultipleSchools || false
  };
  return enriched;
}
function buildAllManagersContext(db2, { yearId, periodId, status } = {}) {
  const where = [];
  const params = [];
  if (yearId) {
    where.push("e.academic_year_id = ?");
    params.push(yearId);
  }
  if (periodId) {
    where.push("e.period_id = ?");
    params.push(periodId);
  }
  if (status && ["draft", "completed", "approved", "superseded"].includes(status)) {
    where.push("e.status = ?");
    params.push(status);
  }
  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  return db2.prepare(`
    SELECT e.id, e.status, e.final_score, e.updated_at, e.approved_at,
           m.full_name AS managerName, s.name AS schoolName,
           ay.label AS yearLabel, ay.id AS yearId,
           ep.name AS periodName, ep.id AS periodId,
           fv.version_number AS formVersionNumber
    FROM evaluations e
    JOIN managers m ON m.id = e.manager_id
    LEFT JOIN schools s ON s.id = m.school_id
    JOIN academic_years ay ON ay.id = e.academic_year_id
    JOIN evaluation_periods ep ON ep.id = e.period_id
    JOIN form_versions fv ON fv.id = e.form_version_id
    ${whereSql}
    ORDER BY ay.label DESC, ep.name, m.full_name
  `).all(...params);
}
function filterLabel({ yearId, periodId, status }, db2) {
  const parts = [];
  if (yearId) {
    const y = db2.prepare("SELECT label FROM academic_years WHERE id = ?").get(yearId);
    if (y) parts.push(`السنة: ${y.label}`);
  }
  if (periodId) {
    const p = db2.prepare("SELECT name FROM evaluation_periods WHERE id = ?").get(periodId);
    if (p) parts.push(`الفترة: ${p.name}`);
  }
  if (status) {
    const map = { draft: "مسودة", completed: "مكتمل", approved: "معتمد", superseded: "مُستبدل" };
    parts.push(`الحالة: ${map[status] || status}`);
  }
  return parts.join(" · ") || "بدون فلاتر";
}
function registerReportsIpc(ipc, db2) {
  ipc.handle("reports:exportManagersExcel", wrap$7(async () => {
    const result2 = listManagers(db2, { status: "all", pageSize: 5e3 });
    return exportManagersExcel(result2.rows);
  }));
  ipc.handle("reports:exportEvaluationsExcel", wrap$7(async (_e, filters) => {
    const evaluations = buildAllManagersContext(db2, filters || {});
    const label = filterLabel(filters || {}, db2);
    return exportEvaluationsExcel({ evaluations, filterLabel: label, db: db2 });
  }));
  ipc.handle("reports:exportPlansExcel", wrap$7(async (_e, filters) => {
    const plans = listPlans(db2, { includeArchived: false, ...filters || {} });
    const label = filterLabel(filters || {}, db2);
    return exportPlansExcel({ plans, filterLabel: label });
  }));
  ipc.handle("reports:exportEvaluationDetailsExcel", wrap$7(async (_e, evaluationId) => {
    const ev = buildEvaluationReportContext(db2, evaluationId);
    const org = getOrgSettings(db2);
    return exportEvaluationDetailsExcel({
      evaluation: ev,
      orgName: org.orgName,
      orgSubtitle: org.orgSubtitle
    });
  }));
  ipc.handle("reports:exportEvaluationPdf", wrap$7(async (_e, evaluationId) => {
    const ev = buildEvaluationReportContext(db2, evaluationId);
    const org = getOrgSettings(db2);
    const fonts = await getFontDataUris();
    const html = renderEvaluationReport({
      evaluation: ev,
      orgName: org.orgName,
      orgSubtitle: org.orgSubtitle,
      appTitle: org.appTitle,
      preparedBy: org.preparedBy,
      ...fonts
    });
    const safeName = (ev.managerName || "manager").replace(/[\\/:*?"<>|]/g, "_");
    return savePdfWithDialog(html, `تقييم-${safeName}-${ev.yearLabel || ""}.pdf`.replace(/\s+/g, "-"));
  }));
  ipc.handle("reports:printEvaluation", wrap$7(async (_e, evaluationId) => {
    const ev = buildEvaluationReportContext(db2, evaluationId);
    const org = getOrgSettings(db2);
    const fonts = await getFontDataUris();
    const html = renderEvaluationReport({
      evaluation: ev,
      orgName: org.orgName,
      orgSubtitle: org.orgSubtitle,
      appTitle: org.appTitle,
      preparedBy: org.preparedBy,
      ...fonts
    });
    return printHtmlWithDialog(html);
  }));
  ipc.handle("reports:exportManagerPdf", wrap$7(async (_e, managerId) => {
    const mgr = getManagerById(db2, managerId);
    if (!mgr) throw Object.assign(new Error("nf"), { userMessage: "المدير غير موجود" });
    const evaluations = db2.prepare(`
      SELECT e.id, e.status, e.final_score, e.updated_at, e.approved_at,
             ay.label AS yearLabel, ep.name AS periodName
      FROM evaluations e
      JOIN academic_years ay ON ay.id = e.academic_year_id
      JOIN evaluation_periods ep ON ep.id = e.period_id
      WHERE e.manager_id = ?
      ORDER BY ay.label DESC, ep.name
    `).all(managerId);
    const plans = listPlans(db2, { managerId, includeArchived: false });
    const org = getOrgSettings(db2);
    const fonts = await getFontDataUris();
    const html = renderManagerReport({
      manager: mgr,
      evaluations,
      plans,
      orgName: org.orgName,
      orgSubtitle: org.orgSubtitle,
      appTitle: org.appTitle,
      preparedBy: org.preparedBy,
      ...fonts
    });
    const safe = (mgr.fullName || "manager").replace(/[\\/:*?"<>|]/g, "_");
    return savePdfWithDialog(html, `مدير-${safe}-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.pdf`.replace(/\s+/g, "-"));
  }));
  ipc.handle("reports:exportAllManagersPdf", wrap$7(async (_e, filters) => {
    const evaluations = buildAllManagersContext(db2, filters || {});
    const label = filterLabel(filters || {}, db2);
    const org = getOrgSettings(db2);
    const fonts = await getFontDataUris();
    const html = renderAllManagersReport({
      evaluations,
      filters: { ...filters || {}, label },
      orgName: org.orgName,
      orgSubtitle: org.orgSubtitle,
      appTitle: org.appTitle,
      preparedBy: org.preparedBy,
      ...fonts
    });
    return savePdfWithDialog(html, `نتائج-التقييمات-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.pdf`);
  }));
}
function wrap$6(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerBackupIpc(ipc, db2) {
  ipc.handle("backup:create", wrap$6(() => createManualBackupWithDialog(db2)));
  ipc.handle("backup:createAuto", wrap$6((_e, reason) => createAutoBackup(db2, reason || "manual-auto")));
  ipc.handle("backup:listAuto", wrap$6(() => listAutoBackups()));
  ipc.handle("backup:lastInfo", wrap$6(() => getLastBackupInfo(db2)));
  ipc.handle("backup:openFolder", wrap$6(() => openBackupsFolder()));
  ipc.handle("backup:pickFile", wrap$6(() => pickBackupFileToRestore()));
  ipc.handle("backup:inspect", wrap$6((_e, zipPath) => inspectBackupZip(zipPath)));
  ipc.handle("backup:restore", wrap$6((_e, zipPath) => restoreBackup(zipPath, { safetyBackup: true, db: db2 })));
  ipc.handle("backup:restartApp", () => {
    setImmediate(() => {
      try {
        electron.app.relaunch();
        electron.app.exit(0);
      } catch (e) {
        logger.error("Restart failed", e);
      }
    });
    return { ok: true, data: true };
  });
}
function userError(m) {
  const e = new Error(m);
  e.userMessage = m;
  return e;
}
function ensureAvatarColumn(db2) {
  try {
    db2.prepare("ALTER TABLE app_users ADD COLUMN avatar TEXT").run();
  } catch {
  }
}
function rowToUser(r) {
  if (!r) return null;
  let permissions = [];
  try {
    permissions = JSON.parse(r.permissions_json || "[]");
  } catch {
    permissions = [];
  }
  return {
    id: r.id,
    username: r.username,
    fullName: r.full_name,
    role: r.role,
    permissions,
    avatar: r.avatar || null,
    isActive: Boolean(r.is_active),
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}
function hasAnyUser(db2) {
  ensureAvatarColumn(db2);
  const row = db2.prepare("SELECT COUNT(*) AS c FROM app_users").get();
  return (row?.c || 0) > 0;
}
function createInitialAdmin(db2, { username, password, fullName, avatar }) {
  ensureAvatarColumn(db2);
  if (hasAnyUser(db2)) {
    throw userError("تم إعداد المسؤول الرئيسي مسبقاً.");
  }
  const u = (username || "").trim();
  const fn = (fullName || "").trim();
  if (!u) throw userError("اسم المستخدم مطلوب");
  if (!password || password.length < 4) throw userError("كلمة المرور يجب أن لا تقل عن 4 خانات");
  if (!fn) throw userError("الاسم الكامل مطلوب");
  const hash = hashPassword(password);
  const permissionsJson = JSON.stringify(ALL_PERMISSIONS);
  let id;
  db2.transaction(() => {
    const res = db2.prepare(`
      INSERT INTO app_users (username, password_hash, full_name, role, permissions_json, avatar, is_active)
      VALUES (?, ?, ?, 'admin', ?, ?, 1)
    `).run(u, hash, fn, permissionsJson, avatar || null);
    id = res.lastInsertRowid;
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("auth.setup_admin", "user", id, JSON.stringify({ username: u, fullName: fn }));
  })();
  return getUser(db2, id);
}
function authenticate(db2, { username, password }) {
  ensureAvatarColumn(db2);
  const u = (username || "").trim();
  if (!u || !password) throw userError("يرجى إدخال اسم المستخدم وكلمة المرور");
  const row = db2.prepare("SELECT * FROM app_users WHERE username = ? COLLATE NOCASE").get(u);
  if (!row) throw userError("بيانات الدخول غير صحيحة");
  if (!row.is_active) throw userError("هذا الحساب موقوف حالياً. يرجى مراجعة المسؤول.");
  const ok = verifyPassword(password, row.password_hash);
  if (!ok) throw userError("بيانات الدخول غير صحيحة");
  db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("auth.login_success", "user", row.id, JSON.stringify({ username: row.username }));
  return rowToUser(row);
}
function listUsers(db2) {
  ensureAvatarColumn(db2);
  return db2.prepare("SELECT id, username, full_name, role, permissions_json, avatar, is_active, created_at, updated_at FROM app_users ORDER BY id ASC").all().map(rowToUser);
}
function getUser(db2, id) {
  ensureAvatarColumn(db2);
  const row = db2.prepare("SELECT id, username, full_name, role, permissions_json, avatar, is_active, created_at, updated_at FROM app_users WHERE id = ?").get(id);
  return rowToUser(row);
}
function createUser(db2, { username, password, fullName, role, permissions, avatar }, executor = {}) {
  ensureAvatarColumn(db2);
  const u = (username || "").trim();
  const fn = (fullName || "").trim();
  if (!u) throw userError("اسم المستخدم مطلوب");
  if (!password || password.length < 4) throw userError("كلمة المرور يجب أن لا تقل عن 4 خانات");
  if (!fn) throw userError("الاسم الكامل مطلوب");
  const dup = db2.prepare("SELECT id FROM app_users WHERE username = ? COLLATE NOCASE").get(u);
  if (dup) throw userError("اسم المستخدم مستخدم بالفعل");
  let perms = Array.isArray(permissions) ? permissions : [];
  const validRole = role && PRESET_ROLES[role] ? role : "custom";
  if (validRole === "admin") {
    perms = [...ALL_PERMISSIONS];
  }
  const hash = hashPassword(password);
  const permissionsJson = JSON.stringify(perms);
  let id;
  db2.transaction(() => {
    const res = db2.prepare(`
      INSERT INTO app_users (username, password_hash, full_name, role, permissions_json, avatar, is_active)
      VALUES (?, ?, ?, ?, ?, ?, 1)
    `).run(u, hash, fn, validRole, permissionsJson, avatar || null);
    id = res.lastInsertRowid;
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("user.create", "user", id, JSON.stringify({ username: u, fullName: fn, role: validRole, executor: executor.username || "admin" }));
  })();
  return getUser(db2, id);
}
function updateUser(db2, id, { username, fullName, role, permissions, avatar, isActive }, executor = {}) {
  ensureAvatarColumn(db2);
  const target = db2.prepare("SELECT * FROM app_users WHERE id = ?").get(id);
  if (!target) throw userError("المستخدم غير موجود");
  const u = (username || "").trim() || target.username;
  if (u !== target.username) {
    const dup = db2.prepare("SELECT id FROM app_users WHERE username = ? COLLATE NOCASE AND id != ?").get(u, id);
    if (dup) throw userError("اسم المستخدم مستخدم بالفعل");
  }
  const fn = (fullName || "").trim() || target.full_name;
  const activeVal = isActive === void 0 ? target.is_active : isActive ? 1 : 0;
  const finalAvatar = avatar !== void 0 ? avatar || null : target.avatar;
  const activeAdmins = db2.prepare("SELECT id FROM app_users WHERE role = 'admin' AND is_active = 1").all();
  const isTargetActiveAdmin = target.role === "admin" && target.is_active === 1;
  if (isTargetActiveAdmin && activeAdmins.length <= 1) {
    if (activeVal === 0) {
      throw userError("لا يمكن إيقاف آخر مسؤول نشط في النظام");
    }
    if (role && role !== "admin") {
      throw userError("لا يمكن تغيير دور آخر مسؤول نشط في النظام");
    }
  }
  let finalRole = role || target.role;
  let finalPerms = permissions;
  if (finalRole === "admin") {
    finalPerms = [...ALL_PERMISSIONS];
  } else if (!finalPerms) {
    try {
      finalPerms = JSON.parse(target.permissions_json);
    } catch {
      finalPerms = [];
    }
  }
  db2.transaction(() => {
    db2.prepare(`
      UPDATE app_users
      SET username = ?, full_name = ?, role = ?, permissions_json = ?, avatar = ?, is_active = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(u, fn, finalRole, JSON.stringify(finalPerms), finalAvatar, activeVal, id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("user.update", "user", id, JSON.stringify({ id, username: u, fullName: fn, role: finalRole, isActive: activeVal, executor: executor.username || "admin" }));
  })();
  return getUser(db2, id);
}
function changePassword(db2, id, newPassword, executor = {}) {
  if (!newPassword || newPassword.length < 4) {
    throw userError("كلمة المرور الجديدة يجب أن لا تقل عن 4 خانات");
  }
  const target = db2.prepare("SELECT id, username FROM app_users WHERE id = ?").get(id);
  if (!target) throw userError("المستخدم غير موجود");
  const hash = hashPassword(newPassword);
  db2.transaction(() => {
    db2.prepare("UPDATE app_users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").run(hash, id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("user.change_password", "user", id, JSON.stringify({ username: target.username, executor: executor.username || "self" }));
  })();
  return true;
}
function deleteUser(db2, id, executor = {}) {
  const target = db2.prepare("SELECT * FROM app_users WHERE id = ?").get(id);
  if (!target) throw userError("المستخدم غير موجود");
  const totalUsers = db2.prepare("SELECT COUNT(*) AS c FROM app_users").get().c;
  if (totalUsers <= 1) {
    throw userError("لا يمكن حذف المستخدم الوحيد في النظام");
  }
  if (target.role === "admin") {
    const adminCount = db2.prepare("SELECT COUNT(*) AS c FROM app_users WHERE role = 'admin'").get().c;
    if (adminCount <= 1) {
      throw userError("لا يمكن حذف آخر مسؤول (Admin) في النظام");
    }
  }
  db2.transaction(() => {
    db2.prepare("DELETE FROM app_users WHERE id = ?").run(id);
    db2.prepare("INSERT INTO audit_log (action, entity_type, entity_id, details) VALUES (?, ?, ?, ?)").run("user.delete", "user", id, JSON.stringify({ username: target.username, executor: executor.username || "admin" }));
  })();
  return true;
}
let currentSessionUser = null;
function wrap$5(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error("auth ipc error", e);
      return { ok: false, error: e.userMessage || e.message || "تعذر تنفيذ العملية" };
    }
  };
}
function registerAuthIpc(ipc, db2) {
  ipc.handle("auth:status", wrap$5(() => {
    try {
      const hasUsers = hasAnyUser(db2);
      if (currentSessionUser) {
        const fresh = getUser(db2, currentSessionUser.id);
        if (fresh && fresh.isActive) {
          currentSessionUser = fresh;
        } else if (fresh && !fresh.isActive) {
          currentSessionUser = null;
        }
      } else {
        try {
          const rem = db2.prepare("SELECT value FROM app_settings WHERE key = 'auth_remembered_user_id'").get();
          if (rem?.value) {
            const fresh = getUser(db2, Number(rem.value));
            if (fresh && fresh.isActive) {
              currentSessionUser = fresh;
            }
          }
        } catch (e) {
          logger.warn("Failed to restore remembered user session", e.message);
        }
      }
      return {
        hasUsers,
        currentUser: currentSessionUser,
        allPermissions: ALL_PERMISSIONS,
        presetRoles: PRESET_ROLES
      };
    } catch (e) {
      logger.warn("auth:status - app_users table may not exist yet", e.message);
      return {
        hasUsers: false,
        currentUser: null,
        allPermissions: ALL_PERMISSIONS,
        presetRoles: PRESET_ROLES
      };
    }
  }));
  ipc.handle("auth:setupAdmin", wrap$5((_, data) => {
    const user = createInitialAdmin(db2, data);
    currentSessionUser = user;
    try {
      db2.prepare("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('auth_remembered_user_id', ?)").run(String(user.id));
    } catch (e) {
      logger.warn("Failed to save initial admin rememberMe session", e);
    }
    return user;
  }));
  ipc.handle("auth:login", wrap$5((_, creds) => {
    const user = authenticate(db2, creds);
    currentSessionUser = user;
    if (creds?.rememberMe !== false) {
      try {
        db2.prepare("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('auth_remembered_user_id', ?)").run(String(user.id));
      } catch (e) {
        logger.warn("Failed to save rememberMe session", e);
      }
    } else {
      try {
        db2.prepare("DELETE FROM app_settings WHERE key = 'auth_remembered_user_id'").run();
      } catch (e) {
        logger.warn("Failed to remove rememberMe session", e);
      }
    }
    return user;
  }));
  ipc.handle("auth:logout", wrap$5(() => {
    currentSessionUser = null;
    try {
      db2.prepare("DELETE FROM app_settings WHERE key = 'auth_remembered_user_id'").run();
    } catch (e) {
      logger.warn("Failed to delete remembered user session on logout", e);
    }
    return true;
  }));
  ipc.handle("auth:currentUser", wrap$5(() => {
    if (!currentSessionUser) return null;
    const fresh = getUser(db2, currentSessionUser.id);
    if (!fresh || !fresh.isActive) {
      currentSessionUser = null;
      return null;
    }
    currentSessionUser = fresh;
    return fresh;
  }));
  ipc.handle("auth:changeMyPassword", wrap$5((_, { newPassword }) => {
    if (!currentSessionUser) throw new Error("يجب تسجيل الدخول أولاً");
    return changePassword(db2, currentSessionUser.id, newPassword, currentSessionUser);
  }));
  ipc.handle("users:list", wrap$5(() => {
    return listUsers(db2);
  }));
  ipc.handle("users:create", wrap$5((_, data) => {
    if (currentSessionUser && currentSessionUser.role !== "admin" && !currentSessionUser.permissions?.includes("manage_users")) {
      throw new Error("ليس لديك صلاحية إضافة مستخدمين");
    }
    return createUser(db2, data, currentSessionUser || {});
  }));
  ipc.handle("users:update", wrap$5((_, { id, data }) => {
    if (currentSessionUser && currentSessionUser.role !== "admin" && !currentSessionUser.permissions?.includes("manage_users")) {
      throw new Error("ليس لديك صلاحية تعديل المستخدمين");
    }
    const updated = updateUser(db2, id, data, currentSessionUser || {});
    if (currentSessionUser && currentSessionUser.id === id) {
      currentSessionUser = updated;
    }
    return updated;
  }));
  ipc.handle("users:changePassword", wrap$5((_, { id, newPassword }) => {
    if (currentSessionUser && currentSessionUser.role !== "admin" && !currentSessionUser.permissions?.includes("manage_users")) {
      throw new Error("ليس لديك صلاحية تغيير كلمة مرور المستخدمين");
    }
    return changePassword(db2, id, newPassword, currentSessionUser || {});
  }));
  ipc.handle("users:delete", wrap$5((_, id) => {
    if (currentSessionUser && currentSessionUser.role !== "admin" && !currentSessionUser.permissions?.includes("manage_users")) {
      throw new Error("ليس لديك صلاحية حذف المستخدمين");
    }
    return deleteUser(db2, id, currentSessionUser || {});
  }));
}
function deltaLabel(delta) {
  if (delta > 0) return { sign: "+", dir: "up", symbol: "⬆", className: "text-emerald-600 dark:text-emerald-400 font-bold" };
  if (delta < 0) return { sign: "", dir: "down", symbol: "⬇", className: "text-red-600 dark:text-red-400 font-bold" };
  return { sign: "", dir: "same", symbol: "➖", className: "text-slate-400 font-medium" };
}
function compareTwoEvaluations(db2, evalAId, evalBId) {
  const evA = db2.prepare(`
    SELECT e.*, m.full_name AS manager_name, ay.label AS year_label, ep.name AS period_name, ep.period_type
    FROM evaluations e
    JOIN managers m ON m.id = e.manager_id
    JOIN academic_years ay ON ay.id = e.academic_year_id
    JOIN evaluation_periods ep ON ep.id = e.period_id
    WHERE e.id = ?
  `).get(evalAId);
  const evB = db2.prepare(`
    SELECT e.*, m.full_name AS manager_name, ay.label AS year_label, ep.name AS period_name, ep.period_type
    FROM evaluations e
    JOIN managers m ON m.id = e.manager_id
    JOIN academic_years ay ON ay.id = e.academic_year_id
    JOIN evaluation_periods ep ON ep.id = e.period_id
    WHERE e.id = ?
  `).get(evalBId);
  if (!evA || !evB) {
    throw new Error("أحد التقييمين غير موجود أو تم حذفه");
  }
  const itemsA = db2.prepare(`
    SELECT element_number, name, weight_bp, score_value, level_label
    FROM evaluation_item_snapshots WHERE evaluation_id = ?
    ORDER BY element_number ASC
  `).all(evalAId);
  const itemsB = db2.prepare(`
    SELECT element_number, name, weight_bp, score_value, level_label
    FROM evaluation_item_snapshots WHERE evaluation_id = ?
    ORDER BY element_number ASC
  `).all(evalBId);
  const bMap = /* @__PURE__ */ new Map();
  for (const it of itemsB) {
    bMap.set(it.element_number, it);
  }
  let improvedCount = 0;
  let declinedCount = 0;
  let sameCount = 0;
  const itemsComparison = itemsA.map((itA) => {
    const itB = bMap.get(itA.element_number) || {};
    const scoreA = itA.score_value ?? 0;
    const scoreB = itB.score_value ?? 0;
    const diff = Number((scoreB - scoreA).toFixed(2));
    if (diff > 0) improvedCount++;
    else if (diff < 0) declinedCount++;
    else sameCount++;
    const indicator = deltaLabel(diff);
    return {
      elementNumber: itA.element_number,
      name: itA.name,
      weightBp: itA.weight_bp,
      weightPct: Number((itA.weight_bp / 100).toFixed(2)),
      scoreA,
      scoreB,
      diff,
      diffFormatted: `${indicator.sign}${diff.toFixed(2)}`,
      symbol: indicator.symbol,
      dir: indicator.dir,
      className: indicator.className,
      levelLabelA: itA.level_label || "—",
      levelLabelB: itB.level_label || "—"
    };
  });
  const scoreDiff = Number(((evB.final_score ?? 0) - (evA.final_score ?? 0)).toFixed(2));
  const scoreIndicator = deltaLabel(scoreDiff);
  return {
    evalA: {
      id: evA.id,
      managerName: evA.manager_name,
      yearLabel: evA.year_label,
      periodName: evA.period_name,
      finalScore: evA.final_score,
      generalRating: evA.general_rating,
      approvedAt: evA.approved_at || evA.updated_at
    },
    evalB: {
      id: evB.id,
      managerName: evB.manager_name,
      yearLabel: evB.year_label,
      periodName: evB.period_name,
      finalScore: evB.final_score,
      generalRating: evB.general_rating,
      approvedAt: evB.approved_at || evB.updated_at
    },
    scoreDiff,
    scoreDiffFormatted: `${scoreIndicator.sign}${scoreDiff.toFixed(2)}`,
    symbol: scoreIndicator.symbol,
    dir: scoreIndicator.dir,
    summary: {
      improvedCount,
      declinedCount,
      sameCount,
      totalCount: itemsComparison.length
    },
    items: itemsComparison
  };
}
function compareMidyearFinal(db2, managerId, academicYearId) {
  const evals = db2.prepare(`
    SELECT e.id, ep.period_type
    FROM evaluations e
    JOIN evaluation_periods ep ON ep.id = e.period_id
    WHERE e.manager_id = ? AND e.academic_year_id = ? AND e.status = 'approved'
  `).all(managerId, academicYearId);
  const midyear = evals.find((e) => e.period_type === "MIDYEAR");
  const finalEval = evals.find((e) => e.period_type === "FINAL");
  if (!midyear || !finalEval) {
    throw new Error("لا يوجد تقييم نصفي ونهائي معتمدان معاً لهذا المدير في هذه السنة للمقارنة بينهما");
  }
  return compareTwoEvaluations(db2, midyear.id, finalEval.id);
}
function getManagerTimeline(db2, managerId) {
  const evals = db2.prepare(`
    SELECT e.id, e.final_score, e.general_rating, e.status, e.approved_at, e.updated_at,
           ay.label AS year_label, ep.name AS period_name, ep.period_type
    FROM evaluations e
    JOIN academic_years ay ON ay.id = e.academic_year_id
    JOIN evaluation_periods ep ON ep.id = e.period_id
    WHERE e.manager_id = ? AND e.status = 'approved'
    ORDER BY e.created_at ASC
  `).all(managerId);
  return evals.map((ev, idx) => {
    let diff = null;
    let symbol = "➖";
    if (idx > 0) {
      const prev = evals[idx - 1];
      diff = Number(((ev.final_score ?? 0) - (prev.final_score ?? 0)).toFixed(2));
      const ind = deltaLabel(diff);
      symbol = ind.symbol;
    }
    return {
      ...ev,
      diff,
      symbol
    };
  });
}
function compareGroups(db2, { yearAId, yearBId, stageId, administrationId }) {
  const paramsA = [yearAId];
  let whereA = 'WHERE e.academic_year_id = ? AND e.status = "approved"';
  if (stageId) {
    whereA += " AND s.stage_id = ?";
    paramsA.push(stageId);
  }
  if (administrationId) {
    whereA += " AND s.administration_id = ?";
    paramsA.push(administrationId);
  }
  const queryA = `
    SELECT AVG(e.final_score) as avgScore, COUNT(e.id) as count
    FROM evaluations e
    JOIN managers m ON m.id = e.manager_id
    JOIN schools s ON s.id = m.school_id
    ${whereA}
  `;
  const resA = db2.prepare(queryA).get(...paramsA);
  const paramsB = [yearBId];
  let whereB = 'WHERE e.academic_year_id = ? AND e.status = "approved"';
  if (stageId) {
    whereB += " AND s.stage_id = ?";
    paramsB.push(stageId);
  }
  if (administrationId) {
    whereB += " AND s.administration_id = ?";
    paramsB.push(administrationId);
  }
  const queryB = `
    SELECT AVG(e.final_score) as avgScore, COUNT(e.id) as count
    FROM evaluations e
    JOIN managers m ON m.id = e.manager_id
    JOIN schools s ON s.id = m.school_id
    ${whereB}
  `;
  const resB = db2.prepare(queryB).get(...paramsB);
  const avgA = Number((resA?.avgScore || 0).toFixed(2));
  const avgB = Number((resB?.avgScore || 0).toFixed(2));
  const diff = Number((avgB - avgA).toFixed(2));
  const ind = deltaLabel(diff);
  return {
    yearA: { id: yearAId, avgScore: avgA, count: resA?.count || 0 },
    yearB: { id: yearBId, avgScore: avgB, count: resB?.count || 0 },
    diff,
    symbol: ind.symbol,
    dir: ind.dir
  };
}
function wrap$4(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.message || "تعذر تنفيذ المقارنة" };
    }
  };
}
function registerComparisonsIpc(ipc, db2) {
  ipc.handle("comparisons:compareTwo", wrap$4((_e, evalAId, evalBId) => {
    return compareTwoEvaluations(db2, evalAId, evalBId);
  }));
  ipc.handle("comparisons:compareMidyearFinal", wrap$4((_e, managerId, academicYearId) => {
    return compareMidyearFinal(db2, managerId, academicYearId);
  }));
  ipc.handle("comparisons:managerTimeline", wrap$4((_e, managerId) => {
    return getManagerTimeline(db2, managerId);
  }));
  ipc.handle("comparisons:compareGroups", wrap$4((_e, params) => {
    return compareGroups(db2, params || {});
  }));
}
function wrap$3(fn) {
  return async (...args) => {
    try {
      const data = await fn(...args);
      return { ok: true, data };
    } catch (e) {
      console.error("[Notifications IPC Error]", e);
      return { ok: false, error: e.message || "فشل تنفيذ عملية الإشعارات" };
    }
  };
}
function registerNotificationsIpc(ipc, db2) {
  ipc.handle("notifications:list", wrap$3(() => {
    return listNotifications(db2);
  }));
  ipc.handle("notifications:unreadCount", wrap$3(() => {
    return countUnreadNotifications(db2);
  }));
  ipc.handle("notifications:markAllRead", wrap$3(() => {
    return markAllNotificationsRead(db2);
  }));
  ipc.handle("notifications:markRead", wrap$3((_event, id) => {
    return markReadNotification(db2, id);
  }));
  ipc.handle("notifications:delete", wrap$3((_event, id) => {
    return deleteNotification(db2, id);
  }));
  ipc.handle("notifications:clearAll", wrap$3(() => {
    return clearAllNotifications(db2);
  }));
  ipc.handle("notifications:create", wrap$3((_event, payload) => {
    return addNotification(db2, payload);
  }));
}
function wrap$2(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerContextIpc(ipc, db2) {
  ipc.handle("context:get", wrap$2(() => getActiveContext(db2)));
  ipc.handle("context:set", wrap$2(async (_e, payload) => {
    const nextCtx = setActiveContext(db2, payload || {});
    pushActiveContextToCloud(db2).catch(() => {
    });
    return nextCtx;
  }));
}
function wrap$1(fn) {
  return async (...args) => {
    try {
      return { ok: true, data: await fn(...args) };
    } catch (e) {
      logger.error(e);
      return { ok: false, error: e.userMessage || "تعذر تنفيذ العملية" };
    }
  };
}
function registerAlertsIpc(ipc, db2) {
  ipc.handle("alerts:list", wrap$1((_e, filters) => listManagerAlerts(db2, filters || {})));
  ipc.handle("alerts:create", wrap$1(async (_e, data) => {
    const created = createManagerAlert(db2, data || {});
    if (created?.id) {
      await pushManagerAlertToCloud(db2, created.id).catch(() => {
      });
    }
    return created;
  }));
  ipc.handle("alerts:delete", wrap$1(async (_e, id) => {
    const res = deleteManagerAlert(db2, id);
    if (res?.portalId) {
      await deleteManagerAlertFromCloud(res.portalId).catch(() => {
      });
    }
    return res;
  }));
}
function wrap(fn) {
  return async (_event, ...args) => {
    try {
      const data = await fn(...args);
      return { ok: true, data };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  };
}
function registerCloudIpc(ipc, db2, app) {
  ipc.handle("cloud:sync", wrap((options) => syncWithCloud(db2, options)));
  ipc.handle("cloud:purgeAttachments", wrap(() => purgeCloudAttachments(db2)));
  ipc.handle("cloud:purgeAllData", wrap(() => purgeAllCloudData()));
  ipc.handle("cloud:listSupervisors", wrap(() => listWebSupervisors()));
  ipc.handle("cloud:addSupervisor", wrap((d) => addWebSupervisor(d)));
  ipc.handle("cloud:updateSupervisor", wrap(({ id, data }) => updateWebSupervisor(id, data)));
  ipc.handle("cloud:deleteSupervisor", wrap((id) => deleteWebSupervisor(id)));
  ipc.handle("cloud:checkUpdate", wrap(() => checkSystemUpdate(app.getVersion())));
  ipc.handle("cloud:openUrl", wrap((url) => {
    if (url) electron.shell.openExternal(url);
    return true;
  }));
  ipc.handle("updater:pickAndApplyPatch", wrap(async () => {
    const res = await electron.dialog.showOpenDialog({
      title: "اختر ملف ترقية النظام (.zip)",
      filters: [{ name: "ملفات ترقية النظام", extensions: ["zip", "pkg"] }],
      properties: ["openFile"]
    });
    if (res.canceled || !res.filePaths.length) return { applied: false, cancelled: true };
    const patchPath = res.filePaths[0];
    try {
      const zip = new AdmZip(patchPath);
      const zipEntries = zip.getEntries();
      if (!zipEntries.length) throw new Error("ملف الترقية فارغ أو غير صالح");
      const appRoot = app.getAppPath();
      zip.extractAllTo(appRoot, true);
      return { applied: true, filePath: patchPath, message: "تم تثبيت ملف الترقية بنجاح. يرجى إعادة تشغيل البرنامج لتطبيق التعديلات." };
    } catch (err) {
      throw new Error("فشل تطبيق ملف الترقية: " + err.message);
    }
  }));
}
function registerAllIpc(ipc, db2, app) {
  registerAuthIpc(ipc, db2);
  registerComparisonsIpc(ipc, db2);
  registerManagersIpc(ipc, db2);
  registerSettingsIpc(ipc, db2);
  registerDashboardIpc(ipc, db2);
  registerYearsIpc(ipc, db2);
  registerPeriodsIpc(ipc, db2);
  registerSchoolsIpc(ipc, db2);
  registerFormsIpc(ipc, db2);
  registerEvaluationsIpc(ipc, db2);
  registerEvidencesIpc(ipc, db2);
  registerPlansIpc(ipc, db2);
  registerReportsIpc(ipc, db2);
  registerBackupIpc(ipc, db2);
  registerNotificationsIpc(ipc, db2);
  registerContextIpc(ipc, db2);
  registerAlertsIpc(ipc, db2);
  registerCloudIpc(ipc, db2, app);
  ipc.handle("sync:cloudSync", (_event, options) => syncWithCloud(db2, options));
  ipc.handle("app:version", () => app.getVersion());
  ipc.handle("app:dataPath", () => app.getPath("userData"));
}
function createMainWindow() {
  const win = new electron.BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1024,
    minHeight: 700,
    show: false,
    title: "تقييم مدراء المدارس",
    backgroundColor: "#0f172a",
    webPreferences: {
      preload: node_path.join(__dirname, "../preload/index.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  win.once("ready-to-show", () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("http://") || url.startsWith("https://")) electron.shell.openExternal(url);
    return { action: "deny" };
  });
  return win;
}
setupLogger();
console.log("CHECKPOINT 1: Main process started");
let mainWindow = null;
const gotLock = electron.app.requestSingleInstanceLock();
if (!gotLock) {
  electron.app.quit();
} else {
  electron.app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}
electron.app.whenReady().then(async () => {
  console.log("CHECKPOINT 2: Electron ready");
  if (!gotLock) {
    console.log("CHECKPOINT: Single instance lock failed");
    return;
  }
  let db2 = null;
  try {
    console.log("CHECKPOINT 3: Before database");
    db2 = getDb();
    console.log("CHECKPOINT 4: Database opened");
    await runMigrations(db2, {
      beforePendingMigrations: async ({ fromVersion, toVersion }) => {
        const managerCount = db2.prepare("SELECT COUNT(*) c FROM managers").get().c;
        if (managerCount === 0) {
          logger.info(`Skipping pre-migration backup (empty database)`);
          return;
        }
        logger.info(`Pre-migration backup: v${fromVersion} → v${toVersion}`);
        await createAutoBackup(db2, `pre-migration-v${toVersion}`);
      }
    });
    await migrateLegacyEmbeddedPlanFiles(db2);
    registerAllIpc(electron.ipcMain, db2, electron.app);
    cleanStaging().catch(() => {
    });
    const triggerSilentSync = () => {
      try {
        const d = getDb();
        if (d) syncWithCloud(d).catch(() => {
        });
      } catch {
      }
    };
    setTimeout(triggerSilentSync, 800);
    setInterval(triggerSilentSync, 8e3);
    logger.info("App ready");
  } catch (e) {
    logger.error("Failed to initialize database", e);
    electron.dialog.showErrorBox(
      "تعذر تشغيل قاعدة البيانات",
      `${e && e.message ? e.message : e}

سيُغلق التطبيق. راجع ملف السجل داخل مجلد logs في بيانات التطبيق.`
    );
    electron.app.quit();
    return;
  }
  mainWindow = createMainWindow();
  mainWindow.on("focus", () => {
    try {
      const d = getDb();
      if (d) syncWithCloud(d).catch(() => {
      });
    } catch {
    }
  });
  if (process.env.ELECTRON_RENDERER_URL) {
    mainWindow.loadURL(process.env.ELECTRON_RENDERER_URL);
  } else {
    mainWindow.loadFile(node_path.join(__dirname, "../renderer/index.html"));
  }
  electron.app.on("activate", () => {
    if (electron.BrowserWindow.getAllWindows().length === 0) {
      mainWindow = createMainWindow();
      if (process.env.ELECTRON_RENDERER_URL)
        mainWindow.loadURL(process.env.ELECTRON_RENDERER_URL);
      else
        mainWindow.loadFile(node_path.join(__dirname, "../renderer/index.html"));
    }
  });
});
electron.app.on("window-all-closed", () => {
  if (process.platform !== "darwin") electron.app.quit();
});
electron.app.on("before-quit", () => {
  closeDb();
});
