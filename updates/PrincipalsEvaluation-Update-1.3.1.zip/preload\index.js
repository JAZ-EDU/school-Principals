"use strict";
const electron = require("electron");
async function invoke(channel, ...args) {
  const res = await electron.ipcRenderer.invoke(channel, ...args);
  if (res && typeof res === "object" && "ok" in res) {
    if (res.ok) return res.data;
    throw new Error(res.error || "تعذر تنفيذ العملية");
  }
  return res;
}
const api = {
  managers: {
    list: (f) => invoke("managers:list", f),
    get: (id) => invoke("managers:get", id),
    create: (d) => invoke("managers:create", d),
    update: (id, d) => invoke("managers:update", id, d),
    archive: (id) => invoke("managers:archive", id),
    restore: (id) => invoke("managers:restore", id),
    delete: (id) => invoke("managers:delete", id),
    seedSamples: () => invoke("managers:seedSamples"),
    deleteSamples: () => invoke("managers:deleteSamples")
  },
  settings: {
    getAll: () => invoke("settings:getAll"),
    set: (k, v) => invoke("settings:set", k, v),
    dbInfo: () => invoke("settings:dbInfo"),
    pickFolder: () => invoke("settings:pickFolder"),
    clearAllManagersData: () => invoke("settings:clearAllManagersData"),
    factoryReset: () => invoke("settings:factoryReset")
  },
  years: {
    list: () => invoke("years:list"),
    create: (l) => invoke("years:create", l),
    activate: (id) => invoke("years:activate", id),
    archive: (id) => invoke("years:archive", id),
    restore: (id) => invoke("years:restore", id),
    delete: (id) => invoke("years:delete", id)
  },
  periods: {
    list: (o) => invoke("periods:list", o),
    create: (d) => invoke("periods:create", d),
    update: (id, d) => invoke("periods:update", id, d),
    delete: (id) => invoke("periods:delete", id),
    toggleActive: (id, a) => invoke("periods:toggleActive", id, a)
  },
  schools: {
    listAdministrations: () => invoke("schools:listAdministrations"),
    createAdministration: (n) => invoke("schools:createAdministration", n),
    updateAdministration: (id, n) => invoke("schools:updateAdministration", id, n),
    archiveAdministration: (id, a) => invoke("schools:archiveAdministration", id, a),
    deleteAdministration: (id) => invoke("schools:deleteAdministration", id),
    listStages: () => invoke("schools:listStages"),
    createStage: (n) => invoke("schools:createStage", n),
    updateStage: (id, n) => invoke("schools:updateStage", id, n),
    archiveStage: (id, a) => invoke("schools:archiveStage", id, a),
    deleteStage: (id) => invoke("schools:deleteStage", id),
    list: (o) => invoke("schools:list", o),
    listSchools: (o) => invoke("schools:list", o),
    create: (d) => invoke("schools:create", d),
    update: (id, d) => invoke("schools:update", id, d),
    archive: (id, a) => invoke("schools:archive", id, a),
    delete: (id) => invoke("schools:delete", id)
  },
  forms: {
    list: () => invoke("forms:list"),
    create: (d) => invoke("forms:create", d),
    delete: (id) => invoke("forms:delete", id),
    listVersions: (formId) => invoke("forms:listVersions", formId),
    getVersion: (id) => invoke("forms:getVersion", id),
    createVersion: (d) => invoke("forms:createVersion", d),
    deleteVersion: (id) => invoke("forms:deleteVersion", id),
    updateVersionSettings: (id, d) => invoke("forms:updateVersionSettings", id, d),
    activateVersion: (id) => invoke("forms:activateVersion", id),
    archiveVersion: (id) => invoke("forms:archiveVersion", id),
    unarchiveVersion: (id, targetStatus) => invoke("forms:unarchiveVersion", id, targetStatus),
    checkReadiness: (id) => invoke("forms:checkReadiness", id)
  },
  formElements: {
    list: (v) => invoke("formElements:list", v),
    add: (v, d) => invoke("formElements:add", v, d),
    update: (id, d) => invoke("formElements:update", id, d),
    delete: (id) => invoke("formElements:delete", id),
    replaceAll: (v, els) => invoke("formElements:replaceAll", v, els),
    pickAndParse: () => invoke("formElements:pickAndParse"),
    saveTemplate: () => invoke("formElements:saveTemplate")
  },
  formLevels: {
    list: (v) => invoke("formLevels:list", v),
    update: (id, d) => invoke("formLevels:update", id, d)
  },
  evaluations: {
    listByManager: (id) => invoke("evaluations:listByManager", id),
    listAll: (f) => invoke("evaluations:listAll", f),
    get: (id) => invoke("evaluations:get", id),
    findForContext: (ctx) => invoke("evaluations:findForContext", ctx),
    createDraft: (d) => invoke("evaluations:createDraft", d),
    saveScores: (id, s, opts) => invoke("evaluations:saveScores", id, s, opts),
    preview: (id) => invoke("evaluations:preview", id),
    approve: (id, o) => invoke("evaluations:approve", id, o),
    correct: (id, d) => invoke("evaluations:correct", id, d),
    deleteDraft: (id) => invoke("evaluations:deleteDraft", id),
    deleteApproved: (id, d) => invoke("evaluations:deleteApproved", id, d)
  },
  evidences: {
    list: (f) => invoke("evidences:list", f),
    get: (id) => invoke("evidences:get", id),
    pickAndStage: () => invoke("evidences:pickAndStage"),
    pickAndStageMulti: () => invoke("evidences:pickAndStageMulti"),
    discardStaged: (stagingId, ext) => invoke("evidences:discardStaged", stagingId, ext),
    create: (input, staged) => invoke("evidences:create", input, staged),
    update: (id, input, staged) => invoke("evidences:update", id, input, staged),
    archive: (id) => invoke("evidences:archive", id),
    restore: (id) => invoke("evidences:restore", id),
    delete: (id) => invoke("evidences:delete", id),
    open: (id, fileIndex = 0) => invoke("evidences:open", id, fileIndex),
    countsByElement: (ctx) => invoke("evidences:countsByElement", ctx),
    addComment: (id, comment) => invoke("evidences:addComment", id, comment),
    deleteComment: (commentId) => invoke("evidences:deleteComment", commentId)
  },
  plans: {
    list: (f) => invoke("plans:list", f),
    get: (id) => invoke("plans:get", id),
    pickAndStageMulti: () => invoke("plans:pickAndStageMulti"),
    discardStaged: (stagingId, ext) => invoke("plans:discardStaged", stagingId, ext),
    create: (input, staged) => invoke("plans:create", input, staged),
    update: (id, input, staged) => invoke("plans:update", id, input, staged),
    setStatus: (id, s) => invoke("plans:setStatus", id, s),
    archive: (id) => invoke("plans:archive", id),
    restore: (id) => invoke("plans:restore", id),
    delete: (id) => invoke("plans:delete", id),
    openAttachment: (id, fileIndex = 0) => invoke("plans:openAttachment", id, fileIndex),
    addFollowUp: (planId, note) => invoke("plans:addFollowUp", planId, note),
    deleteFollowUp: (id) => invoke("plans:deleteFollowUp", id)
  },
  reports: {
    exportManagersExcel: () => invoke("reports:exportManagersExcel"),
    exportEvaluationsExcel: (f) => invoke("reports:exportEvaluationsExcel", f),
    exportEvaluationDetailsExcel: (id) => invoke("reports:exportEvaluationDetailsExcel", id),
    exportPlansExcel: (f) => invoke("reports:exportPlansExcel", f),
    exportEvaluationPdf: (id) => invoke("reports:exportEvaluationPdf", id),
    printEvaluation: (id) => invoke("reports:printEvaluation", id),
    exportManagerPdf: (id) => invoke("reports:exportManagerPdf", id),
    exportAllManagersPdf: (f) => invoke("reports:exportAllManagersPdf", f)
  },
  backup: {
    create: () => invoke("backup:create"),
    createAuto: (reason) => invoke("backup:createAuto", reason),
    listAuto: () => invoke("backup:listAuto"),
    lastInfo: () => invoke("backup:lastInfo"),
    openFolder: () => invoke("backup:openFolder"),
    pickFile: () => invoke("backup:pickFile"),
    inspect: (zipPath) => invoke("backup:inspect", zipPath),
    restore: (zipPath) => invoke("backup:restore", zipPath),
    restartApp: () => invoke("backup:restartApp")
  },
  dashboard: { stats: (f) => invoke("dashboard:stats", f) },
  context: {
    get: () => invoke("context:get"),
    set: (d) => invoke("context:set", d)
  },
  alerts: {
    list: (f) => invoke("alerts:list", f),
    create: (d) => invoke("alerts:create", d),
    delete: (id) => invoke("alerts:delete", id)
  },
  comparisons: {
    compareTwo: (evalAId, evalBId) => invoke("comparisons:compareTwo", evalAId, evalBId),
    compareMidyearFinal: (managerId, yearId) => invoke("comparisons:compareMidyearFinal", managerId, yearId),
    managerTimeline: (managerId) => invoke("comparisons:managerTimeline", managerId),
    compareGroups: (p) => invoke("comparisons:compareGroups", p)
  },
  auth: {
    status: () => invoke("auth:status"),
    setupAdmin: (d) => invoke("auth:setupAdmin", d),
    login: (c) => invoke("auth:login", c),
    logout: () => invoke("auth:logout"),
    currentUser: () => invoke("auth:currentUser"),
    changeMyPassword: (d) => invoke("auth:changeMyPassword", d)
  },
  users: {
    list: () => invoke("users:list"),
    create: (d) => invoke("users:create", d),
    update: (id, d) => invoke("users:update", { id, data: d }),
    changePassword: (id, newPassword) => invoke("users:changePassword", { id, newPassword }),
    delete: (id) => invoke("users:delete", id)
  },
  app: {
    version: () => invoke("app:version"),
    dataPath: () => invoke("app:dataPath")
  },
  sync: {
    cloudSync: (opts) => invoke("sync:cloudSync", opts)
  },
  cloud: {
    sync: (opts) => invoke("cloud:sync", opts),
    purgeAttachments: () => invoke("cloud:purgeAttachments"),
    purgeAllData: () => invoke("cloud:purgeAllData"),
    listSupervisors: () => invoke("cloud:listSupervisors"),
    addSupervisor: (d) => invoke("cloud:addSupervisor", d),
    updateSupervisor: (id, d) => invoke("cloud:updateSupervisor", { id, data: d }),
    deleteSupervisor: (id) => invoke("cloud:deleteSupervisor", id),
    checkUpdate: () => invoke("cloud:checkUpdate"),
    openUrl: (url) => invoke("cloud:openUrl", url),
    pickAndApplyPatch: () => invoke("updater:pickAndApplyPatch"),
    onDataChanged: (cb) => {
      const listener = (_e, val) => cb(val);
      electron.ipcRenderer.on("data:changed", listener);
      return () => electron.ipcRenderer.removeListener("data:changed", listener);
    }
  },
  notifications: {
    list: () => invoke("notifications:list"),
    unreadCount: () => invoke("notifications:unreadCount"),
    markAllRead: () => invoke("notifications:markAllRead"),
    markRead: (id) => invoke("notifications:markRead", id),
    delete: (id) => invoke("notifications:delete", id),
    clearAll: () => invoke("notifications:clearAll"),
    create: (payload) => invoke("notifications:create", payload)
  }
};
electron.contextBridge.exposeInMainWorld("api", api);
